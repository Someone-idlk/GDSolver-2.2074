#pragma once
#include "dp/frames.hpp"

namespace dp {

// `rot` is GD's own getRotation() for that tick (grouptrace's 8th column, added
// 2026-08-13). hw/hh are HALF the AXIS-ALIGNED BOUND, so for a turned object
// they are not the shape -- see Obj::oriented and the note on the portal test.
// Recordings made before the column existed load with rot = 0, i.e. exactly the
// old behaviour.
// `env`: the row is not the object's rect but the box GD's own random numbers can put it in
// (the MOD's areaenv.hpp, --groups' ninth column). The level loader turns such rows into a
// hazard twin of the object (see envTwinUid).
struct DynSample { int t; float cx, cy, hw, hh; uint8_t on; float rot = 0.f; uint8_t env = 0; };
// [2026-08-22 r104] Interpolate linearly between the recording's rows (always;
// --no-dyninterp is gone since the flag clean-up): restores smooth motion to
// moving geometry that grouptrace's 0.05px threshold turned into a staircase.
// (defined up here, before Dynamics, because applyTriggers reads g_autoTrig;
// the touch-trigger story lives with TouchTrig below)
// --movetarget: a Move in target mode and a Stop (1616) act on the
// touch chains' closed form. Without it both are inert there: a target-mode Move
// carries ox=oy=0, and a Stop's target group holds only triggers the walk skips.
// Measured on lv22 (2026-09-21, attempt 30 of a flags-on cold): touching a red
// block spawns group 540 = Stop uid18096 (halts group 543, the two Moves that
// lower the ceiling group 265 over 4.19 s) + Move uid18093 (target mode, y only,
// 0.5 s, ease 9) that takes the ceiling to a total of -122 px. GD's rect of the
// killing spike uid18105 at t=2,599 is 96 px down; the model had it 33 px down
// and never killed, so the loop fenced the spot off with deadbands.
// ON since 2026-09-21, its own unit; always on since the
// flag clean-up.
// Per touch box (the State::trig bit): the Move triggers a Stop in its chain
// halts. Filled with the boxes (buildTouchMoveTicks); read by applyTriggers.
inline std::vector<std::vector<int>> g_touchStops;

struct TrigCtl {          // one object a trigger ends up moving
    int uid;
    float dx, dy;         // total offset once the move has finished
    // How long the move takes, from the firing tick. NOT rounded: GD's duration
    // is in seconds and the physics step is 1/240 s, so the tick count is
    // dur*240 with its fraction. Rounding it cost 4.5 px on lv20's 240 px doors
    // (uid 17399, dur 0.435002 -> 104.4 ticks, rounded to 104).
    double durTicks;
    int ease;             // GD's EasingType, raw (see gdEase)
    double erate;         // its rate (period, for the elastic family)
    // lockToPlayerX anywhere in the chain, in TICKS (0 = not locked). While it
    // lasts the object's x is the player's x, offset by wherever both were when
    // it fired -- so it has a closed form too, just one that needs the SIM's own
    // player x rather than only the level data:
    //
    //     x(t) = base + (moves) + (playerX(min(t, t0+lockTicks)) - playerX(t0))
    //
    // Measured on lv20 (uid 13276 and its group, 2,400 samples): residual
    // 0.002 px, with t0 = the crossing tick itself. No +1 here -- a lock is a
    // per-tick copy of a position, not an eased move, so it has neither the
    // easing's slow start nor the recorder's threshold lag.
    //
    // This is the one class where a RECORDING is provably wrong for anyone
    // else: it followed the recorded run's player, so replaying it against a
    // plan that reaches the trigger at a different x is off by the whole
    // difference. lv20's structure at x=24,900 is exactly this.
    double lockTicks;
    // lockToPlayerY: counted and reported, never used. No level in the suite
    // has one, and guessing at a y lock would be the same mistake made twice.
    double lockYTicks;
    // --movetarget (note at the top of this file). `mover` is the Move trigger whose
    // hop set this entry's motion, so a Stop naming that Move can freeze it.
    // `tmode` marks a target-mode Move (0 = not one; 1 both axes, 2 x only,
    // 3 y only): (tdx, tdy) is where the group ends up relative to its
    // placement, and the offset it adds is decided when it fires (destination
    // minus where the group is by then).
    int mover = 0;
    uint8_t tmode = 0;
    float tdx = 0.f, tdy = 0.f;
};
// Touch boxes a re-anchor caught with their move ALREADY RUNNING (see the
// `init.trig` block at the --start handling). The "has it moved past half its
// offset" test there can only answer "open" or "shut"; an anchor dropped in the
// middle of the slide is neither, and answering "shut" puts the door back where
// it started for the whole tail.
//
// Measured on lv22 (2026-08-13): the wall that forms the FLOOR of the first
// rotated section (uids 1212/1213/1214/1221, one column of id 1 blocks at
// cx=2115) slides cy 345 -> 225 between t=1,697 and t=1,814. Every anchor the
// driver takes in that window -- t=1,730 is the one the loop settles on -- has
// it 20.4 px into its 120, i.e. 17%, so the bit stayed clear, the tail ran
// against the wall at REST, and the spider's tap in the rotated frame found no
// surface for 700 px and teleported to world x=1,459.5 where GD lands at
// 2,143.5. From the head the same plan is exact, which is what says the
// geometry was never the problem.
//
// For these boxes the recording IS the timeline (the live overlay comes from
// this plan's own replays), so the object is re-dated to its own first-motion
// row instead of to the state's trigT -- shift 0, phase preserved.
inline TouchMask g_recPhase{};
// GD's easing, which is cocos2d-x's CCEase* family reached through
// EffectGameObject::m_easingType / m_easingRate. In = t^rate and Out = t^(1/rate)
// are cocos's own convention, not a guess.
//
// Measured against grouptrace on the lv19 and lv20 bootstrap runs (655 objects
// over four families -- None, EaseInOut, ElasticOut, BounceOut): with this
// curve, the exact duration and the fire tick below, the closed form
//     pos(t) = base + offset * gdEase(type, rate, (t - fireT) / durTicks)
// reproduces every recorded sample to within **0.004 px**. See
// py/trigger_curve_fit.py, which is the harness that says so.
//
// The families with no such measurement yet (Exp / Sine / Back, and the In/Out
// halves of Elastic and Bounce) are cocos's formulas placed here unverified;
// they are still far closer than the 0.5-0.5cos(pi*u) stand-in they replace.
inline double gdEase(int kind, double rate, double u) {
    u = u < 0.0 ? 0.0 : (u > 1.0 ? 1.0 : u);
    const double p = (rate > 0.0) ? rate : 2.0;
    const double kPi = 3.14159265358979;
    auto bounceOut = [](double x) {
        if (x < 1.0 / 2.75) return 7.5625 * x * x;
        if (x < 2.0 / 2.75) { x -= 1.5 / 2.75;   return 7.5625 * x * x + 0.75; }
        if (x < 2.5 / 2.75) { x -= 2.25 / 2.75;  return 7.5625 * x * x + 0.9375; }
        x -= 2.625 / 2.75;
        return 7.5625 * x * x + 0.984375;
    };
    auto elasticOut = [&](double x, double period) {
        if (x <= 0.0 || x >= 1.0) return x;
        return std::pow(2.0, -10.0 * x)
             * std::sin((x - period / 4.0) * kPi * 2.0 / period) + 1.0;
    };
    auto elasticIn = [&](double x, double period) {
        if (x <= 0.0 || x >= 1.0) return x;
        const double y = x - 1.0;
        return -std::pow(2.0, 10.0 * y)
             * std::sin((y - period / 4.0) * kPi * 2.0 / period);
    };
    switch (kind) {
        case 0: return u;                                     // None (linear)
        case 1: {                                             // EaseInOut
            const double t = 2.0 * u;
            return t < 1.0 ? 0.5 * std::pow(t, p)
                           : 1.0 - 0.5 * std::pow(2.0 - t, p);
        }
        case 2: return std::pow(u, p);                        // EaseIn
        case 3: return std::pow(u, 1.0 / p);                  // EaseOut
        case 4: return u < 0.5 ? elasticIn(2.0 * u, p) * 0.5
                               : elasticOut(2.0 * u - 1.0, p) * 0.5 + 0.5;
        case 5: return elasticIn(u, p);
        case 6: return elasticOut(u, p);
        case 7: return u < 0.5 ? (1.0 - bounceOut(1.0 - 2.0 * u)) * 0.5
                               : bounceOut(2.0 * u - 1.0) * 0.5 + 0.5;
        case 8: return 1.0 - bounceOut(1.0 - u);
        case 9: return bounceOut(u);
        case 10: return u < 0.5
                     ? 0.5 * std::pow(2.0, 10.0 * (2.0 * u - 1.0))
                     : 0.5 * (2.0 - std::pow(2.0, -10.0 * (2.0 * u - 1.0)));
        // [2026-09-01] The two Exponential ENDPOINTS, read out of the binary
        // (getEasedValue, the 0.001f at rodata 3A83126F is real). Both were
        // wrong, in opposite directions, and both are permanent: an object
        // whose move ends on one of these curves stops in the wrong place and
        // stays there, so the hitbox is off for the rest of the level.
        //
        // ExpIn: GD subtracts 0.001 and therefore stops at 0.999 -- one tenth
        // of a percent SHORT of the offset it was given, forever. The model
        // reached 1.0, i.e. it overshot. cocos has no u==0 guard either (it
        // returns -0.0000234 there), so the guard goes too: match the binary,
        // not the tidier curve.
        case 11: return std::pow(2.0, 10.0 * (u - 1.0)) - 0.001;
        // ExpOut: GD special-cases t==1 to land exactly. Without it the curve
        // stops at 1 - 2^-10 = 0.9990234, 0.0977% short. Six moves in lv22 use
        // this, the largest 51 px, so the model was parking them ~0.05 px low.
        case 12: return u >= 1.0 ? 1.0 : 1.0 - std::pow(2.0, -10.0 * u);
        case 13: return -0.5 * (std::cos(kPi * u) - 1.0);
        case 14: return 1.0 - std::cos(u * kPi * 0.5);
        case 15: return std::sin(u * kPi * 0.5);
        case 16: {
            const double o = 1.70158 * 1.525;
            double x = 2.0 * u;
            if (x < 1.0) return 0.5 * (x * x * ((o + 1.0) * x - o));
            x -= 2.0;
            return 0.5 * (x * x * ((o + 1.0) * x + o) + 2.0);
        }
        case 17: { const double o = 1.70158; return u * u * ((o + 1.0) * u - o); }
        case 18: {
            const double o = 1.70158, x = u - 1.0;
            return x * x * ((o + 1.0) * x + o) + 1.0;
        }
        default: return u;
    }
}
// How many ticks after the move really starts does grouptrace FIRST write a row
// for it? The recorder drops changes under 0.05 px (grouptrace.hpp kEps), and an
// eased move spends its first ticks in the thousandths, so the recording's
// apparent first motion is 1-2 ticks late -- 1 for a linear move, 2 for
// EaseInOut. That lag is not an unknown: with the offset, the duration and the
// curve in hand it is computable, which is what this does. Everything
// downstream then works in TRUE first-motion ticks and the artefact cancels.
// See the ZoomTrig block for the measurements. Progress is mapped through x
// because the state cannot carry the crossing tick.
inline double camScaleAt(double x, double dx) {
    double cur = 1.0;
    if (dx <= 0.0) dx = 1.0;
    for (const auto& z : g_zoomTrigs) {
        if (z.cx > x) break;
        if (z.durTicks <= 0.0) { cur = z.target; continue; }
        const double u = (x - z.cx) / (dx * z.durTicks);
        cur = (u >= 1.0) ? z.target
                         : cur + (z.target - cur) * gdEase(z.ease, z.rate, u);
    }
    return cur;
}

inline int recordLag(double dx, double dy, double durTicks, int ease,
                     double erate) {
    // Nothing moves -- a toggle-only group. A boolean flip has no threshold to
    // climb, so its first row IS its first tick and there is no lag to remove.
    if (durTicks <= 0.0 || (std::fabs(dx) < 0.5 && std::fabs(dy) < 0.5))
        return 0;
    for (int n = 1; n <= 240; ++n) {
        const double e = gdEase(ease, erate, (double)n / durTicks);
        if (std::fabs(dx * e) >= 0.05 || std::fabs(dy * e) >= 0.05) return n;
    }
    return 1;
}
// Autonomous triggers: touch=0 / spawn=0 move rows. GD activates one when the
// PLAYER's x crosses the trigger's own x (EffectGameObject::spawnXPosition()
// returns getPosition().x for exactly this class), and the controlled group's
// first motion lands 2 ticks after the crossing -- measured live on lv19
// uid 15242 (crossing x=30,375 -> first motion t = crossing + 2; reaching it
// on SCREEN does not fire it).
//
// Unlike a touch trigger this is not a per-state fact: every worldline of a
// solve crosses a given x at (nearly) the same tick, so the firing tick is a
// LEVEL property. It is resolved once -- from the frontier's leading x during
// the search, from the single trajectory in --replay, or from the recording
// itself for triggers behind a re-anchor -- and stored in fireT. -1 = not
// crossed yet; controlled objects sit at their FIRST sample until then.
//
// Why this exists when grouptrace already records the motion: the recording
// plays on the RECORDED run's timeline. A bootstrap corpse crossed x=30,375
// at t=23,397 where the real run crosses at t=21,690 -- 1,707 ticks of wall
// phase error, and the DP planned around a wall that was not there (a whole
// session went to diagnosing it). Deriving the fire tick from the solve's own
// x removes the dependence on what the recording happened to do; the recording
// only contributes the SHAPE of the motion, re-timed to this run's crossing.
struct AutoTrig {
    int uid = 0;              // reporting only
    double cx = 0;            // player x that fires it
    std::vector<TrigCtl> ctl;
    // Resolved TRUE effect tick: the last tick the object is still at rest is
    // fireT-1, and gdEase((t-fireT)/dur) is its position from fireT on.
    int fireT = -1;
    // The player's x when it fired, for the lockToPlayer term (see TrigCtl).
    // Resolved with fireT; behind a re-anchor only `cx` itself is known, which
    // is the crossing x to within one tick of travel.
    double fireX = 0;
    // Where the player was on the last tick this trigger's lock was still open.
    // Trails px while the window runs so the object can hold that x afterwards.
    double lockLastX = 0;
    // Ticks between the crossing and the move actually starting.
    // MOVE (901) = 1. Measured 2026-08-09 over the lv19 and lv20 bootstrap runs
    // (nodeath=1 grouptrace=1, so the dump and the recording share one
    // timeline): fitting the closed form to all 655 single-owner objects puts
    // the origin at crossing+1 for EVERY one of them, min = med = max, with a
    // worst-case residual of 0.004 px. py/trigger_curve_fit.py reproduces it.
    //
    // It used to say 2, from lv19 uid 15242 (crossing t=21,688 against first
    // RECORDED motion t=21,690). That measurement was right and its reading was
    // wrong: grouptrace does not write sub-0.05 px changes, and an EaseInOut
    // move is under that for its first two ticks (see recordLag). The extra
    // tick was the recorder's threshold, not GD's.
    // TOGGLE (1049) = 0: a boolean has no such threshold, so its measurement
    // (lv20, the three groups whose toggle is the first thing to touch them --
    // uid 4528 x=6,465, uid 10316 x=17,715, the trio at x=22,455 -- all flip on
    // the very tick the player crosses) stands as read. The later toggles in
    // that level show a large negative offset only because their group had
    // already been flipped by an earlier trigger; they are not independent
    // measurements and are not evidence of anything.
    int delay = 1;
    // The objects a Toggle in this chain switches, which way, and how many ticks after fireT
    // (the chain's spawn delays) -- the root's own switch when the root is a Toggle, and every
    // spawned one below it. Read by the on/off events (autoOnEvents); nothing else.
    struct Tog {
        int uid;
        uint8_t on;
        double delay;
    };
    std::vector<Tog> tog;
};
inline std::vector<AutoTrig> g_autoTrig;

// ---- an object's on/off as a sequence of switches ----------
// One switch of an object's on-state: a Toggle (or an activate) that some trigger's chain
// reaches, taking effect `delay` ticks after that trigger fires. A box (`box` >= 0, the
// State::trig bit) fires at the state's own fireB[box], and only in a state that entered it. An
// x-crossing trigger (`autoIdx` >= 0, its g_autoTrig index) fires at that trigger's fireT, a tick
// the whole level shares and that the search resolves as it goes -- so it is read when the event
// is resolved, not copied in. Otherwise `at` is the fire tick (-1 = never).
//
// A touch mask alone cannot say this. It is monotone -- a bit that is set stays set -- so it has
// no way to express a switch-off later in the same chain, two chains fighting over one object,
// or a delay before either takes effect. Nothing reads these yet.
struct OnEvent {
    int box = -1;
    int at = -1;
    uint8_t on = 1;       // 1 = the object comes on, 0 = it goes off
    double delay = 0.0;   // ticks after the source fires (the chain's spawn delays)
    int autoIdx = -1;
};

// The object's on-state at tick t: `init` (its on/off right after the game's reset) until
// something switches it, then the event with the LATEST effective tick (fire + delay) among those
// that have taken effect by t. On a tie the one later in the list wins, which is chain order --
// NOT known to be the game's order, so a tie between two sources is a place to
// measure, not to trust.
inline bool resolveOn(bool init, const OnEvent* ev, size_t n, TouchMask mask,
                      const uint16_t* fireB, int t) {
    bool on = init;
    double best = -1e300;
    for (size_t k = 0; k < n; ++k) {
        const OnEvent& e = ev[k];
        double f;
        if (e.box >= 0) {
            if (e.box >= kTouchBits || !fireB || !(mask & touchBit(e.box))) continue;
            f = fireB[e.box];
        } else if (e.autoIdx >= 0) {
            if ((size_t)e.autoIdx >= g_autoTrig.size()) continue;
            const int ft = g_autoTrig[(size_t)e.autoIdx].fireT;
            if (ft < 0) continue;
            f = ft;
        } else {
            if (e.at < 0) continue;
            f = e.at;
        }
        const double te = f + e.delay;
        if (te > t || te < best) continue;
        best = te;
        on = e.on != 0;
    }
    return on;
}

// The switches the x-crossing triggers give each object (AutoTrig::tog), by object uid, each
// tied to its trigger's index in `autos` -- which has to be the final g_autoTrig, sorted, since
// the index is how the event finds its fire tick.
inline std::unordered_map<int, std::vector<OnEvent>> autoOnEvents(
        const std::vector<AutoTrig>& autos) {
    std::unordered_map<int, std::vector<OnEvent>> out;
    for (size_t a = 0; a < autos.size(); ++a)
        for (const AutoTrig::Tog& g : autos[a].tog) {
            OnEvent ev;
            ev.autoIdx = (int)a;
            ev.on = g.on;
            ev.delay = g.delay;
            out[g.uid].push_back(ev);
        }
    return out;
}
// Travel coordinate of each touch box, by its bit in State::trig (filled by
// loadTouchTriggers). ownTouch's proximity gate reads it: the one measured
// punch pair (box ~3,255..3,300 lifting uid18119 at 3,486) is 230px apart,
// while the pre-band grazes that phantomed the whole switch band sat 500+px
// from the ceiling they were credited with delaying.
inline float g_touchBoxU[kTouchBits] = {};
// --keycensus: how many times each box divided the dedupe key (search_key.hpp).
// The window's whole cost lands there -- a box in the window splits the key for
// as long as it is moving -- so this says WHICH boxes are worth their bit.
// Relaxed atomics: the layer expansion is parallel and nobody reads the tally
// until the run ends, so the interleaving does not matter, only the per-box
// order of magnitude. Off by default; the counting is one increment.
inline bool g_keyCensus = false;
inline std::array<std::atomic<long long>, kTouchBits> g_keyCount{};
// The tick box b was FIRST entered by any state of THIS solve (-1 = not yet).
// A level property like AutoTrig::fireT, and the same approximation ("the
// first group to reach it wins"). Deliberately not carried by the state: the
// state's trigT only remembers its LAST box, and the per-box delay of the
// switch band needs every punch's own tick. Bits the ANCHOR arrived with stay
// -1 -- their effect is already inside the live recording (it replayed this
// very plan's prefix), so crediting them again would double-count the delay.
// FILLED RATHER THAN LISTED. This used to be 32 literal -1s, which is a trap
// the moment kTouchBits moves: a shorter list leaves the tail at 0, and 0 here
// means "entered at tick 0" rather than "not yet". The fill cannot go out of
// step with the width.
inline std::array<int, kTouchBits> g_touchFireT = [] {
    std::array<int, kTouchBits> a{};
    a.fill(-1);
    return a;
}();
// uids some Rotate (1346) trigger turns. A rotation carries its group around a
// centre object, so no offset describes it and the closed form must not claim
// it -- lv21 has 200 objects that look like plain moves until you notice a
// rotate on the same group (their recorded path missed the move-only formula by
// 120 px). Filled by loadAutoTriggers, which walks the same chains.
inline std::unordered_set<int> g_rotated;
// What a Rotate does to one object, from the dump alone -- the input side of
// the computed timeline that will replace the recording for these objects.
//
// MEASURED 2026-09-01 against grouptrace, lv21 uid15367 (in the turned group,
// orbiting uid15390, both carried down 150 by the same move) over the full 960
// ticks of a -720 degree turn:
//
//   the model today, best single shift of the recording   1.65-2.18 px
//   closed form, absolute angle                           0.0142 px
//   per-tick recurrence in double                         0.0142 px
//   per-tick recurrence, position stored through float    0.0060 px
//
// The first two of those agree EXACTLY, which is what says the composition is
// not where the last hundredth of a pixel lives: it is rounding. After a full
// -720 the object should return to its entry point and GD leaves it at
// (-0.005, +0.013) -- 960 ticks of a float store (the cvtpd2ps in GD's move
// path). Hence the recurrence below, and hence `float` and not `double` for
// the carried position.
//
// lv22 uid254 (7 degrees, BounceOut, over 120 ticks) reaches 0.0940 px by the
// same route, and there the float store makes no difference at all -- 120
// ticks of 7 degrees has nothing to accumulate. Its residual is the shape of
// gdEase case 9 at rate 2, not the composition: the endpoint is exact
// (R(-7 deg) on (0,162) predicts dx=+19.75/dy=-1.21, GD gives +19.743/-1.208)
// and the object's move alone reproduces its cy to 1.208 px, which IS the
// rotation's y-component. That easing is being re-read from the binary; until
// it is, 0.0940 px is the expected value for a Bounce-eased rotate and not a
// defect to chase.
struct RotSpec {
    int trigUid = 0;       // the Rotate, for reporting and for its fire tick
    int centreUid = 0;     // the single object of the centre group
    double total = 0.0;    // t360*360 + deg -- the WHOLE angle
    double durT = 0.0;     // ticks
    int ease = 0;
    double erate = 2.0;
    int lockrot = 0;       // does the object's own facing follow the orbit?
    // Resolved at load, once the objects are placed:
    int anchor = -1;       // g_autoTrig index of the Rotate (-1 = not autonomous)
    int centreIdx = -1;    // index into dyn of the centre object
    float relX = 0.f, relY = 0.f;   // entry position MINUS the centre's entry
};
inline std::unordered_map<int, RotSpec> g_rotSpec;   // uid -> how it turns
// OFF, and the reason is not the physics -- it is that ADDING a rotation in the
// placement path double-applies it. Every collidable turned object in the
// corpus HAS a recording, and a recording is GD's own answer with the orbit
// already in it; turning it again on top is simply wrong. deathref caught it
// in one run: lv21_t13304 PASS -> FAIL, the model killed at t=12,980 against
// GD's 13,416, a rotated hazard swung twice as far as it should.
//
// The population makes this decisive rather than a tuning matter. Of lv21's
// 872 computable orbits, 806 are type 7 -- DECORATION, which the loader never
// admits and which therefore costs nothing standing still; the collidable ones
// are 62 hazards + 4 (type 47), all recorded. lv22 is 264 decoration and 9
// solids, all recorded. So there is no population of "turned objects the model
// holds still": the whole set is 75 objects that already have GD's answer.
//
// What 008 is actually worth is therefore RE-TIMING, not motion: a recording
// is one run's timeline, and one shift cannot carry a rotate and a move that
// cross at different x (1.65-2.18 px). Capturing that means REPLACING those
// objects' samples with rows computed from the definitions, each trigger on
// its own fire tick -- not adding a rotation to the placement path. That is a
// different change, and it is the one to make.
inline bool g_rotCompute = false;
// Load-time self-check: replay the computed timeline against every recorded
// rotated object and report the residual. The corpus-wide version of the
// harness that measured the two objects above.
inline bool g_rotCheck = false;
// Load-time counters, so "the orbit did not arm" can be told apart from "the
// object never reached the router".
inline size_t g_rotSeen = 0, g_rotRouted = 0;
// stage 1': put the ORBIT into samples[] and leave the translation analytic.
// --no-rotsplit for the A/B. See the block in level_loader.hpp for why this is
// the insertion point and adding a rotation to placement is not.
inline bool g_rotSplit = true;

// GD's rotation, one tick of it. `sign` is the mapping from the dump's angle to
// a y-up rotation matrix, measured as -1 on both subjects (GD's positive turn
// is clockwise on screen).
//
// The position is carried as float on purpose -- see the note above; it is the
// difference between 0.0142 px and 0.0060 px on a 960-tick turn.
inline void rotStep(float& x, float& y, double cxPrev, double cyPrev,
                    double cxNow, double cyNow, double dTheta) {
    const double c = std::cos(dTheta), s = std::sin(dTheta);
    const double rx = (double)x - cxPrev, ry = (double)y - cyPrev;
    x = (float)(cxPrev + c * rx - s * ry + (cxNow - cxPrev));
    y = (float)(cyPrev + s * rx + c * ry + (cyNow - cyPrev));
}
// Always on (--no-trigclosed is gone since the flag clean-up). For an
// autonomously moved object the FORMULA places it, not the recording -- but
// only where the object passes autoClosed (a per-object check at load).
//
// Why a formula beats a measurement here: a recording ends where its attempt
// died, it is one run's timeline, and it only exists for objects some plan
// actually reached. The formula has none of those limits and, where both exist,
// they agree to 0.002 px. For a lockToPlayer object the recording is not merely
// limited but WRONG for anyone else -- it followed the recorded run's player.
// Objects the formula cannot describe (move-to-target with no offset, anything
// a rotation carries, two locks, a y lock) fail autoClosed and keep theirs.
// --trigraw: autonomous triggers behind the anchor (before it) use **the
// recording's tick as is** when a recording exists (no switching over to the x
// estimate through the 60 tick gate). est's "how many ticks ago, by
// distance/speed" assumes x advanced monotonically, which breaks behind the
// rotation maze: at lv22's t=14,250 anchor, uid10628 (x=15,075, real firing
// t=10,520) was re-dated to est=13,845, group 331's whole timeline slid by
// +3,325 ticks, the ON return of "off@10,520 -> on@14,198" flew into the future
// at t~17.5k, and the floor GD was riding was missing in the model alone. The
// driver takes the anchor from the same dump as the snap (the recording of this
// attempt's replay), so for that pair the recording's time axis = this run's
// time axis and a shift of 0 is correct. Without the flag the behaviour is
// exactly as before.
inline bool g_trigRaw = false;
// Autonomous lag: an object moved by a touch box AND an autonomous
// trigger (Level::formula) dates that trigger from its recording with the lag of
// the AUTONOMOUS move (Dynamics::autoLag), not the touch move's (recLag). The
// recorder writes nothing until 0.05 px, and a slow ease-in takes a long time to
// get there: lv22's descending ceiling (group 265, uid18098: -480 px over 1,005.6
// ticks, ease-in rate 2.5) first shows at t=2,256 at 0.052 px, while the curve
// through that row and the rows at 2,298 (0.571) and 2,411 (6.597) starts at
// 2,230 to 0.01 px. With recLag (1, the touch move's) the trigger fired at 2,255
// and the ceiling ran 2 px high at t=2,411 and 13.6 px high at t=2,842 -- enough
// for the model to fly past two of GD's deaths.
// ON by default since 2026-09-22, as ONE unit with the mod's anchor opening from
// the recorded positions (cfg dptouchentered, --touchentered below): the old
// opening put that ceiling at its final height, far from the player, which is
// what let the kill records at GD's deaths through the nearDynObject gate; the
// recorded opening puts it where GD has it, and only with this lag is "where GD
// has it" right. The pair: cold 22/22, per-level iterations and [fp] identical
// on 21 levels, lv22 the same 26 iterations and deaths by another route.
// Always on since the 0.2.0 flag clean-up (it was --automixlag).
// --lagfit (print only): for each object the lag above re-dates, the residual of
// its first recorded rows against the autonomous and the touch curve (level_loader).
inline bool g_lagFitDbg = false;
// --lockanchor: an anchor behind an auto lockToPlayerX trigger restores the lock's
// displacement from the recording (cli.hpp, the behind-the-anchor trigger loop).
// On since 2026-09-21; always on since the flag clean-up.
// --touchentered <uid,...|->: the touch boxes (by trigger uid) the attempt's
// recorded positions overlapped by the anchor. Given, the anchor scan opens
// only these from the recording (cli.hpp, `mayOpen`). "-" = given, none.
inline bool g_touchEnteredGiven = false;
inline std::unordered_set<int> g_touchEntered;
// ...and, when the caller writes `uid:tick`, the first tick the recorded positions
// overlapped that box. The anchor scan then takes the box's fire tick from it
// instead of from the recording's first motion, which for an object that an
// autonomous Move also drives is that Move's, not the box's: lv22's trap 18092
// (entered at 2,614 in the recorded rows) was dated 2,255 -- the start of the
// ceiling's slow descent -- so its target-mode slam had long finished at a t0=2,651
// anchor where GD's ceiling is still coming down 3 px a tick.
inline std::unordered_map<int, int> g_touchEnteredT;
// --dyndbg <uid>: dump one moving object's placement inputs at load (see the
// print near the fireT resolution).
inline int g_dynDbg = -1;
// The search's thread pool, lent to the per-object loops of Dynamics::seek and
// Dynamics::applyTriggers: runs task(k) for every k in [0,n) and returns when
// all have run. Set by the search for exactly as long as its pool exists, on
// the thread that owns the pool, and only called there, between its parallel
// phases (seek and applyTriggers are serial-caller-only already). Empty
// everywhere else, which is the plain loop.
inline thread_local std::function<void(size_t, const std::function<void(size_t)>&)>
    g_dynParTasks;
// How many objects the loader put on the formula path, and how many of those
// never saw either controller fire in this call. The second is the guard's
// readout: an object that is formula-driven but whose triggers never fire sits
// at its base position, which is right, but if the count is the whole set the
// classification found objects the plan cannot reach and the formula is
// carrying nothing.
inline int g_formulaDriven = 0;
// (--noformula, which kept every object on the recording path, is gone since the flag clean-up.)
// --touchretime: re-time a touch-controlled object's recording against THIS
// state's entry into the box that reaches it, instead of playing it on the
// recording run's clock (the touch branch below sets anchor = recAnchor, so
// shift is 0 by construction). Measured on lv22's block row, group 508 under
// box uid17771 (worker 98, three arms of the same plan): the row's first moving
// row is two ticks after the ball's rect first overlaps the box -- t=6534 after
// an overlap from 6532, t=6508 after an injected overlap from 6506 without a
// landing, and no motion at all through t=6546 when the ball is held clear.
// Only boxes entered at or after the solve's own start are re-timed
// (g_touchRetimeFrom): a box the anchor arrived with has its fireB seeded from
// the recording's first motion, not from an entry, and its recording is this
// run's own. Also changes how recAuto is classified (level_loader.hpp). On
// since v0.1.4, always on since the flag clean-up; lv19's doors measured a
// 5-tick latency with a spawn delay in the chain, which this does not model.
inline long long g_touchRetimeFrom = 0;
// --touchretimelag: a touch-only object carries the recorder's threshold lag
// (level_loader.hpp) and the re-timed anchor adds it, so the box entry +
// latency (the motion's start) lines up with the recording's first ROW rather
// than being taken for it. Measured against the recording on lv22 uid1214 it
// moves the playback from two ticks ahead of the recorded row to one, and
// against the reference dumps lv22 tracks 19,100 -> 19,343 ticks with the
// standing "tracking shrank at t=2,600" gone. On since 2026-09-20, always on
// since the flag clean-up. It was held off for a while because a
// cold run then routed lv22 into a hole and did not clear inside the budget --
// that was a property of the base it was measured on (c935132 plus all five
// bundle units), and it does not reproduce once the other units are in: lv22
// clears in the same 32 iterations as without it, and the other 21 levels are
// fingerprint-identical.
// --recinterp: a recording's position between two close rows is interpolated,
// not held (Dynamics::seek).
// ON BY DEFAULT since 2026-09-20, PAIRED WITH
// --stickrelease. On its own it moves 9 of the corpus's 1,116 sections, all in
// lv22, and changes no verdict; its value is that it supplies the `dcy` the
// stick re-land needs on a tick the recorder skipped. Always on since the flag
// clean-up, like --stickrelease.
inline constexpr int kRecInterpGap = 4;
// The recorder's per-channel write threshold (grouptrace.hpp kEps): a row is
// written once any of x, y, w, h, rot has moved kRecEps or more from the last
// row written.
inline constexpr double kRecEps = 0.05;
inline constexpr int kTouchRetimeLat = 2;
// --touchretimebox: re-time a touch box's objects against the BOX's entry, not each
// object's own first motion. Without it every object is taken to start moving
// kTouchRetimeLat (+ its lag) after the entry, which holds for an object the box moves
// directly and not for one a spawn chain reaches later. lv22's spike row under box uid 1417
// (id 392, uid 17571 and 18201..18206): the recording has them first moving at 1,755 /
// 1,766 / 1,774 -- they drop one after another -- and the re-timing pinned all of them to
// the entry + 3, so five of the seven sank 10-18 ticks early. GD kills the spider on uid
// 17571 at t=1,813 in its unmoved place; the model had already lowered it and walked on.
// With this, the recording's entry into a box is estimated ONCE per box, as the earliest
// first motion (less latency and lag) among the objects only that box moves, and each
// object keeps its own delay behind it.
// ON BY DEFAULT since 2026-09-24; --no-touchretimebox restores the per-object
// latency. kDefTouchRetimeBox is what reset.hpp writes back.
inline constexpr bool kDefTouchRetimeBox = true;
inline bool g_touchRetimeBox = kDefTouchRetimeBox;
// The one touch box whose chain locks something to the player's x, and how long
// the lock lasts in ticks. A per-BOX quantity rather than a per-object one
// because what a state has to remember is "how far have I travelled since I
// punched THAT box", and the corpus needs exactly one of them: the census over
// all 22 levels found locks down a touch chain on lv19 only, through a single
// box (26 objects, 7 of them collidable). A second box would need a second
// accumulator, so it is reported rather than silently averaged -- the same
// treatment `alockN` already gives two locks on one object.
inline int g_lockBox = -1;
inline double g_lockTicks = 0.0;
// --shiftstat: one `shiftstat:` line per moving object, the first time it is
// placed, saying which recorded row the model ends up reading for it.
//
// The re-timing (`tt = t - shift`) is PER OBJECT, so "the model is N rows behind
// GD" has no single N -- which is exactly what stopped a blanket phase fix on
// 2026-09-03 (uid 434 came out at shift=1, but shift=0 objects are a row nearer).
// This counts the distribution over the objects a collision actually consumes,
// so the size of the re-anchoring family is a number rather than an impression.
// Diagnostic only: prints and changes nothing.
inline bool g_shiftStat = false;
struct Dynamics {
    // Stable storage: `snapObj` / `usedOrb` / `usedPad` hold raw Obj* across
    // ticks, so these must never reallocate after load. The rects are MUTATED
    // in place once per tick by seek().
    std::vector<Obj> objs;
    std::vector<std::vector<DynSample>> samples;  // parallel to objs
    // [2026-08-25] Does a trigger ROTATE this object anywhere in the recording?
    // GD's collision test branches on the object's own "is turned" flag, and a
    // rotate-target carries it for the whole run -- not only once the angle has
    // grown away from zero. See the note at turnedBox's axis-aligned branch for
    // the measurement (lv22's spider portal uid 1156). Parallel to objs; empty
    // in an old Dynamics, which reads as "never", i.e. the previous behaviour.
    std::vector<uint8_t> everRot;
    // --shiftstat only: whether this object has already printed its line.
    // Sized lazily so an old Dynamics (or a run without the flag) carries
    // nothing.
    std::vector<uint8_t> shiftSaid;
    std::vector<size_t> cur;                      // per-object cursor
    // which window each one belongs in, mirroring the static split
    // COIN is last so the existing numbering is untouched. A coin only ever
    // reaches the dynamic set when a trigger controls it (--coins).
    enum Bucket : uint8_t { NEAR, PORT, PAD, ORB, SPEED, SLOPE, COIN };
    std::vector<uint8_t> bucket;
    // FORMULA-DRIVEN: this object's position is computed from its triggers
    // rather than replayed from the recording. Set by the loader for objects a
    // touch controller AND an autonomous one both reach, where BOTH actually
    // move something. GD applies both; a recording only ever holds one
    // attempt's answer to "was this touched" -- lv19's doors are recorded open,
    // lv22's switch band recorded untouched -- so for these objects neither
    // recording is the state's world, and everything the re-timing machinery
    // does below is an approximation of a world it cannot see. The two eased
    // moves ARE that world, to 0.0007 px against all 286 recorded rows of each
    // of lv19's seven (oneoff/py/fit96.py), so an object on this path takes
    // none of it: not the dual special case, not the ownTouch hold, not the
    // autonomous re-timing.
    std::vector<uint8_t> formula;
    // Last tick's FINAL cy (after seek AND applyTriggers). dcy for a
    // trigger-CONTROLLED object must be the delta of its analytic position,
    // not of the raw samples: the recorder SKIPS rows when the move since the
    // last row is under its epsilon, so an eased tail records every 2nd-3rd
    // tick and the raw-sample dcy reads 0 on the skipped ticks -- while the
    // analytic position keeps moving. The ride gates on dcy != 0, so the
    // rider dropped grounded for exactly those ticks (lv22 t=849/851, the
    // hanging spider on the bobbing intro blocks: one +0.129 gravity blip per
    // skipped row).
    std::vector<float> prevCy;
    bool lastStep1 = false;
    // A moving SLOPE carries its surface line with it. sy0/sy1 are absolute
    // heights, so they are re-derived from the load-time values plus however
    // far the object has travelled in y. (Pure translation only -- a ROTATING
    // slope would need its line recomputed, and nothing rides one yet.)
    std::vector<float> baseCy, baseSy0, baseSy1;
    std::vector<uint8_t> on;   // toggled in? (0 = the object is not there)
    // --activators: for an object an activator switches (a pickup or a toggle block), its
    // on/off is not the recording's -- a recording holds one run's presses -- but its t=0 value
    // (onInit, the recording's reset snapshot) with every switch that reaches it applied in time
    // order for THIS group (resolveOn: the boxes by the group's own fire ticks, the x-crossing
    // Toggles by their fireT). Empty for every other object, for one whose recording has no
    // snapshot, and for all of them without the flag. Filled by the level loader.
    std::vector<std::vector<OnEvent>> onEv;
    std::vector<uint8_t> onInit;
    // ---- touch-trigger control (see TouchTrig, below) ----
    // Which touch triggers move this object and by how much once they have.
    // Zero for every object in lv1-18, so all of this is dead weight there.
    std::vector<TouchMask> trigMask;
    // The recording's motion is NOT this object's touch chain (wrong direction
    // or far beyond its offset), so it is an autonomous fact of the recorded
    // worldline and plays for every state -- the switch band's ceiling: chain
    // says nudge +10, the recording descends -100. A door whose recording IS
    // its chain (lv19) stays touch-gated. Filled by the loader.
    std::vector<uint8_t> recAuto;
    std::vector<float> trigDx, trigDy;
    std::vector<double> trigDur;
    std::vector<int> trigEase;
    std::vector<double> trigErate;
    // The tick this object FIRST moved in the recording (-1 = it never did).
    // That is the anchor the recorded trajectory is re-timed against, so a
    // frontier group that fired the trigger at a different tick than the run
    // that recorded it still sees the right shape at the right offset.
    // Shared by the touch and the autonomous machinery.
    std::vector<int> trigRecFire;
    // --touchretimebox: per touch bit, the tick the RECORDING entered that box, estimated from
    // the earliest first motion among the objects only it moves (-1 = none; empty = flag off).
    // Filled by the loader.
    std::vector<int> boxRecEntry;
    // ...and how many ticks late that FIRST ROW is (see recordLag). The true
    // start is trigRecFire - recLag, which is the tick the analytic curve and
    // the re-timing shift are both written against.
    std::vector<int> recLag;
    // ...and the lag of the AUTONOMOUS move alone, for an object that also has a
    // touch move (formula-driven): its recLag is the touch move's, which is the
    // wrong curve for dating the autonomous trigger. Equal to recLag for every
    // other object. Read unless --no-automixlag.
    std::vector<int> autoLag;
    // Does the closed form reproduce this object's recording? Decided per
    // object at load by replaying the formula against every recorded sample
    // (see the check in loadLevel). Only consulted under --trigclosed.
    std::vector<uint8_t> autoClosed;
    // ---- autonomous-trigger control (see AutoTrig, above) ----
    // Which g_autoTrig entry anchors this object's re-timing (-1 = none).
    // An index, not a mask: the fire tick is a level property so no state
    // carries it, and lv21 has 174 autonomous moves (a 32-bit mask cannot).
    // An object moved by several autonomous triggers is anchored on the
    // EARLIEST-crossed one -- its recFire is that controller's first effect,
    // and the later controllers ride the same shift (their relative timing is
    // embedded in the recording).
    std::vector<int> autoAnchor;
    // "This object's touch entry moves it nowhere (dx=dy=0) but it ALSO has a
    // real autonomous mover." Deliberately a SEPARATE flag rather than widening
    // autoAnchor: autoAnchor is read by :632, :710, :853 and cli.hpp:1652/:1981,
    // and widening it would drag the ownTouch punch-freeze (:853) and the
    // anchor-seeding rf scan (cli.hpp:1652, both the ahead branch at :1670 and
    // the behind branch at :1718) along with it -- both were measured as
    // unintended effects of the wider forms. Read at the fire gate below and
    // NOWHERE else.
    std::vector<uint8_t> recSelfFire;
    // Also reached by an autonomous controller (level_loader.hpp). Read only by
    // --touchretime, which leaves such objects on the recording's clock.
    std::vector<uint8_t> autoReach;
    std::vector<float> autoDx, autoDy;   // summed final offset (ease fallback)
    std::vector<double> autoDur;
    std::vector<int> autoEase;
    std::vector<double> autoErate;
    // Every controller's move kept SEPARATELY, because they superpose: each one
    // starts at its own crossing and runs its own curve, and the object is the
    // sum. Adding the offsets up under one anchor is only right when there is
    // one controller -- lv20 has objects under five, and the sum-under-one-
    // anchor form was off by hundreds of px on those. Measured on the lv20
    // bootstrap: the superposition matches all 384 multi-controller objects to
    // 0.002 px (py/trigger_curve_fit.py's sibling check).
    struct AutoPart {
        int trig; float dx, dy; double dur; int ease; double erate;
        // --movetarget only: see TrigCtl's fields of the same names.
        int mover = 0;
        uint8_t tmode = 0;
        float tdx = 0.f, tdy = 0.f;
    };
    std::vector<std::vector<AutoPart>> autoParts;
    // Was this object's recording REPLACED by the computed orbit (g_rotSplit)?
    // The split stores `entry_C + R(theta)*rel` and drops `C(t) - entry_C`
    // -- level_loader's own words, "recorded = orbit + the centre's own
    // translation", with the translation subtracted out at the fit check. The
    // only path that ever added it back sits behind g_rotCompute, which is
    // false and which no flag can set, so for these objects the translation
    // was silently lost. They share their move controllers with their centre
    // (the split refuses them otherwise), so their own autoParts IS that
    // translation; this marks them so the recording arm can add it.
    std::vector<uint8_t> rotSplit;
    // The TOUCH chains kept per box (trig = the box's State::trig bit), where
    // trigDx/trigDy above are their sum. The sum is enough for a door -- one
    // box, one move -- and undecidable for the switch band, where YELLOW boxes
    // (+30 up) and RED boxes (-840 down) drive the same spikes: every per-box
    // question (which way does THIS punch push? is the recorded descent any
    // single box's chain?) has no answer in the summed form. Filled only for
    // touch-controlled objects; empty everywhere lv1-18.
    std::vector<std::vector<AutoPart>> touchParts;
    // lockToPlayerX window in ticks (0 = none) and the g_autoTrig entry that
    // opened it -- NOT necessarily the object's anchor. See TrigCtl::lockTicks.
    std::vector<double> autoLock;
    std::vector<int> autoLockTrig;
    // ...and the touch side. Non-zero means "while this object's box has been
    // punched and the window is open, this object's x IS the player's x,
    // offset by wherever both were when it fired" -- so its x is a property of
    // the STATE, not of the level, and a recording of it is one attempt's
    // player path. dynamics' own note on TrigCtl::lockTicks calls this "the one
    // class where a RECORDING is provably wrong for anyone else".
    std::vector<double> touchLock;
    bool anyTrig = false;
    bool anyAuto = false;
    int lastT = -1;

    size_t size() const { return objs.size(); }

    // ---- caches that change nothing but the time taken ----------------------
    // applyTriggers runs once per frontier GROUP, and a tick can have many
    // groups. For most moving objects the placement it computes does not depend
    // on the group at all: an object no touch box reaches, that is not
    // formula-driven and not locked to the player, is placed from seek()'s state
    // for this tick, its own static data and the level-wide autonomous clocks
    // (AutoTrig::fireT) -- nothing the group carries. Those "pure" objects are
    // placed once and left alone until one of the three changes. Profiled on a
    // level with 868 moving objects: applyTriggers was 9.5% of the main thread,
    // which is the critical path (the workers are idle ~70% of the time).
    uint64_t seekEpoch = 0;              // bumped by every seek() that rewrites
    uint64_t pureEpoch = ~0ull;          // what the pure objects were placed for:
    int pureT = -1;                      //   seek epoch, tick,
    std::vector<int> pureFire;           //   and every AutoTrig::fireT
    bool isPure(size_t i) const {
        return !trigMask[i]
            && !(i < onEv.size() && !onEv[i].empty())   // --activators: depends on the group
            && !(i < formula.size() && formula[i])
            && !(i < autoLockTrig.size() && autoLockTrig[i] >= 0);
    }
    // collect() walks one bucket's objects instead of all of them. Built in
    // seek(), which runs on the main thread between the parallel phases:
    // collect() is also called from step() on the worker threads, so it must
    // never build this itself. Until it exists collect() takes the full walk.
    std::vector<std::vector<uint32_t>> byBucket;
    size_t byBucketN = (size_t)-1;
    bool anyUidM1 = false;   // an object --dyndbg's default of -1 would name
    size_t nNonPure = 0;     // objects a same-tick applyTriggers still places
    void rebuildBuckets() {
        byBucket.assign(8, {});
        for (size_t i = 0; i < objs.size() && i < bucket.size(); ++i)
            if (bucket[i] < byBucket.size())
                byBucket[bucket[i]].push_back((uint32_t)i);
        anyUidM1 = false;
        for (const Obj& o : objs) anyUidM1 |= (o.uid == -1);
        nNonPure = 0;
        for (size_t i = 0; i < objs.size(); ++i) nNonPure += !isPure(i);
        byBucketN = objs.size();
    }
    // The per-object loops of seek() and applyTriggers() split across the
    // search's pool (g_dynParTasks) in runs of kParRun objects. body(b, e)
    // handles objects [b, e). Only for a loop whose body writes nothing but its
    // own object's slots -- then every object is placed by the same arithmetic
    // whichever thread runs it, and the result is the serial loop's. `work` is
    // how many objects the call will actually place -- a second group of the
    // same tick places only the non-pure ones, usually a handful, and the pool
    // is not woken for a handful. Below kParMin the loop stays on this thread.
    // 512 against 2,048: no slower on levels with 868 and 1,063 moving objects,
    // and faster on one with 4,350 (77.5 s against 80.7).
    static constexpr size_t kParMin = 512, kParRun = 64;
    template <class F> void forRuns(bool par, size_t work, F&& body) {
        const size_t n = objs.size();
        if (!par || !g_dynParTasks || work < kParMin) { body((size_t)0, n); return; }
        g_dynParTasks((n + kParRun - 1) / kParRun, [&](size_t k) {
            body(k * kParRun, std::min(n, (k + 1) * kParRun));
        });
    }

    // Place the trigger-controlled objects for a frontier group whose states
    // have touched the triggers in `mask`, `fireHi` being the latest tick any of
    // them fired (-1 = none).
    //
    // Called right after seek(), and it has to be IDEMPOTENT: seek() early-
    // returns when the tick has not changed, so the second group of the same
    // layer would otherwise stack its offset on top of the first group's. It
    // rebuilds each rect from the object's OWN first sample instead of from
    // whatever is currently in objs[i].
    //
    // The first sample and not the current one, deliberately. Once the driver
    // replays a plan that DOES touch the trigger, grouptrace records the door
    // sliding open -- and that recording would then be applied to every state,
    // including the ones that never touched anything. The whole point is that
    // the two worlds differ, so for these objects the recording is ignored and
    // the mask is the only thing that moves them.
    //
    // When the bit IS set the recording is replayed, re-timed so that its first
    // motion lands on this group's firing tick. That is the whole point of not
    // implementing trigger semantics: lv19's third touch trigger is a "move to
    // target" lift, not a simple offset, and m_moveOffset for it is (0,0) --
    // GD's own trace has the ball riding it grounded from x=28,783 to x=29,001
    // across what is otherwise a spike floor. No closed form was going to
    // produce that; the replay already contains it.
    //
    // Only when there is no recording yet (the first iteration, before any plan
    // has touched the box) does it fall back to the static offset, eased. That
    // fallback is no longer an approximation: the curve is GD's own easing by
    // type and rate (gdEase), the duration is the dump's dur*240 unrounded, and
    // the origin is the true first-motion tick -- 0.004 px against 655 recorded
    // objects. It used to be 0.5-0.5*cos(pi*u) over a rounded duration, which
    // was within a few percent of EaseInOut and up to 4.5 px off on lv20's
    // 240 px doors. A union of start and end rect was tried before that and is
    // wrong in BOTH directions -- conservative for a door that opens a gap,
    // optimistic for a platform that rises under your feet.
    // `px` is where the player is THIS tick (the group's leading x during the
    // search, the single trajectory's x in a replay). Only the lockToPlayer
    // term reads it.
    // `fireB` is the group's per-box firing ticks (State::fireB, aggregated the
    // same conservative way `fireHi` is: the LATEST tick in the group). Only
    // the formula path reads it; it may be null, and then no object is
    // formula-driven for this call.
    // `lockOff` is how far the state has travelled since it punched the locked
    // box (State::lockOff). Applied only on the formula path: a recording of a
    // locked object already contains the recorded run's own lock, so adding
    // this to it would count the ride twice.
    void applyTriggers(TouchMask mask, int fireHi, const uint16_t* fireB,
                       float lockOff, int t, double px = 0.0) {
        if (!anyTrig && !anyAuto) return;
        // Skip the pure objects when they are already placed for exactly this
        // (seek epoch, tick, autonomous clocks). Never with a print flag on: those
        // print per call, and skipping would change what they say.
        const bool quiet = g_dynDbg == -1 && g_shiftDbgUid < 0 && !g_shiftStat
                           && !(g_rotCompute && !g_rotSpec.empty());
        bool samePure = quiet && pureEpoch == seekEpoch && pureT == t
                        && pureFire.size() == g_autoTrig.size();
        for (size_t k = 0; samePure && k < g_autoTrig.size(); ++k)
            samePure = (pureFire[k] == g_autoTrig[k].fireT);
        if (!samePure) {
            pureEpoch = seekEpoch;
            pureT = t;
            pureFire.resize(g_autoTrig.size());
            for (size_t k = 0; k < g_autoTrig.size(); ++k)
                pureFire[k] = g_autoTrig[k].fireT;
        }
        // With no print flag on, the only thing an object's placement writes
        // outside its own slots is AutoTrig::lockLastX (the lockToPlayerX
        // branch), and nothing but that branch reads it. So the objects that
        // can take it (autoLockTrig >= 0) are placed afterwards, in index order
        // on this thread, and every other object is placed in runs across the
        // pool (forRuns). The rotation branch, which reads another object, runs
        // only under g_rotCompute, and `quiet` excludes that too.
        const bool par = quiet && !anyUidM1 && byBucketN == objs.size();
        auto place = [&](size_t b, size_t e, bool lockPass) {
        for (size_t i = b; i < e; ++i) {
            if (samePure && isPure(i)) continue;
            if (par && lockPass != (i < autoLockTrig.size() && autoLockTrig[i] >= 0))
                continue;
            const TouchMask m = trigMask[i];
            // FORMULA-DRIVEN OBJECTS LEAVE HERE, before anything reads a
            // sample. `fireHi` cannot serve them: it is the latest box THE
            // STATE entered, which need not be a box that reaches THIS object,
            // so two doors opened by two different boxes would be handed the
            // same tick. The fit wants 20,504 for one and 20,591 for the
            // other. What this object needs is the latest tick among the boxes
            // that both reach it and the state has entered -- which is exactly
            // what the per-box array gives, and is why this path could not be
            // written before State carried one.
            // Deliberately NOT conditioned on `fireB` being non-null: which
            // path an object takes is a property of the object, and making it
            // depend on a pointer would let a caller that forgot the array
            // silently put a formula-driven object back on the recording path
            // -- with the autonomous fields the loader filled in for the
            // formula still set, which is a combination that exists nowhere
            // else. A null array simply means no box has been entered.
            if (i < formula.size() && formula[i]
                && !samples[i].empty()) {
                const DynSample& s0 = samples[i][0];
                int fb = -1;
                if (fireB)
                    for (int b = 0; b < kTouchBits; ++b)
                        if ((m & mask) & touchBit(b))
                            fb = std::max(fb, (int)fireB[b]);
                const int aa0 = autoAnchor[i];
                const int ft0 = (aa0 >= 0 && (size_t)aa0 < g_autoTrig.size())
                                ? g_autoTrig[(size_t)aa0].fireT : -1;
                // The offset at an arbitrary tick. Being a closed form is the
                // point: it answers for t-1 as readily as for t, which is what
                // makes dcy exact here even across an anchor jump, where the
                // recording-driven branch has to fall back to two consecutive
                // recorded rows and reads 0 when the recorder skipped one.
                // --movetarget: the touch side PER BOX, each part at its own
                // box's firing tick (the sum above answers one tick for all of
                // them, which is undecidable once a Stop or a target-mode Move
                // is in play); a Stop freezes the Moves it names at the tick
                // its box fires; a target-mode part's distance is decided on
                // the tick it starts. The group's position is read off this
                // object's own offset, which is right when the object and the
                // target's reference point share their controllers (lv22's
                // ceiling group 265 does: uid18094 is one of its members).
                auto stopTick = [&](int mover) -> int {
                    int st = 1 << 30;
                    if (mover == 0 || !fireB) return st;
                    const int nb = std::min((int)g_touchStops.size(), kTouchBits);
                    for (int b = 0; b < nb; ++b) {
                        if (!(mask & touchBit(b))) continue;
                        for (const int s : g_touchStops[(size_t)b])
                            if (s == mover) st = std::min(st, (int)fireB[b] + 1);
                    }
                    return st;
                };
                auto plainAt = [&](int tt, double& ox, double& oy) {
                    ox = 0.0; oy = 0.0;
                    // A MOVE OF DURATION 0 IS DONE ON ITS OWN TICK: its eased
                    // fraction is 1, and the `/dur` guard that kept it out of
                    // the sum dropped the move altogether. SubZero 4002's group
                    // 87 falls 600 px that way (trigger uid18255 at x=31,899,
                    // dur 0), so every formula-driven member of it stayed where
                    // it started: the saw uid16730 was tested at cy=2,303 while
                    // the recording -- and GD -- have it at 1,703, and the model
                    // walked through the kill GD makes at t=22,893 (ledger
                    // 2026-09-23 06:5x). The recording-driven members were right
                    // all along, which is why this showed up as one object
                    // disagreeing with its own group.
                    if (fireB)
                        for (const AutoPart& p : touchParts[i]) {
                            if (p.tmode) continue;
                            if (!((m & mask) & touchBit(p.trig))) continue;
                            const int f = (int)fireB[p.trig];
                            const int te = std::min(tt, stopTick(p.mover));
                            if (te <= f) continue;
                            const double e = p.dur > 0.0
                                ? gdEase(p.ease, p.erate,
                                         (double)(te - (f + 1)) / p.dur)
                                : 1.0;
                            ox += p.dx * e; oy += p.dy * e;
                        }
                    if (ft0 >= 0) {
                        const int te = std::min(tt, stopTick(g_autoTrig[(size_t)aa0].uid));
                        if (te >= ft0) {
                            const double e = autoDur[i] > 0.0
                                ? gdEase(autoEase[i], autoErate[i],
                                         (double)(te - ft0) / autoDur[i])
                                : 1.0;
                            ox += autoDx[i] * e; oy += autoDy[i] * e;
                        }
                    }
                };
                auto targetAt = [&](int tt, double& ox, double& oy) {
                    plainAt(tt, ox, oy);
                    if (!fireB) return;
                    struct TP { int f; const AutoPart* p; double ddx, ddy; };
                    TP tp[8];
                    int n = 0;
                    for (const AutoPart& p : touchParts[i])
                        if (p.tmode && ((m & mask) & touchBit(p.trig)) && n < 8)
                            tp[n++] = {(int)fireB[p.trig], &p, 0.0, 0.0};
                    std::sort(tp, tp + n, [](const TP& a, const TP& b) { return a.f < b.f; });
                    auto contrib = [&](const TP& q, int at, double& cx, double& cy) {
                        cx = 0.0; cy = 0.0;
                        if (at <= q.f || q.p->dur <= 0.0) return;
                        const double e = gdEase(q.p->ease, q.p->erate,
                                                (double)(at - (q.f + 1)) / q.p->dur);
                        cx = q.ddx * e; cy = q.ddy * e;
                    };
                    for (int k = 0; k < n; ++k) {
                        const int s = tp[k].f + 1;   // the tick it starts
                        double bx = 0.0, by = 0.0;
                        plainAt(s, bx, by);
                        for (int j = 0; j < k; ++j) {
                            double cx, cy;
                            contrib(tp[j], s, cx, cy);
                            bx += cx; by += cy;
                        }
                        const int md = tp[k].p->tmode;   // 1 both, 2 x only, 3 y only
                        tp[k].ddx = (md == 3) ? 0.0 : (double)tp[k].p->tdx - bx;
                        tp[k].ddy = (md == 2) ? 0.0 : (double)tp[k].p->tdy - by;
                    }
                    for (int k = 0; k < n; ++k) {
                        double cx, cy;
                        contrib(tp[k], tt, cx, cy);
                        ox += cx; oy += cy;
                    }
                };
                const bool perBox = !touchParts[i].empty();
                auto offsetAt = [&](int tt, double& ox, double& oy) {
                    if (perBox) { targetAt(tt, ox, oy); return; }
                    ox = 0.0; oy = 0.0;
                    // dur 0 = done on its own tick (the superposition arm below
                    // already reads it that way); see the note in plainAt
                    if (fb >= 0 && tt > fb) {
                        const double e = trigDur[i] > 0.0
                            ? gdEase(trigEase[i], trigErate[i],
                                     (double)(tt - (fb + 1)) / trigDur[i])
                            : 1.0;
                        ox += trigDx[i] * e; oy += trigDy[i] * e;
                    }
                    // NO +1 on this side. The two ticks mean different things:
                    // `fireB` is the tick the box was ENTERED and the move
                    // starts the tick after, while `AutoTrig::fireT` is already
                    // the EFFECT tick (`fireT = crossing + delay`, cli.hpp), so
                    // the move starts on it. The recording-driven branch says
                    // the same by setting `lat = 0` for the autonomous case and
                    // 5 for the touch case. With a spurious +1 lv19's door sits
                    // 0.0615 px above the recording at t=20,601.
                    if (ft0 >= 0 && tt >= ft0) {
                        const double e = autoDur[i] > 0.0
                            ? gdEase(autoEase[i], autoErate[i],
                                     (double)(tt - ft0) / autoDur[i])
                            : 1.0;
                        ox += autoDx[i] * e; oy += autoDy[i] * e;
                    }
                };
                double fx = 0.0, fy = 0.0, px1 = 0.0, py1 = 0.0;
                offsetAt(t, fx, fy);
                offsetAt(t - 1, px1, py1);
                if (g_dynDbg == objs[i].uid)
                    std::printf("formdbg t=%d uid=%d perBox=%d fb=%d ft0=%d "
                                "autoDur=%.2f autoDy=%.1f trigDur=%.2f fy=%.3f "
                                "base=%.3f -> %.3f\n",
                                t, objs[i].uid, perBox ? 1 : 0, fb, ft0,
                                autoDur[i], autoDy[i], trigDur[i], fy,
                                (double)s0.cy, (double)s0.cy + fy);
                const double ncy = (double)s0.cy + fy;
                // ...and the face's PER-TICK motion, from the same closed form.
                // Without it the object teleports as far as anything standing
                // on it is concerned: the support tolerance is
                // `kSupportTol + |dcy|`, so a rider on a descending face keeps
                // its footing only while dcy says the face moved. This IS lv19
                // t=20,601 -- a ball riding uid14011 down at 0.062 px/tick --
                // and with dcy at zero the model drops the support on the first
                // tick, falls, and dies 45 ticks later on a hazard the ride
                // would have carried it over.
                //
                // NOT gated on `lastStep1`, unlike the branch below. That gate
                // exists because a position difference across an anchor jump is
                // the platform's whole journey rather than one tick; a formula
                // evaluated at t-1 is one tick by construction, so the case the
                // gate protects against cannot arise -- and the first tick
                // after an anchor, which is exactly where this object is
                // ridden, is not a 1-tick advance.
                objs[i].dcy = fy - py1;
                // x: the moves, plus the lock. The 158 px that `s0.cx + fx`
                // could not account for (uid14011 is recorded at cx=28,789 at
                // t=20,601 against a base of 28,631, with dx=0 and adx=0 on both
                // controllers) is a lockToPlayerX -- the recording shows its x
                // advancing by the player's own dx, from the tick the box fires.
                // With the lock the closed form covers x as well, so this writes
                // it; without one it stays on the recording, which is where the
                // objects the formula cannot fully describe belong.
                const bool locked = (g_lockBox >= 0 && i < touchLock.size()
                                     && touchLock[i] > 0.0
                                     && mask.test(g_lockBox));
                if (locked) objs[i].cx = (double)s0.cx + fx + (double)lockOff;
                objs[i].cy = ncy;
                // --dyndbg <uid> follows one object; --dyndbg -3 prints EVERY
                // formula-driven object, which is what you want when the set
                // shares a group and a position (lv19's seven doors all sit at
                // the same cy, so following one says nothing about which of
                // them the player is actually standing on).
                if (objs[i].uid == g_dynDbg || g_dynDbg == -3)
                    std::printf("fdrv: uid=%d t=%d box=%d autoFireT=%d "
                                "base=%.3f lock=%d off=%.3f cx=%.3f "
                                "fy=%+.4f dcy=%+.4f -> cy=%.4f\n",
                                objs[i].uid, t, fb, ft0, (double)s0.cy,
                                locked ? 1 : 0, (double)lockOff, objs[i].cx,
                                fy, fy - py1, ncy);
                continue;
            }
            const int aA = m ? -1 : autoAnchor[i];   // touch control wins
            if ((!m && aA < 0) || samples[i].empty()) continue;
            const auto& sm = samples[i];
            const DynSample& s0 = sm[0];
            double cx = s0.cx, cy = s0.cy, hw = s0.hw, hh = s0.hh;
            uint8_t onv = s0.on;
            float rotv = s0.rot;   // GD's own getRotation (see turnedBox)
            // Who controls this object this tick, where its first motion is
            // anchored, and the analytic fallback's offset/duration/curve.
            // Touch: fired = this GROUP's mask bit, anchor = the group's entry
            // tick (fireHi), 5 ticks of box->motion latency (measured, lv19
            // door), and the recording is re-timed against the entry tick as it
            // always was. Auto: fired = the level-wide fireT is resolved AND
            // already reached, anchor = fireT, which IS the true first-motion
            // tick -- so the recording is re-timed against its OWN true start,
            // recFire minus the recorder's threshold lag.
            bool fired; int anchor, recAnchor; float fdx, fdy;
            double fdur; int lat, fease; double ferate;
            // The re-timing this object ends up with, for --shiftstat. 0 means
            // the re-timing branch was not taken at all, which is the same thing
            // as "reads the recording on its own clock".
            int shiftUsed = 0;
            if (m) {
                fired = (mask & m).any();
                anchor = fireHi; recAnchor = trigRecFire[i];
                fdx = trigDx[i]; fdy = trigDy[i];
                fdur = trigDur[i]; lat = 5;
                fease = trigEase[i]; ferate = trigErate[i];
                // ...but `fireHi` is ONE scalar for the whole state (trigT is
                // the tick of the LAST box that state entered), while this
                // object may belong to a different door entirely. Every extra
                // box a branch touches re-dated every door it had already
                // opened. When this object HAS a recording, its own first-motion
                // row is the tick it opens -- the live overlay is this plan's
                // own GD replay -- so anchor on that and let shift be 0.
                //
                // Measured on lv22 (2026-08-13): with the touch boxes turned
                // into the rotated frame (see touchFor) the player finally
                // enters box 30 mid-section, and with the old shared anchor
                // that re-dated the WALL the section stands on -- the replay's
                // exit moved from world x=2,143.5 (GD's value) to 1,425.4.
                //
                // g_recPhase additionally says "the anchor was taken while this
                // one was still sliding", which the state's mask cannot express.
                if (trigRecFire[i] >= 0) {
                    if (g_recPhase & m) fired = true;
                    // A DUAL-controlled object (autonomous descent + touch
                    // nudge, the switch band's ceiling): the recording's
                    // motion is the AUTONOMOUS part and plays for EVERY
                    // state. Gated on the touch mask alone, an untouched
                    // state saw the ceiling at its entry position forever --
                    // dynpos printed two beliefs per tick, 367.75 (rest) and
                    // 296.8 (the recorded descent), and the t=2,164-anchored
                    // solve (before the descent's first motion, so no
                    // recPhase either) crossed the sealed band with zero
                    // punches and died in GD at the same t=2,764 as every
                    // other unpunched worldline. (autoAnchor alone missed it:
                    // the ceiling is classified touch-only; recAuto is the
                    // discriminator that caught it.)
                    // The recSelfFire disjunct is the middle one. The first is
                    // dead here (no object reaching this line has autoAnchor >= 0:
                    // autoCtl implies m == 0, and formulaDriven leaves at :708);
                    // it served --noformula, which is gone since the flag
                    // clean-up, and removing it is left to a change of its own.
                    // The recAuto disjunct is untouched.
                    //
                    // Gated on the RECORDING's own first motion: without the tick
                    // test this forces `fired` from t=1 and the fired branch then
                    // interpolates across the leading gap (:931-942) -- measured
                    // on lv22 uid254, where sample[0] (1, 57.000) and sample[1]
                    // (315, 65.940) gave cy=62.552 at t=196.
                    // `trigRecFire[i] >= 0` is guaranteed by the enclosing :754.
                    //
                    // MEASURED AGAINST GD, and that measurement is the scope of
                    // the claim (2026-09-13). The class is nine objects, all in
                    // lv22 (2,094 triggered objects corpus-wide -> 157 controlled
                    // -> 15 whose touch moves nothing -> 9 that also move by
                    // themselves). A fresh recording of the same plan was taken
                    // from the game and held against both arms at the 20-tick
                    // print points around each object's first use: 33 comparison
                    // points, of which this branch puts 33 within 0.02 px of the
                    // game and the branchless form 27. The two differ on 4 of the
                    // 9 objects and 6 of the 33 points, by up to ~148 px, in the
                    // window between the recording's first motion and the late
                    // fire the touch mask alone produces.
                    // WHAT IT DOES NOT SHOW: the three objects the player
                    // actually rides in this corpus (uid 195, 254, 320) come out
                    // the same either way, so the corpus trajectory does not move
                    // -- the 22 replays are byte-identical with and without this.
                    if (autoAnchor[i] >= 0
                        || (i < recSelfFire.size() && recSelfFire[i]
                            && t >= trigRecFire[i])
                        || (i < recAuto.size() && recAuto[i]))
                        fired = true;
                    anchor = recAnchor; lat = 0;
                    // --touchretime (see the flag): this state's own entry.
                    if (fireB && autoAnchor[i] < 0
                        && !(i < recAuto.size() && recAuto[i])
                        && !(i < autoReach.size() && autoReach[i])
                        && !(g_recPhase & m)) {
                        int fb = -1, fbBox = -1;
                        for (int b = 0; b < kTouchBits; ++b)
                            if (((m & mask) & touchBit(b)) && (int)fireB[b] > fb) {
                                fb = (int)fireB[b];
                                fbBox = b;
                            }
                        // --touchretimebox: the object's own delay behind the box's
                        // recorded entry, carried over to this state's entry.
                        const int boxEntry =
                            (fbBox >= 0 && (size_t)fbBox < boxRecEntry.size())
                                ? boxRecEntry[(size_t)fbBox] : -1;
                        // The `- 1` is not a fudge, and the whole lag is worse.
                        // TRIED AND REVERTED (2026-09-20): adding the whole
                        // recLag here, on the argument that the autonomous
                        // branch below subtracts the whole lag from recAnchor
                        // and that lv22 uid1214 still reads the recording one
                        // tick ahead with the flag on. It does land uid1214 on
                        // the row of the same tick (9 of its 12 clamp rows
                        // match at shift 0, against 8 at +1 with the -1), and
                        // lv22's tracking against the reference then FALLS from
                        // 19,343 to 18,596 ticks with 6 -> 10 diverged sections
                        // and the t=2,600 section back to 168 of 400. So the
                        // one tick that is left is the trace's own convention
                        // -- the recorder samples after the whole tick, and the
                        // model's clamp for tick t wants the row labelled t+1
                        // -- not a residual to be removed.
                        if (fb >= 0 && (long long)fb >= g_touchRetimeFrom)
                            anchor = (boxEntry >= 0)
                                ? fb + (trigRecFire[i] - boxEntry)
                                : fb + kTouchRetimeLat
                                      + ((i < recLag.size())
                                             ? std::max(0, recLag[i] - 1) : 0);
                    }
                }
            } else {
                const int f = g_autoTrig[(size_t)aA].fireT;
                fired = (f >= 0 && f <= t);
                anchor = f;
                recAnchor = trigRecFire[i]
                    - (i < autoLag.size() ? autoLag[i] : recLag[i]);
                fdx = autoDx[i]; fdy = autoDy[i];
                fdur = autoDur[i]; lat = 0;
                fease = autoEase[i]; ferate = autoErate[i];
            }
            // --shiftstat, third line: the object's re-timing INPUTS, once, at
            // the tick its controller first counts as fired. This is where the
            // shift is actually decided, and it is the only place that can say
            // WHY -- the touch branch above sets anchor = recAnchor outright, so
            // a touch-controlled object with a recording is 0 by construction and
            // every non-zero shift comes from the autonomous branch, where the
            // model's own computed fireT is held against the recording's first
            // motion (trigRecFire - recLag).
            if (g_shiftStat && fired) {
                if (shiftSaid.size() != objs.size())
                    shiftSaid.assign(objs.size(), 0);
                if (!(shiftSaid[i] & 4)) {
                    shiftSaid[i] |= 4;
                    std::printf("shiftres: uid=%d bucket=%d branch=%s anchor=%d "
                                "recFire=%d recLag=%d shift=%d ease=%d "
                                "rate=%.3f dur=%.3f dx=%.3f dy=%.3f t=%d\n",
                                objs[i].uid, (int)bucket[i],
                                m ? "touch" : "auto", anchor, trigRecFire[i],
                                (i < recLag.size() ? recLag[i] : -1),
                                (anchor >= 0 ? anchor - recAnchor : 0),
                                fease, ferate, fdur, (double)fdx, (double)fdy,
                                t);
                }
            }
            if (fired) {
                // [2026-08-26] A touch the STATE plans that the RECORDING never
                // made. With a recording present the branch below replays it
                // wholesale, so a planned punch changed NOTHING in the model's
                // world -- the switch band's ceiling (lv22 x=3,255..3,675,
                // hanging blocks) kept descending on the recorded (unpunched)
                // curve and the frontier died under it, which is the measured
                // "frontier dies four ticks after touching" of the 32-cap note.
                // GD's real response to the punch, measured on uid18119 with a
                // jump added at t=2,560: the ceiling RE-BASES at its position
                // of the touch tick, nudges up ~10px, and the descent easing
                // restarts from rest (335 at the punch, 338 at t=2,582 where
                // the unpunched curve reads 328). So when the state's own fire
                // tick is far from the recording's motion anchor -- this touch
                // is NOT what the recording shows -- FREEZE the recording at
                // the touch tick and apply the box's analytic chain offset
                // from there. The re-descent stays unmodeled (frozen): the
                // tail is replayed in GD either way, and that replay's own
                // recording carries the true post-punch world into the next
                // iteration. Recordings that ARE the state's touch (lv19/20
                // doors: recAnchor within a beat of the fire) are untouched.
                // Gated on the object ALSO having an auto controller: the
                // switch-band ceiling is auto-descent + touch-nudge, so its
                // recorded motion is the descent and never this punch; a
                // touch-only door's recording IS its own touch, and freezing
                // it at fireHi (the state's LAST box, one scalar for all
                // doors) re-dated lv19's earlier doors off a later box
                // (quick_regress lv19 t=19,800: 400 -> 3 before this gate).
                bool nearBox = false;
                if (m && (mask & m)) {
                    // TouchMask, not uint32_t: both operands are TouchMask and
                    // the loop below runs to kTouchBits, so a narrow local
                    // truncated the high boxes away and then shifted past its
                    // own width for b >= 32. Boxes 32.. always read as "not
                    // touched" -- and at a width of 64 those are exactly the
                    // boxes the wider mask exists to carry.
                    const TouchMask touched = mask & m;
                    for (int b = 0; b < kTouchBits; ++b)
                        if (touched.test(b)
                            && std::fabs((double)g_touchBoxU[b]
                                         - (double)objs[i].cx) < 400.0) {
                            nearBox = true;
                            break;
                        }
                }
                // An object whose recording is a WORLDLINE fact rather than the
                // state's own touch (recAuto, decided at load from the per-box
                // chains) takes the per-box path below; the single-scalar hold
                // here keeps serving the dual-controlled (autoAnchor) class it
                // was measured on.
                const bool recAutoObj = m && i < recAuto.size()
                                        && recAuto[i] != 0;
                const bool ownTouch = m && (mask & m) && nearBox
                    && trigRecFire[i] >= 0
                    && !recAutoObj && autoAnchor[i] >= 0
                    && fireHi > recAnchor + 8;
                if (trigRecFire[i] >= 0 && !autoClosed[i]) {
                    const int shift = (anchor >= 0) ? (anchor - recAnchor) : 0;
                    shiftUsed = shift;
                    int tt = t - shift;
                    // NOT frozen forever: an eternal freeze let ANY grazed box
                    // hold the whole descent open and the anchored solve
                    // crossed the sealed band with zero punches (a phantom
                    // SOLVED at x=24,145 while GD dies at 2,763). The measured
                    // response is "the recording, DELAYED": hold ~60 ticks at
                    // the punch position, then the descent resumes from rest
                    // -- recorded(t-60) reads 285 at t=2,764 where the punched
                    // GD run measures 285.7. Consecutive punches slide the
                    // window (fireHi is the LAST box), which undercounts the
                    // cumulative delay of a punch chain -- the safe side: the
                    // model plans extra punches, and extra yellow hits are
                    // exactly what the mechanic accepts.
                    if (ownTouch && tt > fireHi) {
                        const int hold = 60;
                        tt = (t - shift > fireHi + hold) ? (tt - hold) : fireHi;
                    } else if (recAutoObj && (mask & m)) {
                        // Cumulative per-box delay. GD's measured response to a
                        // punch is "the recording, held ~60 ticks at the punch
                        // position" (rec(t-60) reads 285 at t=2,764 where the
                        // punched run measures 285.7) -- and the +30 the chain
                        // promises does NOT persist (285.7 measured, 315 if it
                        // did), so the punch's whole effect is the delay. Each
                        // touched box that pushes AWAY (dy > 0, the yellow
                        // punches) contributes its own min(60, t - F) window
                        // from its own fire tick -- for a single box this is
                        // the exact hold above. Boxes the anchor arrived with
                        // (F = -1) are already inside the live recording and
                        // contribute nothing.
                        int delay = 0;
                        for (const AutoPart& p : touchParts[i]) {
                            if (p.dy <= 0.f) continue;
                            if (!mask.test(p.trig)) continue;
                            const int F = g_touchFireT[p.trig & (kTouchBits - 1)];
                            if (F < 0 || t <= F) continue;
                            if (std::fabs((double)g_touchBoxU[p.trig & (kTouchBits - 1)]
                                          - (double)objs[i].cx) >= 400.0)
                                continue;
                            delay += std::min(60, t - F);
                        }
                        tt -= delay;
                    }
                    // --shiftdbg <uid>: print this uid's re-timing once. An
                    // instrument for the suspicion that the descent phase of
                    // the t=2776 spike (uid18118) is off from live by tens of
                    // ticks.
                    if (g_shiftDbgUid >= 0 && objs[i].uid == g_shiftDbgUid
                        && !g_shiftDbgDone) {
                        g_shiftDbgDone = true;
                        std::printf("shiftdbg: uid=%d anchor=%d recAnchor=%d "
                                    "shift=%d t=%d tt=%d touch=%d\n",
                                    objs[i].uid, anchor, recAnchor, shift, t,
                                    tt, m ? 1 : 0);
                    }
                    // binary search: these lists are ~100 samples and this runs
                    // once per object per group per tick
                    size_t lo = 0, hi = sm.size();
                    while (lo + 1 < hi) {
                        const size_t mid = (lo + hi) / 2;
                        if (sm[mid].t <= tt) lo = mid; else hi = mid;
                    }
                    const DynSample& s = sm[lo];
                    cx = s.cx; cy = s.cy; hw = s.hw; hh = s.hh; onv = s.on;
                    rotv = s.rot;
                    // [2026-08-22 r104] **Interpolate linearly between rows.**
                    // grouptrace does not write changes under 0.05px, so an
                    // object moving at 0.045px/tick is recorded as "jumps
                    // 0.09px once every 2 ticks". GD moves smoothly, so holding
                    // (the staircase) is a systematic error of up to 0.09px and
                    // **cannot reproduce the tick at which contact breaks, not
                    // even to within 1 tick** (the lv22@6,129 family).
                    // Position and rot only. on (a boolean) and hw/hh stay
                    // stepped.
                    // --touchretime: not across the LEADING gap. Before the
                    // recording's first motion the object is at rest, and the
                    // row after the gap is already the first moved position --
                    // interpolating toward it from t=1 put lv22's block row at
                    // 344.70 one tick before GD moves it (t=6510, shift 5), which
                    // is exactly the landing tick.
                    const bool leadingGap = m
                                            && trigRecFire[i] >= 0
                                            && tt < trigRecFire[i];
                    // Only a step a uniform mover can make, per channel. Until
                    // the newer row's tick every channel stayed within kRecEps
                    // of the older row (else a row would have been written),
                    // so an object moving under kRecEps a tick arrives less
                    // than 2*kRecEps away. A larger step across a gap is an
                    // object that sat still and then jumped or set off fast,
                    // and holding the older row stays within kRecEps of it
                    // the whole time. 4002 platform uid 18238: rows at 20,066
                    // (y 2,068.5) and 20,711 (1,468.5) are a 600 px instant
                    // Move, which this spread over 645 ticks -- the model's
                    // platform hung 81 px above GD's and crushed the player.
                    if (lo + 1 < sm.size() && !leadingGap) {
                        const DynSample& n = sm[lo + 1];
                        const int span = n.t - s.t;
                        if (span > 0 && tt > s.t) {
                            const double u = (double)(tt - s.t) / (double)span;
                            const auto lerp = [u](float a, float b) {
                                const double d = (double)b - (double)a;
                                return std::fabs(d) < 2.0 * kRecEps
                                           ? (float)((double)a + d * u) : a;
                            };
                            cx = lerp(s.cx, n.cx);
                            cy = lerp(s.cy, n.cy);
                            rotv = lerp(s.rot, n.rot);
                        }
                    }
                    // A recording ends where its attempt died, and holding the
                    // last sample freezes a door mid-slide. Measured on lv19
                    // (2026-08-05): the corridor recording stops at t=20,012
                    // with the slide 32 px into its 45, the model rides the
                    // 67%-open slat 12.94 px above where GD rides the OPEN
                    // door, the 1.1x speed portal at (28,163,303) fires 13
                    // ticks apart, and the whole endgame runs 6.8 px of x
                    // adrift (the 27,686 / 29,024 pincer of the 60-iteration
                    // run). When the map knows the full offset, finish the
                    // slide: add the analytic eased INCREMENT from where the
                    // recording ends -- continuous at the seam, and the small
                    // map-vs-real mismatch (the ease fit is within a few
                    // percent) stays exactly as large as it already was.
                    // Move-to-target pieces (offset 0,0 -- the lift) cannot be
                    // completed analytically; those need the driver's nodeath
                    // re-record instead.
                    // For a recAuto object the summed fdx/fdy is opposing
                    // chains added together, but the slide still has to be
                    // finished: the band's recording is a DEAD attempt's
                    // (grouptrace stops ~25 ticks after the seal kills the
                    // recorder at t=2,764), and holding its last row left the
                    // ceiling at 260.59 forever -- a 13 px slit over the lane
                    // that GD closes, which the anchored solve threaded for
                    // yet another no-punch phantom. The autonomous descent's
                    // own chain is on file per box (the red -840/1005.6t tail
                    // is the same movers), so complete with the largest part
                    // whose dy agrees with the recorded motion's direction.
                    double bdx = fdx, bdy = fdy, bdur = fdur;
                    int bease = fease; double berate = ferate;
                    if (recAutoObj) {
                        bdur = 0.0;
                        const double dirY = (double)s.cy - (double)s0.cy;
                        float best = 0.f;
                        for (const AutoPart& p : touchParts[i])
                            if ((double)p.dy * dirY > 0.0
                                && std::fabs(p.dy) > best) {
                                best = std::fabs(p.dy);
                                bdx = p.dx; bdy = p.dy; bdur = p.dur;
                                bease = p.ease; berate = p.erate;
                            }
                    }
                    if (lo + 1 == sm.size() && tt > s.t && bdur > 0) {
                        const double full = std::hypot((double)bdx, (double)bdy);
                        const double done = std::hypot((double)s.cx - (double)s0.cx,
                                                       (double)s.cy - (double)s0.cy);
                        if (full > 0.5 && done < full - 0.5) {
                            auto ease = [&](double u) {
                                return gdEase(bease, berate, u);
                            };
                            const double uEnd =
                                (double)(s.t - recAnchor) / bdur;
                            const double uNow =
                                (double)(tt - recAnchor) / bdur;
                            // normalized so the terminal position is EXACTLY
                            // rest + offset (the measured open position),
                            // whatever small phase error the recording ended
                            // with; the increment form overshot by that error
                            const double eEnd = ease(uEnd);
                            if (eEnd < 0.999) {
                                const double de =
                                    (ease(uNow) - eEnd) / (1.0 - eEnd);
                                cx += ((double)s0.cx + (double)bdx - (double)s.cx) * de;
                                cy += ((double)s0.cy + (double)bdy - (double)s.cy) * de;
                            }
                        }
                    }
                    // ...and the planned touch's own chain, applied FROM the
                    // frozen base (the measured re-base + nudge; the note at
                    // ownTouch above). 5 = the measured box->motion latency.
                    if (ownTouch) {
                        double u = 1.0;
                        if (fdur > 0) u = (double)(t - fireHi - 5) / fdur;
                        if (u > 0.0) {
                            const double e = gdEase(fease, ferate, u);
                            cx += fdx * e;
                            cy += fdy * e;
                        }
                    } else if (recAutoObj && (mask & m)) {
                        // A touched box that pushes TOWARD the player (dy < 0,
                        // the red skulls) is applied as a step: the user-stated
                        // and measured mechanic is an immediate slam, and the
                        // chain's 1005.6-tick easing belongs to the autonomous
                        // descent, not to this. A state that punches red sees
                        // the seal at once and dies in the model exactly where
                        // GD kills it.
                        for (const AutoPart& p : touchParts[i]) {
                            if (p.dy >= 0.f) continue;
                            if (!mask.test(p.trig)) continue;
                            const int F = g_touchFireT[p.trig & (kTouchBits - 1)];
                            if (F < 0 || t < F + 5) continue;
                            if (std::fabs((double)g_touchBoxU[p.trig & (kTouchBits - 1)]
                                          - (double)objs[i].cx) >= 400.0)
                                continue;
                            cx += p.dx;
                            cy += p.dy;
                        }
                    }
                    // The other half of the g_rotSplit decomposition. The
                    // samples carry `entry_C + R(theta)*rel` -- the orbit about
                    // a STATIONARY centre -- and the loader subtracted the
                    // centre's own translation out to get there ("recorded =
                    // orbit + the centre's own translation", at the fit check).
                    // Nothing added it back: the one path that would is behind
                    // g_rotCompute, which is false and which no flag sets, so
                    // every split object has been running without its
                    // translation since 7c6daa1. The split refuses any object
                    // that does not share its move controllers with its centre,
                    // so this object's own autoParts IS `C(t) - entry_C`, each
                    // controller on its own crossing.
                    if (i < rotSplit.size() && rotSplit[i]) {
                        for (const AutoPart& p : autoParts[i]) {
                            const int f = g_autoTrig[(size_t)p.trig].fireT;
                            if (f < 0 || t < f) continue;
                            const double e = (p.dur > 0.0)
                                ? gdEase(p.ease, p.erate, (double)(t - f) / p.dur)
                                : 1.0;
                            cx += p.dx * e;
                            cy += p.dy * e;
                        }
                    }
                    if (g_dynDbg == objs[i].uid && (t % 40 == 0))
                        std::printf("armdbg t=%d uid=%d arm=recording split=%d "
                                    "parts=%zu cx=%.3f cy=%.3f\n",
                                    t, objs[i].uid,
                                    (int)(i < rotSplit.size() ? rotSplit[i] : 0),
                                    autoParts[i].size(), cx, cy);
                } else {
                    // The closed form. Either there is no recording at all (the
                    // door nobody has opened yet) or --trigclosed is on and this
                    // object's recording AGREES with the formula, in which case
                    // the formula is the better source: it does not end where
                    // some attempt died and it does not carry another run's
                    // phase. `on` and the size still come from the recording --
                    // a toggle is not a move and has no closed form here.
                    // ...and if the object is locked to the player, its x is
                    // THIS run's player x, which is the whole reason a recording
                    // cannot serve it (see TrigCtl::lockTicks).
                    if (aA >= 0 && autoLockTrig[i] >= 0
                        && g_autoTrig[(size_t)autoLockTrig[i]].fireT >= 0) {
                        AutoTrig& A = g_autoTrig[(size_t)autoLockTrig[i]];
                        // The lock starts on the CROSSING, one tick before an
                        // eased move would (measured, 0.002 px over 2,400
                        // samples), and runs for its own duration. `lockLastX`
                        // trails the player while the window is open so that
                        // once it closes the object holds where the player left
                        // it -- the same running-assignment trick fireT uses,
                        // and like fireT it is level-wide: the last group of a
                        // tick wins. States within a tick differ in x by a
                        // speed group at most, which is the same approximation
                        // gFire already makes for doors.
                        const int lockT0 = A.fireT - A.delay;
                        const int lockEnd = lockT0 + (int)autoLock[i];
                        if (t >= lockT0 && t <= lockEnd) {
                            A.lockLastX = px;
                            cx += px - A.fireX;
                        } else if (t > lockEnd) {
                            cx += A.lockLastX - A.fireX;
                        }
                    }
                    if (trigRecFire[i] >= 0 && sm.size() > 1) {
                        const int shift = (anchor >= 0) ? (anchor - recAnchor) : 0;
                        const int tt = t - shift;
                        size_t lo = 0, hi = sm.size();
                        while (lo + 1 < hi) {
                            const size_t mid = (lo + hi) / 2;
                            if (sm[mid].t <= tt) lo = mid; else hi = mid;
                        }
                        hw = sm[lo].hw; hh = sm[lo].hh; onv = sm[lo].on;
                        rotv = sm[lo].rot;
                    }
                    if (recAutoObj) {
                        // No recording yet (first iteration). The summed
                        // offset is opposing chains added together, so play
                        // each TOUCHED box's own part instead. The autonomous
                        // descent is unknowable here (its starter is a
                        // collision trigger the dump cannot time); the next
                        // iteration's recording carries it.
                        for (const AutoPart& p : touchParts[i]) {
                            if (!mask.test(p.trig)) continue;
                            const int F = g_touchFireT[p.trig & (kTouchBits - 1)];
                            if (F < 0) continue;
                            double u = 1.0;
                            if (p.dur > 0) u = (double)(t - F - 5) / p.dur;
                            if (u <= 0.0) continue;
                            const double e = gdEase(p.ease, p.erate, u);
                            cx += p.dx * e;
                            cy += p.dy * e;
                        }
                    } else if (m || autoParts[i].empty()) {
                        // touch trigger (one box, one summed offset), or an
                        // autonomous object with no move at all (toggle only)
                        double u = 1.0;
                        if (anchor >= 0 && fdur > 0)
                            u = (double)(t - anchor - lat) / fdur;
                        const double e = gdEase(fease, ferate, u);
                        cx += fdx * e;
                        cy += fdy * e;
                    } else {
                        // Superposition: every controller on its own clock.
                        if (g_dynDbg == objs[i].uid && (t % 40 == 0))
                            for (const AutoPart& p : autoParts[i])
                                std::printf("armdbg   part t=%d uid=%d trig=%d "
                                            "fireT=%d d=(%.1f,%.1f) dur=%.2f\n",
                                            t, objs[i].uid, p.trig,
                                            g_autoTrig[(size_t)p.trig].fireT,
                                            (double)p.dx, (double)p.dy, p.dur);
                        for (const AutoPart& p : autoParts[i]) {
                            const int f = g_autoTrig[(size_t)p.trig].fireT;
                            if (f < 0 || t < f) continue;
                            const double e = (p.dur > 0.0)
                                ? gdEase(p.ease, p.erate, (double)(t - f) / p.dur)
                                : 1.0;
                            cx += p.dx * e;
                            cy += p.dy * e;
                        }
                    }
                    // DIAGNOSTIC (not for landing): which branch served this
                    // object, and what its parts were clocked by.
                    if (g_dynDbg == objs[i].uid && (t % 40 == 0))
                        std::printf("armdbg t=%d uid=%d branch=%s m=%u "
                                    "parts=%zu recAutoObj=%d anchor=%d "
                                    "cy=%.3f\n", t, objs[i].uid,
                                    recAutoObj ? "recAuto"
                                        : (m || autoParts[i].empty())
                                            ? "collapsed" : "superpos",
                                    (unsigned)m.word(0), autoParts[i].size(),
                                    (int)recAutoObj, anchor, cy);
                    if (g_dynDbg == objs[i].uid && t == 11720)
                        for (const AutoPart& p : autoParts[i])
                            std::printf("armdbg   part trig=%d uid=%d cx=%.1f "
                                        "fireT=%d d=(%.2f,%.2f) dur=%.1f\n",
                                        p.trig, g_autoTrig[(size_t)p.trig].uid,
                                        g_autoTrig[(size_t)p.trig].cx,
                                        g_autoTrig[(size_t)p.trig].fireT,
                                        p.dx, p.dy, p.dur);
                }
            }
            // --shiftdbg <uid> also samples the object's EVALUATED position
            // every 20 ticks -- the belief the kill tests actually see, which
            // no amount of reasoning about the composition rules substitutes
            // for (the switch-band phantom survived three composition fixes
            // that were all aimed at the wrong mechanism).
            // ---- the ROTATION, after whatever produced the translation ------
            // A Rotate carries its group around a centre object, which no
            // offset describes: 806 of lv21's turned objects and 264 of lv22's
            // have no recording at all, so until this ran the model held them
            // PERFECTLY STILL while GD swung them. Applied here, after the
            // branches above, so it composes with any of them rather than
            // being duplicated into each.
            //
            // The centre is evaluated from its own entry plus its own
            // controllers rather than read out of objs[centreIdx]: this loop
            // has no order guarantee, so the centre may not have been placed
            // yet on this tick.
            //
            // Closed form, not the per-tick recurrence. The recurrence with a
            // float store is 0.0060 px against GD and this is 0.0142 px (see
            // RotSpec), but the recurrence needs a sequential carry and this
            // path is idempotent and may be entered with a jumped tick. 0.0142
            // against the 1.65-2.18 px a re-timed recording leaves is the
            // trade; the remaining eight thousandths wait for a table.
            if (g_rotCompute && !g_rotSpec.empty()) {
                const auto rs = g_rotSpec.find(objs[i].uid);
                if (rs != g_rotSpec.end() && rs->second.anchor >= 0
                    && rs->second.centreIdx >= 0) {
                    const RotSpec& R = rs->second;
                    const int f = g_autoTrig[(size_t)R.anchor].fireT;
                    if (f >= 0 && t >= f) {
                        const size_t ci = (size_t)R.centreIdx;
                        double ccx, ccy;
                        if (samples[ci].size() > 1) {
                            // The centre has a recording of its own, and seek()
                            // has already placed it for this tick. Use it.
                            //
                            // Deriving it analytically instead was WRONG and
                            // deathref caught it: a centre whose motion is
                            // recorded rather than trigger-controlled has no
                            // autoParts, so the analytic form pinned it at its
                            // entry and the whole orbit hung off the wrong
                            // point. lv21_t13304 went PASS -> FAIL (died -436)
                            // -- an over-kill, a rotated hazard swung through
                            // the player because its centre never moved.
                            ccx = objs[ci].cx;
                            ccy = objs[ci].cy;
                        } else {
                            ccx = samples[ci][0].cx;
                            ccy = samples[ci][0].cy;
                            for (const AutoPart& p : autoParts[ci]) {
                                const int cf = g_autoTrig[(size_t)p.trig].fireT;
                                if (cf < 0 || t < cf) continue;
                                const double e = (p.dur > 0.0)
                                    ? gdEase(p.ease, p.erate,
                                             (double)(t - cf) / p.dur)
                                    : 1.0;
                                ccx += p.dx * e;
                                ccy += p.dy * e;
                            }
                        }
                        // sign: GD's positive turn is clockwise on screen, the
                        // opposite of a y-up matrix. Measured -1 on both
                        // subjects (lv21 uid15367, lv22 uid254).
                        const double th = -R.total
                            * gdEase(R.ease, R.erate, (double)(t - f) / R.durT)
                            * 3.14159265358979 / 180.0;
                        const double c = std::cos(th), s = std::sin(th);
                        const double rx = cx - ccx, ry = cy - ccy;
                        cx = ccx + c * rx - s * ry;
                        cy = ccy + s * rx + c * ry;
                    }
                }
            }
            if (g_shiftDbgUid >= 0 && objs[i].uid == g_shiftDbgUid
                && t % 20 == 0)
                std::printf("dynpos: uid=%d t=%d cx=%.2f cy=%.2f on=%d\n",
                            objs[i].uid, t, cx, cy, (int)onv);
            objs[i].cx = cx; objs[i].cy = cy; objs[i].hw = hw; objs[i].hh = hh;
            // dcy from the FINAL analytic position, not the raw samples (see
            // prevCy's declaration: the recorder skips sub-epsilon rows and
            // the raw dcy reads 0 on those ticks while the face still moves).
            // Only on a 1-tick advance -- an anchor jump keeps seek's
            // row-based value, same reasoning as seek's step1 gate.
            if (lastStep1 && i < prevCy.size())
                objs[i].dcy = (double)cy - (double)prevCy[i];
            // If the recording says "gone by this tick", the analytic side must
            // not bring it back. The live recording is this very run's own GD
            // replay, so `on` is the truth there. Returning sm[0] as it was here
            // left the block GD switched off at t=10,512 (lv22 uid11470) standing
            // in the model, and the player sliding down the corridor died of a
            // "side collision" at t=11,359.
            if (cur[i] < sm.size() && sm[cur[i]].t <= t && sm[cur[i]].on == 0)
                onv = 0;
            // ...and the mirror for the ON direction, for objects nothing
            // MOVES (a pure toggle). The shifted search above re-times the
            // recording against the controller's predicted firing tick -- the
            // right thing for a door's motion, but an autonomous TOGGLE has no
            // re-timing basis: its "anchor" is the FIRST x-crossing while the
            // crossing that actually fires is the same unsolved gate 2899 has
            // (lv22's uid 6442 fires on its THIRD crossing of x=15,765,
            // together with the 2899 pair). The live recording is this plan's
            // own GD replay, so for a no-move object its unshifted clock is
            // the only truth. Without this, lv22's ship portal uid 6440
            // (group 309, toggled OFF at t=10,116 / ON at 14,225) read the
            // pre-toggle sample through a +1,2xx shift and NEVER fired -- the
            // model kept the cube falling past x=15,785 where GD flies a ship.
            {
                bool noMove = fdx == 0.f && fdy == 0.f;
                for (const AutoPart& p : autoParts[i])
                    if (p.dx != 0.f || p.dy != 0.f) { noMove = false; break; }
                // PORT/SPEED only. The first cut applied this to every no-move
                // object and lv22's frame-3 corridor (t=11,000 segment, the
                // uid 11470 neighbourhood) broke: the regress follow shrank
                // 400 -> 351 and two solid-support families appeared. The
                // solids' interplay with the shifted read is validated the
                // other way (the standing force-off above), so only the
                // interactive classes with a measured case move to the
                // unshifted clock.
                if (!m && noMove
                    && (bucket[i] == PORT || bucket[i] == SPEED)
                    && cur[i] < sm.size() && sm[cur[i]].t <= t) {
                    uint8_t v = sm[cur[i]].on;
                    // Re-ENABLING takes effect the tick AFTER the recorded row
                    // (measured: uid 6440's ON row is t=14,225 -- the toggle
                    // itself ran during 14,224 -- and GD's portal fires during
                    // 14,226, one tick later; the model firing at 14,225 came
                    // out -1.404 where GD has -1.512). The OFF direction stays
                    // on the row's own tick, same as the standing rule above
                    // (validated on uid 11470).
                    if (v && sm[cur[i]].t == t && cur[i] > 0
                        && !sm[cur[i] - 1].on)
                        v = 0;
                    onv = v;
                }
            }
            // --activators: this object's on/off is its switches', not the recording's.
            if (i < onEv.size() && !onEv[i].empty())
                onv = resolveOn(onInit[i] != 0, onEv[i].data(), onEv[i].size(), mask, fireB, t)
                          ? 1 : 0;
            on[i] = onv;
            if (g_dynDbg == objs[i].uid)
                std::printf("dyntrig t=%d uid=%d fired=%d m=%08x cx=%.3f "
                            "cy=%.3f hw=%.1f hh=%.1f on=%d\n",
                            t, objs[i].uid, (int)fired, (unsigned)m.word(0), cx, cy,
                            hw, hh, (int)onv);
            // --shiftstat: `shiftstat:` once per object the first time it is
            // placed (this is the DENOMINATOR -- the objects a collision
            // consumes; decoration never reaches Dynamics at all), and
            // `shiftnz:` the first time its re-timing is non-zero.
            //
            // TWO LINES ON PURPOSE. The first placement happens long before the
            // controlling trigger fires, and until it does `anchor` is -1 and
            // the shift reads 0 -- sampling only there says "every object is at
            // shift 0", which is how the first version of this counter reported
            // 2,094 of 2,094 while --shiftdbg had already shown uid 434 at
            // shift=1. An object that never prints a `shiftnz:` line is the
            // real shift-0 case.
            if (g_shiftStat) {
                if (shiftSaid.size() != objs.size())
                    shiftSaid.assign(objs.size(), 0);
                if (!(shiftSaid[i] & 1)) {
                    shiftSaid[i] |= 1;
                    std::printf("shiftstat: uid=%d bucket=%d t=%d\n",
                                objs[i].uid, (int)bucket[i], t);
                }
                if (shiftUsed != 0 && !(shiftSaid[i] & 2)) {
                    shiftSaid[i] |= 2;
                    std::printf("shiftnz: uid=%d bucket=%d shift=%d t=%d "
                                "anchor=%d recAnchor=%d\n",
                                objs[i].uid, (int)bucket[i], shiftUsed, t,
                                anchor, recAnchor);
                }
            }
            turnedBox(objs[i], bucket[i], (double)rotv,
                      i < everRot.size() && everRot[i] != 0);
            // a moving SLOPE carries its surface line (same rule as seek())
            if (objs[i].slope) {
                const double dy = cy - (double)baseCy[i];
                objs[i].sy0 = (double)baseSy0[i] + dy;
                objs[i].sy1 = (double)baseSy1[i] + dy;
            }
        }
        };
        forRuns(par, samePure ? nNonPure : objs.size(),
                [&](size_t b, size_t e) { place(b, e, false); });
        if (par) place(0, objs.size(), true);
    }

    // Put every object where it was at tick t. Cursors move forward with the
    // layer loop, so this is O(1) amortised; a backwards jump (--start, or the
    // witness resim starting over) rewinds and re-scans, which happens once.
    //
    // ROW t IS THE RIGHT ROW, and this is the note that stops the next person
    // re-deriving otherwise. GJBaseGameLayer::update runs processCommands
    // (0x238090) -> processMoveActionsStep (0x238388) -> checkCollisions
    // (0x23846e), and the mod's recorder writes its row inside the FIRST of
    // those, so the row written as T holds the objects from before that update's
    // move. It is tempting to conclude that a collision therefore saw row T+1.
    // It did not: the player state that collision produces does not appear in
    // the dump until row T+2 either, so the two offsets cancel and the pairing
    // is (player row T, object row T).
    //
    // Measured twice on 2026-09-03, both against the pairing being anything else
    // (a --dynphase flag that shifted the row by one was built, run and reverted):
    //   * lv19 t=20,601. A ball rides a surface descending 0.062 px/tick
    //     (uid 14011, cy 210.178, h 15): row t gives 210.178 + 7.5 + 15 =
    //     232.678, which is GD's dump to the last digit, for eleven ticks. The
    //     shifted row drops the support on the first tick and falls for five.
    //   * lv22 uid 434's firing edge at t=777, swept in GD at 0.05 px (the
    //     earlier 0.5 px sweep could not tell the two apart, which is how the
    //     shifted row briefly looked better):
    //         dy=0     GD (35.502, 35.552)   row t: 35.541 INSIDE   row t+1: 35.859
    //         dy=43.09 GD (32.052, 32.102)   row t: 32.130 (0.028)  row t+1: 31.616 (0.44)
    // The 0.028 px that is left at dy=43.09 is a residual of the portal
    // predicate, not of the row: see the two-gate contact shape.
    void seek(int t) {
        if (objs.empty() || t == lastT) return;
        // Every object is about to be rewritten, so whatever applyTriggers placed
        // is stale from here on (see pureEpoch).
        ++seekEpoch;
        if (byBucketN != objs.size()) rebuildBuckets();
        const bool back = (t < lastT);
        // dcy is PER-TICK surface motion, so the position-difference form is
        // only meaningful when this seek advanced exactly one tick. The FIRST
        // seek of an anchored replay jumps from the load position (lastT=-1)
        // straight to t0, and the difference was the platform's WHOLE journey:
        // lv19 t=21,800 anchored with dcy=136, which put every mover inside
        // the `0.6 + |dcy|` support tolerance and seated the ship on a lift
        // 91 px overhead. A jump (either direction) falls back to the
        // recording's own consecutive rows, same as the backward branch.
        const bool step1 = !back && (t == lastT + 1);
        lastStep1 = step1;
        lastT = t;
        // Each object reads its own recording and writes its own slots, so the
        // loop splits (forRuns) -- unless --dyndbg could print from it.
        forRuns(g_dynDbg == -1 && !anyUidM1, objs.size(), [&](size_t b, size_t e) {
        for (size_t i = b; i < e; ++i) {
            const auto& sm = samples[i];
            if (sm.empty()) continue;
            size_t c = back ? 0 : cur[i];
            while (c + 1 < sm.size() && sm[c + 1].t <= t) ++c;
            cur[i] = c;
            const DynSample& s = sm[c];
            // per-tick y motion of the SURFACE itself (see Obj::dcy).
            // On a BACKWARDS seek (a --start anchor, or the witness resim
            // starting over) there is no previous position to subtract, and
            // zeroing it costs the rider its first step: the ride only fires
            // when `dcy != 0`, so a player anchored mid-ride skips one surface
            // step and stays that much behind for the whole ride. Measured on
            // lv22's ball corridor (2026-08-14): the anchored resim followed
            // 166 ticks and then reported dy=-1.53 growing 0.17/tick with
            // dvy=+0.0000 -- one missed step of a floor that sinks at exactly
            // that rate. The recording knows the answer: when the sample landed
            // on THIS tick and the one before it is the tick before, their
            // difference IS the per-tick motion.
            // last FINAL position before this tick's placement overwrites it
            // (applyTriggers reads it to rebuild dcy for controlled objects)
            if (i < prevCy.size())
                prevCy[i] = step1 ? objs[i].cy : (float)s.cy;
            objs[i].dcy =
                step1 ? ((double)s.cy - (double)objs[i].cy)
                      : (c > 0 && sm[c].t == t && sm[c - 1].t == t - 1)
                            ? ((double)sm[c].cy - (double)sm[c - 1].cy)
                            : 0.0;
            objs[i].cx = s.cx; objs[i].cy = s.cy;
            // --recinterp: between two rows at most kRecInterpGap ticks apart,
            // the object was moving the whole time -- the recorder simply did
            // not write the ticks whose step was under its 0.05 px threshold
            // (grouptrace kEps). Holding the older row made a slow mover step
            // every other tick: lv22 uid5825 at t=6,118..6,124 has rows at
            // 6,118 / 6,119 / 6,121 / 6,123 while GD's rider moves every tick.
            // A longer gap is a real stop and keeps the hold.
            if (s.t < t && c + 1 < sm.size()
                && sm[c + 1].t - s.t <= kRecInterpGap) {
                const DynSample& n = sm[c + 1];
                const double u = (double)(t - s.t) / (double)(n.t - s.t);
                objs[i].cx = (float)((double)s.cx + u * ((double)n.cx - (double)s.cx));
                objs[i].cy = (float)((double)s.cy + u * ((double)n.cy - (double)s.cy));
                if (step1 && i < prevCy.size())
                    objs[i].dcy = (double)objs[i].cy - (double)prevCy[i];
            }
            objs[i].hw = s.hw; objs[i].hh = s.hh;
            on[i] = s.on;
            turnedBox(objs[i], bucket[i], (double)s.rot,
                      i < everRot.size() && everRot[i] != 0);
            if (objs[i].slope) {
                const double dy = (double)objs[i].cy - (double)baseCy[i];
                objs[i].sy0 = (double)baseSy0[i] + dy;
                objs[i].sy1 = (double)baseSy1[i] + dy;
            }
            if (g_dynDbg == objs[i].uid)
                std::printf("dynseek t=%d uid=%d cur=%zu/%zu cy=%.3f "
                            "(sample t=%d) at=%p\n",
                            t, objs[i].uid, c, sm.size(), (double)objs[i].cy,
                            s.t, (const void*)&objs[i]);
        }
        });
    }
    // A MOVING object that is also being TURNED. The recording's hw/hh are half
    // the axis-aligned BOUND, which for a turned box is not the shape at all --
    // and the model was using it as the hitbox.
    //
    // Measured on lv22 (2026-08-13): the spider portal uid 434 (really 34x86) is
    // turned by a trigger from -2.45 deg at t=768 to -39.2 deg at t=810, so its
    // recorded bound grows 37.6x87.4 -> 80.7x88.1. The model fired it THREE
    // TICKS early, which put the whole rest of the run 66 px off in y and was the
    // first divergence on both the seeded clear and every runR3/runR4 plan.
    // A 2-D injection sweep (py/portal_sweep2.py) pinned the real region: at
    // -26 deg only 1 of 168 grid points inside the bound actually fires.
    //
    // The nominal size comes back out of the bound and the angle (the same
    // inversion Obj::oriented already documents for static rotations):
    //   a = W|c| + H|s| , b = W|s| + H|c|  ->  W = (a c - b s)/cos2t , etc.
    // Only PORTALS get this: `oriented` is wired to the portal test and tuned
    // there, and a 90-degree multiple leaves the bound correct anyway.
    static void turnedBox(Obj& o, uint8_t bucketOf, double rotDeg,
                          bool everRot = false) {
        if (bucketOf != PORT) return;
        o.rot = rotDeg;
        // [2026-08-18] **Do not throw away the real box built from w0/h0 at
        // load.** This used to drop oriented to 0 on every seek and rebuild it
        // by inverting the bounding box, and since the inversion does not work
        // near 45 degrees (|cos2θ| < 0.1), grouped portals alone were **firing
        // on the bounding box**. Measured on lv21 uid24194 (id111 UFO portal,
        // rot=43, w0/h0 = 34x86, bound 167x172): GD switches at t=18,087
        // (x=23,929), but the model did so at the bound's left edge at t=18,075
        // (x=23,910) -- 12 ticks / 19px early. Turning **does not change the
        // box's size**, so only the angle needs to be redrawn.
        if (o.oriented) {
            const double th2 = rotDeg * 3.14159265358979 / 180.0;
            o.rc = std::cos(-th2); o.rs = std::sin(-th2);
            return;
        }
        const double om = std::fabs(std::fmod(rotDeg, 90.0));
        // [2026-08-25] A portal a trigger ROTATES is "turned" in GD's sense for
        // the whole run, even while its angle still reads 0 -- and GD's turned
        // branch tests the PLAYER's oriented box too, which an axis-aligned
        // AABB test throws away. That is a real difference: a cube is always
        // spinning, so the window it presents to the portal is not a square.
        //
        // Measured on lv22's spider portal uid 1156 (2085,255, 34x86, static
        // rot 0, rotated by its group from t=1,612). The model fired it at
        // t=1,582 and GD at t=1,583, leaving a CONSTANT 0.087/tick vy error
        // (0.216 cube gravity vs 0.129 spider) that never washes out -- lv22
        // cold has been stuck behind it. Injection sweep at t=1,582, x fixed at
        // 2,053.519, varying only y (GD fires / does not):
        //     y=213.874 FIRES    y=209.000 FIRES    y=208.000 FIRES
        //     y=207.500 no       y=201.138 no       y=199.472 no
        // A plain AABB cannot produce that boundary at ANY half-width (the same
        // y=201.138 fires one tick later at x=2,054.817), but the two-box SAT
        // with the player's box turned by its rotation TWO TICKS BACK -- which
        // is exactly the `pRotHere` the portal loop already computes -- puts the
        // edge at y=208.00 against an observed bracket of (207.500, 208.000].
        // Four more points (including the t=1,583 fire at margin 0.075) fit the
        // same line.
        //
        // Only the near-0 case is taken: at ~90 degrees the bound's halves are
        // the box's SWAPPED, and no measurement covers that.
        // [2026-08-25] OFF BY DEFAULT (--rotport). The measurement above stands,
        // but switching it on cost lv22's cold run 41% -> 15% (x=9,827 ->
        // x=3,689, and the DP calls went 8s -> 94s): with 133 of lv22's moving
        // objects rotate-targeted, every one of them starts testing against the
        // player's turned box, and the route landscape that comes out is worse
        // even though each individual verdict is closer to GD. The measured
        // boundary is also contaminated by something this note cannot yet
        // separate -- GD fires this portal at t=1,583 on one attempt and
        // t=1,582 on another with the SAME plan, so the object's phase carries
        // across attempts. Re-open it with a per-object gate, not a global one.
        if (g_rotPort && om <= 0.5 && everRot && o.hw > 0.5 && o.hh > 0.5) {
            o.oriented = 1;
            o.ohw = o.hw; o.ohh = o.hh;   // axis aligned: the bound IS the box
            const double th0 = rotDeg * 3.14159265358979 / 180.0;
            o.rc = std::cos(-th0); o.rs = std::sin(-th0);
            return;
        }
        if (om <= 0.5 || om >= 89.5) return;   // axis aligned: bound == shape
        const double th = rotDeg * 3.14159265358979 / 180.0;
        const double c = std::fabs(std::cos(th)), s = std::fabs(std::sin(th));
        const double det = c * c - s * s;      // cos 2t
        if (std::fabs(det) < 0.1) return;      // near 45 deg: not invertible
        const double W = ((double)o.hw * c - (double)o.hh * s) / det;
        const double H = ((double)o.hh * c - (double)o.hw * s) / det;
        if (W <= 0.5 || H <= 0.5) return;
        o.oriented = 1;
        o.ohw = W; o.ohh = H;
        o.rc = std::cos(-th); o.rs = std::sin(-th);
    }
    // Dynamic objects cannot live in the sorted-by-cx index, so their window is
    // a linear scan. It is bounded by the number of moving objects in the level
    // (1,731 at worst) and runs once per layer, not once per state.
    // Turn every moving object into a gameplay frame (see turnObj / frameLevel).
    // `collect` is a linear scan and the parallel arrays are indexed by position,
    // so nothing has to be re-sorted -- only the geometry and the OFFSETS turn.
    // Offsets are vectors, so they take the same linear map without the
    // translation part, which toFrame already is (a pure rotation about 0).
    // Not handled: lockToPlayerX (autoLock). A lock copies the player's WORLD x
    // onto the object, which in a turned frame is a v, not a u -- lv22's two
    // locks are both in the un-rotated switch band, so this stays a documented
    // hole rather than a guess.
    void turn(int f) {
        if ((f & 3) == 0) return;
        auto rotVec = [&](float& dx, float& dy) {
            double u, v;
            toFrame(f, (double)dx, (double)dy, u, v);
            dx = (float)u; dy = (float)v;
        };
        for (size_t i = 0; i < objs.size(); ++i) {
            for (DynSample& s : samples[i]) {
                double u, v;
                toFrame(f, (double)s.cx, (double)s.cy, u, v);
                s.cx = (float)u; s.cy = (float)v;
                if (f & 1) std::swap(s.hw, s.hh);
            }
            turnObj(objs[i], f);
            baseCy[i] = objs[i].cy;
            baseSy0[i] = (float)objs[i].sy0;
            baseSy1[i] = (float)objs[i].sy1;
            rotVec(trigDx[i], trigDy[i]);
            rotVec(autoDx[i], autoDy[i]);
            for (AutoPart& p : autoParts[i]) rotVec(p.dx, p.dy);
            for (AutoPart& p : touchParts[i]) {
                rotVec(p.dx, p.dy);
                // --movetarget: the destination turns with the frame, and in an
                // odd frame a one-axis move is on the other axis.
                rotVec(p.tdx, p.tdy);
                if ((f & 1) && (p.tmode == 2 || p.tmode == 3))
                    p.tmode = (uint8_t)(5 - p.tmode);
            }
        }
        std::fill(cur.begin(), cur.end(), (size_t)0);
        lastT = -1;
        ++seekEpoch;
    }

    void collect(uint8_t b, double x0, double x1,
                 std::vector<const Obj*>& out) const {
        // Same objects, same order, fewer visits (see byBucket). --dyndbg prints
        // one line per object of every bucket, so it keeps the full walk.
        if (g_dynDbg < 0 && byBucketN == objs.size() && b < byBucket.size()) {
            for (const uint32_t i : byBucket[b]) {
                if (!on[i]) continue;
                const Obj& o = objs[i];
                if (o.cx + o.hw < x0 || o.cx - o.hw > x1) continue;
                out.push_back(&o);
            }
            return;
        }
        for (size_t i = 0; i < objs.size(); ++i) {
            const Obj& o = objs[i];
            if (g_dynDbg >= 0 && o.uid == g_dynDbg)
                std::printf("dyncollect uid=%d b=%d/%d on=%d cx=%.3f hw=%.3f "
                            "win=[%.1f,%.1f] -> %s\n",
                            o.uid, (int)bucket[i], (int)b, (int)on[i], o.cx,
                            o.hw, x0, x1,
                            (bucket[i] != b || !on[i])          ? "SKIP(bucket/on)"
                            : (o.cx + o.hw < x0 || o.cx - o.hw > x1)
                                ? "SKIP(window)" : "in");
            if (bucket[i] != b || !on[i]) continue;
            if (o.cx + o.hw < x0 || o.cx - o.hw > x1) continue;
            out.push_back(&o);
        }
    }
};

}  // namespace dp



#pragma once
#include "dp/slopes.hpp"

namespace dp {

// ---- WHICH LINE LAST WROTE c.vy ------------------------------------------
//
// Twice now a value read off a fixup record has been blamed on a site chosen
// for having the right shape, and twice the arithmetic killed it (the downhill
// release at :8255 and the robot jump at :3209). Choosing is the weak step, so
// stop choosing: let the writer name itself.
//
// AS AN LVALUE WRAPPER, NOT AN EXTRA STATEMENT. Appending `VYW();` after each
// assignment would silently change every braceless `if (cond) c.vy = X;` into a
// conditional assignment followed by an unconditional call -- and it would
// still compile, still leave c.vy correct, and still pass a byte-identical
// record comparison. C++ keeps the comma operator's right operand an lvalue, so
//     VYSET(c.vy) = expr;
// is the same single statement it always was, whatever surrounds it and however
// many lines the right-hand side spans.
//
// __LINE__ rather than a hand-kept id table: a table is a second copy of the
// truth and drifts from it. Line numbers are resolved by quoting the commit.
//
// THREAD_LOCAL, this and every other record below that a step writes. The
// search steps on every thread of its pool, and a global each of them wrote on
// every step was a cache line passed between cores all search long -- one
// which, depending only on where the linker put it, could also hold a
// read-mostly flag such as g_slopeDbg and slow every read of that too (the same
// source measured 15% apart between two builds). The one reader is the
// replay's per-tick line, which runs the step on its own thread, so it reads
// exactly what it read before.
inline thread_local int g_vyWriter = 0;      // __LINE__ of the last write this tick
inline thread_local int g_vyWrites = 0;      // how many writes this tick -- see below
inline long long g_vyWatchT = -1;   // --vywriter <t>: report only this tick
#define VYSET(x) (::dp::g_vyWriter = __LINE__, ++::dp::g_vyWrites, (x))

// ...and the same for c.y, because the two are written two lines apart from the
// SAME vpNew (:2637 and :2640) while a record reports edy = 0.000 with
// edvy = -6.3952. One value agreeing to the digit and its neighbour disagreeing
// by 6.4 cannot both come from that pair untouched -- so either y is overwritten
// afterwards by something else, or the reading is wrong. The y writer says
// which, and neither answer needs a guess about the terms.
inline thread_local int g_yWriter = 0;
inline thread_local int g_yWrites = 0;
// ...and the RAW values the step began with, so a report can show the sequence
// (in -> out) rather than only naming the last writer. With one write each the
// pair IS the sequence; with several it still bounds it.
inline thread_local float g_yIn = 0.f;
inline thread_local float g_vyIn = 0.f;
// ---- the slope seat's exemption gate, recorded rather than printed ---------
//
// Printing at the gate itself named no state: it lives in stepOne, which the
// search runs for many states at one tick, and at lv22 t=18,568 ninety-four of
// those carried the record's vy in three different flag combinations. Reading
// the first match would have picked one of three by luck.
//
// Recorded into globals instead and emitted from the replay's own per-tick
// line. That reporting point fires once per tick, and a --replay invocation
// does no searching, so the values it reads belong to the replayed state and
// to nothing else.
inline thread_local int g_seatGateSeen = 0;      // times the gate was reached this step
inline thread_local int g_seatImpulsedOff = -1;  // -1 = the gate was not reached
inline thread_local int g_seatTappedOff = -1;
inline thread_local int g_seatOnSlope = -1;
inline thread_local int g_seatTook = -1;         // did it take the exemption (and skip vy)?
// ...and WHICH of the eight sites raised impulsedThisTick, since that flag is
// half of the exemption's condition and the comment justifying the exemption
// names a jump or a flip while the measured vy writer was the integrator.
// Eight candidates, and picking one is what failed twice, so the site says so
// itself -- as a comma expression, which keeps `impulsedThisTick = IMPULSE();`
// the single statement `impulsedThisTick = true;` already was.
inline thread_local int g_impulseSite = 0;
// ...with a count and the sites in order, since the flag only needs to be
// raised once and the FIRST site is the one that means something; the last one
// alone cannot say whether a second site raised it again.
inline thread_local int g_impTrail[8] = {};
inline thread_local int g_impCount = 0;
#define IMPULSE() (::dp::g_impTrail[::dp::g_impCount & 7] = __LINE__, ++::dp::g_impCount, ::dp::g_impulseSite = __LINE__, true)
#define YSET(x) (::dp::g_yWriter = __LINE__, ++::dp::g_yWrites, (x))
// ...and the lines that built vpNew, IN ORDER. c.vy is written once, after the
// whole branch chain, from vpNew -- so the vy writer names that shared line and
// not the branch that produced the value. The last eight writes are kept, so
// a jump, its robot scale and a slope bonus read as the sequence they are.
inline thread_local int g_vpTrail[8] = {};
inline thread_local int g_vpWrites = 0;
inline long long g_vyWatchT2 = -1;  // --vywriter2 <t>: a second (control) tick
#define VPSET(x) (::dp::g_vpTrail[::dp::g_vpWrites & 7] = __LINE__, ++::dp::g_vpWrites, (x))

// --coins: where one coin is THIS tick, and the bit it owns in State::coins.
// A coin can be group-controlled like any other object -- lv20's first sits in a
// toggled group with the platform under it, lv21's third and lv22's third are
// MOVED into reach -- so the collect test cannot read the load-time row. A coin
// its group has switched off simply has no entry: GD does not credit one.
struct CoinLive {
    double cx, cy, hw, hh;
    int bit;
};

struct StepCtx {
    double x, xPrev;
    float dxF;         // this layer's per-tick x advance (see advanceX)
    long long t;
    // (the flying band lives in State now -- see State::bandFloor)
    const std::vector<const Obj*>* near;
    const std::vector<const Obj*>* ports;
    const std::vector<const Obj*>* pads;
    const std::vector<const Obj*>* orbs;
    const std::vector<const Obj*>* slopes;
    const std::vector<const Obj*>* speeds;
    // Both sizes. The ship used ShipParams::normal() unconditionally, so a mini
    // ship climbed at the full-size 0.086/tick where GD gives 0.101 -- measured
    // on lv11 t=8395..8411, a steady 0.0150/tick of drift that put the model
    // 3.6 px below GD within 17 ticks and killed the whole ship section.
    // ShipParams::mini() already held the right numbers; nothing selected them.
    const gdapprox::ShipParams* SP;
    const gdapprox::ShipParams* SPmini;
    const gdapprox::UfoParams* UP;
    const gdapprox::UfoParams* UPmini;
    // Touch-trigger boxes overlapping this group's x window, with the bit each
    // one owns in State::trig. Null on every level that has none.
    const std::vector<std::pair<const TouchTrig*, TouchMask>>* trigs = nullptr;
    // --coins only, and only in gameplay frame 0 (see the collect in cli.hpp).
    // Null everywhere else, which is every run without the flag.
    const std::vector<CoinLive>* coins = nullptr;
    // The search's per-group SlopeVetoIndex over `near` and `slopes`. Null in
    // every other caller; the veto then walks `slopes` whole (see vetoOf).
    const SlopeVetoIndex* veto = nullptr;
    // --solidorder: `near` in GD's solid order (descending uid), built once where `near` is
    // built. Null elsewhere -- the collision loops then sort a copy themselves.
    const std::vector<const Obj*>* nearSolid = nullptr;
};

// slopeVetoesSolid for the element `o` of K.near, through the group's index
// when there is one that was built from these very lists. `o` must be the
// reference into K.near (a range-for over *K.near by reference) -- its position
// is what finds the solid's row. Anything else walks the whole ramp list, which
// gives the same answer.
inline bool vetoOf(const StepCtx& K, const Obj* const& o, double px, double py,
                   double pHalfW, double pHalfH, bool faceIsTop, double prevX,
                   double prevY, int curSlopeUid) {
    const SlopeVetoIndex* V = K.veto;
    if (V && K.near && V->near == K.near && V->slopes == K.slopes) {
        const uintptr_t a = (uintptr_t)&o, b = (uintptr_t)K.near->data();
        const size_t i = (size_t)(a - b) / sizeof(const Obj*);
        if (a >= b && i < K.near->size() && (a - b) % sizeof(const Obj*) == 0) {
            // No candidate is the common case, and the call's own entry and exit
            // were most of what the veto cost on a level with 4,350 movers.
            if (V->off[i] == V->off[i + 1]) return false;
            const Obj* const* rs = V->ramps.data();
            return slopeVetoesSolidIn(o, rs + V->off[i], rs + V->off[i + 1], px, py,
                                      pHalfW, pHalfH, faceIsTop, prevX, prevY,
                                      curSlopeUid);
        }
    }
    return slopeVetoesSolid(o, K.slopes, px, py, pHalfW, pHalfH, faceIsTop, prevX,
                            prevY, curSlopeUid);
}

// Why the last `dead = true` fired, and on what. "The frontier died at x=N" on
// its own never says whether the model is over-killing or under-killing, and
// every wall so far has needed that answer before anything else -- lv16's ramp
// ridge and lv18's spiked tunnel both read as "the search ran out" until the
// object was named. Written unconditionally (a store of two words per kill) and
// only ever READ by --dbg, so the search itself is unaffected.
// thread_local because the layer expansion runs on several threads (see
// ThreadPool): every worker kills its own children and would otherwise stamp on
// the others' reason. --dbg reads them on the same thread that stepped the
// child, so the reason is still the right one there.
inline thread_local const char* g_deadWhy = "";
inline thread_local const Obj* g_deadObj = nullptr;
// Kills by the box GD's own random numbers can put an Area Move's object in (the hazard twins,
// uid >= kEnvTwinUidBase), over the life of the process. The box is a conservative model --
// it also closes routes the seed of any one game would leave open -- so a level whose count
// moves had branches pruned by uncertainty rather than by the level.
// Never reset: a reader takes the difference across what it wants to count.
inline std::atomic<long long> g_envKills{0};
// Whether something that can deliver an impulse (orb / pad) was within reach on this
// tick. **"Was present", not "fired"**. An axis for diagnosing missed impulses; it is
// written to the trace and goes into the driver's cause signature.
inline thread_local uint8_t g_nearOrb = 0;
// The vy that GD's dump prints on the tick a dash ring **engages**. The model's
// internal value is already 0 there (no vy is held while dashing), but GD leaves
// "the value with gravity added once more" in that tick's dump, and it only becomes
// 0 from the next tick on.
// Measured (lv21; y matches exactly on both sides = same trajectory):
//   t=1,894  type37  -10.120 -> GD -10.336 (= -10.120 + g), model 0
//   t=18,955 type37   -5.452 -> GD  -5.668 (= -5.452 + g)
//   t=4,511  type38  -14.256 -> GD  -7.236 (= (-14.256 + g) / 2)
//   t=5,555  type38   -8.908 -> GD  -4.562 (= (-8.908 + g) / 2)
// So **37 passes it through, 38 (with gravity flip) halves it**. y is already frozen
// on the engage tick, so it never shows in the trajectory, and GD also restarts the
// fall from 0 after the dash ends ([[gd-dash-stop-1829]]) -- a purely
// **display-only** difference.
// It is fixed anyway because fixcensus / quick_regress / the driver's fixup all look
// at the trace: left alone, a non-real divergence gets recorded once every time, and
// at worst a fixup gets written back on top of correct physics.
// Not kept in the state (a non-zero vy would split the dedupe key per branch).
inline thread_local double g_dashVy = 0.0;
inline thread_local uint8_t g_dashVySet = 0;
// Why vy was set to 0 on this tick. **Kept the same way as the cause of death.**
// A wrong clamp shows up as "only the model loses velocity", but which clamp fired
// cannot be worked back from outside (it was happening where there is not a single
// static object). "" = not clamped.
inline thread_local const char* g_clampWhy = "";
// What the clamp hit. Chasing a false firing needs "which object was taken as the
// ceiling / floor" (measured: not a single static object at that coordinate = it was
// looking at a moving object).
inline thread_local int g_clampUid = -1;
inline thread_local float g_clampCx = 0.f, g_clampCy = 0.f;
#define CLAMP0(why) do { g_clampWhy = (why); } while (0)
#define CLAMP0O(why, ob) do { \
    g_clampWhy = (why); g_clampUid = (ob)->uid; \
    g_clampCx = (float)(ob)->cx; g_clampCy = (float)(ob)->cy; } while (0)
// ...and WHERE the killer was AT THE MOMENT it killed. Reading cx/cy off the
// pointer after the run is not the same number for a moving object, and that
// difference is exactly what a stale-geometry bug looks like.
inline thread_local float g_deadCx = 0.f, g_deadCy = 0.f;
#define DIE(why, obj) do { dead = true; g_deadWhy = (why); \
    if (g_inRecon) noteReconDeath(why); \
    const Obj* dobj_ = (obj); g_deadObj = dobj_; \
    if (dobj_) { g_deadCx = (float)dobj_->cx; g_deadCy = (float)dobj_->cy; \
        if (dobj_->uid >= kEnvTwinUidBase) g_envKills.fetch_add(1, std::memory_order_relaxed); } \
    else { g_deadCx = g_deadCy = 0.f; } \
    } while (0)

// The ship's accel-switch threshold is per SPEED (see ShipParams::withSpeed).
// The base sets are built once at start-up and never carried a speed, so a
// 0.7 section ran with the 0.9/1.1 threshold and switched to the weak accel one
// tick late -- 0.026 vy, which on lv18 grew to 43 px and a different route.
// Only the slow variant differs, so it is two extra statics rather than a copy
// per step.
inline const gdapprox::ShipParams& shipParamsFor(float dxF, bool mini,
                                                 const StepCtx& K) {
    static const gdapprox::ShipParams kSlow =
        gdapprox::ShipParams::normal().withSpeed(0.7);
    static const gdapprox::ShipParams kSlowMini =
        gdapprox::ShipParams::mini().withSpeed(0.7);
    // [2026-08-21 r54] **1.1 is a separate table too**. `K.SP` is the raw params
    // that never went through `withSpeed`, so until now 0.9 and 1.1 used the same
    // `accelSwitchVy` (1.9165). gdref measured 1.1 at **(1.912, 1.915)**, and
    // 1.9165 is outside that interval (see the note on accelSwitchVyForSpeed).
    // Per-tick advance: 0.7->1.0465 / 0.9->1.29825 / 1.1->1.6143 /
    // 1.3->1.9096 / 1.6->2.3438.
    static const gdapprox::ShipParams kFast =
        gdapprox::ShipParams::normal().withSpeed(1.1);
    static const gdapprox::ShipParams kFastMini =
        gdapprox::ShipParams::mini().withSpeed(1.1);
    // [2026-09-01] ...and 1.3/1.6 are a THIRD row, which this had no arm for at
    // all: everything at or above 1.8 px/tick fell through to K.SP, i.e. to the
    // 0.9 threshold. GD's gravity table gives the two fast speeds one shared
    // row (2g = 1.9223980), so one static covers both -- only dxPerTick would
    // differ between them, and nothing here reads it.
    static const gdapprox::ShipParams kFaster =
        gdapprox::ShipParams::normal().withSpeed(1.3);
    static const gdapprox::ShipParams kFasterMini =
        gdapprox::ShipParams::mini().withSpeed(1.3);
    // --rawvalues (speed.hpp): the four rungs as GD's own products before the 0.001 grid,
    // -G0 x xmm3 x xmm4 / chi (ShipModel::stepVy's reading) with G0 = 0.958199 x 0.225 flat
    // across speeds (the mini ship at 0.7 measures 0.127 = G0 x 0.5 / 0.85, where the 0.7 row's
    // own g would give 0.124). Each literal is this product on the grid.
    if (g_rawValues) {
        auto raw = [](gdapprox::ShipParams p, bool m) {
            const double G0 = 0.958199024 * 0.225, chi = m ? 0.85 : 1.0;
            p.holdStrong = G0 * 0.5 / chi;
            p.holdWeak = G0 * 0.4 / chi;
            p.releaseStrong = -G0 * 1.2 * 0.4 / chi;
            p.releaseWeak = -G0 * 0.8 * 0.4 / chi;
            return p;
        };
        static const gdapprox::ShipParams rS = raw(kSlow, false), rSm = raw(kSlowMini, true),
            rN = raw(gdapprox::ShipParams::normal(), false),
            rNm = raw(gdapprox::ShipParams::mini(), true), rF = raw(kFast, false),
            rFm = raw(kFastMini, true), rX = raw(kFaster, false), rXm = raw(kFasterMini, true);
        if (dxF < 1.2f) return mini ? rSm : rS;
        if (dxF >= 1.45f && dxF < 1.8f) return mini ? rFm : rF;
        if (dxF >= 1.8f) return mini ? rXm : rX;
        return mini ? rNm : rN;
    }
    // 0.7's per-tick advance is 251.16/240 = 1.0465; the next one up is 1.29825
    if (dxF < 1.2f) return mini ? kSlowMini : kSlow;
    if (dxF >= 1.45f && dxF < 1.8f) return mini ? kFastMini : kFast;
    if (dxF >= 1.8f) return mini ? kFasterMini : kFaster;   // 1.950 / 2.400
    return mini ? *K.SPmini : *K.SP;
}
// [2026-08-21 r57] **The UFO too: only the mini at sp1.1 has a different threshold.**
// Measured by sorting gdref's UFO samples by "vp in the player frame" against "dvy"
// (weak=-0.101 / strong=-0.152):
//   mini sp0.7  weak <= 1.784 / strong >= 1.936 -> contains 1.9165
//   mini sp0.9  weak <= 1.891 / strong >= 1.936 -> contains 1.9165
//   **mini sp1.1 weak <= 1.905 / strong >= 1.915 -> 1.9165 is outside the interval**
//   normal size at every speed: weak <= 1.840 / strong >= 1.969 (all contain 1.9165)
//   flipped side: normal sp0.9/1.1 and mini sp1.1 all contain -1.9165
// Take the midpoint 1.910. Real damage: lv20 t=6,303 (mini UFO sp1.1), census
// `m3/mini1/g0/gdg0/sp1.1/air` edvy -0.051.
// [2026-08-21 r85] **The normal-size UFO is per-speed too**. Bracketing the switch
// vy with calibration-rig measurements, ceilrel x 3 speeds (0.7/0.9/1.1, 4 units
// each):
//   sp0.9  T in [1.8380, 1.9670)   contains 1.9165
//   sp0.7  T in [1.7720, 1.9010)   **1.9165 is outside**
//   sp1.1  T in [1.7940, 1.9230)   contains 1.9165
// All three contain the ship's per-speed table values (1.885 / 1.9165 / 1.9135) =
// **the UFO uses the same table as the ship**. 1.9165 at 0.7 became a switch one
// tick early, and 0.043/tick was accumulating (ceilrel07's 4 UFO units, dvy +0.044).
// [2026-09-01] All of that is ONE table now, and it is the ship's: the threshold
// comes out of playerIsFallingBugged, which every mode calls, so the UFO reads
// the same 2g(speed). The three hand-built statics have become the same
// withSpeed ladder shipParamsFor uses, which also gives the two cases they never
// covered -- the NORMAL-size UFO at 1.1 (the exception was mini-only, though the
// rig's normal-size interval [1.794, 1.923) contains the value just as well) and
// either size at 1.3/1.6.
inline const gdapprox::UfoParams& ufoParamsFor(float dxF, bool mini,
                                               const StepCtx& K) {
    static const gdapprox::UfoParams kUfoSlow =
        gdapprox::UfoParams::normal().withSpeed(0.7);
    static const gdapprox::UfoParams kUfoSlowMini =
        gdapprox::UfoParams::mini().withSpeed(0.7);
    static const gdapprox::UfoParams kUfoFast =
        gdapprox::UfoParams::normal().withSpeed(1.1);
    static const gdapprox::UfoParams kUfoFastMini =
        gdapprox::UfoParams::mini().withSpeed(1.1);
    static const gdapprox::UfoParams kUfoFaster =
        gdapprox::UfoParams::normal().withSpeed(1.3);
    static const gdapprox::UfoParams kUfoFasterMini =
        gdapprox::UfoParams::mini().withSpeed(1.3);
    // --rawvalues (speed.hpp): the two gravities before the 0.001 grid, -G0 x 0.4 / chi and
    // -G0 x 0.6 / chi with the ship's G0 = 0.958199 x 0.225 (-0.086 / -0.129, mini -0.101 /
    // -0.152 are these rounded). gdref lv12 t=5,327, lv13 t=9,472 and lv14 t=10,808 are UFO
    // ticks where the rounded step leaves vy one grid step off GD's (-5.439 vs -5.44).
    if (g_rawValues) {
        auto raw = [](gdapprox::UfoParams p, bool m) {
            const double G0 = 0.958199024 * 0.225, chi = m ? 0.85 : 1.0;
            p.gravityWeak = -G0 * 0.4 / chi;
            p.gravityStrong = -G0 * 0.6 / chi;
            return p;
        };
        static const gdapprox::UfoParams rS = raw(kUfoSlow, false),
            rSm = raw(kUfoSlowMini, true), rF = raw(kUfoFast, false),
            rFm = raw(kUfoFastMini, true), rX = raw(kUfoFaster, false),
            rXm = raw(kUfoFasterMini, true), rN = raw(gdapprox::UfoParams::normal(), false),
            rNm = raw(gdapprox::UfoParams::mini(), true);
        if (dxF < 1.2f) return mini ? rSm : rS;
        if (dxF >= 1.45f && dxF < 1.8f) return mini ? rFm : rF;
        if (dxF >= 1.8f) return mini ? rXm : rX;
        return mini ? rNm : rN;
    }
    if (dxF < 1.2f) return mini ? kUfoSlowMini : kUfoSlow;
    if (dxF >= 1.45f && dxF < 1.8f) return mini ? kUfoFastMini : kUfoFast;
    if (dxF >= 1.8f) return mini ? kUfoFasterMini : kUfoFaster;
    return mini ? *K.UPmini : *K.UP;
}

// GD's spider surface search: "the face on the other side, travelling against
// the current gravity". Used by the SPIDER's own tap (inline in stepOne, which
// is where every constant here was measured) and by the SPIDER ORB (type 43),
// which runs the same search from any mode and in mid-air.
// Returns false when there is nothing to land on -- GD's spiderTestJump finds
// no surface then, and the caller must do nothing rather than guess.
// `outHaz` (when given) comes back true if the thing the search stopped on is a
// HAZARD. GD's search does not skip them: measured on lv22 t=1,737 with a hook
// on PlayerObject::spiderTestJump itself (the raw accumulator fields are reset
// every tick, so only a hook inside the call sees the answer) -- the spider taps
// off the ceiling at y=316.500 and GD puts it at **213.250**, which is exactly
// the cy of the id-392 spike row (uid 18201..18206 / 17571, 2.6x4.8, all at
// cy=213.25), and kills it there. The model skipped `type != 0`, walked past the
// row and landed on the block below at y=163.500 -- 50 px lower, alive, and the
// DP then planned a route out of a section GD does not let you leave.
// Eight teleports were captured in that one replay; the other seven land on
// blocks at block-derived heights (223.5 / 163.5 / 316.5 / ~286-291), so the
// hazard case is the only one whose landing is the object's OWN centre. That
// offset is ONE sample -- but the player dies on the same tick, so only the
// stopping matters, not the height.
// `frame` is the gameplay frame the search runs in; it only matters for the
// transverse window (see the note at the window test).
// `bandWall` / `bandLo` / `bandHi`: the band, when it is a wall (bandIsWall).
// spiderTestJumpInternal extends its search rect only as far as
// getMin/MaxPortalY, so nothing beyond the band is a candidate, and GD puts a
// spider that finds nothing inside it on the band's own face. Measured on
// SubZero 4003 t=16,276 (spider band 1354.5/1651.5, Free Mode off, no solid
// between): the tap off the ceiling at y=1,395 lands at 1,368.000 = 1354.5 +
// 13.5, where the model, with no band, fell to the world floor at 103.5.
// GD's own search in frame 0 at normal size: spiderTestJumpInternal (2.2081,
// 0x3943f0) read step by step and checked against the rects GD itself queried
// (hitboxtrace srect:/drect: lines) on SubZero 4002.
//
//  1. Two queries over the same reach along the travel axis -- from 2 px inside
//     the player's leading face to the band. SOLIDS in a strip hung off the
//     centre travelling right, [x, x + w/2 + 1], but off the LEFT EDGE
//     travelling left, [x - w - 1, x - w/2] (0x3947cd tests m_isGoingLeft and
//     moves the origin to minX - (w/2 + 1) instead of mirroring it); HAZARDS in
//     an 8 px strip centred on the player either way. t=21,695: GD's srect is
//     o=30,760.467 w=14.5 for x=30,788.467 running left.
//  2. Solids nearest first. A landing may be up to 10 px BEHIND the player
//     (0x394bcf..0x394c20); t=21,695 the spider on a ceiling at 1,696.5 takes
//     the slat whose top is its own bottom and flips in place. A solid wholly
//     AHEAD of the centre (min x past it right, max x short of it left) is
//     taken only if the player's rect at the landing height intersects no
//     other solid of the same list, each shrunk 2 px top and bottom
//     (0x394d21..0x394dff); t=21,484 the slat uid17831 is blocked by uid17886
//     stacked on it and GD lands on the floor at 1,483.5. A solid reaching back
//     under the centre is taken as it is.
//  3. HAZARDS: if the solid strip came back empty and a hazard did not, the
//     solids are asked again over the player's whole width plus 4,
//     [x - w/2, x + w/2 + 4] (0x39490b..0x394947); with nothing there either,
//     the first hazard is the landing, at its own position. And when a solid
//     landing was chosen but the first hazard is NEARER, the function calls
//     itself with that wider solid query; if the hazard is still nearer, the
//     spider lands on it (0x394f5e..0x394fc7). The shape does not matter:
//     t=20,305 GD asks the strip, the hazards, then the 31-px rect, and puts
//     the spider at y=1,545, the centre of the saw uid18080.
//  Nothing accepted: the band face (the world floor when the band is not a wall).
inline bool spiderTargetGd(const StepCtx& K, double x, double fromY, bool flip,
                           double pHalf, double searchHalfX, double& outY,
                           bool worldFloor, bool* outHaz, bool rev, bool bandWall,
                           double bandLo, double bandHi) {
    const double gs = flip ? -1.0 : 1.0;
    // A CIRCLE hazard enters the damaging query through its RADIUS box, not
    // through the rect. Swept on 4002 by injecting the player's x before a tap
    // and reading the uids GD's own query returned (`dhit:`): saw uid18080
    // (radius 15.876 after the level's 1.47 scale) is in the 8 px strip at a
    // centre distance of 19.86 and out at 19.88, and uid18019 -- the same
    // radius at a different angle -- is in at 19.85 and out at 19.90. Both
    // brackets contain the radius and nothing else: the rotated rect (26.46),
    // the sprite half (18) and the raw radius (10.8) all sit outside them.
    const auto hazHalfX = [&](const Obj* o) {
        return o->type != 0 && o->radius > 0.0 ? o->radius : o->hw;
    };
    const auto hazHalfY = [&](const Obj* o) {
        return o->type != 0 && o->radius > 0.0 ? o->radius : o->hh;
    };
    const auto inReach = [&](const Obj* o) {
        const double hy = hazHalfY(o);
        if (flip ? o->cy - hy > fromY - pHalf + 2.0 : o->cy + hy < fromY + pHalf - 2.0)
            return false;
        return !(bandWall && (flip ? o->cy + hy < bandLo : o->cy - hy > bandHi));
    };
    constexpr int kN = 64;
    const Obj* strip[kN];
    const Obj* wide[kN];
    int nStrip = 0, nWide = 0;
    const Obj* haz = nullptr;
    const double s0 = rev ? x - pHalf - searchHalfX : x;
    const double s1 = rev ? x - pHalf : x + searchHalfX;
    const double w0 = x - pHalf, w1 = x + pHalf + 4.0;
    for (const Obj* o : *K.near) {
        if (!inReach(o)) continue;
        const double lo = o->cx - o->hw, hi = o->cx + o->hw;
        if (o->type != 0) {
            const double hx = hazHalfX(o);
            if (o->cx + hx < x - 4.0 || o->cx - hx > x + 4.0) continue;
            if (!haz || (o->cy - haz->cy) * gs < 0.0) haz = o;   // nearest first
            continue;
        }
        if (!(hi < s0 || lo > s1) && nStrip < kN) strip[nStrip++] = o;
        if (!(hi < w0 || lo > w1) && nWide < kN) wide[nWide++] = o;
    }
    // step 2 over one list, then the fallback faces
    const auto pick = [&](const Obj* const* L, int n, double& y) {
        bool f = false;
        for (int i = 0; i < n; ++i) {
            const Obj* o = L[i];
            const double rest = (flip ? o->cy + o->hh : o->cy - o->hh) - gs * pHalf;
            if ((rest - fromY) * gs < -10.0) continue;
            if (f && (rest - fromY) * gs >= (y - fromY) * gs) continue;
            if (rev ? o->cx + o->hw < x : o->cx - o->hw > x) {
                bool blocked = false;
                for (int j = 0; j < n && !blocked; ++j) {
                    const Obj* b = L[j];
                    if (b == o) continue;
                    blocked = !(x + pHalf < b->cx - b->hw || b->cx + b->hw < x - pHalf
                                || rest + pHalf < b->cy - b->hh + 2.0
                                || b->cy + b->hh - 2.0 < rest - pHalf);
                }
                if (blocked) continue;
            }
            y = rest;
            f = true;
        }
        if (!f && flip && worldFloor && !bandWall) {
            const double rest = kGroundY + pHalf;
            if (fromY - rest > 0.5) { y = rest; f = true; }
        }
        if (!f && bandWall) {
            const double rest = flip ? bandLo + pHalf : bandHi - pHalf;
            if (flip ? fromY - rest > 0.5 : rest - fromY > 0.5) { y = rest; f = true; }
        }
        return f;
    };
    const auto hazNearer = [&](bool f, double y) {
        return haz && (!f || (haz->cy - y) * gs < 0.0);
    };
    double y = 0.0;
    bool f = false, onHaz = false;
    if (nStrip == 0 && haz) {
        if (nWide == 0) onHaz = true;
        else {
            f = pick(wide, nWide, y);
            onHaz = hazNearer(f, y);
        }
    } else {
        f = pick(strip, nStrip, y);
        if (hazNearer(f, y)) {
            double y2 = 0.0;
            const bool f2 = nWide ? pick(wide, nWide, y2) : false;
            if (nWide == 0 || hazNearer(f2, y2)) onHaz = true;
            else { y = y2; f = f2; }
        }
    }
    if (onHaz) { y = haz->cy; f = true; }
    if (outHaz) *outHaz = f && onHaz;
    outY = y;
    return f;
}


inline bool spiderTargetY(const StepCtx& K, double x, double fromY, bool flip,
                          bool mini, double pHalf, double& outY,
                          bool worldFloor = true, bool* outHaz = nullptr,
                          int frame = 0, bool rev = false, bool bandWall = false,
                          double bandLo = 0.0, double bandHi = 1e9) {
    const double gs = flip ? -1.0 : 1.0;
    // 1.0 px wider in x than the spider's own half -- measured, see
    // kSpiderSearchHalfX. This picks WHICH surface it lands on.
    const double searchHalfX = mini ? kSpiderSearchHalfXMini : kSpiderSearchHalfX;
    // frame 0 at normal size: GD's own search, step by step (above)
    if (frame % 2 == 0 && !mini)
        return spiderTargetGd(K, x, fromY, flip, pHalf, searchHalfX, outY, worldFloor,
                              outHaz, rev, bandWall, bandLo, bandHi);
    double bestY = 0.0;
    bool found = false, bestHaz = false;
    // HAZARDS are searched too, but through their OWN rect. Straight off
    // spiderTestJumpInternal (2.2081, 0x3943f0 -- note the version, see the
    // note on kSpiderSearchHalfX): the function builds a rect, extends it to
    // getMinPortalY/getMaxPortalY, narrows it in x, and then asks the layer
    // TWICE with two different rects:
    //     r15 = staticObjectsInRect (rect A)      <- solids
    //     r13 = damagingObjectsInRect (rect B)    <- hazards
    // Using ONE rect for both is what broke the first attempt at this: with the
    // solid column's half (14.5) the spike uid5356 at |dx| = 15.93 becomes a
    // candidate and the model died at t=819, where GD sails past it
    // (163.500 -> 290.860). With the player's own half (13.5) that spike is
    // 15.93 > 13.5 + 2.376 = 15.876 -- OUT by 0.05 px -- while the one that
    // does kill, uid18205 at |dx| = 0.74, is well inside 13.5 + 1.3.
    // The margin is thin, but the two rects are the binary's own structure and
    // the sign of the split is not a free parameter.
    for (const Obj* o : *K.near) {
        const bool haz = (o->type != 0);
        if (haz && o->radius > 0.0) continue;   // saws are circles, not faces
        const double halfX = haz ? pHalf : searchHalfX;
        // ...and in a TURNED frame that half is on the WRONG AXIS. The rect
        // spiderTestJumpInternal builds is narrowed in the player's own x and
        // EXTENDED to getMinPortalY/getMaxPortalY in world Y. In frame 0 the
        // search's transverse axis IS world x, so `halfX` is the narrowing and
        // everything lines up; in an odd frame the transverse axis is world Y --
        // the EXTENDED one -- and narrowing it to 14.5 throws away exactly the
        // objects GD reaches.
        // Measured on lv22's rotated section (2026-08-16, cold run, t=1,813):
        // the spider taps at world (2,266.5, 229.5) and GD lands it at world
        // x=2,173.5 = the right edge of uid1204 (2,152.5,202.5, 15x15) plus the
        // spider's 13.5. That block is 27.0 px away in world Y and the window
        // was 7.5 + 14.5 = 22.0, so the model skipped it and took uid1212/1214
        // at world x=2,115 instead -- landing 30 px further, and every tick
        // after that belongs to a different run.
        // (uid1201/1202 sit at the same world Y but have MOVED to y=84 by then,
        // so exactly one candidate is left at that height and the
        // nearest-ahead rule then picks GD's.)
        // ...and only the SOLID rect is the extended one. The two rects are
        // already known to differ (see the note above this loop); a hazard found
        // with the band's reach is one GD never sees. Measured on the same tick:
        // with the band applied to both, the model stopped on a hazard at world
        // x=2,257.5 -- nearer than uid1204 in the travel axis, so it won the
        // nearest-ahead rule -- and died, where GD sails past it to 2,173.5.
        // [2026-08-26] In a TURNED frame the window is not centred on the
        // player at all. Hooked spiderTestJumpInternal's two queries (the
        // srect:/drect: lines, cfg hitboxtrace=1) on lv22's t=1,813 tap:
        //   srect: o=(0.000,201.517) s=(2255.000,14.500)   <- solids
        //   drect: o=(0.000,225.517) s=(2255.000, 8.000)   <- hazards
        // with the player at world y 230.815 scrolling 1.298/tick. In the
        // model's progress coordinate both anchor at the POST-MOVE centre
        // xF = x + dxF:
        //   solids : [xF + pHalf, xF + 2*pHalf + 1]  (the strip hangs off the
        //            LEADING edge; 14.5 = size*0.5 + 1, the 0x3943f0 constant)
        //   hazards: [xF - 4, xF + 4]                (the +4.0 constant; the
        //            old +-(hw+pHalf) window was ~4x wider than GD's band and
        //            invented the tp-hazard kill at 2,257.5 that doomed every
        //            anchor on the cold run's prefix)
        // This one form reproduces every measurement on both worldlines: the
        // natural tap (lands 2,173.5 on uid1204, a 6px GAP from the player's
        // box -- inside the strip), the y=240/244 injection boundary (strip
        // overlap 0.6px / miss 3.2px), and the 8/16 landings at 2,143.5
        // (uid1204 out of the strip at that worldline's y, the moved-in
        // uid1212/1214 inside it).
        if (frame % 2 != 0) {
            const double xF = x + (double)K.dxF;
            if (haz) {
                if (o->cx + o->hw < xF - 4.0 || o->cx - o->hw > xF + 4.0)
                    continue;
            } else {
                if (o->cx + o->hw < xF + pHalf
                    || o->cx - o->hw > xF + 2.0 * pHalf + 1.0)
                    continue;
            }
        } else if (true) {
            if (!mini && !rev) {   // GD's srect / drect
                if (haz) {
                    if (o->cx + o->hw < x - 4.0 || o->cx - o->hw > x + 4.0) continue;
                } else {
                    if (o->cx + o->hw < x || o->cx - o->hw > x + searchHalfX) continue;
                }
            } else if (std::fabs(x - o->cx) > o->hw + halfX) {
                continue;
            }
        } else {
            // the portal band in this frame's travel coordinate. GD's own
            // limits come from the anchor's dump (--startband); with none, a
            // window wide enough for the 270 px band.
            double bLo = x - 150.0, bHi = x + 150.0;
            if (startBandUsable()) {
                const double u0 = frameU(frame, 0.0, g_startBandFloor);
                const double u1 = frameU(frame, 0.0, g_startBandCeil);
                bLo = std::min(u0, u1); bHi = std::max(u0, u1);
            }
            if (o->cx + o->hw < bLo || o->cx - o->hw > bHi) continue;
        }
        // the face that matters is the one the player comes to rest ON: the
        // UNDERSIDE of a solid when travelling up, its TOP when travelling down
        const double face = flip ? (o->cy + o->hh) : (o->cy - o->hh);
        // a hazard is not landed ON -- GD puts the player at its centre and
        // kills it there (lv22 t=1,737: 316.500 -> 213.250, the id392 row's cy)
        const double rest = haz ? o->cy : (face - gs * pHalf);
        if ((rest - fromY) * gs <= 0.5) continue;   // not ahead of us
        if (!found || (rest - fromY) * gs < (bestY - fromY) * gs) {
            bestY = rest;
            bestHaz = haz;
            found = true;
        }
    }
    if (outHaz) *outHaz = found && bestHaz;
    // ...and the world's own floor counts when travelling down with no block
    // under us. NOT in a turned frame: there `v` is a world X, so kGroundY is a
    // vertical line at world x=90 -- a floor that does not exist. Measured on
    // lv22 (2026-08-13): the tap sent the model to world x=1,459
    // and then it slid off the level, where GD lands at x=2,143.5 every time.
    // GD does have a ground in the turned frame (the spider bounces between
    // 2,143.5 and 2,266.5 with no object at the former), but its position is
    // not derived yet -- and a missing floor kills the branch, which is the
    // safe direction, while a phantom one invents a route.
    if (flip && worldFloor) {
        const double rest = kGroundY + pHalf;
        if (fromY - rest > 0.5 && (!found || rest > bestY)) {
            bestY = rest;
            found = true;
        }
    }
    // ...and a band that is a wall bounds the search: its face is the landing
    // for a spider that found nothing nearer, and whatever lies beyond it was
    // never in GD's rect. Frame 0 only, for the same reason as the world floor.
    if (bandWall && frame == 0) {
        const double rest = flip ? bandLo + pHalf : bandHi - pHalf;
        const bool ahead = flip ? (fromY - rest > 0.5) : (rest - fromY > 0.5);
        const bool beyond = found && (flip ? bestY < rest : bestY > rest);
        if (ahead && (!found || beyond)) {
            bestY = rest;
            found = true;
            if (outHaz) *outHaz = false;
        }
    }
    outY = bestY;
    return found;
}

// --rotpretap: bring every OTHER built frame's moving geometry to tick t. The
// re-tap in applyRotation reads the NEW frame's rects on the tick it turns, and a
// frame the player is not in is otherwise left where it stood when the player
// last left it. Measured on lv22 t=1,817: frame 0 still had uid1214 at
// y=299.93 from t~1,745, while frame 1's own copy (the block the spider was
// standing on) had it at 225.0 -- so the re-tap landed on a block that had
// gone, 45 px short of GD's 316.5. Recording and closed-form positions only;
// the touch doors (applyTriggers) are the current frame's and stay there.
// SERIAL CALLERS ONLY: seek() writes the rects in place and the search reads
// them from the worker threads.
inline void seekOtherFrames(const Level* cur, int t) {
    if (g_rotTrig.empty()) return;
    for (int f = 0; f < 4; ++f) {
        Level* lv = levelOfFrame(f);
        if (lv && lv != cur) lv->dyn.seek(t);
    }
}

// Turn the state if this tick's advance crossed a rotation object (id 2900).
// `uPrev` is where it was BEFORE the move, in its own frame. Returns the new
// frame, or -1 when nothing changed.
//
// The world POINT carries over (it is one player in one world) and so does the
// world VELOCITY: the forward speed becomes the new perpendicular one, and the
// old perpendicular is dropped because the forward speed is the section's, not
// a free variable. Everything that names a surface or a band is cleared -- the
// band is a pair of world-Y limits and would clamp the player into a wall.
// `t` is this tick, and it is READ ONLY here: a trigger already spent on an
// earlier tick is skipped, one spent on THIS tick still fires (the whole group
// crosses together, and the marking is done once per group in the layer
// prologue -- this runs on the worker threads).
// `input` / `wasGrounded` describe the tick's BUTTON, which GD processes after
// the rotation has already turned the world (see the re-tap at the end).
inline int applyRotation(State& c, double uPrev, double dxUsed, long long t,
                         int input = 0, bool wasGrounded = false,
                         double sPrevY = 0.0, bool havePrevY = false) {
    if (g_rotTrig.empty()) return -1;
    const int f0 = (int)c.frame;
    const int rev0 = (int)c.rev;   // reverse travel is a 180-degree heading = true frame +2
    int nf = -1;
    int nflip = -1;
    // --rotpretap: the perpendicular coordinate the collision pass tests, i.e.
    // before the tap. Only a grounded spider's tap moves it (the re-tap below
    // uses the same predicate); otherwise it is c.y.
    const double vColl = (input == 1 && c.mode == 6 && wasGrounded && havePrevY)
        ? sPrevY : (double)c.y;
    // ---- THE QUEUE (frames.hpp) ------------------------------------------
    // GD walks ONE channel from a cursor and stops at the first element the
    // player has not passed. That is not a nearest-match search, so none of the
    // selection below runs: no perpendicular window (the pairs 6 px apart that
    // it was invented for are in DIFFERENT CHANNELS, and the cursor picks
    // between them), no scroll gate, no last/nearest rule.
    //
    // The axis is the player's -- vertical exactly when the frame is turned,
    // since a quarter turn is what makes travel vertical -- while the DIRECTION
    // is the channel's reverse bit. GD is asymmetric that way on purpose, and
    // the comparison is against WORLD coordinates either way.
    bool qFired = false;
    float qModY = 1.0f;
    uint8_t qOvr = 0;
    if (g_rotQueue && !g_rotQ.empty()) {
        double wx, wy;
        fromFrame(f0, (double)c.xAbs, (double)c.y, wx, wy);
        // A guard rather than `while (true)`: GD's loop is bounded by the
        // bucket, and a bug here would otherwise hang the search.
        for (int guard = 0; guard < 64; ++guard) {
            const int ch = (int)c.rotChan & 15;
            const int beg = g_rotQBeg[(size_t)ch], end = g_rotQEnd[(size_t)ch];
            if (end <= beg) break;                       // no such channel
            const int done = popCount32(c.rotSpent & g_rotQChanMask[(size_t)ch]);
            const int idx = beg + done;
            if (idx >= end) break;                       // (A) consumed to the end
            const RotQEntry& e = g_rotQ[(size_t)idx];
            const bool rev = ((c.rotRev >> ch) & 1u) != 0;
            const bool vertical = (f0 & 1) != 0;
            const double ref = vertical ? wy : wx;
            const double p = vertical ? e.py : e.px;
            // (B2)-(B5). Forward fires on `ref >= p`, reverse on `ref <= p`;
            // the same value fires in both, which is GD's own asymmetry.
            if (!rev) { if (ref < p) break; }
            else      { if (p < ref) break; }
            if (idx < 32) c.rotSpent |= (uint32_t)1 << idx;
            // --rotqtoggle: the object sits in a group this state has switched
            // off by entering a touch Toggle's box. GD skips triggerObject for
            // it (checkSpawnObjects 0x21aad8 on +0x28e, which toggleGroup
            // 0x223cbc sets) and moves the cursor on anyway (0x21ab62), so it is
            // consumed here with neither the switch nor the rotation half.
            if (g_rotQToggle && (size_t)idx < g_rotQOff.size()
                && popCount32((uint32_t)c.trig.word(0) & g_rotQOff[(size_t)idx])
                       > popCount32((uint32_t)c.trig.word(0) & g_rotQOn[(size_t)idx]))
                continue;
            // The switch half: only a 2900 with `swarm` moves the active
            // channel, and the reverse it writes is the pure predicate
            // `gnddir - 2 <u 2` -- no mapping through the frame. The id check
            // is not defensive: ten of lv22's thirty queued objects are 2899
            // Options triggers, and an Options trigger never reaches
            // rotateGameplay -- it is consumed here and does nothing to the
            // channel.
            //
            // [2026-09-10] This used to say "two of them carry
            // m_changeChannel". They carry none: a 2899 is a GameOptionsTrigger
            // and has no such field. The dumper was reading the offsets off the
            // base class, so five of the ten rows came out with swarm=1 and
            // five with swarm=255 -- neither of which was a field. The id check
            // was load-bearing for a reason slightly different from the one
            // written here, and stays.
            if (e.id == 2900 && e.swarm && e.swch >= 0 && e.swch <= 15) {
                c.rotChan = (uint8_t)e.swch;
                const int gd = (e.rotIdx >= 0)
                    ? g_rotTrig[(size_t)e.rotIdx].gndDir : 0;
                if ((unsigned)(gd - 2) < 2u) c.rotRev |= (uint16_t)(1u << e.swch);
                else c.rotRev &= (uint16_t)~(1u << e.swch);
            }
            // ...and the rotation half, which a channel-only trigger skips.
            if (!e.chanOnly && e.rotIdx >= 0) {
                const RotTrig& r = g_rotTrig[(size_t)e.rotIdx];
                if (r.setRev >= 0) c.rev = (uint8_t)r.setRev;
                nf = r.frame;
                nflip = r.setFlip;
                qModY = r.vmodY;
                qOvr = r.ovrVel;
                qFired = true;
                if (g_rotWatchLo >= 0) g_rotWatchUid = r.uid;   // --rotwatch, print only
                // ONE ROTATION PER TICK. GD's loop would keep going, and the
                // next element could be eligible in the frame this one just
                // set. It does not happen in the corpus -- lv22's 20 firings
                // are 71 to 2,884 ticks apart -- and the effect code below
                // rebases the state once, so a second turn in the same tick
                // would need it restructured. If a level ever needs it, the
                // symptom is a frame transition GD makes and the model makes
                // one tick late.
                break;
            }
        }
    }
    const bool qUsed = (g_rotQueue && !g_rotQ.empty());
    const RotTrig* best = nullptr;   // the matching trigger nearest in the perpendicular axis
    double bestDv = 1e18;
    float rotModY = 1.0f;          // vy multiplier of the adopted trigger (RotTrig::vmodY)
    uint8_t rotOvr = 0;
    bool toggleRev = false;
    for (const RotTrig& r : g_rotTrig) {
        if (qUsed) break;   // the queue above already decided
        // --rotqtoggle, the pre-queue selection's half: a trigger whose object
        // this state has switched off (see the queue branch above) is not a
        // candidate at all.
        if (g_rotQToggle) {
            const size_t k = (size_t)(&r - g_rotTrig.data());
            if (k < g_rotTrigOff.size()
                && popCount32((uint32_t)c.trig.word(0) & g_rotTrigOff[k])
                   > popCount32((uint32_t)c.trig.word(0) & g_rotTrigOn[k]))
                continue;
        }
        // A 2900 that points to the current frame is a **reverse-travel toggle**.
        // GD measurement (2026-08-15, lv22's 14 firings tabulated by frame and
        // travel before/after):
        //   t=18,382 (22575,1755) f0=0 -> 0, dx +1.613 -> **-1.613**, player 4px
        //   from the obj. Neither ug nor the y progression changes, so it is not
        //   a rotation
        //   t=14,489 (16365,1275) f0=0 -> 0 but travel unchanged -- here the player
        //   is **543px** from the obj's cy, a firing that fails the proximity test
        // The other 12 all actually change the frame. So it is not "points to the
        // same frame = do nothing" but "reverse the travel direction".
        // In an export that has gnddir, the frame and rev this trigger sets are
        // known, so "same frame means toggle" is not needed. If the heading is
        // already the same it is naturally a no-op (lv22's uid11177 is exactly that).
        const bool same = (r.setRev < 0) ? (r.frame == f0)
                                         : (r.frame == f0
                                            && r.setRev == (int)c.rev);
        const int shot = same ? r.revT : r.firedT;
        if (shot >= 0 && shot != (int)t) continue;
        const double ru = frameU(f0, r.cx, r.cy);
        // In reverse travel (State::rev) the travel coordinate **decreases**, so a
        // forward-only crossing test can never step on it. [2026-08-16] lv22
        // t=11,965: GD turns to frame 1 on uid6307 (15,405,859), but the model only
        // saw u drop 15,405.5 -> 15,404.2, never once judged it "crossed", and
        // dropped the rotation entirely.
        // The DP side's group latch already looks at grev (the layer prologue), so
        // only this spot had been left behind.
        const bool crossed = c.rev
            ? (uPrev > ru && (double)c.xAbs <= ru)
            : (uPrev < ru && (double)c.xAbs >= ru);
        if (!crossed) continue;
        // ...and the player has to be AT the trigger, not merely past its
        // travel coordinate. `frameU` is the trigger's world Y once f0 is odd,
        // so without this a trigger ANYWHERE in the level matches: lv22's
        // uid5957 sits at world (8,297,423) -- 1,548 px away -- its frame-3 u
        // is 423, and the model turned back to frame 0 at t=4,688 on it and
        // flipped its gravity, which GD never does.
        // GD's own firings (hooked GJBaseGameLayer::rotateGameplay, `rot:`):
        //   t=1,745 uid1343 obj(2265,316)   player(2265.4,316.5)
        //   t=1,816 uid1215 obj(2143.5,225) player(2143.5,224.3)
        //   t=4,664 uid4355 obj(6735,399)   player(6735.3,399.0)
        //   t=5,120 uid4467 obj(6875,885)   player(6878.3,885.3)
        //   t=5,968 uid5809 obj(8247,963)   player(8247.2,961.0)
        // In all five the player is ON the trigger in both axes within 3.3 px,
        // which is why this used to test both. **BOTH HALVES ARE WRONG.**
        // Falsified 2026-08-15 on lv22's own cold run, twice, from GD's dump
        // for the plan the DP built (model and GD bit-identical either side):
        //   t=1,746  frame 0 -> 1 on uid1343 (2,265, 316) with the player at
        //            (2,265.4, **1,306.2**) -- 990 px ABOVE it in y
        //   t=2,579  frame 1 -> 0 on uid1215 (2,143.5, 225) with the player at
        //            (**5,027.8**, 224.8) -- 2,884 px away in x
        // The travel axis is the only one that matters: in frame 0 the player
        // crossed the trigger's world X, in frame 1 it crossed its world Y, and
        // the other coordinate was arbitrary both times. Those five samples
        // were routes that happened to pass over their own trigger.
        // Without this the model plans the whole rotated section in frame 0 --
        // lv22's cold run flew 990 px over the entrance, GD turned, and it died
        // 900 ticks later at x=5,112 with the death looking like a spike.
        //
        // What DOES gate it is the level's own x window: an object is not live
        // until the level has scrolled past it. Dropping the test entirely is
        // wrong in the other direction -- the same replay then turns back to
        // frame 0 at t=1,771 on uid11177 (16,365, 1,275), whose frame-1 travel
        // coordinate the player crosses while it is still at x=2,310, i.e.
        // **14,055 px before that part of the level exists**.
        // `r.cx <= wxP` fits all seven observations at once:
        //   FIRE   uid1343 (2,265)   player x 2,265.4     (frame 0, crossing)
        //   FIRE   uid1215 (2,143.5) player x 5,027.8     (frame 1, 2,884 back)
        //   FIRE   uid4355 (6,735)   player x 6,735.3
        //   FIRE   uid4467 (6,875)   player x 6,878.3
        //   FIRE   uid5809 (8,247)   player x 8,247.2
        //   SKIP   uid11177 (16,365) player x 2,310.5     (14,055 ahead)
        //   SKIP   uid5957 (8,297)   player x ~6,735      (1,562 ahead)
        // In an even frame the crossing already implies it, so this only bites
        // in a turned one -- which is exactly where `frameU` stops meaning
        // "world x" and a trigger anywhere in the level can match by y.
        // The 30 is one tick of slack for the crossing tick itself.
        // OPEN: "has ever reached" would be the literal reading of scrolling
        // and would differ from "is at" for a player that drifted back left
        // inside a turned frame. lv22 never does, so the cheaper form stands
        // (the alternative costs a State field and a dedupe-key bit).
        double wxP, wyP;
        fromFrame(f0, (double)c.xAbs, vColl, wxP, wyP);
        if (r.cx > wxP + 30.0) continue;
        // ...and the PERPENDICULAR axis has to overlap. [2026-08-16 revived]
        // The note below says both halves are wrong; the perpendicular half is
        // NOT. GD was asked directly (cfg hitboxtrace=1 -> `rot:` lines) on the
        // x=15,656 plan and named its six firings:
        //   t=1745 (2265,316)   player(2265.4, 316.5)   du 0.4  dv 0.5
        //   t=1816 (2143.5,225) player(2143.5, 224.3)   du 0.0  dv 0.7
        //   t=4435 (6735,399)   player(6735.4, 406.5)   du 0.4  dv 7.5
        //   t=4893 (6875,885)   player(6849.6, 885.8)   du 25.4 dv 0.8
        //   t=5759 (8247,963)   player(8247.0, 961.0)   du 0.0  dv 2.0
        //   t=6093 (8297,423)   player(8275.9, 421.9)   du 21.1 dv 1.1
        // Every |dv| is under 8, and the two it did NOT fire on that same run
        // are uid6308 (15,399,615) |dv|=89.4 and uid6307 (15,405,859)
        // |dv|=330.9 -- the player crossed both travel coordinates.
        // The level's own layout settles it: lv22's 2900s past x=15,000 come in
        // PAIRS 6 px apart in x and 126-366 px apart in y, each half setting the
        // OPPOSITE direction (15,399 gnd=4 / 15,405 gnd=2; 16,005 gnd=1 /
        // 16,011 gnd=3; 16,125 gnd=1 / 16,131 gnd=3). Only the player's height
        // can pick between them, so a travel-axis-only rule cannot be right.
        // Without this the model turned at x=15,405 where GD's gframe stays 0,
        // and planned the rest of the level in a frame GD does not have.
        // The travel-axis CROSSING above stays: it is what stops a fast tick
        // from stepping over the box, and dropping it is the 2026-08-15 fix.
        //
        // [2026-08-24] **30 IS FALSIFIED, and the window was doing the pair's job.**
        // Read off GD's own gframe changes in two full lv22 runs, measured on the
        // tick BEFORE the change (once gframe moves the reported x/y are in the new
        // frame, and comparing those to the trigger's world position is nonsense --
        // that mistake is what made this look settled):
        //   FIRES  0, 0, 0.5, 1.2, 1.3, 2.0, 3.7, 5.6, 6.0, 9.3, 12.0, 14.1, 14.7,
        //          24.4, 25.6, 29.3, and **116.7**
        //   SKIPS  274.4 (uid16911), 657.8 (uid11177)
        // The 116.7 is uid11342 (20115,723) on lv22's cold route -- THE SAME TRIGGER
        // the known-good route fires at 29.3. One trigger, two heights, both fire, so
        // no window of 30 can be right. lv22's 84% wall is exactly this: the model
        // dropped that firing, planned the rest of the level in frame 0, and every
        // route it found there is in a world the game does not have.
        //
        // What the window was really for is the PAIRS (the note above): two triggers
        // 6px apart setting opposite directions, where "only the player's height can
        // pick between them". That is a CHOICE, not a range -- so the choice is made
        // explicitly below (nearest |dv| wins) and the window goes back to being what
        // it says it is, "the player is at this trigger rather than somewhere else in
        // the level". Bracketed by the measurements above at (116.7, 274.4); 150 sits
        // in that gap with ~30% margin either side. The older note's non-firings at
        // 89.4/330.9 are from a lineage this could not re-measure -- if 89.4 is real
        // and not a pair losing to its partner, this is too wide and the regression is
        // where that shows up. ([[gd-constant-justification-goes-stale]])
        const double dv = std::fabs(vColl - frameV(f0, r.cx, r.cy));
        if (dv > kRotPerpWin) continue;
        if (same) { if (r.setRev < 0) toggleRev = true; continue; }
        // NEAREST WINS. The loop used to let the last match overwrite the earlier
        // ones, which is only safe while the window is too narrow for two to match at
        // once -- i.e. the tight window was hiding this. With the pairs 6px apart in
        // travel and 126-366 apart perpendicular, both halves now match and the height
        // has to choose, which is what the note above says GD does.
        // ...and the winner is adopted **inside the loop**, exactly where the old
        // code adopted the last match. That is not a style point: `c.rev` is read
        // by the `same` test at the top of this loop, so a trigger adopted here
        // decides whether the NEXT one counts as a rotation or as a reverse-travel
        // toggle. Deferring the write until after the loop -- which is how the
        // nearest-wins choice was first written -- classifies every trigger against
        // the ORIGINAL heading, and that is a different rule even on a tick where
        // only one trigger ends up winning.
        //
        // Bisected 2026-08-25, in-process cold lv22, same binary either way:
        //   db91ab5 (adopt in the loop)      x=20,135  84%, first veto x=8,294
        //   0a1e8b6 (adopt after the loop)   x=2,266   stuck at the level's FIRST
        //                                             2900, first veto x=2,266
        //   0a1e8b6 with --rotperp 30        x=2,266   -- so it was never the
        //                                             window that did it
        // The pair choice the rewrite was for is kept: a strictly nearer match
        // still overwrites a farther one, and with one match this is the old code.
        // --rotlast drops even that and restores the plain LAST-MATCH-WINS rule,
        // so the whole pre-0a1e8b6 function can be put back with one flag (plus
        // --rotperp 30) and A/B'd against everything that was built on top of it.
        if (g_rotLast || dv < bestDv) {
            bestDv = dv;
            best = &r;
            if (g_rotWatchLo >= 0) g_rotWatchUid = r.uid;   // --rotwatch, print only
            if (r.setRev >= 0) c.rev = (uint8_t)r.setRev;   // absolute value
            nf = r.frame;
            nflip = r.setFlip;
            rotModY = r.vmodY;
            rotOvr = r.ovrVel;
        }
    }
    if (qUsed) {
        // The queue owns the answer: no toggle rule (a same-frame firing sets
        // reverse as an absolute value from gnddir) and no nearest-match.
        if (!qFired) return -1;
        rotModY = qModY;
        rotOvr = qOvr;
    } else if (toggleRev) {
        c.rev = (uint8_t)!c.rev;
    }
    if (nf < 0) return -1;
    // A same-frame firing (one that sets reverse travel as an absolute value via
    // gnddir) changes **only the heading**. Coordinates and velocity stay as they
    // are -- running it through the re-basing below (fromFrame/toFrame and
    // kRotCarry) would replace the vy of an ongoing jump arc with the dx-derived
    // carry. Measured (uid 16659, the note at the head of this function): dx
    // +1.613 -> -1.613 with "the y progression does not change" -- GD's vy
    // simply decays normally across the turn tick. [2026-08-18]
    // The note gave t=18,382; in today's gdref that firing is t=18,467, same
    // uid, 9.1200 -> 8.9050, one gravity step. The tick moved with the base and
    // the uid did not, so match a note's evidence on the uid, not the tick.
    // It is the flip-UNCHANGED case, so it is not a counter-example to the
    // halving below -- it is that rule's negative side.
    if (nf == f0) {
        // --slopedbg: WHICH of the two 2900 branches ran, and what it did to the
        // flip. The two are measurably different in GD and the trace's own
        // columns cannot tell them apart (both leave `frame` where it was for
        // the same-frame one, and neither writes a clamp label):
        //   lv22 t=11,351  frame 0->3   vy 5.7040 -> 5.1930  ratio 0.910  the
        //                  frame-carry value (9245), NOT a halving
        //   lv22 t=20,954  frame 0      vy 15.9450 -> 7.9725 ratio 0.500  a
        //                  halving, and this branch is the one that runs
        if (g_slopeDbg)
            std::printf("rot2900 t=%lld site=samefr uid=%d nf=%d f0=%d "
                        "nflip=%d flip=%d->%d vy=%.4f\n",
                        (long long)t, best ? best->uid : -1, nf, f0, nflip,
                        (int)c.flip, (nflip >= 0 ? nflip : (int)c.flip),
                        (double)c.vy);
        // ...and the polarity change halves vy, because GD reaches this through
        // flipGravity, whose `mulsd 0.5` @0x39a2dc runs whenever the polarity
        // ACTUALLY changes. Measured on every 2900 firing in the corpus, split
        // by branch with the print above (18 firings, lv20/21/22):
        //   same-frame, flip changes    lv22 t=20,954 uid 17039
        //                               15.9450 -> 7.9725, ratio 0.500
        //   same-frame, flip unchanged  t=13,685 / 18,467 / 19,376
        //                               9.1200 -> 8.9050, ratio 0.976, i.e. one
        //                               gravity step -- no halving
        // 4 of 4 with no exception. The frame-changing branch below is a
        // different mechanism and must not get this: its 14 firings replace vy
        // with the frame-carry value (5.193 / 6.457 / 7.8) and their ratios
        // scatter from 0.000 to 3.095.
        // NO MODE GATE. This first excluded ball / robot / spider, on a reading
        // of the ledger's "the fly/bird/dart/swing toggles each halve in both
        // directions (roll/robot/spider do not)". That sentence is about the
        // MODE TOGGLES, not about flipGravity, and the function has no mode
        // branch at all -- read at 0x39a1d0:
        //   0x39a1e9  cmp byte [rcx+0x9bf], dl   ; the requested polarity
        //   0x39a1ef  je  0x39a41f               ; unchanged -> early out
        //   0x39a2cb  cmp byte [rbx+0x7e1], 0
        //   0x39a2d2  jne 0x39a32f               ; set -> skip the halving
        //   0x39a2d4  movsd xmm0, [rbx+0x9a0]
        //   0x39a2dc  mulsd xmm0, [rip+0x288ab4] ; x 0.5
        // Between the early-out and the multiply there is no test of any mode
        // byte, so the halving is unconditional on mode; the two guards are the
        // polarity actually changing and [+0x7e1], which is not modelled here
        // and is not a mode (the mode flags live at +0x9b9..+0x9c4).
        // The corpus could not have caught the mistake either way: all four
        // same-frame firings are cube.
        // No double-halving guard against the portal pass's own `gravChanged`
        // halving (step.hpp:7628): applyRotation is called from the CLI tick
        // loop after stepOne, not from inside it, and the one firing that halves
        // has no portal on its tick (the objects at x=21,555 are the 2900 itself
        // and two force boxes). If a tick ever carries both, this is where to
        // look.
        if (nflip >= 0 && (uint8_t)nflip != c.flip)
            VYSET(c.vy) = (float)((double)c.vy * 0.5);
        if (nflip >= 0) c.flip = (uint8_t)nflip;
        return nf;
    }
    // The point that carries over is the one GD's collision pass sees: AFTER the
    // move, BEFORE the button (see the re-tap below). stepOne already applied
    // the tap, so for the one case where that moves the player discontinuously
    // -- a grounded spider -- the tap's y is undone here and redone in the new
    // frame. Measured on lv22 t=1,745: GD's dump reads y=316.500 on the rotation
    // tick, i.e. the parent's y untouched, while the model had already dropped
    // it to 313.500 with the old frame's tap.
    const bool reTap = (input == 1 && c.mode == 6 && wasGrounded);
    if (reTap && havePrevY) YSET(c.y) = (float)sPrevY;
    double X, Y;
    fromFrame(f0, (double)c.xAbs, (double)c.y, X, Y);
    double nu, nv;
    toFrame(nf, X, Y, nu, nv);            // no origin correction is needed
    c.xAbs = (float)nu;
    YSET(c.y) = (float)nv;
    // ---- vy hand-over [2026-08-19 settled -- replaces the whole old kRotCarry set] --
    // Cross-checking the disassembly of PlayerObject::rotateGameplay (0x399d50)
    // against lv22's raw level data (keys 169/582/583/584 of the 2900s) closed all
    // 15 of gdref's transitions, all 15 exactly (measured 2026-08-19):
    //   The velocity swap runs **only when** the vertical/horizontal flag
    //     (mvdir 3/4 = vertical) changes: yvel := travel speed (= |dx|/0.25, always
    //     positive) x modY. The old vy is discarded (outside platformer mode the
    //     old-vy component is thrown away wholesale).
    //   modY is per trigger instance: if m_editVelocity(169) is set, then
    //   m_velocityModY(583, member default 0.0); otherwise pass-through (x1).
    //   m_overrideVelocity(584) is an absolute assignment, not a multiply (no
    //   example in lv22).
    //   vertical/horizontal = parity of the true frame. A transition that keeps the
    //   parity (true 2->0, gdref t=13,646) runs no swap at all and leaves vy as
    //   is -- in the model's representation that is same frame + rev, so the
    //   nf==f0 early return above already behaves that way.
    // Every constant and exception of the old implementation was a misreading of
    // this law:
    //   kRotCarry 0.90 = (dx/0.25)/(dx/0.225). The ball's 0.99 was modY 1.1
    //   misread (6.457x1.1 = 7.175x0.990, indistinguishable from one sample).
    //   t=4,665's "starts from rest" = editVelocity=1 with 583 missing (x0).
    //   t=6,094's "mystery of the ball's magnitude" = modY -1.21. t=16,956's
    //   "robot has no mirror" = modY +1 (the paired trigger at t=4,894 is -1 -- it
    //   was the trigger's sign, not a mode mirror).
    // Mapping onto the internal convention: the model's frame 3 has +v=-X (the
    // parser's kUpFor correspondence), opposite to GD's local up (+X), so only
    // enf==3 flips the sign. gdref measurements, 3 points:
    //   t=11,344 (0->3)                     GD +5.193 -> internal -5.192
    //   t=11,626 (true 3->2 = frame0+rev1)  GD +5.193 -> internal +5.192
    //   t=1,817  (1->0)                     GD -5.193 -> internal -5.193
    // dxUsed arrives **negative** in reverse travel, so only its magnitude is used
    // (measured lv22 t=11,965, f0=0 rev0=1 -> nf=1: with the sign included the
    // world-x direction is opposite to GD's).
    const int ef0 = (f0 + 2 * rev0) & 3;
    const int enf = (nf + 2 * (int)c.rev) & 3;
    if (((ef0 ^ enf) & 1) != 0) {
        double vyGd = (double)rotModY * std::fabs(dxUsed) / 0.25;
        if (rotOvr) vyGd = (double)rotModY;   // absolute assignment (no example in lv22)
        VYSET(c.vy) = (float)(vyGd * (enf == 3 ? -1.0 : 1.0));
    }
    // [2026-08-21 r52] Carry "the tick the frame changed" one tick forward
    // (see the note on State::frameChg. The rotation hits **after** stepOne, so an
    //  assignment on the stepOne side alone never sets it -- that misfired once).
    if ((uint8_t)nf != c.frame) c.frameChg = 1;
    c.frame = (uint8_t)nf;
    // ...and the trigger SETS the gravity direction too (m_moveDirection, the
    // `mvdir` column). The model used to carry `flip` across a rotation, which
    // is only right when the trigger happens to agree. Measured 2026-08-15 on
    // lv22's cold run, GD's dump against the trace's own `flip` column:
    //   t=1,746  uid1343 mvdir=4 (right), nf=1: GD upsideDown stays 1
    //   t=2,579  uid1215 mvdir=2 (down),  nf=0: GD upsideDown **1 -> 0**
    // The carry got the first one right by luck and the second one wrong, and
    // from that tick the model's gravity stepped +0.216/tick where GD stepped
    // -0.216 -- the whole post-rotation section solved upside down.
    if (g_slopeDbg)
        std::printf("rot2900 t=%lld site=newframe uid=%d nf=%d f0=%d "
                    "nflip=%d flip=%d->%d vy=%.4f\n",
                    (long long)t, best ? best->uid : -1, nf, f0, nflip,
                    (int)c.flip, (nflip >= 0 ? nflip : (int)c.flip),
                    (double)c.vy);
    if (nflip >= 0) c.flip = (uint8_t)nflip;
    // Entering frame 3 flips `upsideDown`. Measured directly with the trace's
    // own `flip`/`frame` columns against GD's dump: the two agree on every tick
    // up to t=4,664 and disagree from t=4,665 -- the rotation tick itself --
    // where GD goes up 0 -> 1 and the model stays 0. The frame-1 rotation
    // (t=1,745) does NOT flip it, which is the odd frames' opposite handedness
    // showing up (`toFrame` gives frame 1 v = +X, frame 3 v = -X).
    // Without this a type-4 portal asks `c.flip != 0`, reads 0, and is skipped
    // as inert -- GD fires it at t=5,110 and halves vy (12.824 -> 6.413).
    // (the frame-3 mirror is handled by gdUpOf, where GD's statement is read --
    // flipping it HERE puts the sign in the physics and makes the player fall
    // the wrong way in world; tried and reverted)
    c.grounded = 0;
    c.snapObj = nullptr;
    c.snapDist = 0.f;
    c.onSlope = 0;
    c.slopeM = 0.f;
    c.usedOrb = nullptr;
    c.usedOrbOld = -1;
    for (int i = 0; i < 3; ++i) c.usedOrbHist[i] = -1;
    for (int i = 0; i < 4; ++i) c.touchRing[i] = -1;
    c.touchRingT = 0;
    c.bandFloor = 0.f;
    c.bandCeil = 1e9f;
    c.bandRefY = 0.f;
    // ---- the tick's BUTTON, run again in the NEW frame -----------------------
    //
    // GD's per-tick order is update -> checkCollisions -> buttons. The rotation
    // trigger fires in the collision pass, so a tap on the SAME tick is served
    // by a world that has already turned. stepOne applied it in the old frame
    // and everything above then overwrote x, y and vy, so the tap vanished.
    //
    // Measured on lv22's cold run (2026-08-16), the entrance to the first
    // rotated section, model and GD bit-identical up to the tick:
    //   t=1,744  both (2,264.850, 316.500) vy=0.000 frame 0
    //   t=1,745  GD (**2,143.500**, 316.500) vy=**-1.000** frame 1
    //            model (2,266.149, 313.500) vy=+5.193 frame 1
    // -1.000 is the teleport's own signature (see the spider tap in stepOne), and
    // 2,143.5 is a landing along the NEW frame's vertical (world X). The model
    // kept the rotation's carry and never teleported, and every tick after that
    // belongs to a different run -- the whole reason lv22's cold stalled at
    // x=2,275 with a frontier that otherwise reaches x=23,513 of 24,085.
    //
    // Only the SPIDER needs this: it is the one mode whose button moves the
    // player discontinuously along the gameplay vertical, which is the axis the
    // rotation just redefined. A cube/ball/ship impulse is a velocity, and the
    // rotation sets the velocity itself from the carry.
    if (reTap) {
        Level* nlv = levelOfFrame(nf);
        if (nlv) {
            const double pH = c.mini ? kSpiderHalfMini : kSpiderHalf;
            // the new frame's near list around the landing column
            std::vector<const Obj*> nr;
            const double lo = (double)c.xAbs - 40.0, hi = (double)c.xAbs + 40.0;
            auto lb = std::lower_bound(
                nlv->objs.begin(), nlv->objs.end(), lo - 80.0,
                [](const Obj& o, double v) { return o.cx < v; });
            for (auto it = lb; it != nlv->objs.end() && it->cx <= hi + 80.0; ++it)
                nr.push_back(&*it);
            nlv->dyn.collect(Dynamics::NEAR, lo, hi, nr);
            StepCtx NK{};
            NK.near = &nr;
            NK.t = t;
            double bestY = 0.0;
            bool hazTgt = false;
            if (spiderTargetY(NK, (double)c.xAbs, (double)c.y, c.flip != 0,
                              c.mini != 0, pH, bestY, nf == 0, &hazTgt, nf,
                              c.rev != 0)
                && !hazTgt) {
                const double gs = c.flip ? -1.0 : 1.0;
                YSET(c.y) = (float)bestY;
                c.flip = c.flip ? 0 : 1;
                VYSET(c.vy) = (float)(1.0 * gs);   // the teleport's own +-1.000
                c.spiderJumpT = 0;   // GD's +0x820 (State::spiderJumpT)
                c.grounded = 1;
                c.snapObj = nullptr;
            }
        }
    }
    return nf;
}

// ---- the gravity portal's suppressions, shared by both readers -------------
//
// "Does a gravity portal fire on this tick" has TWO readers. The portal pass
// near the end of stepOne is the one that acts on it; the ground arm, thousands
// of lines earlier, has to ask the same question before it settles the footing
// and the button, because flipGravity takes both away (m_isOnGround = 0 at
// 0x39a3cd, the last-touched uids at 0x39a2aa/b5/c0) and both of those are
// decided up there. Two readers of one rule drift, and this pair did: the early
// one was the bare geometry, so it answered "fires" on ticks the pass then
// declined. That was harmless while it only withheld a jump and stopped being
// harmless when it also withdrew a ball's support, so the gates live here,
// where neither reader can have one the other lacks.
//
// What CANNOT be shared is the position: the early reader runs before the tick
// is integrated, so it tests the start-of-tick y where the pass tests `yFree`.
// In that one respect it stays an over-approximation, deliberately.

// Was the player inside this portal's box at the PREVIOUS tick's position? Two
// of the pass's rules ask exactly this and used to spell it out separately --
// which is how one of them came to ask the BOUND while the firing test asked
// the ORIENTED box (lv16 t=8,014: p1's gravity portal was then skipped on every
// tick of the section and the fixup recorder wrote 30 records with dvy off by
// two full cube gravity steps). One expression, three callers.
inline bool portalWasInsideAtPrev(const Obj& p, double xPrev, double yPrev,
                                  double half, double pRot) {
    return std::fabs(xPrev - p.cx) <= p.hw + half
           && std::fabs(yPrev - p.cy) - (p.hh + half) < 0.0
           && (!p.oriented || orientedHit(p, xPrev, yPrev, half, pRot));
}

// [2026-08-21 r52] A portal SITTING ON THE ROTATION TRIGGER THAT PUT US IN THIS
// FRAME does not fire again: GD fires on ENTRY and the player is already deep
// inside these when the frame turns (lv22: 36 px into uid4360's 52.5 at
// t=4,665), so GD has them in its touched list. Scoped to the trigger that owns
// the CURRENT frame -- matching any trigger also ate the robot portal uid4607,
// 10 px from uid4467, and cost the mode switch GD makes at t=5,108.
inline bool portalOnFrameRotTrigger(const Obj& p, int frame) {
    if (frame == 0 || g_rotTrig.empty()) return false;
    double wpx, wpy;
    fromFrame(frame, p.cx, p.cy, wpx, wpy);
    for (const RotTrig& r : g_rotTrig)
        if (r.frame == frame && std::fabs(r.cx - wpx) <= 60.0
            && std::fabs(r.cy - wpy) <= 60.0)
            return true;
    return false;
}

// --portalonce (speed.hpp): the mode portals -- ship 5, cube 6, ball 16, UFO 19, wave 26, robot 27,
// spider 33, swing 41 -- and the size portals, normal 17 and mini 18.
inline bool isModePortalType(int type) {
    return type == 5 || type == 6 || type == 16 || type == 19 || type == 26 || type == 27
        || type == 33 || type == 41 || type == 17 || type == 18;
}
// Fly-rings (speed.hpp): the rings a ship or UFO takes through pushButton. Only the impulse rings
// -- yellow 11, pink 12, gravity 13, green 29, red 35, drop 32 -- take this path; dash, spider,
// teleport and custom rings keep the old one.
inline bool flyEarlyRingType(int type) {
    return type == 11 || type == 12 || type == 13 || type == 29 || type == 35 || type == 32;
}
// Was `uid` fired before usedOrbOld? (speed.hpp, the note that was --ringonce's)
inline bool ringFiredBefore(const State& s, int uid) {
    if (uid < 0) return false;
    for (int i = 0; i < 3; ++i)
        if (s.usedOrbHist[i] == uid) return true;
    return false;
}
// A ring fired: usedOrb takes it and the one it displaces moves to usedOrbOld -- and the one
// usedOrbOld held moves into the history instead of being forgotten.
inline void noteRingFired(State& c, const Obj* ob) {
    if (g_histStatOn && ob) {
        ++g_hist.orbFired;
        if (std::find(g_histFired.begin(), g_histFired.end(), ob->uid) != g_histFired.end())
            ++g_hist.orbRefire;
        else
            g_histFired.push_back(ob->uid);
        if (c.usedOrb && c.usedOrb != ob && c.usedOrbOld >= 0 && c.usedOrbHist[2] >= 0)
            ++g_hist.orbDrop;
    }
    if (c.usedOrb && c.usedOrb != ob) {
        if (c.usedOrbOld >= 0) {
            c.usedOrbHist[2] = c.usedOrbHist[1];
            c.usedOrbHist[1] = c.usedOrbHist[0];
            c.usedOrbHist[0] = c.usedOrbOld;
        }
        c.usedOrbOld = c.usedOrb->uid;
    }
    c.usedOrb = ob;
}
// The ring GD's pushButton would fire from `s`: in contact at the END of the previous tick (s.xAbs,
// s.y), or of the one before it, with the previous tick's body. GD fires the one it touched first
// (m_touchedRings keeps first-contact order; the late loop's note), so a ring that was also in
// contact a tick earlier beats one that was not, and otherwise the lowest uid wins -- the late
// loop's rule. That earlier position is not in the state: it is taken back one flight step, x by
// the step's advance and y by s.vy x 0.225, which is the ship's and UFO's own integration when
// nothing clamped it. A ring that entered two or more ticks before its rivals is not told apart
// (a custom level t=2,741: GD fires yellow 447, entered a tick before gravity 443; both read as earlier).
inline bool flyRingContact(const Obj* ob, double px, double py, double ph) {
    if (std::fabs(px - ob->cx) >= ob->hw + ph || std::fabs(py - ob->cy) >= ob->hh + ph)
        return false;
    if (ob->oriented) {
        const double rx = px - ob->cx, ry = py - ob->cy;
        const double lx = rx * ob->rc - ry * ob->rs, ly = rx * ob->rs + ry * ob->rc;
        const double oph = ph * (std::fabs(ob->rc) + std::fabs(ob->rs));
        if (std::fabs(lx) >= ob->ohw + oph || std::fabs(ly) >= ob->ohh + oph) return false;
    }
    return true;
}
// --padsection (speed.hpp): does GD's collision pass reach object `o` after the object at (cx, cy)
// with uid `uid`? checkCollisions walks the section cells around the player x-major then y
// (a section is 100 units, layer +0x36a0/+0x36a4 hold the reciprocal), and collisionCheckObjects
// takes one cell's objects in the order its sort left them: ascending +0x39c (0x205210), the uid.
inline bool gdCollidesAfter(const Obj& o, double cx, double cy, int uid) {
    const int ox = (int)std::floor(o.cx * 0.01), px = (int)std::floor(cx * 0.01);
    if (ox != px) return ox > px;
    const int oy = (int)std::floor(o.cy * 0.01), py = (int)std::floor(cy * 0.01);
    if (oy != py) return oy > py;
    return o.uid > uid;
}
// --solidorder (speed.hpp): the near list in the order GD resolves solids, descending uid. A local
// copy per call, not a shared buffer: a step can run another step inside its collision loop.
inline void solidOrderInto(const std::vector<const Obj*>& near, std::vector<const Obj*>& out) {
    out.assign(near.begin(), near.end());
    std::stable_sort(out.begin(), out.end(),
                     [](const Obj* a, const Obj* b) { return a->uid > b->uid; });
}
// ...the list a collision loop walks: K.nearSolid when the caller built it, else a sorted copy in
// `buf`, else K.near as it is.
inline const std::vector<const Obj*>& solidWalk(const StepCtx& K, std::vector<const Obj*>& buf) {
    if (K.nearSolid) return *K.nearSolid;
    solidOrderInto(*K.near, buf);
    return buf;
}
// --solidorddbg t0:t1 (speed.hpp): the solids a collision loop visits while the player's box
// overlaps them, in visiting order -- the model's side of GD's hbox call order. Replays only.
inline void noteSolidVisit(const StepCtx& K, const Obj* o, double x, double y, double pHalf) {
    if (g_solidOrdDbgT0 < 0 || K.t < g_solidOrdDbgT0 || K.t > g_solidOrdDbgT1 || o->type != 0) return;
    if (std::fabs(x - o->cx) < o->hw + pHalf && std::fabs(y - o->cy) < o->hh + pHalf)
        std::printf("solidord t=%lld uid=%d\n", (long long)K.t, o->uid);
}
// --faceclass (speed.hpp): is the player's foot, in its own gravity, inside solid `o`'s face by no
// more than the landing tolerance -- or, for the ball, its head inside the underside by no more?
// Measured modes only: cube, ship, ball.
inline bool footFaceContact(const Obj& o, const State& c, double pHalf) {
    if (!(c.mode == 0 || c.mode == 1 || c.mode == 2)) return false;
    const double gs = c.flip ? -1.0 : 1.0;
    const double tol = (c.mode == 1) ? kShipLandTol : kLandTol;
    const double face = c.flip ? (o.cy - o.hh) : (o.cy + o.hh);
    const double pen = (face - ((double)c.y - gs * pHalf)) * gs;
    if (pen >= 0.0 && pen <= tol) return true;
    if (c.mode != 2) return false;
    const double under = c.flip ? (o.cy + o.hh) : (o.cy - o.hh);
    const double headPen = (((double)c.y + gs * pHalf) - under) * gs;
    return headPen >= 0.0 && headPen <= tol;
}
// --flipgrace (speed.hpp): does GD re-seat instead of kill here -- a ground-mode body within
// kFlipGraceTicks of a gravity flip, touching static solid `o` on its head side, frame 0?
inline bool flipGraceSeat(const Obj& o, const State& c, const State& s, bool tapAfterCollide,
                          double pHalf) {
    if (o.dynObj || s.frame != 0) return false;
    if (!(c.mode == 0 || c.mode == 2 || c.mode == 5 || c.mode == 6)) return false;
    // A ball's tap on a fresh press flips in GD's buttons phase, after the collision pass, so it
    // does not open the window for this tick's contacts. A custom level t=8,012: a ball taps on block 1538
    // and its inner box enters 1537's side the same tick; GD kills it (no flip before that pass).
    // A side entry does get the window otherwise (the same level t=3,208: a cube x-enters block 702 just
    // under its underside and GD seats it at 345).
    const int age = (gdUpOf(c) != gdUpOf(s) && !tapAfterCollide) ? 0 : (int)s.flipT + 1;
    if (age >= kFlipGraceTicks) return false;
    // GD's side classification (collidedWithObjectInternal's CVar29): the foot moved 10 px toward
    // the head, now and at the previous position, against the solid's far edge. Upright, the
    // contact is on the head side when the solid's bottom is at or above either widened foot;
    // flipped, mirrored. Only a head-side contact gets the grace. It replaces the proxy "centre
    // outside the y span", which spared a custom level t=19,794: a mini cube flipped upright by a pad two
    // ticks earlier enters a slab's side with its head 8.7 px past the underside -- foot + 10 is
    // above the bottom at both positions, so GD calls it a ground contact and kills.
    const double kReach = 10.0;
    if (!c.flip)
        return o.cy - o.hh >= (double)c.y - pHalf + kReach
               || o.cy - o.hh >= (double)s.y - pHalf + kReach;
    return o.cy + o.hh <= (double)c.y + pHalf - kReach
           || o.cy + o.hh <= (double)s.y + pHalf - kReach;
}
// ...and the seat: the head-side face (GD: MinY - h/2 upright, MaxY + h/2 flipped), vy 0, and
// grounded -- GD calls hitGround there. The onGround it leaves outlives the contact on a flipped
// body (--upsidecoyote's linger): a custom level t=3,902, a flipped ball seated on block 291 drifts off it
// with onGround 1 and taps on a press six ticks later (3,908, vy -3.354).
inline void seatOnNearFace(const Obj& o, State& c, double pHalf) {
    YSET(c.y) = (float)(c.flip ? o.cy + o.hh + pHalf : o.cy - o.hh - pHalf);
    VYSET(c.vy) = 0.f;
    c.grounded = 1;
}
// --ringorder (speed.hpp): a ring's place in m_touchedRings (State::touchRing), 4 when absent.
inline int touchRank(const State& s, int uid) {
    for (int i = 0; i < 4; ++i)
        if (s.touchRing[i] == uid && uid >= 0) return i;
    return 4;
}
// ...and the array's update for one tick: at the head, resetTouchedRings keeps only the entries
// the tick before touched, in order; the collision pass then appends this tick's new contacts in
// ascending uid (checkCollisions sorts each bucket by uid). Contact is the ring box at (px, py),
// the position the collision pass works from.
inline void updateTouchRings(State& c, const State& s, const StepCtx& K, double px, double py,
                             double ph) {
    int32_t a[4] = {-1, -1, -1, -1};
    int n = 0;
    for (int i = 0; i < 4; ++i)
        if (s.touchRing[i] >= 0 && ((s.touchRingT >> i) & 1)) a[n++] = s.touchRing[i];
    int32_t fresh[8];
    int nf = 0, nfAll = 0;
    uint8_t touched = 0;
    for (const Obj* ob : *K.orbs) {
        if (ob->uid < 0 || !flyRingContact(ob, px, py, ph)) continue;
        int at = -1;
        for (int i = 0; i < n; ++i)
            if (a[i] == ob->uid) at = i;
        if (at >= 0) touched |= (uint8_t)(1u << at);
        else {
            ++nfAll;
            if (nf < 8) fresh[nf++] = ob->uid;
        }
    }
    std::sort(fresh, fresh + nf);
    const int nKept = n;
    for (int j = 0; j < nf && n < 4; ++j) {
        touched |= (uint8_t)(1u << n);
        a[n++] = fresh[j];
    }
    if (g_histStatOn) {   // --histstat (speed.hpp)
        g_hist.touchMax = std::max(g_hist.touchMax, n);
        g_hist.touchDrop += nfAll - (n - nKept);
    }
    for (int i = 0; i < 4; ++i) c.touchRing[i] = a[i];
    c.touchRingT = touched;
}
inline const Obj* flyEarlyRing(const State& s, const StepCtx& K, double stepDx) {
    (void)stepDx;
    const Obj* pick = nullptr;
    int pickRank = 4;
    for (const Obj* ob : *K.orbs) {
        if (!flyEarlyRingType(ob->type)) continue;
        if (ob == s.usedOrb || (ob->uid >= 0 && ob->uid == s.usedOrbOld)) continue;
        if (ringFiredBefore(s, ob->uid)) continue;
        // the array pushButton walks is the previous tick's end state's (State::touchRing)
        const int rk = touchRank(s, ob->uid);
        if (rk < pickRank) { pick = ob; pickRank = rk; }
    }
    return pick;
}
// ringJump's writes for those types, on a ship or UFO, applied to the state it fires from. The
// values are the late loop's (applyOrb) with the flying modes' own ratios.
inline void applyFlyEarlyRing(State& c, const Obj* ob, float useDx) {
    if (ob->rev) c.rev = c.rev ? 0 : 1;
    const double ms = (c.mini ? kMiniImpulse : 1.0) * ringScaleFor(useDx);
    if (ob->type == 13) {
        const double gv = g_rawValues ? rawQ(kCubeJump * 0.8 * ms) * 0.5 : kOrbGravity * ms;
        c.flip = c.flip ? 0 : 1;
        c.vy = (float)(gv * (c.flip ? 1.0 : -1.0));
    } else if (ob->type == 32) {
        const double dv = (c.mode == 3) ? kRingDropUfo : kRingDropFly;
        if ((double)c.vy * (c.flip ? -1.0 : 1.0) >= 2.0) c.pNoTerm = 1;
        c.vy = (float)(c.flip ? dv : -dv);
    } else if (ob->type == 35 || ob->type == 29) {
        const bool green = (ob->type == 29);
        const double r = green ? ((c.mode == 1) ? kRingGreenShip : kRingGreen)
                         : (c.mode == 1) ? (c.mini ? kRingRedShipMini : kRingRedShip)
                                         : (c.mini ? kRingRedUfoMini : kRingRedUfo);
        if (green) c.flip = c.flip ? 0 : 1;
        const double ov = g_rawValues ? rawQ(kOrbYellow * r * ms) : kOrbYellow * r * ms;
        c.vy = (float)(c.flip ? -ov : ov);
        if (!green && boostLatchMode(c.mode)) c.boost = 1;
    } else {
        const double ratio = (ob->type == 12) ? pinkRingRatio(c.mode) : 1.0;
        const double ov = g_rawValues ? rawQ(kCubeJump * ratio * ms) : kOrbYellow * ratio * ms;
        c.vy = (float)(c.flip ? -ov : ov);
    }
    c.grounded = 0;
    c.rHover = 0;
    noteRingFired(c, ob);
    c.ringHold = 1;
    c.pressSpent = 1;
    // The press is GD's previous tick's: it is no longer an edge on this one, so the UFO's flap
    // gate (`input && !s.action`) stays shut, as ringJump's spent +0x986 keeps GD's shut.
    c.action = 1;
    c.jumpBuf = 0;
}

// `linkFlip`, when given, comes back true if a gravity portal actually changed
// this body's polarity. It is an out-parameter and NOT a global on purpose: the
// DP's phase 1 steps the whole layer in parallel, so a global written in here
// would be a race between states as well as leaking from one call into the next
// (the shape gd-cli-globals-leak-in-process records). `dead` is passed the same
// way for the same reason.
inline State stepOne(const State& s, int input, const StepCtx& K, bool& dead,
                     bool* linkFlip = nullptr) {
    // Per STEP, not per tick: the search runs many states through the same tick,
    // and a counter carried between them would report whichever ran last. Zeroed
    // here so `g_vyWrites == 0` means this step wrote vy nowhere -- which is a
    // distinct answer from "wrote it once".
    g_vyWriter = 0;
    g_vyWrites = 0;
    g_yWriter = 0;
    g_yWrites = 0;
    g_yIn = s.y;
    g_vyIn = s.vy;
    g_vpWrites = 0;
    g_impCount = 0;
    g_impulseSite = 0;
    // ...and the (frame, rev) the step ran in. Counted for EVERY step, not only
    // the ones that consult a fixup, so the fixup census below it has a
    // denominator: "frame 2 never reached a lookup" and "frame 2 never happened"
    // are different findings and the pair separates them.
    if ((unsigned)s.frame < 4)
        ++g_frameRevReach[g_threadSlot & (kThreadSlots - 1)].n[s.frame][s.rev ? 1 : 0];
    State c = s;
    c.tpSkip = 0;   // one tick of life: set again only by this tick's teleport
    // The spider's teleport clock ages a tick; a teleport this tick sets it back to 0.
    c.spiderJumpT = (uint8_t)std::min<int>(kSpiderJumpGraceTicks, (int)s.spiderJumpT + 1);
    c.ogLinger = 0; // --upsidecoyote: re-earned every tick by the cube branch
    for (int i = 0; i < 3; ++i) c.portSeen[i] = -1;   // --portalonce: this tick's overlaps
    // --stickseam: a tie lives only as long as the ride; the grounded block
    // below re-ties on the first grounded tick (State::groundUid).
    if (!s.grounded) c.groundUid = -1;
    // A shared gravity-portal bit changes hands where x crosses the point between its two
    // portals (g_gpHandoff, level_loader.hpp). Empty on every level with kGravPortalBits or fewer.
    for (const GpHandoff& h : g_gpHandoff)
        if (K.xPrev < h.x && K.x >= h.x) {
            c.portalLatch &= ~GravLatch::bit(h.bit);
            c.portalLatch2 &= ~GravLatch::bit(h.bit);
        }
    // The no-control window (id 2899 / GameOptionsTrigger; history at the
    // declaration of g_ctrlWin). **Only the button fails to reach the physics**;
    // the held-button bookkeeping stays alive: the caller writes `c.action = curIn`
    // from the raw input, so a hand kept pressed across the window counts as a
    // continuation from the tick the window lifts (GD measurement: on lv22, holding
    // from t=14,100 onward makes the ship climb from the lift at t=14,225).
    if (!g_ctrlWin.empty() && ctrlOffAt(K.t)) input = 0;
    // The ring a ship or UFO takes fired at the end of the previous tick (speed.hpp, the fly
    // rings), so this tick runs from the state it left.
    if (!g_flyRingNested && (s.mode == 1 || s.mode == 3) && !s.dual && input
        && !s.jumpBuf && !s.pressSpent && K.orbs) {
        const float ringDx = (s.dx > 0.f) ? s.dx : K.dxF;
        const double stepDx = (double)ringDx * timeWarpAt((double)s.xAbs) * (s.rev ? -1.0 : 1.0);
        if (const Obj* ring = flyEarlyRing(s, K, stepDx)) {
            State s2 = s;
            applyFlyEarlyRing(s2, ring, ringDx);
            g_flyRingNested = 1;
            State r = stepOne(s2, input, K, dead, linkFlip);
            g_flyRingNested = 0;
            return r;
        }
    }
    // ...and the buffer mirrors the button AFTER that gate, which is the whole
    // point of having it: GD's pushButton returns before touching m_jumpBuffered
    // when the controls are off, so the mirror must be taken from the input that
    // actually reached the physics rather than from the raw plan value in
    // `action`. Consumers below clear it where GD clears it (the ball's tap, a
    // ring that spends the press).
    c.jumpBuf = (uint8_t)(input ? 1 : 0);
    // --heldall (speed.hpp): the button level every mode came in with, not only the flying ones
    if (g_heldAll) c.held = (uint8_t)input;
    // --holdlatch: a release, or a fresh press (pushButton sets +0x985), makes the hold live again
    if (!input || !s.action) c.holdDead = 0;
    c.pFlap = 0;   // 1-tick lifetime (see the note on State::pFlap)
    c.pExitVy = 0.f;  // same (State::pExitVy, r93)
    c.pNoTerm = 0;    // same (State::pNoTerm, r102)
    // The velocity-limit exemption (State::boost) is carried by the three modes
    // whose updateJump branch reads GD's byte: ship, UFO and swing
    // (boostLatchMode, which has the addresses). Outside them nothing here
    // maintains it, so drop it rather than let a stale bit cross a mode portal.
    // LEAF: GD does NOT drop it on a mode change. Its byte has no mode test at
    // any writer and survives a cube section untouched; only the flying band
    // test and the five other clearers put it down. Nothing in the corpus
    // enters a cube out of band and comes back to a ship still out of band, so
    // the two readings are indistinguishable here.
    if (!boostLatchMode(c.mode)) c.boost = 0;
    // ONE float x per state, advanced and snapped exactly as GD does it.
    // It used to be `shared double base + per-state xAdj`, which cannot be exact:
    // GD writes the stair snap straight into the same float it accumulates into,
    // so after a snap its rounding follows a different path than base+offset.
    // That was the last 0.003 px, and 0.003 px is not academic -- lv5 t=8482 sat
    // exactly on |x - cx| = 30.0, where the model let go of the ledge and GD did
    // not.
    // This state's own speed (see State::dx); 0 = never set, use the layer's.
    // EVERYTHING speed-dependent below reads it -- the x advance, the stair
    // table, the cube's jump/gravity, the ball's flip value, the ship params
    // and the ring scale. They used to read the LAYER's dxF, which is the same
    // number only while the whole frontier shares one speed. On lv18 it does
    // not: the layer accumulator picked up every speed portal ANY state could
    // touch and ran up to 1,700 px ahead of the plan's own x (measured), so
    // the search planned against displaced geometry and
    // handed 1.1's constants to states that were still at 0.7.
    const float useDx = (s.dx > 0.f) ? s.dx : K.dxF;
    c.dx = useDx;
    // TIME WARP (id 1935). A pure TIMESCALE, not a speed: the x advance, the y
    // integration and the velocity increment are all multiplied by the same
    // factor, while the dump's `speed` column does not move at all. Read off x
    // rather than carried in the state -- it is a monotone function of x and
    // the level's warps sit outside the rotated section, so there is nothing to
    // remember. `xPrev` because the effect starts the tick AFTER the crossing,
    // the same +1 every autotrigger has (measured on lv22: the player crosses
    // cx=4,535 during t=3,131 and t=3,132 is the first slowed tick; the
    // partner at cx=4,615 is crossed during t=3,335 and t=3,336 is normal
    // again).
    const double tScale = timeWarpAt((double)s.xAbs);
    // THE BAND ANIMATION ages by one tick here, wherever this state is. It is
    // a tween in TIME, and the first thing a version mapped through x got
    // wrong was lv22's rotated shaft, where the run crosses x=15,765 three
    // times and fires the portal there once (it passes the other two at a
    // height that misses the box). Nothing outside the g_staticCamCol gate
    // touches it, so a dump without those columns leaves it at 0 for ever.
    if (g_staticCamCol) c.bandAnim = bandAnimStep(s.bandAnim);
    // [2026-08-21 r44] The free-integration y from **before** the ride overwrites
    // y. Written just before the slope block, read on the portal side (a different
    // scope).
    float yFreeBeforeSlope = 0.f;
    // [2026-08-27] **The y the UPDATE phase wrote, before any collision clamp.**
    // GD's tick is update -> collisions -> buttons, and the collision pass reads
    // the player rect it snapshotted at entry (disassembly 0x2149b8; the long
    // note at `yColl`). Every clamp, seat, ride and push-out below happens
    // INSIDE that pass, so none of them is visible to it -- which makes this,
    // not `c.y`, the position the pass works from.
    // Only the DUAL BIRTH reads it so far (`c.y2` in the type-23 branch);
    // `yColl` and `yPort` still carry their own approximations of the same
    // quantity and are left alone on purpose (they decide portal timing on
    // every level, this decides where a second body appears).
    // Written next to each mode branch's own integration, never next to a
    // clamp. `s.y` is the right value for a branch that integrates nothing:
    // a body at rest moves by kYScale * 0 = 0.
    float yFree = s.y;
    // [2026-08-21 r52] Whether a "gravity portal right after a frame change" was
    // suppressed on this tick. Needed so State::frameChg is not lowered while the
    // suppression continues.
    bool gravHoldOver = false;
    // [2026-08-21 r61] Whether this tick's ride was a "push-out with gravity still
    // pointing the other way" (the branch that left vy and grounding in place).
    // Used only when a gravity portal at the end of the tick returns to upright,
    // to apply GD's landing on the spot.
    bool rodeFlipped = false;
    // [2026-08-21 r66] Whether a ceiling-ramp push-down (upceil) took effect on
    // this tick. Read by the release test at the end of the tick (ceil/release).
    bool ceilPressedNow = false;
    double ceilPressM = 0.0;
    uint8_t ceilPressMode = 0;   // --ceilreleasemode: c.mode at the press site
    // Reverse travel (State::rev) decreases x. `useDx` is a speed (positive), so
    // the sign is applied to the state-side advance as well. Drop this and only the
    // replay's local `x` goes negative while the state's xAbs keeps growing: it
    // matches GD on the 1st tick only and diverges from the 2nd.
    c.xAbs = advanceX(s.xAbs,
                      (float)(useDx * tScale * (s.rev ? -1.0 : 1.0)));
    const double x = (double)c.xAbs, xPrev = (double)s.xAbs;
    // LOCKED-TO-PLAYER GEOMETRY. While the lock its box opened is still running,
    // whatever that box locked moves with the player, so the state carries how
    // far it has come since it punched the box -- which is this tick's advance
    // added to the parent's total. Summing the advance is the same quantity as
    // `playerX(t) - playerX(t0)` and needs no remembered x. `fireB` is the tick
    // the box was entered, so the window is open while `t - fireB <= lockTicks`;
    // once it closes the sum stops, which is the formula's own `min(t, t0+L)`.
    // The window closes `lockTicks` after the move STARTS, and the move starts
    // the tick after the box is entered -- the same `+1` the eased moves take,
    // so the last accumulating tick is F + 1 + lockTicks. Measured on lv19:
    // uid14011's recording runs to t=20,788 with the box entered at 20,503 and
    // a 284.1-tick lock, and 20,503 + 1 + 284.1 lands on 20,788. Without the
    // +1 the model stops one tick early and freezes a whole dx short.
    if (g_lockBox >= 0 && c.trig.test(g_lockBox)
        && (double)((long long)K.t - (long long)c.fireB[g_lockBox] - 1)
               <= g_lockTicks)
        c.lockOff = s.lockOff + (float)(x - xPrev);
    // STATIC CAMERA crossings. Unlike a portal these carry no box test at all
    // -- the x-crossing queue fires on the player's x passing the trigger's
    // own x -- so the test is the span this tick covered, taken both ways
    // because lv22 runs backwards through its rotated section.
    if (g_staticCamCol && !g_staticCams.empty()) {
        const double lo = std::min(xPrev, x), hi = std::max(xPrev, x);
        for (const StaticCam& sc : g_staticCams) {
            if (sc.cx <= lo || sc.cx > hi) continue;
            if (sc.exit_) c.bandBranch &= (uint8_t)~1;   // Exit Static
            else          c.bandBranch = (uint8_t)((c.bandBranch | 1) & ~2);
        }
    }
    // The start-of-tick point in WORLD coordinates, for the modifier boxes.
    //
    // `frameLevel` turns the colliders, portals, pads, orbs, speeds, slopes and the
    // moving geometry into each rotated frame -- but NOT the modifier lists (force
    // boxes 2069, force fields 3645, the head-flip box 2866, the dash stop 1829).
    // Those are loaded once, in world coordinates, and State::xAbs/y are always the
    // CURRENT frame's coordinates, so a rotated frame was asking them about a place
    // the level does not have. The box does not misfire, it silently stops applying.
    //
    // Measured, lv22 t=16,462-16,471 (robot in frame 3, inside uid17701 -- whose
    // robot strength 0.330 is already in the table in modifiers.hpp, fitted at
    // t=16,367 in frame 0). GD's dvy is +0.330 for exactly the ten ticks the
    // player's lower edge is still below the box's top edge at y=733.5, and +0.000
    // from the tick it is not. The model held +0.000 throughout -- the robot hover's
    // own shape with the field missing -- which is 10px off GD's arc by t=16,480,
    // and it then planned the rest of the shaft in a place GD is not.
    //
    // Nothing about the DIRECTION needs turning: `acc += forceBoxAcc(...) * gsign`
    // and `c.vy = vp * gsign` cancel, so the exported dvy is +k whatever the frame
    // and whatever the flip. That is what GD does -- the same +0.330 appears at
    // t=16,367 (frame 0, upright) and at t=16,462 (frame 3, flipped) -- and it acts
    // on the frame's vertical axis rather than on world y: the travel advance
    // through those ten ticks stays +1.95/tick to the last digit.
    //
    // The time warp above stays on the frame's own x: the level's warps sit outside
    // the rotated sections (see tScale). The deadbands below get the same world
    // treatment, for the same reason -- they are authored in world coordinates.
    double modX = xPrev, modY = (double)s.y;
    if (s.frame & 3) fromFrame((int)s.frame, xPrev, (double)s.y, modX, modY);
    // DART SLIDE ARM (id 1755) -- the same start-of-tick position every modifier
    // box reads, and the same decay as the ceiling arm. What it enables is in
    // the wave arm (slideBoxTouch's note).
    //
    // ARMED HERE, ABOVE THE MODE BRANCHES, because GD's counter is player state
    // and does not belong to a mode. It sat next to the ceiling arm first, which
    // is inside the GROUND arm -- so a wave never reached it, c.slideT stayed at
    // its "never armed" 255, and the seat below could not fire at all.
    c.slideT = (!g_slideBoxes.empty()
                && slideBoxTouch(modX, modY, playerHalf(s.mode, s.mini != 0)))
                   ? 0
                   : (uint8_t)std::min<int>(kArmTicks, (int)s.slideT + 1);
    // ...and the sign that family converts with. The strengths were fitted against
    // GD's dump, whose "up" in frame 3 is the MIRROR of the model's internal one --
    // the same statement gdUpOf makes about lip and the trace writer makes about
    // vy. Identical to gsign in frames 0/1/2. (History: the modifier-boxes commit.)
    const double gdSign = gdUpOf(s) ? -1.0 : 1.0;
    // [2026-08-25] A "recorded band ceiling holds in turned frames" kill lived here
    // for half a day and was measured FALSE both ways: the reference run spends
    // 1,282 of its 3,260 turned-frame ticks above pmax-15 (up to +1,069px -- the
    // tower at t=13,33x), and inside the DP the kill pruned exactly the
    // reference-shaped climb (the west weave whose jump apexes cross pmax-13,
    // killed at t=16,554 on a bit-exact replay), leaving only the eastern dead-end
    // branches that die under the roof at (20,175,1,215). The ship wedge at
    // y = pmax-15 exactly is real, but it is a property of that worldline's frozen
    // camera, not a law of the ceiling; the wedge machinery (stall guard, wedge
    // credit, mode-specific veto) owns that case now.    // --deadband x0,x1 (repeatable): discard branches that enter this x band.
    //
    // Why it is needed: a deepest-first driver keeps choosing "dead ends that are
    // merely deep".
    // lv22's fast lane jams at x=5,097 (confirmed by measurement: GD section solver,
    // 1,743 layers + 4 entry steps, all EXHAUSTED), but the branches that reach it are
    // the deepest, so the correct slow lane is never chosen. A point DOOMED is not
    // enough; the **whole band** is closed to force the split earlier. Like needtrig
    // this is search guidance, not a seed (the band comes from a measured jam; it does
    // not violate CLAUDE.md's cold rule).
    // ...and a band is WORLD-COORDINATE guidance, so it is tested against the world
    // point, not the frame's own. Every band that exists is authored that way: the
    // phantom veto draws its box around GD's dump state (repair.hpp, checkPhantom) and
    // a hand-written --deadband is read off GD too. Tested in frame coordinates a band
    // in a turned stretch cannot match anything -- lv22's cold run vetoed the wall at
    // (2266,229) twice while the search was in frame 1, where the travel coordinate is
    // about -229 and the band asks for 2262..2270, and then spent 114 rounds walking
    // back into the box the veto had already closed.
    if (!g_deadBands.empty()) {
        double dbX = x, dbY = (double)s.y;
        if (s.frame & 3) fromFrame((int)s.frame, x, (double)s.y, dbX, dbY);
        for (const auto& db : g_deadBands) {
            if (dbX < db.x0 || dbX > db.x1 || dbY < db.y0 || dbY > db.y1)
                continue;
            // mode semantics at the struct: -1 all die, >=0 forcing, <=-2 only
            // that one mode dies (what a refutation honestly supports).
            const bool hit = (db.mode == -1)
                || (db.mode >= 0 && (int)s.mode != db.mode)
                || (db.mode <= -2 && (int)s.mode == -2 - db.mode);
            if (hit) {
                // The coordinates go with the object: without this the outcome
                // publishes the last killer's position under uid = -1 (see DIE).
                dead = true; g_deadWhy = "deadband"; g_deadObj = nullptr;
                g_deadCx = g_deadCy = 0.f;
                return c;
            }
        }
    }
    // GD's MAX GAMEPLAY Y (--maxplayy; the disassembly is at g_maxPlayY's
    // declaration). World y above the bound is out of bounds; GD destroys with
    // a NULL object after two consecutive out-of-bounds ticks. Checking the
    // INCOMING state's world y lands the model's death on the same tick as
    // GD's latch for a state that stays out; one that pokes above for exactly
    // one tick dies here but survives in GD -- the bound sits 390px above the
    // level's top structure, nothing playable does that. This is what closes
    // the sky-escape phantom: lv22's cold run was pinned at 41% planning a
    // free ball climb to y=3,600+ that GD kills (fresh world at the bound
    // 3,675; the loop's own dirty worlds even earlier). Rotated frames map
    // through fromFrame the same way the deadbands above do. The mini bound
    // adjustment (checkCollisions adds (1-sizeFactor)*vehicleSize*k) is left
    // off: it only RAISES the bound, so full-size is exact and mini errs a few
    // px early at an altitude nothing reaches legitimately.
    if (g_maxPlayY < 1e17) {
        double wy = (double)s.y;
        if (s.frame & 3) {
            double wx;
            fromFrame((int)s.frame, x, (double)s.y, wx, wy);
        }
        if (wy > g_maxPlayY) {
            dead = true; g_deadWhy = "maxplayy"; g_deadObj = nullptr;
            g_deadCx = g_deadCy = 0.f;                      // see the deadband site
            return c;
        }
    }
    // --offboard (EXPERIMENT; speed.hpp): the loop's playfield bound, against the recorded band's
    // row at this tick -- the row offBoardTick reads for the attempt, in world y.
    if (g_offBoardMargin > 0.0) {
        double fl = 0.0, ce = 0.0;
        if (bandTrackRowAt(K.t, fl, ce)) {
            double wy = (double)s.y;
            if (s.frame & 3) {
                double wx;
                fromFrame((int)s.frame, x, (double)s.y, wx, wy);
            }
            if (wy > ce + g_offBoardMargin || wy < fl - g_offBoardMargin) {
                dead = true; g_deadWhy = "offboard"; g_deadObj = nullptr;
                g_deadCx = g_deadCy = 0.f;                  // see the deadband site
                return c;
            }
        }
    }
    // Player half sizes for THIS tick. Mini shrinks every box, so the rest of
    // the body reads them from here instead of from the constants. The size
    // portal is resolved at the end of the tick, so a change only takes effect
    // on the next one -- which is what GD does (lv11: the portal box is entered
    // at t=3384 and the player first loses support at t=3385).
    // ...and the WAVE's is 10, not 15 (see kWaveHalf). This has to be the
    // half used for PORTAL, pad and orb contact too, not just for collisions:
    // with 15 the model entered lv17's ship portal at (8865,195) four ticks
    // early (it fires at |x - cx| <= hw + half, so 8833 instead of 8838) and
    // came out halved and in the wrong mode while GD was still a wave.
    // `s.mode` and not `c.mode`: on the tick a portal switches modes, the
    // contact test that switched it belongs to the OLD body.
    const double pHalf = playerHalf(s.mode, c.mini != 0);
    // pInner is NOT scaled by mini. Bracketed on lv12's block at x[5820,5850]
    // y[180,210], where a mini cube falls past the left face:
    //   t=4479  |dx| 21.19  |dy| 11.17  GD does NOT kill  -> pInner <= 6.19
    //   t=4480  |dx| 19.89  |dy| 14.39  GD KILLS           -> pInner >  4.89
    // so pInner is in (4.89, 6.19] and the full-size 5.0 sits inside it, while
    // the scaled 3.0 does not. With 3.0 the model never killed at all: by the
    // time |dx| dropped under 18 the cube had fallen out from under the block,
    // and the DP happily planned straight through a wall GD stops it at.
    const double pInner = kCubeInner;
    dead = false;
    // Was the cube touching a solid from below at THIS tick's x, before the
    // input was applied? The stair snap needs this rather than c.grounded: on
    // the tick the player jumps, c.grounded goes 0, but GD still resolves the
    // bottom collision and still refreshes m_snapDistance. Gating on c.grounded
    // dropped exactly that one tick, leaving every snapDistance 1.308 px (one
    // tick of x) short -- measured against GD on lv4, every snap event.
    bool cubeContact = false;
    // Whether this is a tick on which GD called `runNormalRotation` (= the tick
    // that rewrites the rotation's sign). The callers are **take-off and
    // rings/orbs/pads**; **portals do not call it**.
    // Measured (lv20): the green ring at t=7,154 (flip 0->1) reverses the sign of
    // rot, but the gravity portal at the teleport destination at t=7,282
    // (flip 1->0) does not, and the next reversal was the yellow pad at t=7,286
    // (flip stays 0, sign +). "Rewrite whenever flip changes" would wrongly
    // rewrite at 7,282.
    bool rotWrite = false;
    // ...and whether that call came from a PAD, which additionally turns the
    // sprite one full step on the tick itself (measurements at the use site).
    bool rotPadSpin = false;
    // ...and the gravity that pad's call saw. Its own, not rotWriteFlip's: a
    // ring or orb later in the same tick overwrites rotWriteFlip (the assignment
    // inside applyOrb), and the pad's step has to keep the value from its own
    // call. The two never differ in this corpus -- 0 of the 289 pad ticks the 22
    // replays take -- so this is a guard, not a measured effect.
    uint8_t rotPadFlip = 0;
    // ...and the sign written is "the gravity **at the moment of the call**".
    // Inside ringJump the call site comes after the green ring's (29) flip
    // (0x3993bf) and before the gravity orb's (13) flip (0x399608). The
    // measurements mirror that order exactly:
    //   lv20 t=7,154 green ring  flip 0->1 -> rot **does reverse** (new gravity)
    //   lv22 t=685   gravity orb flip 0->1 -> rot **does not reverse** (old gravity)
    // So "the new one whenever flip changes" breaks lv22 (measured: tracking fell
    // from 400 -> 181 ticks). Default to the value from before entering the
    // branch, and override for the green ring only.
    uint8_t rotWriteFlip = 0;
    // The surface a standing player is being CARRIED by this tick, if it moved
    // (see the ride block near the stair snap). Only a MOVING support sets it,
    // so a static floor leaves everything bit-identical.
    bool rideOn = false;
    double rideFace = 0.0;
    // ...and how far that face moved THIS tick. The ride carries the player by
    // the face's delta rather than re-seating it on the face, so an offset the
    // state came in with survives. It only differs after a RE-ANCHOR: from the
    // head the player is exactly on the face and the two are the same number.
    // Measured on lv22 (2026-08-14): the ladder's anchor at t=5,769 sits in the
    // middle of a sinking-floor ride in the ball corridor, and the re-seat
    // dragged the player 2.559 px down on the very first tick
    // (`first divergence t=5,770 dy=-2.5590 dvy=+0.0000`), so every anchor taken in
    // that corridor started 2.5 px below GD.
    double rideDy = 0.0;
    double rideGap = 0.0;   // how far the chosen face is from the foot
    // A pad sitting ON a block fires in the same tick the cube would land on
    // that block's corner. GD resolves both in one pass and the pad's upward
    // velocity wins: the player never rests on the block. The model landed
    // first, so its y was snapped to the surface and ran 0.71 px above GD from
    // there on (measured on lv6, t=4502, yellow pad on the block at x=5864).
    bool landedThisTick = false;
    // [2026-08-21 r94] **When several faces satisfy the landing condition on the
    // same tick, the face that is highest "up" along the gravity direction wins.**
    // Not scan order. Measured lv16 t=17,627 (a cube falling at the end lands on
    // the corner at x=27,150): overlapping there are
    //   uid8869 (30x30 block, top face **600.000**)
    //   uid8868 (30x1.5 slab, top face **599.95**)
    // and GD landed at 615.000 (=600+15), the model at 614.950 -- the loop's
    // **last-one-wins** let the lower slab overwrite. The flight branch's support
    // scan has long taken "the face that actually supports = highest along the
    // gravity direction" (see the note at lv19 t=21,746). Same rule for landing.
    double landFaceBest = 0.0;
    float preLandY = 0.f;
    // ...and the SAME start-of-tick problem hits the stair snap. `cubeContact`
    // above is the support the state came in with, so it covers "was standing,
    // then jumped" but NOT "landed and jumped on the same tick" -- there
    // s.grounded is 0 (airborne) and c.grounded is set back to 0 by the jump
    // (see the cube branch by `impulsedThisTick`), so the snap block never ran.
    // GD calls checkSnapJumpToObject from the landing branch of
    // collidedWithObjectInternal, i.e. on the collision itself, before the
    // buttons: measured on lv21 t=1172 (cfg snaptrace=1) GD logs
    //   prev=567,(1425,165) obj=664,(1515,225) dx=90 dy=60
    //   x=1521.5475->1522.5475 d=+1.0000 sd=13.4615->7.5475
    // -- the `big` pattern, off a buffered press. The model held the identical
    // snapObj and snapDistance (13.4615) and simply did not make the call, so it
    // ran exactly 1 px behind GD from t=1173 to the end of the level (18,700
    // ticks), which is the whole of lv21's x divergence.
    // Kept separate from `landedThisTick` because `releasePin` clears that one
    // on a slope release, where GD's snap call still happens.
    // [2026-09-05 CORRECTED] This used to read "...whether or not a pad later
    // undoes the landing", and that half was never measured: the lv21 t=1,172
    // evidence above is a yellow ORB (11.180 = kOrbYellow), and an orb reaches
    // releasePin by a different route (the orb loop's `if (ob->type != 13)`).
    // The only pad case in the corpus says the opposite -- lv13 t=16,783, where
    // gdref's snapuid stays 4973 across the tick and hbox reports hit=0 for the
    // solid. GD never lands there at all: the activation pass runs before the
    // solid pass, the pad has already set vy = -12.8, and collidedWithObject's
    // inverted branch gates on `vy >= 0`. So releasePin now clears this flag too
    // (see there), and a pad-undone landing runs no snap.
    // The orb route at the type != 13 line reaches the same branch, so the same
    // correction applies to it; the corpus has no instance of an orb undoing a
    // landing that also matched a stair pattern.
    bool cubeLandedThisTick = false;
    // [2026-08-21 r84] The tick on which, mid-ride, the player moved onto a "step
    // deeper than the line". The ride ends there (on a tick with this flag set both
    // the stick and the seat-priority are stopped -- otherwise the slope pulls the
    // player straight back to the seat and the step is as if it never existed).
    bool stepLandedThisTick = false;
    // The same thing for a player that was ALREADY resting on a block: it also
    // carries this tick's gravity step until something re-seats it. Filled in
    // by the cube branch (see the long note at `pinnedOnBlock`), consumed by
    // whatever launches the player out of the pin.
    //
    // `pinnedOnBlock` is tested BEFORE `landedThisTick` and not after: a ramp
    // ride sets BOTH (the slope code books a landing on every riding tick), and
    // taking the landing branch there puts the player straight back on the
    // ramp's surface -- which is exactly the 0.0486 px this is here to keep.
    // They are otherwise mutually exclusive (landing from the air means the
    // state came in with grounded = 0, so nothing was pinned).
    bool pinnedOnBlock = false;
    float prePinY = 0.f;
    // Whether this tick jumped through a teleport portal (pads/orbs at the landing site
    // count from the next tick).
    bool teleportedThisTick = false;
    // ...and **the uid of the teleport that fired on that tick**. GD processes the
    // objects of one section in uid order, and a teleport does not change x
    // (ignoreX/Y=0), so the landing site falls in the **same section**. That is:
    //   uid > teleport's uid -> processed after the teleport = **fires on the
    //   landing tick**
    //   uid < teleport's uid -> already processed = judged at the old position
    //   (usually does not fire)
    // Measured (GD, cfg padtrace=1/hitboxtrace=1):
    //   lv20 dump t=7,282: teleport uid7021 -> yellow pad uid7025 fires on the
    //     **same tick**, vy 15.000 -> -16.000 (p=(10830.065,161.000) = post-landing
    //     coordinates), then uid7026 re-fires with the same value, and finally the
    //     gravity portal uid7028 flips + halves to -8.000. All three uids are
    //     greater than 7021
    //   lv21 dump t=4,710: teleport uid5090 -> gravity portal uid5050 fires on the
    //     **next tick**. Smaller uid
    // A blanket "landing site counts from the next tick" breaks lv20; a blanket
    // "same tick" breaks lv21. uid order explains both.
    int teleUid = -1;
    // The SPIDER's tap moves y discontinuously, and GD's collision pass never
    // looks at the path it did not travel. Set where the teleport lands, read
    // by the hazard sweep below (which otherwise samples s.y -> c.y and kills
    // on anything in between).
    bool spiderWarpedThisTick = false;
    // `undoSnap` is passed ONLY by the two impulse sites (the pad at the
    // `pad wins` comment and the orb loop's `type != 13` line). The two slope
    // releases pass false: this diff has no measurement covering them, and a
    // release is not an activation reordering -- GD does land on the ramp and
    // only leaves it afterwards, so there is no reason to think its snap call
    // is skipped there. Clearing the flag for all four callers would have been
    // an unmeasured claim about the slope path riding along with a measured one
    // about the pad path.
    auto releasePin = [&](bool undoSnap) {
        if (pinnedOnBlock) {
            YSET(c.y) = prePinY;
            pinnedOnBlock = false;
        } else if (landedThisTick) {
            YSET(c.y) = preLandY;
            landedThisTick = false;
            // ...and the STAIR SNAP must not run either. GD does not undo a
            // landing at all -- it never makes one. checkCollisions (0x2137f0)
            // runs the activation pass (0x214412 / 0x21446e) BEFORE the solid
            // pass (0x214687), so propellPlayer (0x39f850) has already written
            // vy synchronously -- for lv13's mini yellow pad, sign * strength *
            // 16.0 * 0.8 = exactly -12.8 -- and the solid pass then reads that.
            // collidedWithObject's inverted branch gates on the sign alone:
            //   0x392a60  movsd  xmm0, [r14+0x9a0]   ; m_yVelocity
            //   0x392a69  comisd xmm0, xmm11         ; 0.0
            //   0x392a6e  jae    0x392a9b            ; vy >= 0 lands, else no-op
            // At -12.8 the jae falls through to the no-op exit and the call
            // returns hit=0. There is NO minimum-overlap threshold (the 0.3
            // inset belongs to the crush test) and the rect is built from
            // getRealPosition, which does not read velocity -- so the 0.147 px
            // overlap was never the discriminator.
            // This undo is the model's way of replaying that ordering after the
            // fact, and it was only half done: `landedThisTick` was cleared but
            // `cubeLandedThisTick` was not, and the snap gate below reads the
            // latter -- so the snap ran, matched a stair pattern, and wrote
            // +1.0000 into c.xAbs that GD never wrote. lv13 t=16,783 is the
            // whole of that level's remaining divergence: gdref's snapuid stays
            // 4973 across the tick and hbox reports hit=0 for the solid 4987.
            // Clearing it here also keeps snapObj/snapDist untouched, which
            // matters -- rolling back only x would leave snapObj = 4987 and
            // corrupt the NEXT tick's stair pattern match.
            if (undoSnap) cubeLandedThisTick = false;
        }
    };
    // Did this tick consume a discrete impulse (cube jump / ball flip / UFO
    // flap)? GD's per-tick order is update -> checkCollisions -> buttons, so an
    // impulse on the same tick as a MODE portal belongs to the NEW mode.
    // Measured on lv12 t=16112: a grounded UFO enters the cube portal at
    // x=20919 and GD reports vy = 11.1800, a plain cube jump, on that tick --
    // not the UFO's flap 6.871, and not that flap halved by the portal (3.4355,
    // which is what the model produced). The DP was buying a boost GD refuses.
    bool impulsedThisTick = false;
    // --portalpress: the grounded press action this tick took (1 cube jump, 2 ball tap), and
    // whether a mode portal undid it for the new mode to redo.
    int pressAction = 0;
    bool portalPressRedo = false;
    // --padsection: the size portal this tick fired, for GD's collision order against the pads
    bool sizeFiredThisTick = false;
    double sizeFiredCx = 0.0, sizeFiredCy = 0.0;
    int sizeFiredUid = -1;
    uint8_t sizePreMini = s.mini;
    // --lawseatonslope: the --slopelaw seat wrote this body's y on a floor ramp this
    // tick (read where slopeT is computed; see State::seatT).
    bool lawSeatedNow = false;
    // --mpushlaunch: GD's m_c6 for this tick as the push-out wrote it (0 when
    // nothing did -- postCollision zeroes it at every tick's end).
    double c6Now = 0.0;
    const bool wasGrounded = (s.grounded != 0);
    // A pad also beats the ball's tap-flip. Measured on lv9 t=9126: a flipped
    // ball on a ceiling taps while touching the pad under it, and GD comes out
    // STILL flipped with the pad's velocity -- the flip never happens. The model
    // flipped first, which then made its own pad test look at the wrong side and
    // skip the pad entirely, so it read -3.354 where GD had -9.600.
    bool ballFlippedThisTick = false;
    // mode 0 = cube, 1 = ship, 2 = ball. Cube and ball share this branch: the
    // ball is a cube with a weaker gravity whose tap flips gravity instead of
    // jumping. Everything else (support, landing, hazards) is identical.
    // mode 3 = UFO. It shares the ship's whole contact story (rides floors,
    // lands from above, inner-box side kills, ceiling ride) and differs only in
    // how vy advances, so it goes down the ship branch rather than getting a
    // third copy of the collision code that would drift out of sync.
    // mode 4 = WAVE. It is not a variant of anything else: there is no gravity,
    // no impulse and no landing -- the player travels on a fixed diagonal whose
    // direction is the input, and the only thing that ever happens to it is
    // dying. Measured on lv17 t=3396..3412 (speed 0.9, full size), holding
    // nothing: x advances 1.29825 and y falls 1.29825 EVERY tick, i.e. exactly
    // 45 degrees, and the dump reports a constant yvel of -5.193 = 4 * dx.
    // (The reported velocity is carried so the dump and the dedupe key stay
    // meaningful; nothing reads it as an integrator.)
    // Contact is the ship's old under-approximation: ANY solid overlap ends the
    // branch. GD lets a wave graze some surfaces, so this is conservative --
    // it can only refuse routes, never invent one.
    if (s.mode == 4) {
        // The wave's box is SMALLER than everyone else's. Measured on lv17
        // t=3564..3565: it comes down the diagonal and stops dead at y=100.000
        // with vy=0 and onGround=1, then slides. The band's floor there is 90,
        // so the half extent is 10, not the 15 every other mode uses.
        const double wHalf = (c.mini ? kWaveHalfMini : kWaveHalf);
        // ...and the HAZARD half is a different one again for MINI. The
        // disassembly note at the hazard branch below says stage 1 is the AABB
        // of `player->getObjectRect()`, and that rect is 10x10 full / **6x6
        // mini** (cfg `hitboxtrace=1`) -- half 5.0 and 3.0. kWaveHalf is already
        // 5.0, but the mini value here (kWaveHalfMini = 2.0) is a bracket taken
        // off a SPEED PORTAL's firing, which is a different code path.
        // Bisected live in GD on both sides of the box, two levels, two speeds:
        //   lv21 t=14411 sp0.9, uid18870 top 124.988, read at x=18713.57
        //     centre 2.762 / 2.962 above -> dies    3.012 / 3.512 -> lives
        //   lv18 t=19426 sp0.7, uid13692 (26958,214) 6x7.2, top 217.6
        //     centre 2.95 above -> dies             3.05 -> lives
        //   lv18 t=19421 sp0.7, same spike, SIDEWAYS (y held at 216, inside the
        //     band): right edge to x=26,952.05 -> dies, 26,951.95 -> lives
        // so the box is square and the boundary is 3.000 on every face, with
        // touching counting as a hit. It is NOT speed-dependent.
        const double wHazHalf = (c.mini ? kWaveHazHalfMini : kWaveHalf);
        // The direction is the input the state came in WITH, not this tick's --
        // GD's per-tick order is update -> checkCollisions -> buttons, so a
        // press lands one tick later. Measured on lv17: the wave is pinned on
        // the floor at y=100 through t=3619 and only starts climbing at t=3620,
        // while the model turned at 3619 and ran a tick ahead from there on.
        // ...and a MINI wave climbs and dives at TWICE the angle. Measured on
        // lv20 t=654, the tick the size portal fires: y steps by 1.29825 while
        // vsize is 1.0 and by 2.59650 from the tick vsize reads 0.6 -- exactly
        // 2x, four digits, with the speed and everything else unchanged.
        // The REPORTED velocity does not double: GD prints -5.193 (= 4 * dx)
        // on both sides of the portal, so `c.vy` keeps the un-doubled value.
        // That matters because the driver re-anchors from GD's yvel column and
        // reads the wave's direction back out of its sign.
        // Without this the model held a 45-degree line where GD dived at 2:1
        // and was 8 px above it within six ticks; lv20's cold run sat at
        // x=907..956 for a dozen iterations.
        const double waveSlope = c.mini ? 2.0 : 1.0;
        const double dyDir = (s.held ? 1.0 : -1.0) * (s.flip ? -1.0 : 1.0);
        const double dy = dyDir * useDx * waveSlope;
        YSET(c.y) = (float)((double)s.y + dy);
        yFree = c.y;
        VYSET(c.vy) = (float)(dyDir * useDx * 4.0);
        c.held = (uint8_t)input;
        c.grounded = 0;
        // SPRITE ROTATION. The dart eases toward the angle it is travelling at,
        // by a FIXED fraction of the remaining gap each tick:
        //     rot += kWaveRotK * (target - rot)
        // Fitted from GD's own OBB corners (cfg hitboxtrace=1, `pobb`), lv20's
        // whole run, grouped by size and speed:
        //     full  k = 0.06250  (781 samples at dx=1.950, and 0.0624/0.0627 at
        //                         dx=1.298 / 1.614 -- speed-independent)
        //     mini  k = 0.10000  (110 samples)
        // and the target is the travel angle itself, +45/+63.435 going DOWN and
        // -45/-63.435 going up (cocos rotation is clockwise-positive), i.e.
        // atan(slope) with slope 1 full / 2 mini. The two k are MEASURED, not
        // derived -- nothing yet explains why mini eases 1.6x faster.
        {
            const double target = kRadToDeg * std::atan(waveSlope)
                                * (dy < 0.0 ? 1.0 : -1.0);
            const double k = c.mini ? kWaveRotKMini : kWaveRotK;
            c.rot = (float)((double)s.rot + k * (target - (double)s.rot));
        }
        // ...and it RIDES the band rather than dying on it (the t=3565 slide
        // above runs for 30+ ticks with y pinned at 100.000).
        const double wClamp = (c.mini ? kWaveClampMini : kWaveClamp);
        // The recorded band, if any, takes priority over the frozen band (history at
        // the declaration of g_bandTrack). But **only while the current y is inside
        // the recorded band**: in a section flying outside the band GD's pmin/pmax
        // are merely camera state, not a clamp (same reasoning as --startband's
        // OUTSIDE gate; measured 2026-08-16, when letting the track pass through
        // wiped out every anchor in the ball section).
        double btF = (double)s.bandFloor, btC = (double)s.bandCeil;
        if (s.frame == 0) {
            // Only an interval is a band to sit in. A collapsed one is not a
            // ceiling, an absent one is not a ceiling either, and a row the
            // writer could not read says nothing -- in all three the state's own
            // band stands. (Before the kinds existed the three arrived as "no
            // row" and this kept the last interval it had seen instead.)
            BandKind bk = BandKind::Unknown;
            double f_ = btF, c_ = btC;
            long long bage = 0;
            if (bandTrackKindAt((long long)K.t + 1, bk, f_, c_, bage)
                && bk == BandKind::Interval
                && (double)s.y >= f_ - 1.0 && (double)s.y <= c_ + 1.0) {
                btF = f_; btC = c_;
            }
        }
        const double bFloor = std::max(btF, kGroundY);
        const double yMaxW = btC - wClamp;
        if (g_bandDbg && (double)c.y > yMaxW - 8.0)
            std::printf("banddbg t=%lld x=%.1f y=%.2f band=[%.0f,%.0f] yMaxW=%.1f\n",
                        (long long)K.t, x, (double)c.y, (double)s.bandFloor,
                        (double)s.bandCeil, yMaxW);
        if ((double)c.y > yMaxW) {
            YSET(c.y) = (float)yMaxW; VYSET(c.vy) = 0; c.grounded = 1; CLAMP0("wave/ceil");
        }
        if ((double)c.y < bFloor + wClamp) {
            YSET(c.y) = (float)(bFloor + wClamp); VYSET(c.vy) = 0; c.grounded = 1;
            CLAMP0("wave/floor");
        }
        if (c.y > g_yBound) DIE("wave/out-of-play", nullptr);
        // A WAVE STANDS ON A SOLID ONLY WHILE THE DART SLIDE ARM HOLDS, and the
        // arm comes from touching an id 1755 box on this tick or the one before
        // (slideBoxTouch, where the sweep that measured it is written up).
        //
        // Armed, contact with the top face puts the player at top + wave half --
        // a PUSH-OUT, not a landing: the sweep lifted players injected 1 to 6 px
        // INTO the block back to the same line, with no depth, horizontal or
        // phase condition. Unarmed, the face does nothing, which is why lv17's
        // wave passes 0.47 px through a block's seat line and flies on.
        //
        // Without this the model falls through the face GD stands it on and dies
        // to the crush test a tick later (lv22 t=20,133).
        //
        // Full size only: the sweep has zero mini samples and no 0.6 is invented
        // here. Top face only, for the same reason. Collected in the loop and
        // applied after it, because the sweep below reads its path from c.y.
        double waveSeat = -1e18;
        const bool slideArmed = c.slideT < kArmTicks;
        for (const Obj* o : *K.near) {
            if (dead) break;
            // --hazdbg <uid> in the FLIGHT loop too: the flag's own note says
            // "the ground-mode hazard loop", and a wave that GD kills and the
            // model does not (lv19 t=7,130, uid 4666) had no line to read at
            // all. Print only, gated on the uid, so the search is untouched.
            if (g_hazDbgUid == o->uid) {
                // the two gates at the tick's own end position, which is the sample
                // GD's collision pass runs (si = kSubSteps)
                const bool g1 = hazardHit(o, x, (double)c.y, wHazHalf, kHazMargin,
                                          kSawMargin, 4, c.mini);
                const bool g2 = (!o->obbOk || s.mode != 4
                                 || obbOverlap(*o, x, (double)c.y, wHazHalf,
                                               (double)s.rot));
                const double ddx = x - o->cx, ddy = (double)c.y - o->cy;
                const double hh_ = wHazHalf + kHazMargin;
                const double rr = hh_ * (std::fabs(o->bc) + std::fabs(o->bs));
                const double lx_ = ddx * o->bc + ddy * o->bs;
                const double ly_ = -ddx * o->bs + ddy * o->bc;
                const double ex_ = o->bhw * std::fabs(o->bc) + o->bhh * std::fabs(o->bs);
                const double ey_ = o->bhw * std::fabs(o->bs) + o->bhh * std::fabs(o->bc);
                std::printf("wavehazgate t=%lld uid=%d stage1=%d stage2=%d slope=%d "
                            "dx=%.3f dy=%.3f bc=%.4f bs=%.4f r=%.3f lx=%.3f/%.3f "
                            "ly=%.3f/%.3f ex=%.3f ey=%.3f\n",
                            (long long)K.t, o->uid, g1 ? 1 : 0, g2 ? 1 : 0,
                            (int)o->slope, ddx, ddy, o->bc, o->bs, rr,
                            lx_, o->bhw + rr, ly_, o->bhh + rr, ex_, ey_);
            }
            if (g_hazDbgUid == o->uid)
                std::printf("wavehaz t=%lld uid=%d type=%d cx=%.3f cy=%.3f hw=%.3f "
                            "hh=%.3f obbOk=%d bhw=%.3f bhh=%.3f r=%.3f "
                            "x=%.3f xPrev=%.3f y=%.4f yPrev=%.4f rot=%.4f "
                            "half=%.2f mini=%d mode=%d frame=%d\n",
                            (long long)K.t, o->uid, (int)o->type, o->cx, o->cy,
                            o->hw, o->hh, (int)o->obbOk, o->bhw, o->bhh,
                            o->radius, x, xPrev, (double)c.y, (double)s.y,
                            (double)s.rot, wHazHalf, (int)c.mini, (int)c.mode,
                            (int)s.frame);
            if (slideArmed && !c.mini && o->type == 0 && !o->slope
                && !o->oriented) {
                const double top = o->cy + o->hh;
                if (std::fabs(x - o->cx) <= o->hw + wHalf
                    && (double)c.y >= o->cy && (double)c.y <= top + wHalf)
                    waveSeat = std::max(waveSeat, top + wHalf);
            }
            // The sweep below is the rest of this object's turn; see outOfSweepReach.
            if (outOfSweepReach(o, xPrev, (double)s.y, x, (double)c.y,
                                std::max(wHazHalf, kWaveKillHalf)))
                continue;
            for (int si = 0; si <= kSubSteps && !dead; ++si) {
                const double f = si / (double)kSubSteps;
                const double sx = xPrev + (x - xPrev) * f;
                const double sy = (double)s.y + ((double)c.y - (double)s.y) * f;
                if (o->type == 0) {
                    // <= and not <: exactly-touching dies (measured, see
                    // kWaveKillHalf).
                    if (std::fabs(sy - o->cy) <= o->hh + kWaveKillHalf
                        && std::fabs(sx - o->cx) <= o->hw + kWaveKillHalf)
                        DIE("wave/solid", o);
                    // The HAZARD still runs on the contact half, and that is a
                    // PLACEHOLDER, not a measurement. What is measured is that
                    // both shapes on offer are wrong, so there is nothing to
                    // switch to yet (2026-08-09, lv20 spike id667 rot -63 at
                    // (1057.19,167.595), the kill boundary swept in x and
                    // bisected in y to 0.014 px, one tick, 33 positions):
                    //
                    //   x <= 1054.0   rising, slope +1.969
                    //   1054.25..1057.00  FLAT at y = 175.964   (width 3.00)
                    //   1057.25..1060.25  slope -0.314
                    //   x >= 1060.5   slope -0.503
                    //
                    // Four straight pieces. A turned RECTANGLE dilated by an
                    // axis-aligned player box can only produce three (its two
                    // edges plus the player's flat top), so the tested shape is
                    // not o->hw/hh (the bound: refuted twice over) and not the
                    // recorded OBB either. Its own two edges do show up as the
                    // +1.969 and -0.503 ends; the -0.314 in between belongs to
                    // something neither shape has.
                    //
                    // The flat is worth reading: its width is 3.00 = 2 * 1.5,
                    // which is the SOLID half, so the player's box is very
                    // likely 1.5 here too and the earlier "hazards use the
                    // contact half (2.96..2.98)" was an artefact of assuming
                    // the hazard was its OBB. Do not act on that until the
                    // shape is known -- the two are not separable from one
                    // boundary.
                    // ...and the path was found, by disassembly. GD's hazards
                    // never go through collidedWithObject at all: there is a
                    // dedicated loop in GJBaseGameLayer::checkCollisions
                    // (win 0x2137f0, head 0x2147C0) that ends in
                    // destroyPlayer(player, obj), and it is TWO tests, not one:
                    //   1. AABB of player->getObjectRect() vs the object's rect
                    //   2. if obj->m_shouldUseOuterOb, the two ORIENTED boxes
                    // The four-piece envelope above is those two conditions and
                    // not one exotic shape -- the flat is stage 1 (it sits at
                    // objMaxY + 3.0 on both spikes measured), the slopes are
                    // stage 2. That is why no single box ever fitted.
                } else if (hazardHit(o, sx, sy, wHazHalf, kHazMargin,
                                     kSawMargin, 4, c.mini)
                           // Stage 2. `s.rot` and not `c.rot`: the collision
                           // pass runs BEFORE the rotation is updated for the
                           // tick. Measured both ways on lv20 t=816 -- this
                           // tick's 22.113 puts the boundary at 175.586 and
                           // misses by 0.05, the previous tick's 17.522 gives
                           // 175.632 and lands inside the 0.014 px bracket.
                           && (!o->obbOk || s.mode != 4
                               || obbOverlap(*o, sx, sy, wHazHalf, (double)s.rot))) {
                    DIE("wave/hazard", o);
                }
            }
        }
        // ...and the push-out, once every object has had its say (see waveSeat).
        if (!dead && waveSeat > -1e17) {
            YSET(c.y) = (float)waveSeat;
            VYSET(c.vy) = 0;
            c.grounded = 1;
            CLAMP0("wave/slide");
        }
        // ...and RAMPS, which live in their own array and so were invisible to
        // the loop above. A plain ramp lifts a cube or a ball out (see the
        // slope block below), but the wave has no such resolution -- it just
        // dies. Measured on lv17 t=3699: zig-zagging at y=190.9/192.2 the wave
        // runs into the 30x30 ramp at (4815,195) and GD destroys it, while the
        // model flew on and the loop sat at x=4,805 for 40 iterations.
        // A ramp's solid half is on ONE side of its line, and which side is
        // slopeDir's business, not the line's (slopeIsCeiling). Testing every
        // ramp as if the solid were "box floor up to the line" kills the wave
        // in the EMPTY half of a ceiling ramp: lv20's zig-zag corridor is a
        // floor ramp with a mirrored ceiling ramp 100 px above it, and the
        // model died 8 px below a ceiling it never touched, on the rising tick
        // only, from t=4043 (x=5,640) on -- the whole x=6,342 wall.
        if (K.slopes) {
            const double wsR = (c.mini ? kWaveSlopeDxRMini : kWaveSlopeDxR);
            const double wsL = (c.mini ? kWaveSlopeDxLMini : kWaveSlopeDxL);
            const double wsY = (c.mini ? kWaveSlopeDyMini : kWaveSlopeDy);
            for (const Obj* sp : *K.slopes) {
                if (dead) break;
                const double sx0 = sp->cx - sp->hw, sx1 = sp->cx + sp->hw;
                if (x + wHalf <= sx0 || x - wHalf >= sx1) continue;
                const double sm = (sp->sy1 - sp->sy0) / (sx1 - sx0);
                const bool ceilRamp = slopeIsCeiling(sp->slopeDir);
                // Sample where the wedge is THICKEST -- the corner of the box
                // that reaches deepest into the player. For a ceiling that is
                // where the line is lowest, for a floor where it is highest,
                // which comes out as the same end of the object either way.
                // The clamp to the box is what makes the boundary go flat
                // around a corner instead of following the line out of it.
                const bool toRight = ceilRamp ? (sm < 0.0) : (sm > 0.0);
                const double sxc = std::min(std::max(x + (toRight ? wsR : -wsL),
                                                     sx0), sx1);
                const double surf = sp->sy0 + sm * (sxc - sx0);
                if (ceilRamp) {
                    // above the box entirely: clear of it (measured -- the
                    // sweep comes back alive at y >= 315 over a 280..310 box)
                    if ((double)c.y > surf - wsY
                        && (double)c.y - wsY < sp->cy + sp->hh)
                        DIE("wave/slope", sp);
                } else {
                    if ((double)c.y < surf + wsY
                        && (double)c.y + wsY > sp->cy - sp->hh)
                        DIE("wave/slope", sp);
                }
            }
        }
    } else if (s.mode != 1 && s.mode != 3 && s.mode != 7) {
        const bool isBall = (s.mode == 2);
        // The ROBOT rides this branch too: it is a cube with a 0.9 gravity, a
        // half jump and a hover while the button is held (see kRobotGScale).
        // Everything else about it -- support, landing, stair snaps, hazards,
        // orbs, pads, slopes -- is the cube's, so it must not get a second copy
        // of that code.
        const bool isRobot = (s.mode == 5);
        // ...and so does the SPIDER, whose only difference from a ball is that
        // its tap teleports instead of flipping in place (see kSpiderGScale).
        const bool isSpider = (s.mode == 6);
        // The band clamps the BALL as well as the flying modes (GD's `flyish`
        // is m_isShip|m_isBird|m_isBall|m_isDart|m_isSpider|m_isSwing) and does
        // NOT clamp the cube. This is what every hand-placed `--ceil` was:
        // lv9's 330, lv14's 420@13100:13600 and lv15's 330@16300:17800 all come
        // straight out of their ball portal's cy. The knob stays as an override
        // and wins where it is given.
        // ...and the SPIDER is in GD's `flyish` list too (m_isShip | m_isBird |
        // m_isBall | m_isDart | m_isSpider | m_isSwing), so the band clamps it
        // exactly like the ball.
        // [CAUTION 2026-08-16] Do not apply bandtrack to the ball/spider. Once it
        // was applied, every anchor on the high route at lv22 t=5,6xx (ball at
        // y=983, recorded band 90..387) became PARTIAL t=0. There are two
        // measurements of GD's ball flying through while ignoring pmin/pmax (y=983
        // and y=3,677), while on lv9/14/15 there are also measurements of the ball
        // stopping at the band -- the condition is unresolved. Left as the frozen
        // band (the previous behaviour).
        // [2026-08-20 trial] When the band is **not on the grid** it is not a
        // physical ceiling. GD's pmax is a multiple of 30 when it comes from a
        // portal, but on lv22 it is the camera-derived value 386.999969, and GD's
        // ball punches through it at vy=6.5 (t=6,736..6,745, up to y=387.684). On
        // lv9 on the other hand pmax=330 exactly, and **even charging in at
        // vy=+15.000 (terminal velocity)** it stops at y=315.000 (t=7,312). Not the
        // speed but where the value comes from.
        // [2026-08-21 r81] The recorded band (--bandtrack), if any, takes priority
        // over the frozen band -- the same wiring as the wave/flight band clamps
        // (5803/7103) was missing from the ball/spider's ceilHere. Measured lv22
        // t=8,458 (spider warp): the model cuts the target to 586.5 with the
        // spider-portal-derived band 600, but GD's getMaxPortalY is camera-driven
        // at 755 (the dump's pmax says so directly) -- the recorded band is off-grid
        // so bandUsable drops out, and the warp reaches the actual object at 646.5.
        // The "only while the current y is inside the recorded band" gate is the
        // same (see the note at 5803).
        double bandCT = (double)s.bandCeil, bandFT = (double)s.bandFloor;
        if (s.frame == 0) {
            // Same reading as the wave side: interval or nothing.
            BandKind bk = BandKind::Unknown;
            double f_ = bandFT, c_ = bandCT;
            long long bage = 0;
            if (bandTrackKindAt((long long)K.t + 1, bk, f_, c_, bage)
                && bk == BandKind::Interval
                && (double)s.y >= f_ - 1.0 && (double)s.y <= c_ + 1.0) {
                bandFT = f_; bandCT = c_;
            }
        }
        const double bandC = bandCT;
        // ...and being on the grid is NOT enough: a CAMERA-driven band rests on
        // the grid whenever the camera is pinned at the floor, and GD's ball
        // flies straight through it. bandTrackIsCamera() carries the
        // measurements -- lv9's portal band blocks, lv22's camera band does not.
        // Only the whole recording can tell them apart, so a run without one
        // keeps exactly the old behaviour.
        // [2026-09-22] ...all of which was standing in for GD's Free Mode byte,
        // and is still what decides when that byte is not known (an anchor with
        // no hist v2): see bandIsWall.
        const bool bandUsable =
            bandC < 1e8
            && bandIsWall(s.bandBranch,
                          std::fabs(bandC - std::round(bandC / 30.0) * 30.0) < 0.01
                          && !bandTrackIsCamera());
        const double ceilHere = std::min(
            playerCeilAt(x),
            ((isBall || isSpider) && bandUsable) ? bandC : 1e9);
        // --tpbandskip / --ballceilpos [2026-09-19]: whether this tick's ceiling
        // is the BAND's (not the level's own ceiling), and whether a teleport on
        // the previous tick has GD skip the band block this tick (State::tpSkip).
        // lv20 t=9,233..9,235 (mini ball, 747 to y=505, band [270,510]): GD
        // leaves 9,234 at 503.361 unclamped and puts 9,235 at 501.000 = 510 - 9
        // with vy -7.414 kept -- a POSITION clamp that does not look at vy.
        const bool ceilIsBand = (isBall || isSpider) && bandUsable
            && bandC <= playerCeilAt(x);
        const bool tpSkipBand = s.tpSkip != 0;
        const CubePhys cph = cubePhysFor(useDx);
        // The SPIDER takes the ball's LITERAL, not the cube's g scaled by 0.6.
        // The lv22 note above already measured "-0.129 / tick ... the ball's
        // number to three digits" and then wrote it as 0.216 * 0.600 = 0.1296,
        // which qVy rounds to 0.130 -- 0.001 too much on every airborne tick.
        // GD's own lv21 replay steps by exactly 0.129, twelve consecutive ticks
        // across both orientations (t=9303.. +9.600 9.471 9.342 9.213 9.084
        // 8.955 8.826, and t=8470.. the same with the sign flipped).
        // It matters because it accumulates: 0.001 per tick is ~1 px of y after
        // 100 airborne ticks and ~4.5 px after 200, which is a different landing.
        // OPEN: measured at speed 0.9 only. The cube's g is speed-dependent
        // (-0.216 / -0.215 / -0.212) while the ball's is one flat literal; the
        // spider is given the ball's treatment because that is what it matched
        // here, not because the other speeds were checked.
        // The robot's g splits by speed band: in the fast band (dx>1.78, lv22's
        // sp1.4 plateau) GD measures **exactly -0.195** every tick (CLEARED
        // t=16,970-17,016, vy column 8.944->8.749->8.554...). With the rounded
        // total of cph.g*0.9=0.1944 (-0.194), the 0.001/tick accumulation turned
        // into a landing-phase shift on the plateau's bounces and SOLVED plans were
        // failing in GD (same family as the spider taking the ball's literal 0.129).
        // The slow band stays as before (-0.194): setting every speed to -0.195
        // turned lv19/20/21 red (10/2/4 sections) = the measurements there are
        // correct at -0.194. The cube's 1.4 row falls back, unmeasured, to 1.3's
        // {11.230, -0.216} (the jump side is unverified).
        // [2026-08-18] The robot's g is now a **table of literals** too (not 0.9x
        // the cube's). Measured by counting gdref's free-fall ticks across all
        // levels by speed and size (only ticks that are not pressed, not grounded
        // and not at terminal):
        //   robot 0.9  vsize1.0  n=2,305  -0.194 x2,304
        //   robot 0.9  vsize0.6  n=933    -0.194 x933
        //   robot 1.1  vsize1.0  n=2,424  -0.194 x2,422
        //   robot 1.1  vsize0.6  n=1,776  -0.194 x1,774
        //   robot 1.3  vsize1.0  n=767    -0.195 x694
        // cph.g * 0.9 comes to 0.1935 in the 1.1 band, and rounding to the 0.001
        // grid alternates 0.193/0.194. GD is exactly 0.194 on all 2,400 ticks. This
        // is the origin of fixcensus's largest family (lv19x5 + lv20x4, which the
        // landing clamp had turned into edy=+0.088).
        // ...and the BALL's 0.129 was confirmed **flat across all speeds and
        // sizes** (mode 0.129 in all 8 combinations of 0.7/0.9/1.1/1.3 x 1.0/0.6,
        // n=21,900). The "OPEN: measured at speed 0.9 only" above is resolved.
        const double gAcc =
            g_rawValues ? rawGravStep(isBall || isSpider, isRobot, (double)useDx)   // speed.hpp
            : isBall     ? kBallG
            : isRobot  ? ((useDx > 1.78) ? -0.195 : -0.194)
            : isSpider ? kBallG
                       : cph.g;
        const double gTerm = isBall ? kBallTerm : kCubeTerm;
        // cube. GD re-evaluates support at THIS tick's x before the input:
        // walking off the edge and pressing on the same tick does NOT jump
        // (measured at x=1546, lv1). All vertical reasoning is in the PLAYER
        // frame so flipped gravity is the same code with mirrored signs.
        const double gsign = s.flip ? -1.0 : 1.0;
        const double vp = (double)s.vy * gsign;
        auto faceOf = [&](const Obj* o) {
            return s.flip ? (o->cy - o->hh) : (o->cy + o->hh);
        };
        bool groundedNow = s.grounded != 0;
        // `s.y <= kGroundY + pHalf` is "standing on the world ground plane", so
        // the support scan is skipped and `grounded` is kept for free. That is
        // only true in the UNTURNED frame: in a turned one `y` is a world X, so
        // the test reads as "the player is left of world x=105" -- true for the
        // whole rotated section -- and the model stays grounded on nothing.
        // Measured on lv22 t=4,723: GD leaves the surface and accelerates away
        // at +0.212/tick while the model sat pinned at x=6,801.00 with
        // grounded=1 for 167 ticks; the support loop never even ran (no `supp`
        // line). Same class as the note at spiderTargetY's `worldFloor` gate --
        // a world floor does not exist in a turned frame.
        if (groundedNow
            && (s.flip || s.frame != 0 || s.y > (kGroundY + pHalf) + 0.5)) {
            bool sup = false;
            // [2026-08-22 r103] **In a rotated frame the player is not carried by a
            // "receding face".** GD's hitboxes (`hbox:` lines with cfg
            // hitboxtrace=1) named it: in lv22's rotated section, at t=6,128 (MOD
            // tick) alone **not a single collidedWithObject line appears** = zero
            // contact on that tick; GD sets og=0, accumulates one gravity step (the
            // ball's -0.129), and recovers on the next tick by penetrating the wall
            // at vy=-0.258. The wall (moving solid uid5825) is receding at
            // **0.045px/tick** at that point, and the player's one tick of fall,
            // **0.225x0.129 = 0.029px**, cannot keep up. Once the floor slows to
            // 0.02/tick the contact holds from then on (og drops on this 1 tick
            // only).
            // **Frame 0 is the opposite** -- in the same lv22's non-rotated corridor
            // at t=5,930, even with a floor sinking 0.838px/tick, GD carries the
            // player with onGround=1 (the measurement in the note just below). So
            // GD's "carry" exists only along world vertical; in a rotated frame the
            // face escapes in world x, so the carry has no effect.
            // [Rejected (2026-08-22 r103)] Tried narrowing this to "in a rotated
            // frame, follow a receding face by at most one tick of fall (0.225*g)",
            // but **the recording's resolution is insufficient**. In GD's
            // measurement (hbox: lines) the wall recedes smoothly at 0.045px/tick
            // and contact breaks on just the 1 tick where the gap crosses
            // 0.03->0.04. The model's moving geometry, with grouptrace's 0.05px
            // threshold, **moves only once every 2 ticks**, so the gap oscillates
            // 0/0.09, and with the same rule it also drops at 6,126 / 6,128 / 6,133
            // (GD does not). Closing it would need both "linear interpolation of
            // the recording" + "rotated-frame contact tolerance ~0.035" -- a change
            // that moves the moving geometry on every level, for a 1-tick vy blip
            // (zero effect on y), so it is shelved.
            // [Abandoned (2026-08-22 r105 / final)] lv22@6,129 **cannot be closed in
            // principle within this model's abstraction**. Laying out the window
            // (t=6,118..6,136) tick by tick after adding r104's interpolation:
            //
            //   The player's descent is **perfectly uniform at 1.6145 px/tick**
            //   (spread 0.001 from print rounding only). GD's y **matches the model
            //   on every tick**, and t=6,129 sits exactly on the carry line too.
            //   Only GD reports that 1 tick as vy=-0.129 / og=0, and returns to 0
            //   on the next tick.
            //
            // So it is **a reporting difference with zero effect on y that
            // self-heals in 1 tick**. Moreover the geometry the model sees carries
            // no signal whatsoever that distinguishes that tick from the others
            // (the 1.615 steps appear at 6,121 / 6,125 / 6,129 / 6,133, a rounding
            // pattern every 4 ticks, and og drops only at 6,129). The signal exists
            // only inside the float accumulation of GD's own resolution loop, so
            // **no function** of the model state can pick out this tick. That is
            // why r103 (narrowing the tolerance) and r105 (narrowing by one tick of
            // fall) both over-fired on the neighbouring 4 ticks. Adding a fake
            // "move vy only" rule would merely add a phantom distinction to the
            // dedupe key and make the search more expensive, so it is **not added**.
            // [2026-09-19] **The tick IS a function of state once the ride carries
            // the object it is tied to.** GD's own bytes (cfg `sticktrace`, lv22,
            // frame 1, ball): the ride that lands at t=6,098 on the column
            // 5822/5821/5825 is tied to uid5821 (+0x608) and the stick re-lands on
            // it every tick; at t=6,122 the ball's rect has left 5821 by 1.56 px,
            // the stick does not fire, the fallback +0x600 is empty (it is
            // pre-registered on world y only -- in frame 0 it is set, 5803 at
            // t=5,944), so og=0 and one gravity step; 5825 catches it by an
            // ordinary landing on the next tick. The "every 4 ticks" pattern above
            // was the recording's rounding, not the seam. `--stickseam` (off by
            // default) carries the tie in State::groundUid: the lowest-uid support
            // on the first grounded tick (GD's reverse loop keeps the last object
            // it landed on; 5821 < 5822 fits, and so does "the larger overlap" --
            // one point does not tell them apart), kept while only receding faces
            // hold the rider.
            bool seamTied = false, seamHold = false;
            int32_t seamLow = -1;
            if (g_supDbg)
                for (const Obj* o : *K.near)
                    if (o->type == 0 && std::fabs(x - o->cx) < 60.0)
                        std::printf("supdbg t=%lld uid=%d cx=%.2f cy=%.2f hw=%.2f hh=%.2f "
                                    "face=%.3f foot=%.3f gap=%.4f xok=%d dcy=%.4f\n",
                                    (long long)K.t, o->uid, o->cx, o->cy, o->hw, o->hh,
                                    faceOf(o), (double)s.y - gsign * pHalf,
                                    std::fabs((double)s.y - gsign * pHalf - faceOf(o)),
                                    std::fabs(x - o->cx) <= o->hw + pHalf + kContactEps ? 1 : 0,
                                    (double)o->dcy);
            for (const Obj* o : *K.near)
                if (o->type == 0
                    && std::fabs(x - o->cx) <= o->hw + pHalf + kContactEps
                    && std::fabs((double)s.y - gsign * pHalf - faceOf(o))
                           < kSupportTol + std::fabs(o->dcy)) {
                    sup = true;
                    if (gsign * o->dcy >= 0.0) seamHold = true;
                    if (o->uid == s.groundUid
                        && std::fabs(x - o->cx) < o->hw + pHalf)
                        seamTied = true;
                    if (seamLow < 0 || o->uid < seamLow) seamLow = o->uid;
                    // ...and if that face MOVED this tick, the player goes with
                    // it (see the ride block by the stair snap).
                    // The `+ |dcy|` in the test above is what lets that happen:
                    // `s.y` is LAST tick's player y and `faceOf(o)` is THIS
                    // tick's face, so a surface that dropped more than 0.6 px in
                    // one tick read as "no longer under him" and the rider was
                    // dropped on the very tick the ride was supposed to start.
                    // Measured on lv22 t=5,930 (ball corridor, x=8,180): the
                    // floor's first step is 0.838 px (eased Move, 12 px over
                    // 0.5 s), GD keeps onGround=1 and carries the ball down
                    // 975.000 -> 972.020 over 11 ticks while the model let go
                    // and free-fell. That lost the ball's tap-flip at t=5,940
                    // (a ball only flips gravity while it is ON something) and
                    // the whole corridor after it.
                    // ...and when more than one moving face qualifies, ride the
                    // one the foot is actually on. The loop used to keep the
                    // LAST match, so a stacked corridor could re-seat the player
                    // onto a face a couple of pixels away. Measured on lv22's
                    // ball corridor (2026-08-14): the anchored resim followed
                    // for 178 ticks and then jumped 2.21 px in one tick with
                    // dvy=0.0000 -- a re-seat, not physics.
                    if (o->dcy != 0.0) {
                        const double foot = (double)s.y - gsign * pHalf;
                        const double gap = std::fabs(foot - faceOf(o));
                        if (!rideOn || gap < rideGap) {
                            rideOn = true;
                            rideGap = gap;
                            rideFace = faceOf(o);
                            rideDy = o->dcy;
                        }
                    }
                }
            if (sup && (s.frame & 1) && s.groundUid >= 0 && !seamTied
                && !seamHold) {
                // the tied solid is gone and nothing but receding faces is
                // under the rider: no stick, no fallback, one tick of fall
                sup = false;
                rideOn = false;
                c.groundUid = -1;
                if (g_slopeDbg)
                    std::printf("stickseam t=%lld x=%.2f y=%.2f tied=%d\n",
                                (long long)K.t, x, (double)s.y,
                                (int)s.groundUid);
            } else {
                c.groundUid = (seamTied && !seamHold) ? s.groundUid : seamLow;
            }
            // --slopedbg: WHAT is holding the player up. A model that stays
            // grounded where GD falls looks identical to a physics bug until
            // the supporting object is named (lv22 t=4,723: 167 ticks pinned at
            // x=6,801 while GD accelerates away in the rotated frame).
            if (g_slopeDbg) {
                std::printf("supp t=%lld x=%.2f y=%.2f flip=%d sup=%d uids=",
                            (long long)K.t, x, (double)s.y, (int)s.flip,
                            sup ? 1 : 0);
                for (const Obj* o : *K.near)
                    if (o->type == 0
                        && std::fabs(x - o->cx) <= o->hw + pHalf + kContactEps
                        && std::fabs((double)s.y - gsign * pHalf - faceOf(o))
                               < kSupportTol + std::fabs(o->dcy))
                        std::printf("%d(%.1f,%.1f) ", o->uid, o->cx, o->cy);
                std::printf("\n");
            }
            // the invisible ceiling supports too. Without this a ball resting on
            // it lost `grounded` on the very next tick and could never tap back
            // off -- and tapping off is the only way down. lv9 rides that
            // ceiling over one wall and has to drop before the next one.
            if (!sup && s.flip
                && std::fabs((double)s.y + pHalf - ceilHere) < 0.6)
                sup = true;
            // ...and so does a RAMP. Slopes are a separate list, so this loop
            // never saw them: a ball riding a ramp lost `grounded` on the tick
            // after it landed and could never tap off it. The tap is the ball's
            // only action, so the whole ramp was a forced no-input corridor --
            // the frontier ran at alive=1 for 70 ticks on lv16 and then died on
            // the saw at x=6,849 that one tap anywhere in a 55-tick window
            // clears (measured in GD: tap at any t in 4676..4730 reaches
            // x=7,047, and the level's own route is to flip up onto the ceiling
            // blocks at y=440 and ride them over the saw).
            // The window is the ride's own (see the slope block), so a ramp
            // that has run out this tick correctly stops supporting.
            // ...and a FLIPPED player standing under a CEILING ramp is on one
            // too. Kept to that pair on purpose: the blanket `s.flip` relaxation
            // is what took lv16 from CLEARED to STUCK once (see the ceiling
            // branch's own note), and the case measured here is exactly
            // "flipped + the ramp whose solid side is up".
            // lv22 t=4,636 (cube, one tick after the swing->cube portal, ramp
            // uid4359 (6705,435) m=-1): the push-out already puts the model at
            // GD's 413.802, GD reads onGround=1 and jumps off at vy=-2.390 the
            // next tick, and without this the flag is gone by then.
            if (!sup && s.onSlope && K.slopes) {
                for (const Obj* sp : *K.slopes) {
                    // upright: any ramp. flipped: ONLY one whose solid side is
                    // up, and then the contact offset mirrors. The blanket
                    // `s.flip` relaxation is what took lv16 from CLEARED to
                    // STUCK once (see the ceiling branch's note), so this stays
                    // on the pair that was measured.
                    if (s.flip && !slopeIsCeiling(sp->slopeDir)) continue;
                    const double sx0 = sp->cx - sp->hw, sx1 = sp->cx + sp->hw;
                    const double m = (sp->sy1 - sp->sy0) / (sx1 - sx0);
                    if (m == 0.0) continue;
                    // the contact point mirrors for a flipped player, the same
                    // way the ceiling branch's `rc` does
                    const double off = (m > 0) ? slopeXOffset(m, pHalf)
                                               : -slopeXOffset(m, pHalf);
                    const double xr0 = x + (s.flip ? -off : off);
                    // [2026-08-19] A cube's continued ride downhill (in the travel
                    // direction) stays on the extrapolated line past the low end
                    // too (sampleAt's extrapolation branch). Support extends to the
                    // same window -- with the old 1.5px, a press during an
                    // extrapolated ride was refused with groundedNow=0 and only GD
                    // jumped (lv16 t=6,322, y matches exactly, vy alone differs by
                    // 11.42).
                    double loB = sx0, hiB = sx1 + 1.5;
                    // --slopedbg only: which term built the bound that decides the test
                    // below. `extC` and `revS` live inside the block, so by the time the
                    // comparison runs they are gone -- and the comparison is the whole
                    // question ("a model that stays grounded where GD falls looks like a
                    // physics bug until the supporting object is named"; the same applies
                    // to the object it REFUSES to be supported by). Recorded, not
                    // recomputed: a second copy of this arithmetic could drift from the
                    // one that actually ran.
                    double extUsed = 0.0;
                    int extSide = 0;          // 0 none, -1 widened loB, +1 widened hiB
                    if (!s.flip && s.mode == 0) {
                        const bool revS = ((double)K.dxF < 0.0 || s.rev != 0);
                        const double extC = pHalf * std::sqrt(1.0 + m * m)
                                            / std::fabs(m);
                        if (!revS && m < -0.01) { hiB = sx1 + extC; extUsed = extC; extSide = 1; }
                        else if (revS && m > 0.01) { loB = sx0 - extC; extUsed = extC; extSide = -1; }
                    }
                    if (xr0 < loB || xr0 > hiB) {
                        // The rejection, with every term that produced it. lv22 t=4,612-4,629
                        // refuses ramp uid4359 and first takes it at 4,630 -- the push-out
                        // itself already places the model where GD is (see the note above),
                        // so what is late is the ACQUISITION, and this line is the only place
                        // that can say which bound refused it.
                        if (g_slopeDbg)
                            std::printf("slprej t=%lld x=%.2f uid=%d m=%.4f xr0=%.3f "
                                        "loB=%.3f hiB=%.3f side=%s off=%.3f ext=%.3f "
                                        "extside=%d onslope=%d ceil=%d flip=%d mode=%d\n",
                                        (long long)K.t, x, sp->uid, m, xr0, loB, hiB,
                                        (xr0 < loB) ? "lo" : "hi", off, extUsed, extSide,
                                        (int)s.onSlope, slopeIsCeiling(sp->slopeDir) ? 1 : 0,
                                        (int)s.flip, (int)s.mode);
                        continue;
                    }
                    sup = true;
                    break;
                }
            }
            groundedNow = sup;
        }
        // A gravity portal firing on this tick EATS the cube's jump. GD flips
        // first (flipGravity clears m_isOnGround) and only then handles the
        // button, so the press finds nothing to jump off.
        // Measured on lv16 x=27,315 (portal id 11, cy=665), press one tick
        // apart with everything else identical:
        //   press t=17,439 -> t=17,440 vy = 11.42 (jump), then the portal
        //                     halves it at 17,441 to (11.42-0.215)/2 = 5.6025
        //   press t=17,440 -> t=17,441 vy = -0.1075 = (0 - 0.215)/2, NO jump
        // The model jumped anyway and left with 5.710 = 11.42/2, i.e. 6 px
        // above GD within a tick; the plan then walked into the spike at
        // (27,333,609) that GD's flat trajectory passes under.
        // [2026-09-03] ...and **the BALL's tap is eaten by the same thing**.
        // The line above used to read "cube only -- the ball's tap on a portal
        // tick has not been measured"; it is measured now, both in the game and
        // in the binary, and there is nothing cube-shaped about it.
        //   binary: `flipGravity` writes `m_isOnGround = 0` (0x39a3cd), and the
        //     ONLY thing gating a ball's tap is `m_isOnGround` -- `pushButton`
        //     0x397f40 reads `(m_isBall || ...) && m_isOnGround` and nothing
        //     else. No buffer, no second flag.
        //   game: lv22's it27 plan, the tap moved one tick either side of the
        //     type-4 portal uid13833 at t=6,291 (worker 98, 2026-09-03):
        //       tap at 6,290 (portal a tick later)  -3.4260, then the ladder
        //       tap at 6,291 (the tick that fired)  **+0.0645 = old g / 2**
        //       tap at 6,292 (portal a tick before) +0.0645 then -0.0650
        //     i.e. on the firing tick the press produces NO impulse at all, and
        //     one tick later it still produces none because the flip has taken
        //     the support away. The model tapped first and let the portal halve
        //     the tap, which is how -3.4260 reached the state as -1.7130.
        // The corpus never exercises it -- of 161 gravity-portal firings and 140
        // ball taps in the verified solutions, ZERO share a tick -- so this is
        // measured out of the game, not fitted to a replay.
        //
        // IT SITS HERE, above `cubeContact` and `pinnedOnBlock`, because
        // flipGravity does more than eat the button and everything else it
        // takes away is decided in the lines below. `s.y` and the contact half
        // are the tick-start values the whole ground arm reads, so moving the
        // block up does not change what it answers.
        // The pass's own numbers, recomputed here rather than guessed at: its
        // contact half at pass entry (`pHalfPortal`) and its player rotation
        // (`pRotHere`). Both are start-of-tick values by construction -- the
        // pass's `pHalfLive` only leaves `pHalfPortal` once a mode or size
        // portal has fired inside the pass, which is long after this point, and
        // `s.rot` is the previous tick's rotation in both places.
        const double pHalfE = (c.mode == 4 && c.mini) ? kWaveContactHalfMini
                                                      : pHalf;
        // [2026-09-06] The one-step advance is deleted here as well; the
        // mechanism is at the pad site and the measurement in constants.hpp
        // (g_noSatRotRaw, which is the switch that puts it back). What the
        // corpus decides at THIS site is small and it is not a first fire: of
        // the oriented gravity portals a cube reaches, lv16's uid 3448 (type 4)
        // answers the same either way and is a no-op anyway (`upsideDown` is 0
        // across 8,008..8,020), and lv16's uid 3450 (type 3) fires first on
        // 8,062 either way -- the arms part only on the TAIL of the contact,
        // 8,072 against 8,073.
        double pRotE = (double)s.rot;
        if (g_noSatRotRaw && s.mode == 0)
            pRotE += (s.rotNeg ? 1.0 : -1.0) * (s.mini ? 2.25 : 1.7307692);
        bool gravPortalThisTick = false;
        const Obj* gravPortalP = nullptr;
        for (const Obj* p : *K.ports) {
            if (p->type != 3 && p->type != 4) continue;
            const uint8_t wantFlip = (p->type == 3) ? 1 : 0;
            // The pass's `changes`, and it states GD's upsideDown rather than
            // the model's frame-local flip. This used to read `s.flip`, which
            // is the SAME MISTAKE the pass's second gate was fixed for on lv22
            // t=5,110: inside frame 3 the two statements are opposites, so the
            // early reader answered the exact reverse of the pass there.
            // `gdUpOf(s)` and not `gdUpOf(c)` because nothing has flipped yet
            // -- which is also what the pass reconstructs when the ball's tap
            // has flipped by the time it runs (`ballFlippedThisTick`).
            if (gdUpOf(s) == wantFlip) continue;
            if (portalOnFrameRotTrigger(*p, (int)c.frame)) continue;
            // r52 (a portal being sat in when the frame turned) and the dual's
            // entry-tick rule, which ask the same question of the same box.
            // The pass's r52 gate also tests `s.frame == c.frame`; that is not
            // repeated because nothing inside stepOne changes the frame
            // (applyRotation runs after it), so it is always true here.
            if ((s.frameChg || c.dual)
                && portalWasInsideAtPrev(*p, xPrev, (double)s.y, pHalfE, pRotE))
                continue;
            if (p->oriented
                && !orientedHit(*p, x, (double)s.y, pHalfE, pRotE)) continue;
            if (std::fabs(x - p->cx) <= p->hw + pHalfE
                && std::fabs((double)s.y - p->cy) < p->hh + pHalfE) {
                gravPortalThisTick = true;
                gravPortalP = p;
                break;
            }
        }
        // --slopedbg: THE EXPOSURE. One line per tick the predicate answers
        // "fires", in every mode -- the ball gate below prints only its own.
        if (g_slopeDbg && gravPortalThisTick)
            std::printf("gravpred t=%lld uid=%d type=%d mode=%d frame=%d "
                        "flip=%d dual=%d sup=%d ride=%d in=%d\n",
                        (long long)K.t, gravPortalP->uid,
                        (int)gravPortalP->type, (int)c.mode, (int)c.frame,
                        (int)s.flip, (int)c.dual, groundedNow ? 1 : 0,
                        rideOn ? 1 : 0, input ? 1 : 0);
        // [2026-09-03] **flipGravity takes the BALL's footing away, not just its
        // button.** Three writes in the same function, all of them before the
        // solids are resolved (checkCollisions is two passes -- portals fire in
        // place during the bucket sweep, solids are pushed to a list and
        // resolved afterwards, disasm 0x2137f0 / 0x214960 / 0x214687):
        //   0x39a3cd  m_isOnGround = 0
        //   0x39a2aa/b5/c0  the last-touched-object uids := -1, which is the
        //                   link a rider is carried by
        // So on the firing tick the ball is NOT standing on anything: it takes
        // the update phase's ordinary gravity step in the OLD direction, the
        // portal halves that, and only then do the solids get a say -- and
        // their say is an actual rectangle overlap, not a support tolerance.
        // Both outcomes are measured on the SAME portal, frame and block, with
        // nothing but the contact differing (worker 98, 2026-09-03):
        //   lv22 t=6,291   the block recedes 0.182 px/tick, the ball falls the
        //                  0.029 px one tick of gravity buys, the gap opens to
        //                  0.153 px -> no overlap -> GD keeps **+0.0645 = g/2**
        //   the same tick with the ball injected 0.20 / 0.50 px into the block
        //                  -> overlap -> GD reports **0.0000**, then -0.129/tick
        //   lv16 t=4,237   the same shape on a STATIC block (so the contact is
        //                  never broken) -> GD reports **0.0000** -- and it is
        //                  the corpus row this has to leave alone
        // Handing the ball to the airborne branch produces all three: the free
        // step is +0.129 in the old direction (which the portal halves to
        // GD's +0.0645), and where the surface is still there the landing loop
        // catches the foot and zeroes vy exactly as it does for a fall.
        //
        // BALL ONLY, and that is GD's own split rather than caution: the
        // head-side vertical resolution is SKIPPED for cube/robot/spider and
        // TAKEN for ball/ship/ufo/wave/swing (the mode gate at 0x39289d). A
        // cube run through this branch would land on the block it was pinned to
        // and come out 0.000 where GD measures g/2 -- which is what the pair of
        // rules at the portal (vAtPortal's reconstruction and the y half step)
        // already encode for it. The flying modes take GD's resolution too, but
        // they never reach this arm; their 12 grounded firings are green as
        // they stand.
        //
        // WHAT THE PREDICATE ABOVE IS: the portal pass's own decision, minus
        // the one part of it that cannot be had yet. The pass tests `yFree`,
        // which this tick has not produced, so the early reader tests the
        // start-of-tick y and remains an over-approximation in exactly that
        // respect. Everything else is the SAME CODE both readers call --
        // `changes` read through gdUpOf, portalOnFrameRotTrigger, and
        // portalWasInsideAtPrev for r52 and for the dual's entry-tick rule.
        // Until 2026-09-03 it was the bare geometry, so the exposure of the
        // difference was counted on both sides of the sharing (--slopedbg's
        // `gravpred`, one line per tick the predicate answers "fires"):
        //   the 22 verified solutions -- 52 ticks, 5 of them supported or
        //     riding, and the sharing moves NONE of them: every one is frame 0,
        //     dual 0, with no frame change in flight, so no gate can bite.
        //     8 of the 52 are balls (the only mode this branch acts on) and one
        //     of those is supported -- lv16 t=4,237, the anchor above.
        //   lv22's it27 plan, where the over-answering was found -- the ball
        //     predicate was true on 31 ticks and is now true on 1: t=6,291, the
        //     tick GD really fires uid13833 on (sup=1 ride=1). The 30 that went
        //     are t=6,307.. inside that same portal after the frame turned. The
        //     pass had held it over (r52), which keeps `frameChg` raised, and
        //     the early reader now reads the same hold instead of re-answering
        //     "fires" for the length of the corridor. All 30 were airborne, so
        //     that replay is byte-identical across the change: the hole was
        //     closed before it cost anything.
        if (gravPortalThisTick && isBall) {
            if (g_slopeDbg)
                std::printf("gravflip t=%lld x=%.2f y=%.3f flip=%d sup=%d "
                            "ride=%d in=%d act=%d\n",
                            (long long)K.t, x, (double)s.y, (int)s.flip,
                            groundedNow ? 1 : 0, rideOn ? 1 : 0, input ? 1 : 0,
                            (int)s.action);
            groundedNow = false;
            rideOn = false;
        }
        // --upsidecoyote (speed.hpp): og still set on an upside-down cube that has walked off
        // its surface. It is the og the last tick left -- a grounded tick, or a linger it carried
        // -- that GD's own falling test on the last tick's vy did not clear. Cube and ball, frame
        // 0, single body: the cases measured.
        const bool ogLingerGate =
            g_upsideCoyote && !g_fixGravityBug
            && (s.mode == 0 || s.mode == 2) && s.flip && s.frame == 0 && !s.dual
            && !groundedNow && !gravPortalThisTick
            && (s.grounded || s.ogLinger)
            && !((double)s.vy > gdapprox::accelSwitchVyForSpeed(speedMulForDx(useDx)));
        bool ogLingerJump = false;
        cubeContact = groundedNow;
        // the ceiling pin is re-earned every tick (see "cube/ceilstop")
        c.ceilPin = 0;
        // A player standing on a BLOCK carries that tick's gravity step in y.
        // GD's tick is update(gravity + move) -> collisions -> buttons, and only
        // the ordinary jump puts the player back on the surface; anything else
        // that launches it leaves the moved y in place. Measured over the 19
        // verified replays (scratchpad/pad16.py, impulse.py):
        //   plain jump (11.180 etc.)          y unchanged   832 + 151 + 56 + 45
        //   pad / orb while on a BLOCK        y moves       9 of 9
        //   pad / orb while on the GROUND     y unchanged   12 of 12
        // The yellow pad's 21 firings split 9/12 on exactly that line with no
        // exception, which is why the ground test below is the discriminator
        // and not the pad's value or the mode.
        //
        // It matters because the offset does not decay: the model drew its whole
        // arc 0.0486 px high and LANDED A TICK LATE. lv19 t=290 is that landing,
        // and everything after it (2,818 divergent ticks) hangs off it.
        pinnedOnBlock =
            groundedNow && (s.flip || (double)s.y > (kGroundY + pHalf) + 0.5);
        prePinY = (float)((double)s.y + kYScale * qVy(gAcc) * gsign);
        double vpNew = vp;
        bool ballFlipped = false;
        // (`gravPortalThisTick` is decided ABOVE the support scan -- the whole
        // note, and the reason it has to sit there, is at its declaration.)
        if (groundedNow && input && !s.action && !gravPortalThisTick
            && isSpider) {
            // SPIDER: teleport to the surface on the other side and flip.
            // The search is the mirror of the support test above -- the same
            // x-overlap rule, and the face that matters is the one the player
            // will come to rest ON: the UNDERSIDE of a solid when travelling
            // up, its TOP when travelling down.
            // A tap with nothing to land on is dropped rather than guessed at:
            // refusing the branch can only cost routes, while inventing a
            // landing invents a plan GD will not follow.
            double bestY = 0.0;
            bool hazTgt = false;
            // (the search itself is spiderTargetY, shared with the SPIDER ORB)
            // The band bounds the search only when it is KNOWN to be a wall:
            // with the Free Mode byte unknown this keeps the old search, which
            // never looked at the band (legacy argument false).
            const bool tapBandWall = bandFT > kGroundY + 0.01 && bandCT < 1e8
                                     && bandFT < bandCT
                                     && bandIsWall(s.bandBranch, false);
            const bool found = spiderTargetY(K, x, (double)s.y, s.flip != 0,
                                             c.mini != 0, pHalf, bestY,
                                             s.frame == 0, &hazTgt,
                                             (int)s.frame, s.rev != 0,
                                             tapBandWall, bandFT, bandCT);
            if (!found) DIE("spider/no-target", nullptr);
            // ...and the search STOPS on a hazard (see spiderTargetY's note):
            // GD lands the spider on it and kills it on the same tick.
            if (hazTgt) DIE("spider/tp-hazard", nullptr);
            impulsedThisTick = IMPULSE();
            spiderWarpedThisTick = true;
            c.spiderJumpT = 0;   // GD's +0x820 (State::spiderJumpT)
            if (g_touchCensus) g_tcBranch |= 1;
            // ...and the block-pin has to let go. `pinnedOnBlock` was armed
            // above for a player standing on a solid, and `releasePin` puts y
            // back to `prePinY` -- which on a teleport tick drags the player
            // back onto the block it just left. Measured on lv22 t=2,023: the
            // tap fires, the model teleports to y=163.5 and the ball portal
            // uid1590 fires there (both exactly as GD does), and then the pin
            // pulls y back to 316.53 -- 153 px above GD for the whole section,
            // and straight into the solid uid1616 (2415,345) 5 ticks later.
            pinnedOnBlock = false;
            g_preBtnSet = true; g_preBtnY = (double)c.y;
            YSET(c.y) = (float)bestY;
            yFree = c.y;
            // GD leaves 1.0 of velocity pointing the way the teleport went, not
            // zero. Straight off its own dumps (lv21, cfg gatetrace):
            //   t=9057  y 406 -> 223.5 (down), yvel = -1, onGround 0
            //   t=9058  y 223.5,             yvel =  0, onGround 1
            // and the four teleport fixups the driver recorded all read
            // edvy = +1 going up / -1 going down, with edy = 0 -- i.e. the
            // landing height was already right and only this was missing.
            // `gs` is +1 for an upright spider (which teleports UP) and -1 for a
            // flipped one, so it IS the direction of travel.
            // Not scaled by anything: all four records are sp0.9 full size and
            // read exactly 1.000.
            //
            // [2026-08-18] grounded is **0** (matching GD's onGround=0). This used
            // to be 1, held back with "the next tick zeroes vy and grounds the
            // player either way, so changing the flag too would move two
            // variables". **A sample that separates the two has appeared**: lv22
            // t=2,044 fires an orb on the tick after the teleport. Treated as
            // grounded, the flight branch's vp is crushed to 0, the carried -1.000
            // vanishes, and y moves only 0.225 px (GD moves 0.254 px at -1.129).
            // Treated as airborne, the landing test re-seats the player on the
            // face on the next tick, so routes without an orb are unchanged.
            //
            // It has to go in vpNew, NOT in c.vy. The branch ends with
            // `c.vy = vpNew * gsign` (and gsign is built from s.flip, the OLD
            // gravity), so anything written to c.vy here is dead. vp is the
            // velocity in the player's own pre-teleport frame, and +1 there is
            // "moving the way the teleport went" for both orientations:
            //   upright  gsign=+1 -> c.vy = +1 (teleported up)
            //   flipped  gsign=-1 -> c.vy = -1 (teleported down)
            // Setting c.vy alone looked right in a y-only spot check and changed
            // nothing at all; what caught it was the driver still recording the
            // same edvy=+-1 fixups on the next cold run.
            c.flip = s.flip ? 0 : 1;
            c.grounded = 0;
            c.snapObj = nullptr;
            VPSET(vpNew) = 1.0;
            // [2026-08-21 r93] **When a warp interrupts a ride, the ramp's
            // slope-exit launch pulse appears on the next tick.** Measured lv21
            // t=16,713/16,714 (spider, rode an |m|=2 uphill for 3 ticks, then
            // warped by tap):
            //   16,713 warp (y 161.5 -> 226.5, flip 0->1, vy=+1.000 = the signature)
            //   16,714 GD alone **vy=+5.226**, og=0 (y does not move)
            //   16,715 pushed back onto the ceiling, 0.000 / og=1
            // 5.226 = slopeExitVy(2, spider, sp1.1) 13.064 x the ramp factor 0.400
            // for a 3-tick ride, exactly. The sign is **the pre-warp orientation**
            // (an uphill launch is + when upright) -- not the orientation after the
            // warp flipped it.
            // A pending carried for 1 tick (same shape as pFlap; also in the key).
            if (s.onSlope && (double)s.slopeM != 0.0) {
                const double mTravW =
                    (double)s.slopeM
                    * (((double)K.dxF < 0.0 || s.rev != 0) ? -1.0 : 1.0);
                const bool upW = s.flip ? (mTravW < 0.0) : (mTravW > 0.0);
                if (upW)
                    c.pExitVy = (float)rawQ((s.flip ? -1.0 : 1.0)   // speed.hpp
                                        * slopeExitVy(
                                              std::fabs((double)s.slopeM),
                                              c.mode, useDx, c.mini != 0)
                                        * slopeRampFactor((int)s.slopeT + 1));
            }
        // The CUBE re-jumps while the button is simply HELD -- it does not need
        // a fresh press. Measured on lv1 with a single press at t=60 and no
        // release at all: jump at t=61 (vy=11.18), land at t=164, and GD jumps
        // AGAIN at t=165 with the same 11.18. The model's `!s.action` edge gate
        // refused that, which is why the seeded lv22 clear diverged at t=10,556
        // (GD jumps off the ceiling lane on a hold started 4 ticks earlier,
        // model sat still) -- and why every plan that holds through a landing
        // came back as a divergence the driver had to paper over.
        // THE CUBE, AND NOT THE ROBOT. That was the other way round here until
        // 2026-09-03, on the strength of "lv22 t=15,878: a robot with the button
        // held lands and GD re-jumps with vy=+5.615". That citation cannot be
        // checked any more -- t=15,878 is SHIP in today's gdref, because the
        // solution has been re-solved since -- and the corpus cannot decide it
        // either: across all 22 verified plans there are 81 robot landings and
        // not one has the button held through it (4 rising edges, 77 with no
        // press at all). So it was asked of the game, on a rig built for it
        // (data/rigs/calib_holdjump_{robot,cube}.lvl -- header-only flat ground,
        // one press at t=30, never released):
        //   robot  jumps once at t=31 (vy=5.59), lands at t=195, and is STILL
        //          sitting on the floor at t=600. No second jump.
        //   cube   bounces continuously -- five jumps in 600 ticks, vy back to
        //          +8..+11 every time. The same rig, so the negative above is
        //          not the rig failing to see one.
        // The disassembly says exactly that: updateJump takes m_jumpBuffered
        // (player+0x985) straight for everything else, but for the robot
        // (+0x9bd) it needs +0x986 as well (0x38ba3c..0x38ba51), and the arm that
        // jumps clears +0x986 (0x38c728). Only releaseButton puts it back
        // (`mov word ptr [rbx+0x985], 0` at 0x398260 clears both, and pushButton
        // writes the pair). ball / spider / UFO stay edge-triggered and
        // unmeasured -- this rig cannot answer for them (no ceiling to land on).
        // ...and NOT when this same press already spent itself on a ring:
        // lv22 t=10,352 presses, the spider orb fires at 10,353, the player is
        // grounded at 10,354 with the button still down through 10,356 -- and
        // GD does NOT jump. One press activates one thing; the re-jump needs
        // the press back. `ringHold` is exactly "this press has fired a ring"
        // and is cleared on release, so it is the gate.
        // [2026-09-03] THE RULE IS BACK, reading the BUFFER instead of `action`.
        // The disassembly settles both the
        // rule and the refutation that killed the first attempt:
        //   * the cube's gate in updateJump is `m_jumpBuffered && m_isOnGround &&
        //     !spider && !dashing` -- no latch, no accumulator. m_jumpBuffered is
        //     a LEVEL, set by pushButton and cleared by releaseButton
        //   * GD reads that level TWICE in a tick: the rising edge at the head of
        //     the frame (pushButton -> updateJump(dt=0), y frozen) and the held
        //     level in the physics (update -> updateJump(dt), y moves). The second
        //     is one tick older than the model's `input` -- so the gate is
        //     `input || <the previous tick's level>`, which is what the first
        //     attempt got right
        //   * lv22 t=20,234 is not physics: it sits inside a no-control window
        //     (ctrlOff 20,131..20,506) where pushButton returns immediately, so
        //     GD has no press there at all. The model zeroes `input` in that
        //     window but keeps `action` raw, so reading `action` walked straight
        //     through it. Reading `jumpBuf` -- mirrored from the gated input --
        //     does not.
        // 240 landing jumps across the five reference dumps are all rising-edge
        // (`input && !s.action`), so none of them moves.
        // TRIED AND REVERTED (2026-09-02): the same gate reading `s.action`.
        // The evidence for the rule is real and still stands: on GD-authored
        // section crossings (the verified solutions cannot witness it, having been
        // authored by a solver with this very gate) 111 cube landings, 19 of them
        // jumps, and the seven whose press ended at or before the landing tick
        // separate perfectly on the plan's value at t-1 -- 3 distinct events jump,
        // 4 do not, no counter-example in lv1-22. It even fixed the one case where
        // the model had been caught missing it with both sides on the SAME plan
        // (w6077: t=6367 lands bit-identically, and with the change t=6368 comes
        // out at y=230.058 vy=12.341, GD's numbers to the digit).
        // WHAT KILLED IT: `groundedNow` is any grounded tick, not a landing.
        // lv22 t=20,234 presses while the cube has been sitting still (y=2,235.000,
        // vy=0, onGround=1, gframe=0) for twenty ticks; GD does not jump on the
        // press tick OR after it, and the branch above does not fire either -- but
        // the released tick t=20,236 has s.action=1, so the reverted form did.
        // Three of lv22's sections lost tracking (worst t=20,200: 400 -> 36 ticks).
        // Re-try needs the missing half: either "the previous tick was a LANDING",
        // which is a state bit nobody has yet, or "this press has not already been
        // spent", which is what ringHold does for rings and nothing does for
        // whatever consumed the press at 20,234. Narrowing it by hand here would be
        // fitting, not measuring.
        // CUBE ONLY for the buffered half, and now for a measured reason rather
        // than a cautious one: on calib_holdjump_robot the robot jumps once and
        // stays on the floor for the next 400 ticks with the button still down,
        // while the cube on the identical rig bounces five times. The binary
        // agrees -- the robot's arm needs +0x986 on top of m_jumpBuffered and
        // clears it when it jumps. See the block above for the whole reading.
        } else if (groundedNow
                   && (input || ((s.mode == 0 || s.mode == 2) && s.jumpBuf))
                   && !gravPortalThisTick
                   && (!s.action
                       // the cube's gate is +0x985 alone (speed.hpp, the hold latch), which a
                       // ring fired by a cube leaves set (a custom level t=12,551: yellow ring 2314 at
                       // 12,434, held, GD re-jumps on landing) and a spider orb clears
                       // (spiderTestJump -- the lv22 t=10,352 case ringHold was built on)
                       || (s.mode == 0 && !s.holdDead)
                       || (s.mode == 5 && !s.ringHold)
                       // a ball's press that nothing consumed is still +0x985 when it lands,
                       // and updateJump taps it the next tick -- even if the release comes on
                       // that tick (s.jumpBuf, as for the cube; speed.hpp, the buffered tap)
                       || (s.mode == 2 && s.jumpBuf && !s.holdDead))) {
            // TRIED AND REVERTED (2026-08-26): delaying the grounded BALL's
            // tap-flip by one tick. The lv22 ball-corridor fixups show GD
            // firing the flip one transition late there (paired records:
            // in=1 edvy=-3.426, then in=0 edvy=+3.426, at three heights),
            // but the delay is NOT a function of anything the model can see:
            // unconditional, it broke every static-floor ball level at once
            // (lv9-15/18, all by exactly -ballFlipFor on the edge tick);
            // gated on rideOn (a moving support), quick_regress still broke
            // lv19 t=20,600 (400->80), lv20 t=5,400 and SIX lv22 segments
            // including the corridor itself (t=5,800 400->23) -- on the very
            // reference plan the records came from, GD fires edge-tick flips
            // on movers too. Whether the buttons phase sees the re-seated
            // grounded that tick is decided inside GD's collision pass, below
            // the model's resolution (the gd-shrinking-gap class). Per-run
            // fixup records are the only honest carrier for it.
            impulsedThisTick = IMPULSE();
            // --portalpress (speed.hpp): which press action this was, so a mode portal that
            // fires later in this tick can hand the press to the new mode instead.
            if (input && !s.action && (s.mode == 0 || s.mode == 2) && !isSpider)
                pressAction = isBall ? 2 : 1;
            // The press is now SPENT. GD's updateJump clears +0x986 when it jumps
            // (0x38bbef), and the ball's arm ends the same way, so a ring met later
            // in the same hold finds the 0x98a mirror at 0 and does not fire. This
            // branch is every grounded consumer at once -- the cube's jump, the
            // ball's tap, the spider's flip. Written to `c`, read from `s` at the
            // ring gate; the ordering note is on the field itself.
            c.pressSpent = 1;
            if (isBall) {
                // the tap flips gravity and drops toward the NEW floor; the
                // player-frame velocity is expressed against the new sign, so
                // this cannot go through the shared `vpNew * gsign` below
                c.flip = c.flip ? 0 : 1;
                // The tap IS a flipGravity, one of the only two callers that
                // write the ball's AIR step. Staked here, AFTER the flip above,
                // because GD stores the new gravity before it stakes -- that
                // ordering is the whole of why a stake arriving with a flip
                // keeps the sign while one arriving without it inverts.
                //
                // runBallRotation2's sign is `NOT (g XOR r)`: inverted against
                // the grounded law, and with no rotation-gameplay term. The
                // inversion exists to cancel the flip that brought us here, so
                // the spin looks continuous through a tap.
                c.rotStep = (float)ballRotRate(c.mini != 0, true, useDx);
                c.rotNeg = (uint8_t)!((c.flip != 0) ^ (c.rev != 0));
                // the ball's tap scales with size like every other impulse.
                // Measured on lv11 t=8398 (mini ball): GD leaves with 2.6832
                // where the model produced 3.3540, and 2.6832 / 3.354 = 0.800.
                // ...and with the section's speed, by the same factor as the
                // rings: measured on lv15 t=10685, GD taps out at 3.426 where
                // the 0.9 constant gives 3.354, and 3.426 / 3.354 = 1.0214669,
                // the jump's ratio at 1.1 to seven digits.
                // tapping UP off a slope adds the measured bonus (see above)
                // The bonus scales with the gradient's exit ratio (the measurement
                // site of 0.2796, lv16 t=4701, is uid1715 = w60 h30 with m=0.5.
                // lv20 t=5,270's corner (m=1) is 0.5178 = 0.2796 x
                // exit(1)/exit(0.5)).
                // [2026-08-21 r92] The gate is **the same "uphill in the player's
                // own frame" as the cube's bonus** (mirrored when flipped). The old
                // `c.flip` (whether the tap went to the flipped side) was a
                // restatement of one corpus sample, "an upright ball jumping uphill
                // on a floor", and dropped the hang (a flipped ball sliding along a
                // ceiling ramp tapping downward) -- the rig's 6 ball cells are on
                // that side.
                const double mTravB =
                    (double)s.slopeM
                    * (((double)K.dxF < 0.0 || s.rev != 0) ? -1.0 : 1.0);
                const bool bUphill =
                    s.onSlope
                    && (s.flip ? (mTravB < 0.0) : (mTravB > 0.0));
                // ...**the bonus does not scale with mini** (same ordering as the
                // cube side: the mini ratio applies to the tap value only, and the
                // bonus sits raw on top). The rig's 3 mini cells gave the same
                // 0.225/0.417/0.591 as normal size.
                const double bBonus =
                    bUphill ? kBallSlopeExitBonus
                                  * slopeExitVy(std::fabs((double)s.slopeM),
                                                2, useDx, c.mini != 0)
                            : 0.0;
                const double bTap =
                    ballFlipFor(useDx) * (c.mini ? kMiniImpulse : 1.0)
                    + bBonus;
                VYSET(c.vy) = (float)(-bTap * (c.flip ? -1.0 : 1.0));
                // A buffered tap is updateJump's, which runs before the step moves the ball, so
                // the new vy moves it this tick (a custom level t=5,444: y 135 -> 135.7546 = 3.354 x
                // kYScale). An edge tap is the buttons phase's, after the move, and leaves y
                // where it is.
                if (!(input && !s.action))
                    YSET(c.y) = (float)((double)s.y + (double)c.vy * kYScale);
                // --slopedbg: the tap's own inputs. Without them "the model
                // wrote -1.713" cannot be told from "some other branch wrote
                // -1.713", and the value does not factor by inspection: at
                // lv22 t=6,291 it needs ballFlipFor to come out at 1.713 on a
                // full-size ball, where 3.354 x a ring scale should be near
                // 3.4. Print the terms rather than infer them.
                if (g_slopeDbg)
                    std::printf("balltap t=%lld frame=%d flip=%d->%d mini=%d "
                                "dx=%.4f base=%.4f bonus=%.4f bTap=%.4f "
                                "vy=%.4f uphill=%d slopeM=%.3f\n",
                                (long long)K.t, (int)c.frame, (int)s.flip,
                                (int)c.flip, (int)c.mini, (double)useDx,
                                ballFlipFor(useDx), bBonus, bTap,
                                (double)c.vy, bUphill ? 1 : 0,
                                (double)s.slopeM);
                ballFlipped = true;
                ballFlippedThisTick = true;
            } else {
                // jump edge: vy set, y frozen this tick
                // mini keeps the measured 0.800 ratio against this speed's jump
                VPSET(vpNew) = c.mini ? (cph.jump * (kCubeJumpMini / kCubeJump))
                               : cph.jump;
                // ...and the robot's is half of it, with the hover budget
                // armed. GD zeroes the budget (this+0x830) in the same block
                // that sets the jump velocity.
                if (isRobot) {
                    VPSET(vpNew) *= kRobotJumpScale;
                    c.rHover = rePushNoHoverAt(K.t)
                                   ? (uint8_t)0
                                   : (uint8_t)kRobotHoverTicks;
                }
                // A jump taken WHILE STILL ON A RAMP carries the ramp's own
                // push on top of the jump. The ramp-exit rule next door only
                // fires when the player actually leaves the ramp window
                // (`!rampWindowHere`), so a mid-ramp jump got the bare jump
                // and ran a whole velocity unit slow for the rest of the arc.
                //
                // Structure from the disassembly (updateJump 0x38bc77): the
                // term is gated on the on-slope flag (this+0xb58), it is added
                // AFTER the robot's x0.5 (0x38bc44) so it is not scaled by it,
                // and it is a ratio `|double@0xaf8| / (float@0x9f4 *
                // double@0x7b8)`.
                //
                // Corpus (all three exact, and all |m| = 0.5):
                //   lv18 t=11,030  sp1.0 ride 6    11.180 -> 11.580
                //   lv18 t=10,938  sp1.0 ride24+   11.180 -> 12.180
                //   lv16 t=16,810  sp1.1 ride24+            +1.243
                // so the speed factor is sp exactly and the ride uses the same
                // ramp the exit does (0.400 is that ramp's 0.4 floor).
                //
                // The GRADIENT was measured on a purpose-built map
                // (py/mklevel.py `rampjump`, 2026-08-18: cube/robot x |m| in
                // {0.5,1,2} x normal/mini, one press 70% along a 3-ramp chain,
                // 12 units in one run). Bonus, by |m|:
                //   0.5 -> 1.000   1.0 -> 1.851   2.0 -> 2.627
                // which is slopeExitVy's own cube row divided by 3.999:
                //   3.999/3.999   7.405/3.999    10.507/3.999
                //   = 1.0000      1.8517         2.6274
                // i.e. the bonus is a QUARTER of the ramp's own exit. It is
                // size-independent (the six mini units give the identical
                // bonus on top of the mini jump) and the full-size ROBOT gives
                // the cube's bonus on top of its halved jump, which is what
                // the disassembly's ordering says.
                // OPEN: the MINI ROBOT at |m| = 1 and 2 both come out at
                // 6.261 (= base 4.472 + 1.789) where the law wants 6.323 and
                // 7.099. Two units out of twelve, both the same number, so
                // something caps there; unexplained and unmodelled.
                // [2026-08-19] The bonus applies **only to a ride that is uphill in
                // the travel direction**. The rampjump rig was measured on uphill
                // chains only, and the downhill measurement (lv16 t=5,991, press
                // from a downhill ride at m=-0.5) had GD at exactly the raw jump
                // 11.42 = bonus 0.
                // [2026-08-20] The OPEN above ("the mini robot at |m|=1 and 2 both
                // come out at 6.261, something caps there") is closed. **The bonus
                // is capped at 0.4x the player's own jump value.** 12 units
                // re-measured on the rampjump rig with its header fixed:
                //   cube  base 11.180  cap 4.472 ... 0.5/1/2 all pass the raw 1.000/
                //         1.851/2.627 (12.180 / 13.031 / 13.807)
                //   robot base  5.590  cap **2.236** ... 0.5->1.000 and 1->1.851
                //         pass, but **2->2.236 hits the cap** (GD 7.826; the
                //         uncapped model gave 8.217)
                //   mini robot base 4.472  cap **1.789** ... |m|=1 and 2 are both
                //         6.261 = 4.472+1.789 (the old note's "2 unexplained units")
                // The mini cube, base 8.944, cap 3.578, passes the raw values.
                // 12/12 explained by this one rule.
                // [2026-08-21 r91] **Uphill mirrors when flipped.** For a hanging
                // player (flipped, sliding along the underside of a ceiling ramp),
                // a line descending in the world is uphill in its own frame, and GD
                // produces the same bonus. The calibration rig ceilhold's 6 cube
                // cells and 6 robot cells are **identical, without exception, to
                // the rampjump rig's (floor-side) table**:
                //   cube  |m| 0.5/1/2 -> +1.000 / +1.851 / +2.627 (normal and mini)
                //   robot same -> +1.000 / +1.851 / **+2.236 (cap)**,
                //          mini up to +1.789 (cap) at both |m|=1,2
                // The exit gate (uphillExit) already has the same mirror.
                const double mTravJ =
                    (double)s.slopeM
                    * (((double)K.dxF < 0.0 || s.rev != 0) ? -1.0 : 1.0);
                if (s.onSlope
                    && (s.flip ? (mTravJ < 0.0) : (mTravJ > 0.0))) {
                    const double bonus =
                        kSlopeJumpBonus
                        * slopeExitVy(std::fabs((double)s.slopeM), 0,
                                      useDx, c.mini != 0)
                        * slopeRampFactor((int)s.slopeT + 1);
                    VPSET(vpNew) += std::min(bonus,
                                      kSlopeJumpBonusCap * std::fabs(vpNew));
                }
                // On the fresh-jump tick of a **downhill** ride, y first drops by
                // one more step of the seat and then jumps (collisions before
                // buttons, and a falling seat does not cancel the jump). Measured
                // lv16 t=5,991: GD y=232.217 = the seat's next step, vy=11.42 = the
                // raw jump value. Asymmetric with the uphill freeze (the note just
                // below). Measured for the cube only.
                else if (s.onSlope && c.mode == 0) {
                    YSET(c.y) = (float)((double)c.y
                                  + (double)s.slopeM
                                        * std::fabs((double)useDx)
                                        * (((double)K.dxF < 0.0
                                            || s.rev != 0) ? -1.0 : 1.0));
                    yFree = c.y;
                }
            }
            c.grounded = 0;
            // ...and the HELD re-jump also MOVES on this tick, where a fresh
            // press does not. GD's order says why: a press is consumed at the
            // end of its tick (after the move), so its velocity first shows in
            // the next one, while the hold is read in updateJump at the top of
            // the tick and the move that follows already carries it.
            // Both halves measured on lv1 with one press at t=60, never
            // released:
            //   fresh: t=61 vy=11.18, y=105.000 (frozen)  -> t=62 y=107.4669
            //   held : t=164 landed, t=165 vy=11.18 AND y=105 -> 107.5155
            //          (+2.5155 = 11.18 * kYScale, in the same tick)
            // lv22 t=10,556 is the same thing upside down: GD leaves the
            // ceiling at 1035 -> 1032.431 = -11.42 * kYScale on the jump tick.
            // Without this the model runs exactly one tick behind for the rest
            // of the level (a flat 2.5695 px on lv22).
            if (s.action && s.mode == 0) {
                YSET(c.y) = (float)((double)s.y + kYScale * vpNew * gsign * tScale);
                yFree = c.y;
            }
        } else if (groundedNow) {
            VPSET(vpNew) = 0;
            c.grounded = 1;
            c.rHover = 0;
            // ...but GD's update phase still took this tick's gravity step
            // before the collision pass put the body back on the surface --
            // that step is what `prePinY` holds (the 9-of-9 pad/orb split in
            // the note at `pinnedOnBlock` measures exactly this quantity), so
            // it, and not the seat, is the pre-collision position.
            yFree = prePinY;
        } else {
            c.grounded = 0;
            // ROBOT hover: while the button is STILL held from the jump and the
            // budget lasts, GD adds back exactly the gravity step it is about
            // to subtract, so vy does not change at all.
            // The hold that counts is `s.action`, the input this state came in
            // WITH, not this tick's: GD's per-tick order is update -> collisions
            // -> buttons, so the button state updateJump sees is the one set at
            // the end of the previous tick. (Same reason the wave steers on
            // s.held.) A release therefore still hovers on the release tick and
            // stops on the next one, which is what GD does.
            if (s.dashing && s.action
                && (g_dashStopBoxes.empty()
                    || !dashStopAt(modX, modY, pHalf))) {
                // DASH: no gravity at all, a straight line at the ring's own
                // angle. Same "the hold that counts is s.action" rule as the
                // robot's hover and the wave's steering.
                // A DASH STOP box (id 1829) at the START-of-tick position
                // drops the dash into the gravity branch below: vp is 0 while
                // dashing, so the fall restarts from 0 exactly like GD's
                // measured -0.215 on the cancel tick (see DashStopBox).
                c.dashing = 1;
                c.rHover = 0;
                VPSET(vpNew) = 0.0;
                YSET(c.y) = (float)((double)s.y + (double)s.dashSlope * useDx);
                yFree = c.y;
            } else if (isRobot && s.rHover && s.action) {
                VPSET(vpNew) = vp;
                // FORCE BOX (id 2069): the field applies during hover too, at the
                // ROBOT's strength -- this branch is gated on isRobot, so `s.mode`
                // is 5 by construction and the mode-less lookup could only ever
                // read the wrong column of a per-uid x mode table.
                // Measured lv22 t=16,462-16,471 (hover held, inside uid17701):
                // GD's dvy is +0.330 = that box's kRobot, not its 0.172.
                // The note that used to stand here read a ship's dvy at
                // t=15,846-848 as "a robot hover, +0.159 minus the hover's own
                // small decay". The mode there is ship, which never reaches this
                // branch, and the hover's decay is 0.000 in 23 of the 24 held robot
                // jumps in the corpus -- so neither half of that was measuring this.
                // The dash branch stays pass-through, as measured for 3645.
                if (!g_forceBoxes.empty())
                    VPSET(vpNew) += forceBoxAcc(modX, modY, pHalf,
                                         forceUnitFor(s.mode, useDx)) * gdSign;
                c.rHover = (uint8_t)(s.rHover - 1);
                YSET(c.y) = (float)((double)s.y + kYScale * vpNew * gsign * tScale);
                yFree = c.y;
            } else {
                c.dashing = 0;
                double acc = gAcc;
                // FORCE FIELD: world-frame push, converted to the player frame
                // by gsign like every other world force. Position is the
                // START-of-tick one (xPrev, s.y): the effect shows up one tick
                // after the overlap in all six measured entry/exit edges.
                double forceAcc = 0.0;
                if (!g_forceFields.empty())
                    forceAcc += forceFieldAcc(modX, modY, pHalf) * gdSign;
                // FORCE BOX (id 2069): same convention (start-of-tick position,
                // world->player via gsign). Measurements at the declaration of kFF2069
                if (!g_forceBoxes.empty())
                    forceAcc += forceBoxAcc(modX, modY, pHalf,
                                            forceUnitFor(s.mode, useDx)) * gdSign;
                // THE FORCE IS ADDED OUTSIDE THE TERMINAL, because GD adds it in
                // a different function. `updateJump` does gravity, then the cap
                // (maxsd against -15.0 @0x623778 upright / minsd against +15.0
                // @0x622EF0 flipped -- bare literals, no mini/speed/timeMod
                // factor), then the 0.001 quantisation, all at 0x38c2f2-0x38c350.
                // The force block's contribution is applied by PlayerObject::
                // update AFTER updateJump returns (0x3892db-0x389302) and is not
                // clamped at all.
                // Folded into `acc` before the cap, as it used to be, the model
                // pinned lv22 at exactly 15.000 where GD reaches 15.945. GD's
                // own arithmetic, to three digits on all three ticks:
                //   min(13.9040+0.215, 15) + 0.945 = 15.0640   GD 15.0640
                //   min(15.0640+0.215, 15) + 0.945 = 15.9450   GD 15.9450
                //   min(15.9450+0.215, 15) + 0.945 = 15.9450   GD 15.9450
                // and 0.945 = 1.160 - 0.215 is the force's own step (0.225 x
                // 4.2 x 1.0 for a cube), which is why mini, speed and flip do
                // not enter: 15.945/15.0 = 1.063 is a coincidence, not a scale.
                // qVy stays on the gravity half, where updateJump has it.
                // The TIME WARP scales the increment, not the terminal: the cap
                // is a velocity. The 0.001 grid is applied to each step (GD's
                // vy went 0 -> 0.043 -> 0.086 -> 0.129 under a 0.0432 step; the
                // exact accumulation would have given 0.130 on the third).
                // r102: the tick after hitting a black orb on a fast climb has no terminal
                VPSET(vpNew) = s.pNoTerm ? qVy(vp + acc * tScale)
                                  : qVy(std::max(vp + acc * tScale, gTerm));
                VPSET(vpNew) += forceAcc * tScale;
                if (isRobot) c.rHover = 0;
                YSET(c.y) = (float)((double)s.y + kYScale * vpNew * gsign * tScale);
                yFree = c.y;
                // --upsidecoyote: a fresh press finds og still set and jumps from mid-air. The
                // move above has already taken this tick's gravity step, as GD's update did
                // before its buttons phase; only the velocity is the jump's.
                // The ball's tap is its ground tap exactly (a custom level, mini ball: every press at
                // k=1..11 left with vy -2.6832 = the mini tap, gravity flipped, y moved by the
                // step), so it is written the way the grounded branch writes it.
                if (ogLingerGate && input && !s.action) {
                    if (isBall) {
                        c.flip = c.flip ? 0 : 1;
                        c.rotStep = (float)ballRotRate(c.mini != 0, true, useDx);
                        c.rotNeg = (uint8_t)!((c.flip != 0) ^ (c.rev != 0));
                        const double bTap = ballFlipFor(useDx) * (c.mini ? kMiniImpulse : 1.0);
                        VYSET(c.vy) = (float)(-bTap * (c.flip ? -1.0 : 1.0));
                        ballFlipped = true;
                        ballFlippedThisTick = true;
                    } else {
                        VPSET(vpNew) = c.mini ? (cph.jump * (kCubeJumpMini / kCubeJump))
                                              : cph.jump;
                    }
                    impulsedThisTick = IMPULSE();
                    c.pressSpent = 1;
                    ogLingerJump = true;
                }
            }
        }
        if (!ballFlipped) VYSET(c.vy) = (float)(vpNew * gsign);
        c.ogLinger = (ogLingerGate && !ogLingerJump && !impulsedThisTick) ? 1 : 0;
        // [2026-08-19 D9, REMOVED 2026-09-03] `if (s.pBallOff && c.mode == 2)
        // c.vy = -1.000 * gsign;` used to sit here -- the tick after a ball left
        // its face through a gravity flip in a rotated frame. The game has no
        // such write (see State's note where the field was), so the ball now
        // simply keeps the ordinary ladder the lines above produced: at lv22
        // t=6,292-4 that is -0.0650 / -0.1940 / -0.3230, which is what GD
        // reports.
        // FLIP-ON-HEAD-HIT arming (id 2866). Same START-of-tick position the
        // force field uses -- measured on lv22: GD's counter goes positive on
        // the tick whose PRE-move x first overlaps the box (t=2,707, pre-move
        // x=3,708.886 against the box's left edge 3,717 and a 9 px half), not
        // on the tick whose post-move x does (t=2,706). ~~Sticky once set.~~
        // [2026-09-07] **THAT MEASUREMENT IS ABOUT ONSET, NOT PERSISTENCE, AND
        // "sticky once set" IS REFUTED BY GD** -- gdref arms at t~2,707 and
        // still does NOT flip at t=11,342 (up stays 0, vy -0.216/tick straight
        // through), which is lv22's whole-run killer. It decays rather than
        // being consumed: three firings at t=2,749 / 2,890 / 2,961, all mini
        // cube. (This line said 4,592 -- that one is a SWING and a tap
        // reproduces the shape, so it was dropped; 2,961 was found later by a
        // census after an arbitrary |vy| > 3.0 in the scan had cut it by 0.064.
        // The count stayed three by coincidence.) The decay constant is NOT
        // known -- see the full record at State::fgArm, and do not write one
        // from the bracket there.
        // [2026-09-07] TWO ERRORS THAT CANCEL, and only for the case measured.
        // g_flipHeadBoxes holds LOAD-TIME positions (level_loader.hpp:1211) and
        // `!c.fgArm` makes this a set-once latch that never clears -- while GD
        // re-arms every tick from LIVE contact and drops two ticks after it
        // ends. On lv22 the 2866 rides the player, so a parked box that arms
        // forever and a live box that re-arms every tick produce the same
        // trace. They diverge for a 2866 that rides without ever statically
        // overlapping, and after any ride ends. fgArm is in the dedupe key
        // (search_key.hpp:305, bit 63), so this cannot be judged by replay --
        // see the full account at State::fgArm before touching it.
        // --fgarmlive [2026-09-20]: both halves of the pair above, together.
        // The live lookup keeps the three flips GD makes on lv22 (the box rides
        // the player, so the contact never ends there) and the decay stops the
        // arm from reaching t=11,342, 12,000 px past any 2866. Either alone is
        // worse than neither: see the note at g_fgArmLive.
        if (g_fgArmLive) {
            c.fgArm = (!g_flipHeadBoxes.empty()
                       && flipHeadArms(modX, modY, pHalf, (int)K.t))
                          ? (uint8_t)kArmTicks
                          : (uint8_t)(s.fgArm ? s.fgArm - 1 : 0);
        } else if (!c.fgArm && !g_flipHeadBoxes.empty()
                   && flipHeadArms(modX, modY, pHalf, (int)K.t))
            c.fgArm = 1;
        // CEILING ARM (id 1859) -- the same start-of-tick position the 2866 arm
        // and the force field read, and unlike fgArm it DECAYS: GD's counter is
        // set to 2 by the touch and stepped down every tick. The box is where the
        // recording has it on this tick (it can ride the player).
        c.armT = (!g_armBoxes.empty() && armBoxTouch(modX, modY, pHalf, (int)K.t))
                     ? 0
                     : (uint8_t)std::min<int>(kArmTicks, (int)s.armT + 1);
        // Dual anti-collision bounce. Measured on lv16's second dual (mini
        // ball, 11 point probes): a body moving
        // TOWARD its partner that ends the tick within 23 px of it while the
        // partner is GROUNDED is flipped away with vy = +/-2.000 EXACTLY
        // (not mini-scaled), y not clamped. Input-independent; inactive
        // while the partner is airborne (fires the tick after it lands);
        // a body moving AWAY sails through the zone untouched.
        // 23 = 2*half + 5 is a guess at the shape -- only the mini sum
        // (9+9+5) is measured, and only for the ball. The partner side here
        // is the START-of-tick y2/grounded2, which matches the measured
        // "fires the tick AFTER the partner lands".
        if (s.dual && isBall && !c.grounded && s.grounded2) {
            const double sep = (double)c.y - (double)s.y2;
            const double moved = (double)c.y - (double)s.y;
            if (std::fabs(sep) < 2.0 * pHalf + 5.0 && moved * sep < 0.0) {
                c.flip = (sep > 0.0) ? 1 : 0;
                VYSET(c.vy) = (sep > 0.0) ? 2.0f : -2.0f;
                c.grounded = 0;
            }
        }
        // invisible ceiling: a flipped ball rides it exactly like ground
        const double pCeil = ceilHere;
        // r75: whether this tick's grounding comes from the "invisible ceiling" (no
        // actual object supporting). Read by the reach-back gate in the landing
        // loop below.
        bool groundedInvCeil = false;
        if (c.flip && (double)c.y + pHalf >= pCeil
            && !(tpSkipBand && ceilIsBand)) {
            YSET(c.y) = (float)(pCeil - pHalf);
            VYSET(c.vy) = 0; CLAMP0("ground/flipceil");
            c.grounded = 1;
            groundedInvCeil = true;
            // GD runs buttons AFTER the collision pass, so a ball that
            // ARRIVES at the ceiling on the press tick flips on that same
            // tick. The input gate above ran on the pre-clamp position and
            // rightly said "airborne", so the edge would otherwise be spent
            // by the time the ride grounds it -- measured on lv16's second
            // dual t=12,494: GD clamps p2 to 621 and it leaves with the
            // mirrored tap (-2.7408) in the SAME tick; the model froze it
            // at 621 with the plan holding, and the pair never re-mirrored.
            if (isBall && input && !s.action
                && !gravPortalThisTick) {
                impulsedThisTick = IMPULSE();
                ballFlippedThisTick = true;
                c.flip = 0;
                VYSET(c.vy) = (float)(-ballFlipFor(useDx)
                               * (c.mini ? kMiniImpulse : 1.0));
                c.grounded = 0;
            }
        }
        // [2026-08-20 rig ramps] The ceiling **blocks from above regardless of the
        // gravity direction**. An upward-moving player is merely stopped, not
        // seated (not set grounded). Measured (rig ramps t=17,347, ball non-mini,
        // sp0.9, band [90,330]):
        //   GD  t=17,346 y=314.336 vy=+5.300 -> t=17,347 y=315.000 vy=0.000
        //       onGround=0 throughout, then free fall at -0.129/tick
        //   the model passed straight through and climbed to y=334 (divergence
        //   167 ticks / max 139px)
        // The exact mirror of the flipped-side branch just above and of the
        // "ground blocking from below" (kGroundY) just below. `c.vy > 0` is the
        // gate limiting it to **only the tick it pushed up from below**: at lv22
        // t=5,683.. an upward ball at y=1,035 (above the actual ceiling) comes down
        // far above band 387, and without this it gets sucked to 372.
        else if (!c.flip && (double)c.y + pHalf >= pCeil
                 && (c.vy > 0 || ceilIsBand)
                 && !(tpSkipBand && ceilIsBand)) {
            YSET(c.y) = (float)(pCeil - pHalf);
            if (c.vy > 0) VYSET(c.vy) = 0;
            CLAMP0("ground/ceilblock");
        }
        // GD's ground plane blocks the player from BELOW whatever its gravity is:
        // an inverted mini ship flown downward is stopped at 99.000 and held there
        // (lv11 t=9793). The old test had !c.flip and let it sink through the world.
        // Skipped in a TURNED frame: `y` is a world X there, so this plane is a
        // wall at world x=90 that does not exist (see spiderTargetY's note).
        // [2026-08-20 r38] **The band's floor catches the ball/spider too.** The
        // ceiling side (pCeil) was in but the floor side was not, so the model let
        // a ball fall straight through where GD stops it at pmin+pH. The flight
        // branch already does this (`floorY = max(btFlyF, kGroundY)`) -- the same
        // picture on the cube-family side.
        // Measured lv20 t=9,055 (mini ball, sp0.9, band [270,510], with a press):
        //   GD  t=9,054 y=280.263 vy=-9.128 -> t=9,055 **y=279.000 exactly**
        //       (=270+9); the flip tap rides on the same tick, upsideDown 0->1,
        //       vy=+2.683 = ballFlipFor(0.9) x kMiniImpulse exactly
        //   the model stayed in free fall at 278.18 (census edy +0.820 /
        //   edvy +11.940)
        // The gate is the same as the ceiling's: "the band value sits on the 30
        // grid" (see the note on bandUsable).
        const double bandF = bandFT;   // r81: recorded band first (see the ceilHere note)
        const bool bandFUsable =
            bandF > kGroundY + 0.01 && bandF < 1e8
            && bandIsWall(s.bandBranch,
                          std::fabs(bandF - std::round(bandF / 30.0) * 30.0) < 0.01);
        const double floorHere =
            ((isBall || isSpider) && bandFUsable) ? bandF : kGroundY;
        // [2026-08-21 r90] **The ground does not catch on a tick the player
        // warped.** Calibration rig ceilhold's 6 spider cells (pressing while hung
        // from a ceiling ramp = teleport to the opposite face, landing on this
        // world ground): GD **stays vy=-1.000 / onGround=0 on that tick** and seats
        // on the next tick (the teleport's signature -/+1.000 is as measured in the
        // note at 6291). The model's teleport puts y exactly at the seat, so this
        // caught it on the same tick and erased the -1.000 (all 6 cells edvy
        // exactly 1.000). The other loops (10435 / 11351 / 11611) already have the
        // same gate.
        // Ground-grow (speed.hpp): GD's ground clamp (in update) also lifts an upright player
        // that stands embedded in the ground -- the tick after a size portal grew it there.
        const bool embeddedOnGround = c.grounded && !c.flip
                                      && (c.mode == 0 || c.mode == 2)
                                      && c.y < floorHere + pHalf - 0.01;
        if (c.frame == 0 && (!c.grounded || embeddedOnGround) && !spiderWarpedThisTick
            && c.y <= floorHere + pHalf
            && c.vy <= 0
            && !(tpSkipBand && (isBall || isSpider) && bandFUsable)) {
            // ...but an INVERTED CUBE is not blocked here: GD kills it.
            //
            // The block above reads "whatever its gravity is", and its evidence is one
            // measurement -- an inverted mini SHIP held at 99.000 on lv11. Carried to the
            // cube it invents a floor GD does not have. Measured on a custom level
            // (2026-08-27), twice, on two different plans:
            //   plain plan  t=425 y=105.262 (bottom 90.262) alive
            //               t=426 y=104.982 (bottom 89.982) DEAD, obj=NULL
            //   +tap plan   t=379 bottom 91.522 alive -> t=380 bottom 89.735 DEAD, obj=NULL
            // The kill is on the crossing tick, with no object and no two-tick latch, and
            // there is no collider anywhere near y=90 in that stretch -- it is the world
            // plane itself. The model instead landed the cube at y=105 exactly (bottom
            // 90.000, vy=0) and flew the rest of the level from a state GD had ended, which
            // is why every plan it built there died in the game at the same three x's.
            // Confirmed on an OFFICIAL level, so the rule does not rest on levels this
            // repository does not carry: lv4 t=8,358 x=10,863, where the player is
            // genuinely an inverted cube and the nearest object of any kind is 210 px away
            // in y (nothing within 120 px of that x below y=200). Injected at y=120 with
            // vy=-14.5, GD ran it down 120 -> 116.79 -> 113.62 -> 110.50 -> 107.44 ->
            // 104.42 and fired destroyPlayer on that last tick -- the tick, and the only
            // tick, on which the box bottom went under 90 (92.44 -> 89.42). Every suspect
            // came back with POSITIVE clearance, the nearest at +180.6 px. Two controls at
            // the same tick: vy=0 floats up and lives, and vy=-2 (which descends to a
            // bottom of ~100 and reverses) lives 42 ticks -- so it is the CROSSING of 90
            // that kills, not the descending. The plane is not level-specific, which is
            // what makes lv4 an answer to the question lv20 could not host (every one of
            // lv20's 872 inverted-cube ticks has geometry in the y=70..122 band, so any
            // death there is an object's, and the state cannot be injected either: mode
            // and gravity are not injectable and lv20 is a WAVE at the tick in question).
            // Ground modes other than the cube are left alone: the ball's catch at lv20
            // t=9,055 is measured UPRIGHT (the flip tap lands on the same tick), so nothing
            // in the corpus says what an inverted one does, and inventing it would be the
            // same mistake in the other direction.
            // The rule was for a day a switch, off by default, because it cost lv20 its
            // cold clear -- not on physics but on the CAP: the route survives the rule and
            // the first solve is PARTIAL at x=28,823 at cap 2000 and 4000 and SOLVED at cap
            // 8000, both frontiers identical to t=2,500 and parting at the rule's first
            // firing (t=2,528, an inverted cube descending at vy=-14.5), then sitting at
            // the cap with 7.3M states dropped. What the loop actually could not get past
            // was x=25,760.9, where GD kills the dual's SECOND body in the corridor mode
            // portal uid13881 opens; three measured holes fed it (a mode portal did not end
            // a ceiling press the way it ends a slope ride, a ceiling release fired on the
            // tick the body came to rest instead of the tick after, and the two bodies
            // shared one `mode` and one press counter although each is tested at its own
            // y). With those closed the suite clears cold with the rule unconditional --
            // 22/22, net -29 iterations -- so there is nothing left for a switch to select.
            if (c.mode == 0 && c.flip) {
                DIE("ground/floor-inverted-cube", nullptr);
                return c;
            }
            YSET(c.y) = (float)(floorHere + pHalf);
            VYSET(c.vy) = 0; CLAMP0("ground/floor");
            // only an upright player RESTS on it; a flipped one is merely
            // blocked and drifts back up under its own gravity, which is what
            // GD's two ticks of vy = 0 then +0.122 show.
            if (!c.flip) c.grounded = 1;
            // ROBOT: a press buffered while airborne jumps on the LANDING tick,
            // on the ground plane exactly as on a block (the cube/ball branches
            // of the solids loop below; the ground landing had none at all).
            // Measured on lv22 t=19,835 (mini, sp1.1): press t=19,834 airborne
            // (vy=-5.326), GD's landing tick carries BOTH y=99 (=90+9, the
            // ground) and vy=+4.568 (=11.42 x 0.8 mini x 0.5 robot), onGround
            // 0, never a vy=0 tick. The model landed and jumped one tick late
            // -- fixcensus edvy=+4.568 / edy=0.000 exactly.
            // ROBOT ONLY: the cube's ground-plane case is unmeasured (its
            // block-landing branch below IS measured, lv20 t=1,224).
            if (c.mode == 5 && !c.flip && input && !s.action
                && !impulsedThisTick) {
                impulsedThisTick = IMPULSE();
                const CubePhys jph = cubePhysFor(useDx);
                VYSET(c.vy) = (float)(jph.jump
                               * (c.mini ? (kCubeJumpMini / kCubeJump) : 1.0)
                               * kRobotJumpScale);
                c.rHover = (uint8_t)kRobotHoverTicks;
                c.grounded = 0;
            }
            // ...and the CUBE the same, now measured (speed.hpp, the ground cube jump)
            if (c.mode == 0 && !c.flip && input && !s.action
                && !impulsedThisTick) {
                impulsedThisTick = IMPULSE();
                const CubePhys jph = cubePhysFor(useDx);
                VYSET(c.vy) = (float)(jph.jump
                               * (c.mini ? (kCubeJumpMini / kCubeJump) : 1.0));
                c.grounded = 0;
            }
            // ...and a BALL that ARRIVES here on the press tick flips on that
            // same tick -- GD runs buttons AFTER the collision pass, so the
            // input gate further up ran on the pre-clamp position and rightly
            // said "airborne". This is the **mirror** of the ceiling side (the
            // same-tick tap inside `ground/flipceil`), which was measured at lv16
            // t=12,494. The floor-side measurement is lv20 t=9,055 (note above): GD
            // emits both upsideDown 0->1 and vy=+2.683 on the same tick. The
            // impulse is in **the new gravity's direction**, so upward +ballFlipFor
            // (the ceiling side is -).
            if (isBall && !c.flip && input && !s.action && !impulsedThisTick
                && !gravPortalThisTick) {
                impulsedThisTick = IMPULSE();
                ballFlippedThisTick = true;
                c.flip = 1;
                VYSET(c.vy) = (float)(ballFlipFor(useDx)
                               * (c.mini ? kMiniImpulse : 1.0));
                c.grounded = 0;
            }
        }
        // The cube's hazard test for one object. A lambda so that --hazaftersolid can run
        // it after the solid loop instead of inside it (note in constants.hpp); the statements
        // are the ones that ran inline, unchanged.
        auto sweepCubeHazard = [&](const Obj* o, bool hazDbg) {
                    // TRIED AND REVERTED (2026-08-03): sampling SAWS at the tick
                    // END only (nSub = 1, si from 1), on the theory that the
                    // intermediate samples eat lv18's sub-pixel clearance past
                    // the saw at (24,571.7,375.5). The frontier was UNCHANGED --
                    // same alive counts, same y ranges, same death tick.
                    // ...but a spider TELEPORT is not travel. GD puts the
                    // player on the other surface in one step and never looks
                    // at the gap. Measured on lv22 t=1,910: GD warps
                    // y 316.5 -> 163.5 and lives, while the model swept the
                    // 153 px segment and died on the spike uid17571 (2.6x4.8 at
                    // 2272.5,213.25) sitting 50 px above the landing -- the
                    // only thing stopping a from-the-head replay of the r24
                    // plan, which otherwise matched GD's dump on every tick.
                    // ...and the LANDING is not where GD looks either. The
                    // per-tick order is update -> checkCollisions -> buttons,
                    // so the collision pass of the warp tick runs at the
                    // position the player had BEFORE the tap: the new x, the
                    // OLD y. Measured on lv22 2026-08-15 (spliced plan, GD
                    // worker 98, the event list): with the press at t=1,969 the
                    // warp lands on t=1,970 and the run reaches x=4,824; with
                    // the press at t=1,970 the warp would land on the same tick
                    // x reaches 2,343.444, and GD prints
                    //   checkCollisions
                    //   destroyPlayer 2343.44 163.5     <- the OLD y
                    //   INJECT_handleButton 1970 1      <- the tap, too late
                    // The model sampled the landing (2,343.444, 316.5), found
                    // it clear, and returned SOLVED on a plan GD kills -- the
                    // whole lv22 wall at x=2,343.
                    // The landing is not lost by skipping it here: the NEXT
                    // tick's si=0 sample is exactly (this tick's x, the landing
                    // y), which is where GD's next collision pass runs.
                    const bool warped = spiderWarpedThisTick;
                    const int subLo = warped ? kSubSteps : 0;
                    for (int si = subLo; si <= kSubSteps && !dead; ++si) {
                        const double f = si / (double)kSubSteps;
                        if (g_hazEndpoint && si < kSubSteps) continue;   // --hazendpoint: endpoint only
                        const double sx = xPrev + (x - xPrev) * f;
                        const double sy = warped
                            ? (double)s.y
                            : (double)s.y + ((double)c.y - (double)s.y) * f;
                        const bool hzHit = hazardHit(o, sx, sy, pHalf, kHazMargin,
                                                     sawMarginFor(s.mode),
                                                     s.mode, c.mini);
                        if (hazDbg)
                            std::printf("hazdbg t=%lld uid=%d si=%d sx=%.6f "
                                        "sy=%.6f pHalf=%.2f marg=%.3f saw=%.3f "
                                        "mode=%d mini=%d radius=%.3f obbOk=%d "
                                        "|dx|=%.6f |dy|=%.6f limx=%.3f limy=%.3f "
                                        "hit=%d at=%p cy=%.3f dyn=%d\n",
                                        (long long)K.t, o->uid, si, sx, sy,
                                        pHalf, kHazMargin,
                                        sawMarginFor(s.mode), (int)s.mode,
                                        (int)c.mini, o->radius,
                                        o->obbOk ? 1 : 0,
                                        std::fabs(sx - o->cx),
                                        std::fabs(sy - o->cy),
                                        o->hw + pHalf + kHazMargin,
                                        o->hh + pHalf + kHazMargin,
                                        hzHit ? 1 : 0, (const void*)o, o->cy,
                                        (int)o->dynObj);
                        if (hazDbg)
                            std::printf("hazdbg t=%lld uid=%d si=%d obbAll=%d "
                                        "obbOk=%d sat=%d bhw=%.3f bhh=%.3f "
                                        "bc=%.4f bs=%.4f rot=%.4f\n",
                                        (long long)K.t, o->uid, si,
                                        g_obbAll ? 1 : 0, o->obbOk ? 1 : 0,
                                        (o->obbOk && obbOverlap(*o, sx, sy, pHalf,
                                                                (double)s.rot)) ? 1 : 0,
                                        o->bhw, o->bhh, o->bc, o->bs,
                                        (double)s.rot);
                        if (hzHit
                            && (!g_obbAll || !o->obbOk
                                || obbOverlap(*o, sx, sy, pHalf, (double)s.rot)))
                            DIE("cube/hazard", o);
                    }
        };
        std::vector<const Obj*> solidOrd;   // --solidorder
        for (const Obj* const& o : solidWalk(K, solidOrd)) {
            noteSolidVisit(K, o, x, (double)c.y, pHalf);   // --solidorddbg
            // [2026-09-08] --hazdbg <uid>: say how far ONE object got down this
            // loop, gate by gate, and what the hazard predicate then answered.
            // Written because reading could not settle 22@5400: every gate and
            // every constant on the path says the spike uid 5897 should kill at
            // (8286.023, 1076.070) -- rect identical to GD's, in K.near by both
            // the window arithmetic and XSlice's own rewind, radius 0 and absent
            // from the obb table so the plain branch at object.hpp:448 runs,
            // kHazHalf 15 + margin 1.5 against |dy| 18.930 -- and the model
            // lives. Eight candidates were read and refuted; the ninth has to be
            // asked, not read.
            // Same shape as `pogate` (1292e5c) and `rampwin` (3d2a4ef): name the
            // term that refused, rather than leaving a choice between all of
            // them. Parameterised rather than hardcoded, default -1 = off.
            const bool hazDbg = (g_hazDbgUid >= 0 && o->uid == g_hazDbgUid);
            if (hazDbg)
                std::printf("hazdbg t=%lld uid=%d type=%d reach=loop x=%.6f "
                            "cx=%.3f hw=%.3f hh=%.3f pHalf=%.2f eps=%.3f "
                            "dx=%.6f lim=%.3f\n",
                            (long long)K.t, o->uid, (int)o->type, x, o->cx,
                            o->hw, o->hh, pHalf, kContactEps,
                            std::fabs(x - o->cx), o->hw + pHalf + kContactEps);
            // inclusive: touching edges count as overlapping (see kSupportReach)
            if (std::fabs(x - o->cx) > o->hw + pHalf + kContactEps) {
                if (hazDbg) std::printf("hazdbg t=%lld uid=%d dropped=xwindow\n",
                                        (long long)K.t, o->uid);
                continue;
            }
            if (hazDbg)
                std::printf("hazdbg t=%lld uid=%d passed=xwindow type!=0 is %d, "
                            "K.t>14 is %d\n", (long long)K.t, o->uid,
                            (o->type != 0) ? 1 : 0, (K.t > 14) ? 1 : 0);
            if (o->type != 0) {  // hazard (sub-tick sampled, planning margin)
                // --hazaftersolid: every hazard is left to the second walk below,
                // after the solids have placed the player.
                continue;
            }
            const double face = s.flip ? (o->cy - o->hh) : (o->cy + o->hh);
            const double prevFoot = (double)s.y - gsign * pHalf;
            const double newFoot = (double)c.y - gsign * pHalf;
            const double vpNow = (double)c.vy * gsign;
            // While riding a slope the ordinary landing test must be strict.
            // kLandTol lets a player "reach up" 6 px onto a face it never
            // crossed, and lv19's first slope has a 1.5 px slab (id 468) at its
            // top: climbing past it, the cube's foot is 5.5 px below the slab,
            // inside the tolerance, so the model teleported onto the slab at
            // t=245 while GD stayed on the slope until t=253.
            //
            // TRIED AND REVERTED (2026-08-18, same session): capping the
            // reach-back by the X penetration (min(kLandTol, xpen)), on an
            // axis-resolution theory. It refused the everyday landing where
            // the foot sinks past the face plane BESIDE the block and the
            // block then arrives (depth <= ~4, xpen ~1.3 on the entry tick)
            // -- 14 new census families across 13 levels, all gdg1. The
            // worker-98 sweep that killed the theory is in kLandTol's own
            // comment: at the SAME depth 10, an x-centred inject lands and a
            // side entry refuses -- but at depth 9.5 the side entry lands
            // too, so the discriminator is the DEPTH boundary (~10.0), not
            // the entry direction. The flat kLandTol stays; only its value
            // moved (10.5 -> 10.0, see the declaration).
            // GD walks the player's slope map before it resolves a solid, and a
            // ramp already governing this face makes the solid a no-op for the
            // whole tick -- no clamp, and no crush kill either (0x393643). The
            // predicate is slopeVetoesSolid; witnesses lv20 t=5,278 and lv16
            // t=8,696, both measured through GD's own hit flag.
            //
            // NOTE the neighbouring `landTol` line is very likely a compensating
            // fossil of this: it was added for lv19 t=245, a 1.5px slab (id 468)
            // at the top of the first slope -- the same object family and the
            // same arrangement as lv19 t=254/506, two of the five ticks the veto
            // census caught. Whether it can go once the veto is in is a separate
            // measurement; leaving it means both rules guard the same tick.
            // LEAF: GD picks the face block from which side the contact entered
            // (playerBottom + tol >= solid.maxY for the top site, solid.minY >=
            // playerTop - tol for the underside), not from gravity. `gsign > 0`
            // agrees with that on an ordinary landing and is what the 14 corpus
            // ticks were scored with; a player entering a face against its own
            // gravity would part them.
            if (vetoOf(K, o, x, (double)c.y, pHalf, pHalf,
                       gsign > 0, xPrev, (double)s.y, c.slopeUidNow))
                continue;
            double landTol = c.onSlope ? 0.001 : kLandTol;
            // Counting the fossil (--slopedbg). If this branch stops being taken
            // now that the veto is in, the 0.001 was standing in for it and can
            // retire; if it is still taken, the two guard different ticks and
            // both are load-bearing. Retiring it is a separate judgement -- this
            // only supplies the number.
            if (g_slopeDbg && c.onSlope)
                std::printf("landtol0001 t=%lld uid=%d\n",
                            (long long)K.t, o->uid);
            bool stepCandidate = false;
            // [2026-08-21 r84] **Even mid-ride, a "top face deeper below the line"
            // is grabbed as a step.** The 0.001 above was a guess to reject lv19
            // t=245 (a 1.5px slab sitting on the ramp's top end = **above** the
            // line), and it blocked the opposite side (a shelf below the line) too.
            // Calibration rig ridestep (a top face placed beside an uphill chain,
            // sweeping the **depth below the line** in 0.05px steps): GD splits at
            //   depth <= 3.100 -> passes / depth >= 3.200 -> mounts
            // with **the same boundary at |m|=1 and 0.5** (phase/reach do not split
            // it). ball/robot the same (2 points each). **Only the spider does not
            // mount even at depth 3.6**, so it is excluded. Consistent with both
            // corpus samples:
            //   lv16 t=5,378 (block uid1935 top=326, line 334 -> depth 8) mounts
            //   lv19 t=245  (slab above the line -> depth < 0)            does not
            if (c.onSlope && s.onSlope && !c.flip && c.mode != 6
                && (double)s.slopeM != 0.0) {
                const double mR = (double)s.slopeM;
                const double xoffR = slopeXOffset(mR, pHalf);
                // Foot and contact point are both taken at the **previous tick**
                // (s.y is the previous tick's ride y = the line at the previous
                // tick's contact point. Extrapolating at this tick's x
                // underestimates by m*dx and shifts the boundary by 1 tick)
                const double rR = xPrev + (mR > 0 ? xoffR : -xoffR);
                const double footR = (double)s.y - pHalf;
                // The point where depth is measured is "the contact point clamped
                // to the object's span". Measuring at the near end in the travel
                // direction, a player **already inside the object's span** gets
                // extrapolated back to the far end and the depth jumps (lv19
                // t=15,515: going back 44px to the left end of a 60-wide 1.5px slab
                // read depth 43.7, and it wrongly moved onto the step from a
                // downhill ramp GD keeps riding -- exposed as family +1).
                const double nearX = std::min(std::max(rR, o->cx - o->hw),
                                              o->cx + o->hw);
                const double lineAt = footR + mR * (nearX - rR);
                if (lineAt - face >= kStepDepth) {
                    landTol = kLandTol;
                    stepCandidate = true;
                }
            }
            if (g_dynDbg >= 0 && o->uid == g_dynDbg)
                std::printf("land? t=%lld uid=%d frame=%d flip=%d gs=%.0f "
                            "cy=%.3f hh=%.3f face=%.3f prevFoot=%.3f "
                            "newFoot=%.3f vpNow=%.3f -> %s\n",
                            (long long)K.t, o->uid, (int)c.frame, (int)s.flip,
                            gsign, o->cy, o->hh, face, prevFoot, newFoot, vpNow,
                            (vpNow <= 0 && (prevFoot - face) * gsign >= -landTol
                             && (newFoot - face) * gsign <= 0) ? "LAND" : "no");
            // [2026-08-19 the ball's corner landing is pen>1.0 (lv20 t=5,269)] When
            // a falling ball's centre is past the high end of a slope and the
            // landing face is at the same height as that corner, GD does not land
            // until the tick the box bottom breaks 1.0px below the corner (worker98
            // bisection 0.9955/1.0055, the same constant as preSlopeCollision's end
            // strip 1px inside). The site is the 1.5-wide bar uid5263, but the
            // edgeland rig measured "a plain plate catches even at 12.3 overhang",
            // so it is the neighbouring slope hijacking the test, not the bar's
            // width. The corner's gradient is also needed for the same-tick tap
            // bonus (below), so it is recorded.
            double ballCornerM = 0.0;
            if (c.mode == 2 && !c.flip && vpNow <= 0 && K.slopes
                && (newFoot - face) * gsign <= 0
                && (prevFoot - face) * gsign >= -landTol) {
                for (const Obj* spc : *K.slopes) {
                    if (spc->slopeHazard) continue;
                    if (slopeIsCeiling(spc->slopeDir)) continue;
                    const double sx0 = spc->cx - spc->hw;
                    const double sx1 = spc->cx + spc->hw;
                    const double sm = (spc->sy1 - spc->sy0) / (sx1 - sx0);
                    if (sm == 0.0) continue;
                    const double cxE = (sm > 0) ? sx1 : sx0;
                    const double cyE = (sm > 0) ? spc->sy1 : spc->sy0;
                    if (std::fabs(cyE - face) > 0.01) continue;
                    const bool past = (sm > 0)
                        ? (x > cxE && x - pHalf <= cxE + kContactEps)
                        : (x < cxE && x + pHalf >= cxE - kContactEps);
                    if (!past) continue;
                    ballCornerM = std::fabs(sm);
                    break;
                }
            }
            if (ballCornerM != 0.0 && (face - newFoot) * gsign < 1.0)
                continue;
            // [2026-08-21 r75] **A tick grounded on the invisible ceiling does not
            // grab a reach-back (a landing where the foot did not cross the
            // face).** kLandTol's boundary sweep (d=10.0 centre = lands) is entirely
            // measurements of a ball **injected in mid-air**. Calibration rig
            // ceilramp unit16 (flipped ball, hang-riding the band ceiling 330 with
            // og=1): the underside 320 of backfill block uid869 is 10.0px beyond
            // the foot (330) = just inside the tolerance, and only the model
            // "landed" at 305 on t=20554 and jumped 10px. GD does not grab even as
            // the x overlap grows; at t=20555 the ceiling ramp's line (313.033 =
            // ceilLimAt) picks it up, and from then on onSlope's strict tol (0.001)
            // guards it.
            // The gate is **groundedInvCeil only**: applying it to all of c.grounded
            // at first also dropped legitimate reach-back re-seats while grounded on
            // an actual object (the flipped cube's 0.05px / the flipped robot's
            // 0.75px, lv16/lv20) and families went +2 -- GD does grab the small
            // re-seats of a player standing on an actual object, even while
            // grounded.
            const double dHangL = (prevFoot - face) * gsign;
            if (vpNow <= 0 && dHangL >= -landTol
                && (dHangL >= 0.0 || !groundedInvCeil)
                && (newFoot - face) * gsign <= 0) {
                // kept in case a pad fires this same tick -- and only the FIRST
                // landing of the tick may record it. A 30 px box straddles two
                // 30 px blocks whenever it is not exactly aligned, so the loop
                // lands twice: the second pass then saved the y the first pass
                // had already snapped, and the pad "undid" the snap back to the
                // snap. Measured on lv16 t=4783: a flipped ball rising at
                // vy=10.285 into the ceiling blocks at x=6855 and x=6885 hits
                // the yellow pad at (6885,438) on the same tick, and GD leaves
                // it at the free-flight 426.6987 with vy=-9.6 -- it never rests
                // on the face. The model reported 425.000 and stayed 1.70 px low
                // for the rest of the section.
                if (!landedThisTick) preLandY = c.y;
                // r94: only the face highest along gravity writes y (measured, see decl.)
                const bool higherFace =
                    !landedThisTick || (face - landFaceBest) * gsign > 0.0;
                landedThisTick = true;
                cubeLandedThisTick = true;
                // r84: moved onto a step mid-ride (stops the slope loop below)
                if (stepCandidate && dHangL < -0.001)
                    stepLandedThisTick = true;
                if (higherFace) {
                    landFaceBest = face;
                    YSET(c.y) = (float)(face + gsign * pHalf);
                }
                // The ORDINARY landing on a solid's face, in every mode -- not a
                // flight one. It carried the label `fly/land` (which belongs to
                // the flight branch further down) and the object-less CLAMP0, so
                // the census saw `clamp:fly/land` with uid -1 and could not say
                // WHAT the player had landed on. Both halves are the instrument,
                // not the physics: the label and the uid are what `cause_of`
                // signs a family with.
                VYSET(c.vy) = 0; CLAMP0O("solid/land", o);
                c.grounded = 1;
                // GD runs buttons AFTER the collision pass, so a ball that
                // LANDS on the press tick flips on that very tick. The input
                // gate above saw the pre-landing position and said airborne,
                // and the edge would be spent by the next tick. Measured on
                // lv16's second dual t=12,495: p2 (flipped, rising 9.93)
                // reaches the ceiling blocks at 630, GD reports y=621 AND the
                // mirrored tap (-2.7408) on the same tick; the model parked
                // it at 621 and the pair never re-mirrored. Ball only: the
                // cube's same-tick jump is unmeasured and the last "one
                // measurement" cube landing rule cost 7 levels (see below).
                // not on a gravity portal's firing tick (speed.hpp, the gravity-portal landing tap)
                if (isBall && input && !s.action && !ballFlippedThisTick
                    && !gravPortalThisTick) {
                    impulsedThisTick = IMPULSE();
                    ballFlippedThisTick = true;
                    c.flip = c.flip ? 0 : 1;
                    // A tap on the tick of a corner landing carries the slope
                    // bonus. The value scales with the gradient's exit ratio (lv20
                    // t=5,270 measured: 3.9438 = 3.426 + 0.5178, 0.5178 = 0.2796 x
                    // exit(1)/exit(0.5) = x1.8517. Both samples are sp1.1, so it is
                    // written as a ratio that makes no claim about speed scaling).
                    const double cornerBonus = (ballCornerM != 0.0)
                        ? kBallSlopeTapBonus
                              * (slopeExitVy(ballCornerM, 2, useDx,
                                             c.mini != 0)
                                 / slopeExitVy(0.5, 2, useDx, c.mini != 0))
                        : 0.0;
                    VYSET(c.vy) = (float)(-(ballFlipFor(useDx) + cornerBonus)
                                   * (c.mini ? kMiniImpulse : 1.0)
                                   * (c.flip ? -1.0 : 1.0));
                    c.grounded = 0;
                }
                // ...and the CUBE does the same thing, which the note above
                // called unmeasured. MEASURED 2026-08-09 on lv20 t=1224 (cfg
                // orbtrace=1 for the event list, so the press tick is read and
                // not inferred): the plan's edge is `INJECT_handleButton 1223
                // 1`, the cube is still airborne at t=1223 (y=256.500,
                // vy=-8.576), and on t=1224 GD's dump has BOTH the landing
                // (y=255.250, the slab id664 top 240.3 plus half 15) and the
                // jump (vy=+11.180). The model landed and sat there: its
                // `groundedNow` is the support at the START of the tick, so the
                // edge was spent while airborne and the next tick had no edge
                // left. It stayed 22 px/tick behind for the rest of the level.
                // The EDGE is kept (`!s.action`) -- this only moves WHEN the
                // support is read, exactly as the ball's case above does. The
                // rule that cost 7 levels was a different one: it let a cube
                // jump off a face it had merely touched, without the edge.
                // ...and the ROBOT too (2026-08-18): the buffered press works
                // exactly like the cube's. Measured on lv22 t=19,835 (mini,
                // sp1.1): the plan presses at t=19,834 while airborne
                // (vy=-5.326), the robot lands the next tick, and GD's dump has
                // BOTH the landing (y=99, the surface) and the jump
                // (vy=+4.568 = 11.42 x 0.8 mini x 0.5 robot) on t=19,835 --
                // never a vy=0 tick. onGround stays 0. The model landed, sat
                // one tick, and jumped at 19,836: the fixcensus signature is
                // edvy=+4.568 with edy=0.000 exactly.
                // Held-through (edge 30+ ticks old) is DIFFERENT and stays as
                // is: lv22 t=15,878 measured GD re-jumping the tick AFTER the
                // landing (the kRobotGScale note), which the main grounded
                // branch already does. The edge here is what distinguishes the
                // two -- same as the cube.
                else if ((c.mode == 0 || c.mode == 5) && input && !s.action
                         && !impulsedThisTick) {
                    impulsedThisTick = IMPULSE();
                    const CubePhys jph = cubePhysFor(useDx);
                    double vj = jph.jump
                                * (c.mini ? (kCubeJumpMini / kCubeJump) : 1.0);
                    if (c.mode == 5) {
                        // half impulse + the hover budget, exactly as the
                        // ordinary robot jump arms it (GD zeroes this+0x830 in
                        // the same block that writes the jump velocity)
                        vj *= kRobotJumpScale;
                        c.rHover = (uint8_t)kRobotHoverTicks;
                    }
                    VYSET(c.vy) = (float)(vj * (c.flip ? -1.0 : 1.0));
                    c.grounded = 0;
                }
            } else if (c.mode == 2 && !s.flip && vpNow >= 0.0
                       && (o->cy - o->hh) - ((double)s.y + pHalf) >= -kLandTol
                       && ((double)c.y + pHalf) - (o->cy - o->hh) > 0.0) {
                // --ballceil (speed.hpp): the landing's mirror on an underside, one-way
                // plates included -- the ball is on GD's unconditional ceiling list.
                YSET(c.y) = (float)((o->cy - o->hh) - pHalf);
                VYSET(c.vy) = 0; CLAMP0O("ball/ceil", o);
                c.grounded = 1;
                continue;
            } else if (c.mode == 2 && s.flip && c.flip && vpNow >= 0.0
                       && ((double)s.y - pHalf) - (o->cy + o->hh) >= -kLandTol
                       && (o->cy + o->hh) - ((double)c.y - pHalf) > 0.0) {
                // --ballceilflip (speed.hpp): the same on a flipped ball's head side, a top
                YSET(c.y) = (float)((o->cy + o->hh) + pHalf);
                VYSET(c.vy) = 0; CLAMP0O("ball/ceilflip", o);
                continue;
            } else if (!o->oneway) {
                // CEILING STOP. A cube whose HEAD reaches a solid's near face is
                // not killed -- GD pins it there, zeroes vy and sets onGround,
                // so it can even jump off again.
                // Measured on lv22 (runR5's plan, cfg hitboxtrace=1, so the
                // rects are GD's own):
                //   t=2,748  y=320.771 vy=10.816 onGround=0 (head 329.77,
                //                                            face 330.01)
                //   t=2,749  y=321.008 vy=0      onGround=1
                //
                // Two gates, both needed -- a version with neither made 13 of
                // the 21 levels worse, and a version with only the first still
                // did:
                //   * ACQUIRING it needs the same depth test the ship's ceiling
                //     ride has. Instrumented lv1's false stop against lv22's
                //     real one: xPen 6.67 (full size, threshold 26.25) vs 19.78
                //     (mini, 15.75), so `xPen > kSolidResolveX * pHalf` splits
                //     them exactly.
                //   * HOLDING it reads `ceilPin`, not `grounded`. lv22 rides
                //     this face for 60+ ticks while the slab itself creeps
                //     upward, so the pin has to survive; but `grounded` is also
                //     true for a player walking the floor, and then any block
                //     whose underside passes within a pixel of its head grabs
                //     it (lv1 t=5,800).
                //   * the tolerance is 0.001, NOT kLandTol. That 6 px is the
                //     landing's "reach up onto a face" slack; reused on the head
                //     it grabs anything whose underside passes within 6 px.
                //     This one gate took the damage from 13 levels to 2.
                //   * UPRIGHT only. A flipped cube descending onto a block's top
                //     is the same geometry mirrored, and GD does NOT stop it:
                //     lv8 t=1,263 has the flipped cube 0.2 px into uid79 and it
                //     keeps falling (134.80, 134.23, 133.71 ...) with
                //     onGround=0 the whole way. With `!s.flip` the whole suite
                //     is byte-identical; without it lv8 loses 137 ticks.
                // [2026-08-19] The ball's head bonk has an "entering from the side"
                // path. Measured lv9 t=18,354 (uid3976, 30x30, underside 270): on
                // the tick the right edge of a rising ball's box (vy +2.279,
                // decaying arc) crosses the left edge 23,850, GD **pushes y down**
                // to 255 (=underside-pH), vy=0, not grounded (g=0), free fall from
                // the next tick (-0.129/tick). yPen 2.94 / xPen 0.99 -- a
                // **crossing in the opposite sense** from the cube bonk rejected on
                // 2026-08-18 (the grazing arc with yPen<=xPen); the gate is "x
                // entered on this tick". The cube stays as is, per the rejection's
                // measurement; the robot is covered by the bonk above. The flipped
                // side and the upper bound of yPen (vertical clip) are unmeasured
                // -- provisionally pH/2.
                if (c.mode == 2 && !s.flip && vpNow > 0.001) {
                    const double headB = o->cy - o->hh;
                    const double yPenB = ((double)c.y + pHalf) - headB;
                    const bool xEntered =
                        std::fabs(x - o->cx) <= o->hw + pHalf
                        && std::fabs(xPrev - o->cx) > o->hw + pHalf;
                    if (xEntered && yPenB > 0.0 && yPenB < pHalf * 0.5) {
                        YSET(c.y) = (float)(headB - pHalf);
                        VYSET(c.vy) = 0; CLAMP0O("ball/headbonk", o);
                        c.grounded = 0;
                        continue;
                    }
                }
                // [2026-08-18] cube only -> robot too. The head-bonk measurement is
                // a mini robot (lv22 t=18,600, the bonk note below). The robot
                // shares every other rule of this branch as "a cube with 0.9
                // gravity", yet only the head side passed straight through.
                // ball/spider are kept outside, unmeasured (the ball's ceiling has
                // the separate flipceil rule).
                if (c.mode == 0 || c.mode == 5) {
                    const double head = s.flip ? (o->cy + o->hh)
                                               : (o->cy - o->hh);
                    const double prevHead = (double)s.y + gsign * pHalf;
                    const double newHead = (double)c.y + gsign * pHalf;
                    const double xPenC = (o->hw + pHalf) - std::fabs(x - o->cx);
                    // 1.0, not a hair: lv22's slab is itself climbing, and by
                    // t=2,771 it moves 0.35 px in a tick -- a tolerance that
                    // tight drops the pin mid-ride and the model peels away.
                    const bool held = s.ceilPin != 0
                                      && std::fabs(prevHead - head) <= 1.0;
                    // The PIN is upright-only (the lv8 measurement above). The
                    // ARMED flip is not: GD's didHitHead has no orientation
                    // gate, it runs off the head-collision branch, and the head
                    // follows the player's own gravity. Measured on lv22's
                    // reference replay, x=3,774 -> 4,395 is a CORRIDOR the cube
                    // crosses by flipping back and forth off both surfaces:
                    //   t=2,991 up 0->1 (y=321)   t=3,207 up 1->0 (y=293)
                    //   t=3,301 up 0->1 (y=321)   t=3,421 up 1->0 (y=291)
                    // With `!s.flip` on the armed path the model could only ever
                    // make the FIRST of those, so from x=3,790 it had no way
                    // down: every route it found flew off the top of the level
                    // and died to GD's out-of-bounds kill at y=3,684.
                    const bool acquireBase = vpNow > 0.001
                                             && (prevHead - head) * gsign <= 0.001
                                             && (newHead - head) * gsign >= 0;
                    const double yPenC = (newHead - head) * gsign;
                    // The ARMED flip does NOT get the depth gate. That gate is a
                    // stand-in for "GD resolved this collision vertically", and
                    // 1.75*pHalf is far too strict: measured on lv22 t=2,961 the
                    // cube flips off uid3094 (a static 30x30 at 4,185,345) while
                    // its centre is at x=4,204.19 -- 4.19 px PAST the slab's
                    // right edge, so xPen is 4.81 against a threshold of 15.75.
                    // GD picks the axis with the SMALLER penetration, and the
                    // vertical one there is 0.6 px. That is the test used here.
                    // Without this the model could not make the corridor's
                    // second flip and every route it found flew off the level.
                    const bool acquire = acquireBase && !s.flip
                                         && xPenC > kSolidResolveX * pHalf
                                         && g_ceilPin;
                    const bool acquireFlip = acquireBase && s.fgArm
                                             && yPenC <= xPenC;
                    // [2026-08-18] The plain **head bonk**. What g_ceilPin's note
                    // rejected was "grab and ride (pin: running along the underside
                    // with grounded=1)", which does not mean GD does nothing -- on
                    // the tick a rising head crosses the underside with
                    // **yPen <= xPen** (the shallow axis), GD puts y on the face,
                    // vy=0, **does not ground it**, and free-falls it from the next
                    // tick. Measured lv22 t=18,600 (slope-exit arc off the
                    // reverse-travel staircase, mini robot, underside 2070,
                    // yPen 1.25 / xPen 14.44):
                    //   GD: y=2061 (=2070-9) vy=0 -> -0.194/tick from t=18,601
                    //   model: passed straight through, kept climbing (nearceil
                    //   family)
                    // Consistent with the 2026-08-16 sweep ("no pin" at xPen
                    // 15.957 / 24.0): that was the rejection of the pin; the bonk
                    // only erases vy.
                    // **ROBOT ONLY.** Applied to the cube too, it over-fired on 14
                    // levels / 28 families and was rejected at once (verify
                    // 2026-08-18): GD's cube passes straight through a yPen<=xPen
                    // crossing where the jump arc grazes a corner, with no bonk. As
                    // the neighbouring note says, "one point is not a rule" -- the
                    // cube's head side (lv16's nearceil family) awaits a separate
                    // measurement.
                    // [2026-08-26] ...and the MINI cube gets it too. The switch
                    // band's punch IS this bonk: lv22's certified tap sequence,
                    // four contacts of four, has GD clamp a mini cube rising
                    // +7.65 into a plain block's underside to y=261.000 =
                    // underside 270 - pHalf 9, vy=0, grounded=0, falling away
                    // from the next tick. The model killed it as
                    // cube/solid-side, a rule for LATERAL entry (lv9, xpen~11).
                    //
                    // FULL SIZE MUST NOT, and that is measured, not assumed.
                    // The first cut gated on "x already overlapped at tick
                    // start" -- which reads identically on both sizes -- and it
                    // cost eleven levels their fidelity (quick_regress, the
                    // whole cube suite) plus lv18's cold clear: the model
                    // clamped a full cube grazing 0.175 px into uid12842
                    // (30x30 at 25,095/315) at t=18,252 and lost the only
                    // corridor, while GD flies straight through -- an injection
                    // sweep of that contact passes at every penetration from
                    // -0.5 to +5.25 px with vy untouched. lv13's three contacts
                    // and lv21's one are the same story from the other side:
                    // with the bonk on they diverge, with it off they are
                    // bit-identical.
                    //
                    // What separates the sizes is NOT in this branch's
                    // geometry. Refuted by measurement: object id (lv18's
                    // uid12830, same id 269, same pad beneath, CLAMPS a full
                    // cube at dx=+1.1 where uid12842 passes at dx=+18.6), a
                    // pad flush under the block (both have one), the
                    // neighbourhood (identical but for decorations), and every
                    // threshold on |dx| / xPen / xPen-over-pHalf (mini clamps
                    // at 4.65 px of overlap where full passes at 11.41).
                    // So the rule stands only where it was measured. The next
                    // instrument is the disassembly of the head branch, not
                    // another fitted constant.
                    // [2026-09-01] ...and the next instrument WAS the
                    // disassembly, and it says the size was never the point.
                    // collidedWithObjectInternal :739-750 lets ship, UFO, wave,
                    // swing and ball into the ceiling resolution
                    // unconditionally and the classic ground modes -- cube,
                    // robot, spider, SIZE UNCONSIDERED -- only while an id-1859
                    // arm is up. Three injections say the same (armBoxTouch):
                    // a FULL-SIZE cube bonks under lv22's armed ceiling at
                    // exactly y=2,055.000, the same full-size cube dies under
                    // lv18's plain one, and a MINI cube dies under lv11's. So
                    // "robot or mini cube" was a proxy for "an 1859 is here",
                    // which is also why f3ca55d had to cut the bonk down to
                    // mini to stop it firing where GD kills.
                    // Ball stays out of this branch: it is on GD's
                    // unconditional list, but putting it there is a separate
                    // change with no measurement of mine behind it.
                    // [005 GATE WITHDRAWN 2026-09-01] `c.armT < kArmTicks` --
                    // the measured discriminant -- stood here for one cold run
                    // and cost lv22 its clear: 201 repair rounds against a
                    // budget of 186, the search never past x=4,914, with 94 of
                    // its deaths piled at x=2,900-2,949 where a FULL-SIZE cube
                    // is mid-jump and neither rule applies. So the wall is not
                    // where the gate acts: the frontier arriving there is what
                    // got thinner.
                    // Why: GD's gate is an OR of four arming sources -- 1859,
                    // 2866, platformer, and a gravity flip within 0.1 s -- and
                    // only the first two are modelled. Implementing one arm of
                    // a measured OR makes the model STRICTER THAN GD, and lv22
                    // is the most flip-dense level in the corpus, so it paid
                    // for the missing flip arm. The measurements behind the
                    // 1859 arm are not in doubt (three injections, both
                    // directions, reproduced by the model); what is wrong is
                    // shipping one quarter of a gate.
                    // The flip arm could not be probed on its own: the case it
                    // needs is an UPRIGHT player within 25 ticks of a flip
                    // meeting a ceiling, and a blue pad leaves the player
                    // flipped -- injecting it back onto the same pad does not
                    // re-fire it, and the flipped variant (head into a block's
                    // top from above) shows GD doing neither bonk nor kill but
                    // passing straight through. That third behaviour is its own
                    // unmeasured thing, and `!s.flip` above may be part of the
                    // old proxy rather than of GD.
                    // 004b re-lands all of it together, behind CVar29.
                    // --bonkarm (default off) puts the measured discriminant back:
                    // the id-1859 arm (armT: the touch tick and the one after)
                    // instead of the robot / mini proxy. Only the discriminant
                    // moves, as in 005. The flip arm is still missing, so with the
                    // flag on the model is stricter than GD right after a flip.
                    const bool bonkWho = c.armT < kArmTicks;
                    const bool bonk = bonkWho
                                      && acquireBase && !s.flip && !s.fgArm
                                      && yPenC <= xPenC;
                    if (std::fabs(x - o->cx) <= o->hw + pInner
                        && (held || acquire || acquireFlip || bonk)) {
                        // ARMED (id 2866 touched): PlayerObject::didHitHead runs
                        // its body instead of doing nothing, so the player turns
                        // over and stands on the face rather than hanging under
                        // it. The resting y is the same either way (head - pHalf
                        // upright == head + gsign*pHalf flipped), which is why
                        // the pin looked right when it was first fitted to this
                        // very event -- everything downstream is different.
                        // GD also sets vy to +/-2 here, but the landing that
                        // follows in the same tick zeroes it (measured: t=2,749
                        // has onGround=1, yvel=0).
                        if (acquireFlip) {
                            c.flip = (uint8_t)!s.flip;
                            const double g2 = c.flip ? -1.0 : 1.0;
                            YSET(c.y) = (float)(head + g2 * pHalf);
                            VYSET(c.vy) = 0; CLAMP0O("cube/fliphead", o);
                            c.grounded = 1;
                            c.ceilPin = 0;
                            // every gravity flip negates the cube's spin
                            c.rotNeg = c.flip;
                            continue;
                        }
                        // plain bonk: stops but does not grab (note at the declaration above)
                        if (bonk && !held && !acquire) {
                            YSET(c.y) = (float)(head - gsign * pHalf);
                            VYSET(c.vy) = 0; CLAMP0O("cube/headbonk", o);
                            c.grounded = 0;
                            c.ceilPin = 0;
                            continue;
                        }
                        YSET(c.y) = (float)(head - gsign * pHalf);
                        VYSET(c.vy) = 0; CLAMP0O("cube/ceilstop", o);
                        c.grounded = 1;
                        c.ceilPin = 1;
                        continue;
                    }
                }
                // one-way platforms never kill.
                //
                // OPEN BUG (2026-08-03): this ALSO kills on the block a PAD just
                // launched the player off, and GD does not. Measured on lv18
                // from `18000,24372.438,275,0,0,0,0,0,1,...`: the blue gravity
                // pad at (24,375,273) flips the player and gives vy = 5.12,
                // model and GD agreeing exactly at t=18,001. On the NEXT tick
                // the player is at y=276.15 and still overlaps the block the pad
                // sits on (274 at (24,375,255), top 270) by 2.85 px -- GD lets
                // it go because it is leaving, the model kills it on the side
                // test. Every branch that uses that pad dies one tick later.
                // TRIED: gating on `!impulsedThisTick`. It does NOT work --
                // the pad branch never sets that flag (only the cube jump, the
                // ball tap and the UFO flap do), so nothing changed. The gate
                // has to key off the PAD firing: set a local flag in the
                // `c.usedPad[slot] = pd` branch and skip the side test for the
                // rest of this tick, or better, skip only when the player is
                // moving AWAY from this object's face in its own gravity frame.
                // ...unless the player is SEPARATING from it: centre moving away
                // from the block's centre means it is leaving, not running in.
                // This is what a pad/orb launch off the top of a block looks
                // like for the tick after it fires.
                // ...and only when it was ALREADY over/under the block at the
                // start of the tick. Without that x test the guard also spared
                // a player entering through the SIDE while drifting down past
                // the block's centre, which GD does kill (lv18 t=18,175:
                // (24,654.8, 252.0) vy=-4.19 into 269 (24,675,255), xPrev is
                // still 21.85 px away = not yet over it).
                const bool separating =
                    ((double)c.y - o->cy) * (double)c.vy > 0.0
                    && std::fabs(xPrev - o->cx) < o->hw + pInner;
                // [004b, GATE WITHDRAWN 2026-09-01] GD does not take this kill
                // arm at all within 0.1 s of a gravity flip -- it puts the
                // player on the face and calls hitGround instead
                // (collidedWithObjectInternal :1184). MEASURED on lv18, worker
                // 98, the player injected 2.5 px into a block's top face with
                // only the flip age varied: no flip DEATH / age 0, 12, 24 LIVES
                // (re-seated to y=285.000 = face+15, og=1) / age 25, 30, 36
                // DEATH. So the window is 25 ticks from the tick the dump shows
                // the flip, and State::flipT (still carried, still stamped)
                // counts it.
                //
                // The gate stood here for one full-suite cold and was taken
                // back out: it cost lv22 62 -> 99 iterations, lv20 38 -> 61,
                // and the suite's repairs 416 -> 667 with the no-op marks up
                // 3.5x. The mechanism is not in doubt -- the DISCRIMINANT is.
                // GD's guard also tests CVar29, the ground/ceiling side
                // classification of the contact, and the model of it used here
                // was a static "the centre is outside the object's y span".
                // That matched all four probe points and is too loose in
                // motion: the real classifier compares widened foot and head
                // (base reach + |surface speed|) against the object's MinY/MaxY
                // at the CURRENT AND PREVIOUS positions, mirrored by flip, so a
                // fast mover near the boundary is exactly where a static test
                // parts company -- and lv20 and lv22, the two that blew up, are
                // the levels with the movers and the rotated frames.
                // An over-loose grace is UNDER-kill, and unlike over-kill the
                // loop can see it: it comes back as repairs found in replay.
                // 004b re-lands it behind the real classifier, with the same
                // nine points plus a probe against a MOVING block.
                // --faceclass (speed.hpp): a face contact is not a side hit
                const bool faceC = footFaceContact(*o, c, pHalf);
                const bool graceC = flipGraceSeat(*o, c, s, ballFlippedThisTick && input && !s.action, pHalf);   // --flipgrace (speed.hpp)
                for (int si = 0; si <= kSubSteps && !dead && !separating && !faceC; ++si) {
                    const double f = si / (double)kSubSteps;
                    const double sx = xPrev + (x - xPrev) * f;
                    const double sy = (double)s.y + ((double)c.y - (double)s.y) * f;
                    if (std::fabs(sy - o->cy) < o->hh + pInner + kHazMargin
                        && std::fabs(sx - o->cx) < o->hw + pInner + kHazMargin) {
                        if (graceC) {
                            seatOnNearFace(*o, c, pHalf);
                            CLAMP0O("cube/flipgrace", o);
                            break;
                        }
                        // A spider within 0.04 s of its teleport is spared the side kill of a solid
                        // whose right edge is left of the inner box's right edge (State::spiderJumpT).
                        // GD compares world x, so only in frame 0, where the model's x is world x.
                        if (c.mode == 6 && c.frame == 0 && c.spiderJumpT < kSpiderJumpGraceTicks
                            && o->cx + o->hw < sx + pInner)
                            break;
                        DIE("cube/solid-side", o);
                    }
                }
                // TRIED AND REVERTED (2026-07-31): a cube "face snap" here --
                // when the box overlaps a solid too shallowly to kill and the
                // player is moving into the face with its centre still outside
                // it, put the player on the face (c.y = face + gsign*pHalf,
                // vy = 0, grounded). It reproduces lv14 t=7078 exactly, where a
                // flipped cube rising at vy=10.936 first overlaps the block at
                // (9225,751) by 1.24 px in x and GD pins it at y = 721.000 --
                // but the COLD REGRESSION went 13/13 -> 6/13: lv1, lv3, lv6,
                // lv8, lv9, lv10 and lv12 all went stuck. The centre test was
                // supposed to keep it from becoming a step climb and does not.
                // One measurement is not a rule (this is the seventh time).
                // Whatever GD does at that tick, it is narrower than this.
            }
        }
        // --hazaftersolid: the hazards the loop above skipped, tested where the solids left
        // the player -- the landing snap included. A second walk of the same K.near, in the
        // same order, applying the same two gates. It was a fixed hazLater[64] buffer until
        // 2026-09-20: K.near has no length bound (cli.hpp collects every static and dynamic
        // object in the x window), so past the 64th hazard the overflow went back to the old
        // order silently, and the rule's meaning would have varied with object density.
        if (K.t > 14) {
            for (const Obj* o : *K.near) {
                if (dead) break;
                if (o->type == 0) continue;
                const bool hazDbg = (g_hazDbgUid >= 0 && o->uid == g_hazDbgUid);
                if (std::fabs(x - o->cx) > o->hw + pHalf + kContactEps) {
                    if (hazDbg) std::printf("hazdbg t=%lld uid=%d dropped=xwindow\n",
                                            (long long)K.t, o->uid);
                    continue;
                }
                sweepCubeHazard(o, hazDbg);
            }
        }
    } else {
        // ship: rides floors, lands from above, inner-box side/ceiling kills.
        //
        // The whole branch used to run in the WORLD frame with no notion of
        // flipped gravity -- only the cube branch mirrored. An inverted ship was
        // therefore simulated as an upright one, and since the ship's fall and
        // thrust accelerations are not symmetric the vy sequence came out wrong
        // in both magnitude and sign pattern: measured on lv7 t=5810 (ship with
        // upsideDown = 1) GD alternated -0.086/+0.103 per tick while the model
        // alternated -0.069/+0.108. Everything vertical is now done in the
        // PLAYER frame, the same way the cube branch does it.
        const double gsign = s.flip ? -1.0 : 1.0;
        // The flying band's floor, where the section has one, replaces the
        // world's ground line entirely: on lv12 the UFO is put back at y=195
        // (floor 180) with nothing underneath, and 90 never comes into it.
        // The recorded band, if any, takes priority over the frozen band (history at
        // the declaration of g_bandTrack). Zoom and camera movement are both folded
        // into the recording, so the zoom correction below is skipped. But **only
        // while the current y is inside the recorded band** (same gate as the wave
        // side: in a section flying outside the band, pmin/pmax are camera state
        // and not a clamp).
        double btFlyF = (double)s.bandFloor, btFlyC = (double)s.bandCeil;
        bool btFlyOn = false;
        if (s.frame == 0) {
            // The two phases are looked up separately and can land on rows of
            // DIFFERENT kinds. The ceiling decides: without an interval there is
            // no recorded band to fly in, and the floor is not taken from a
            // collapsed or absent row on its own.
            BandKind bk = BandKind::Unknown, bkF = BandKind::Unknown;
            double f_ = btFlyF, c_ = btFlyC;
            long long bage = 0;
            if (bandTrackKindAt((long long)K.t + 1, bk, f_, c_, bage)
                && bk == BandKind::Interval
                && (double)s.y >= f_ - 1.0 && (double)s.y <= c_ + 1.0) {
                btFlyF = f_; btFlyC = c_; btFlyOn = true;
                // The FLOOR side reads the previous row (the pan lands after the
                // clamp -- measurement at bandTrackFloorAt). The ceiling keeps the
                // r107 phase it was calibrated with.
                double ff = f_, fc = c_;
                long long fage = 0;
                if (bandTrackKindAt((long long)K.t - 1, bkF, ff, fc, fage)
                    && bkF == BandKind::Interval)
                    btFlyF = ff;
            }
        }
        const double floorY = std::max(btFlyF, kGroundY);
        bool groundedNow = s.grounded != 0;
        // A grounded SHIP on a MOVING face rides it, exactly like the cube
        // family's support loop (the `+ |dcy|` widening and the ride re-seat
        // by the stair snap). This loop had the plain 0.6 and no ride, so a
        // floor rising 0.2616/tick under a resting mini ship walked into it
        // for 3 ticks and the model re-landed 0.785 higher -- a staircase
        // where GD glides (lv19 t=21,73x, uid 15031's lift; the two
        // edy=+0.2616 census items). The ride gate is dcy != 0, so a static
        // floor is bit-identical.
        bool flyRide = false;
        double flyRideFace = 0.0, flyRideGap = 0.0, flyRideDcy = 0.0;
        int flyRideUid = -1;              // --dcydbg only: names the surface
        if (groundedNow && (s.flip || s.y > (floorY + pHalf) + 0.5)) {
            bool sup = false;
            for (const Obj* o : *K.near) {
                if (o->type != 0) continue;
                const double face = s.flip ? (o->cy - o->hh) : (o->cy + o->hh);
                const double gap =
                    std::fabs((double)s.y - gsign * pHalf - face);
                if (std::fabs(x - o->cx) <= o->hw + pHalf + kContactEps
                    && gap < 0.6 + std::fabs(o->dcy)) {
                    sup = true;
                    // When TWO moving faces qualify, GD stands on the one that
                    // actually supports -- the highest along gravity -- not
                    // the one nearest the (stale) foot. Measured on lv19
                    // t=21,746: the thin platform uid 15033 enters the x-range
                    // 0.047 px BELOW the lift uid 15031 the ship rides;
                    // nearest-gap hopped to it and ran 0.0506 low from there.
                    if (o->dcy != 0.0
                        && (!flyRide
                            || face * gsign > flyRideFace * gsign)) {
                        flyRide = true;
                        flyRideGap = gap;
                        flyRideFace = face;
                        flyRideDcy = (double)o->dcy;
                        flyRideUid = o->uid;
                    }
                }
            }
            groundedNow = sup;
        }
        // [2026-08-21 r88/r89] **A "carried vy" is not the resting slide.** The
        // convention written for the rising-floor catch (flyRide) (the note below:
        // only the vy==0 rest re-accumulates from 0) applies just as well to a
        // **hanging ride** (s.onSlope, sliding along the underside of a ceiling
        // ramp). The calibration rig ceilhold exposed both spots:
        //   ship held: on the tick the support scan re-raised groundedNow, the
        //     ladder re-accumulated from 0 (unit0 -3.376 -> -0.086)
        //   UFO after a jump: the UFO's act is an edge, so even while held it fell
        //     into the "rest short-circuit" from the next tick and vy became 0
        //     (unit7 -3.912 -> 0.000, GD keeps decaying at -3.760)
        // [2026-08-21 r96] **Narrowed to the hang (s.flip) only.** The rig
        // ceilhold's cells are all flip=1; there is no evidence about upright
        // rides. Applied to every ride, lv16's cold run swelled from 22 iterations
        // -> 56+ (census stayed green = the [[gd-census-green-cold-broken]] pattern).
        const bool ridingCarry =
            (flyRide || (s.onSlope && s.grounded && s.flip)) && s.vy != 0.0f;
        c.held = (uint8_t)input;
        // The UFO acts on the EDGE, the ship on the level. One press is one
        // flap and holding does not repeat it -- measured on lv12: pressed at
        // t=170 and held to 195, GD flapped once (vy := 6.871 at t=172, the
        // usual 2-tick input latency) and then decayed at the plain gravity
        // -0.129 for the whole hold. So a held button is "thrust" for a ship and
        // "nothing" for a UFO, and the grounded test below has to agree.
        const bool isUfo = (c.mode == 3);
        // SWING rides this branch too (see the note on kSwingG): airborne with a
        // TOGGLED gravity. Support / band / hazards / solids are the ship's.
        const bool isSwing = (c.mode == 7);
        // s.pFlap: a fresh edge on the same tick as a ship->UFO portal was eaten by
        // the old mode (thrust = the edge is not consumed). GD buffers it and emits
        // the flap on the next tick (lv19 t=13,892 portal -> 13,893 vy=+6.871). But
        // **only if still pressed on the next tick** -- lv14 t=14,193, pressed and
        // released within the same tick, does not fire in GD either (14,194
        // vy=1.619, plain decay).
        const bool act = (isUfo || isSwing)
            ? ((input && !s.action) || (isUfo && s.pFlap != 0 && input))
            : (input != 0 && !c.holdDead);   // the ship reads +0x985 (speed.hpp, the hold latch)
        if (isUfo && act) impulsedThisTick = IMPULSE();
        // ...but a PENDING SWING FLIP must not be swallowed by the grounded
        // short-circuit. The tap sets the pending bit and is then RELEASED, so
        // on the tick the flip is due `act` is 0 and this branch used to eat it
        // -- the model only left the surface on the NEXT press, one tick late
        // (lv22 t=3,630: GD is already airborne at vy=-1.000 while the model
        // was still grounded at 0).
        // A ship CARRIED by a rising floor is not the resting slide: its vy
        // holds the floor's own velocity (see the catch below), so a carried
        // state with vy != 0 goes through the airborne integration + catch
        // even without a press. The resting slide (vy == 0) keeps the hold.
        // FORCE BOX (id 2069) LIFTS a grounded swing off the floor: the seat
        // does not hold against a net upward push. Measured on lv22
        // t=3,479-3,488 (landed on the band floor y=105 inside the cy=105
        // carpet): GD's vy climbs 0 -> 0.13 -> ... -> 0.65 (+0.130/tick, two
        // boxes) and the y follows it up off the floor -- then the step drops
        // to +0.022/tick (= 0.108 - 0.086, ONE box) the tick after x passes
        // the carpet edge at 4,845+30, which is what pins the per-box k at
        // 0.108. The gate converts the world-up push into the player frame,
        // so a FLIPPED swing under a ceiling is pushed INTO its seat and
        // stays put (unmeasured, but the sign has nowhere else to go).
        // [2026-08-30] The gate compares the push against THE SAME gravity it
        // is scaled by, so it says exactly "the push beats gravity" -- which
        // under dvy = m_force x |g| / kForceGDiv reduces to m_force > 0.9582,
        // the same verdict in every mode and both sizes. It used to compare a
        // per-uid constant against the FULL-SIZE kSwingG. The COMPARISON is
        // left exactly as it was -- this change is the push's value and nothing
        // else -- so a mini swing is still judged on kSwingG. Same verdict on
        // the measured case (lv22's carpet: 2 boxes gave 0.216 > 0.086, and
        // 2.4 x 0.0900 = 0.216 gives the same).

        const bool swingLift =
            isSwing && !g_forceBoxes.empty()
            && forceBoxAcc(modX, modY, pHalf,
                              forceUnitFor(s.mode, useDx)) * gdSign > kSwingG;
        if (groundedNow && !act && !(isSwing && s.rHover) && !swingLift
            && !ridingCarry) {
            VYSET(c.vy) = 0;
            c.grounded = 1;
            // the ride: seat on the moved face (cube family's rule, same
            // ordering -- the carry happens in the collision pass)
            if (flyRide)
                YSET(c.y) = (float)(flyRideFace + gsign * pHalf);
            // [2026-08-21 r86] **A resting flyer also holds "this tick's half
            // gravity step"** (same shape as the cube's pinnedOnBlock). This
            // short-circuit moves neither vy nor y, so left alone the model's y
            // stays one step high on the tick it launches off the ramp's top end.
            // Measured, calibration rig ceilrel07: on the launch tick GD first drops
            // y by 0.019 (= 0.225 x the UFO's weak gravity 0.086) and then writes
            // the launch value. The ship side has the same shape, 0.020. Consumed by
            // releasePin (slope-exit launch, pad, orb). The swing has its own branch
            // so it is left alone.
            // The swing is the same (the rig ceilrel07's 3 swing units: the sink is
            // 0.0193 = 0.225 x kSwingG, same shape as ship/UFO).
            if (!pinnedOnBlock
                && (s.flip || (double)s.y > (floorY + pHalf) + 0.5)) {
                const bool thrFlipRest = s.dual ? true : (s.flip != 0);
                const double vpRest = qVy(
                    isSwing ? -kSwingG
                    : isUfo ? gdapprox::UfoModel::stepVy(
                                0.0, false, ufoParamsFor(useDx, c.mini, K),
                                thrFlipRest)
                            : gdapprox::ShipModel::stepVy(
                                0.0, false, shipParamsFor(useDx, c.mini, K),
                                thrFlipRest));
                pinnedOnBlock = true;
                prePinY = (float)((double)c.y + kYScale * vpRest * gsign);
                // the same statement as the cube's grounded branch: the update
                // phase's step happened, the seat is the collision pass undoing it
                yFree = prePinY;
            }
        } else if (isSwing) {
            // The toggle lands ONE TICK AFTER the press edge: on the edge tick
            // GD still steps with the old gravity (t=3701 vy=-6.424, one plain
            // gravity step past -6.338), and the flip+damp appear on the next
            // (t=3702 vy=-5.053 = -(-0.8*(-6.424) - 0.086)). A same-tick flip
            // reproduced the shape but ran 0.155 high on every tick after.
            // The pending bit rides rHover, which is robot-only and therefore
            // free in mode 7 -- and it MUST be in the state (two states that
            // differ only in the pending flip diverge next tick).
            c.grounded = 0;
            // (the take-off special case that skips the clamp is now the
            // ceiling half only -- see ceilTakeoff below)
            double vpS = groundedNow ? 0.0 : (double)s.vy * gsign;
            double gsS = gsign;
            // GD's velocity-limit exemption (State::boost) clears at the HEAD
            // of updateJump's flying branch, on the INCOMING gravity-frame vy,
            // before the press flip and the gravity step
            // (0x38c527..0x38c59e). The band is (-6.4, +8.0)/chi: the
            // fall-side edge is 6.4, NOT the clamp's 8, which is exactly what
            // lets a slope exit at 6.4..8 keep the flag alive while the fall
            // accelerates past the terminal (lv22 x=5,391). chi is keyed on
            // the same [player+0x9f0]!=1 test that switches the swing gravity
            // 0.4->0.6 (the model's kSwingG->kSwingGMini), i.e. mini; no mini
            // swing exists in the corpus, so the divisor rides the
            // disassembly alone.
            {
                const double bandChi = (c.mini != 0) ? 0.85 : 1.0;
                if (vpS > -6.4 / bandChi && vpS < 8.0 / bandChi) c.boost = 0;
            }
            if (s.rHover) {                    // apply the previous tick's edge now
                c.rHover = 0;
                c.flip = s.flip ? 0 : 1;
                gsS = c.flip ? -1.0 : 1.0;
                vpS = -kSwingFlipDamp * vpS;   // vp in the new frame (sign mapped too)
            }
            if (act) c.rHover = 1;             // takes effect on the next tick (measured)
            // RETRACTED (2026-08-18): "taking off from a surface gets a fixed
            // unit push (-1.000) and no gravity step".
            //
            // It was written from lv22 t=3,630 ("grounded swing at y=327.875,
            // vy=-1.000 exactly"). **That tick does not exist in the current
            // reference** -- lv22 t=3,630 is now an AIRBORNE swing at y=262.07
            // with vy=+1.063, so the constant's justification was a stale
            // worldline ([[gd-constant-justification-goes-stale]]).
            //
            // The current reference contradicts it directly. lv22 t=4,621
            // (swing resting on the flat floor at y=405, tap at 4,620):
            //   GD      vy=+0.086   y=405.019348 (= 405 + 0.225*0.086)
            //   -1.000  vy=+1.000   y=405        (frozen)
            // +0.086 is exactly the ordinary path: vpS is 0 for a resting
            // state, the damp multiplies it to 0, and one kSwingG step in the
            // NEW frame is all that is left. The "the damp leaves the player
            // stuck" worry the rule was built on is unfounded -- the gravity
            // step below is what unsticks it.
            //
            // Retracted only for the case that was actually measured: a swing
            // leaving a FLOOR (s.flip == 0). The stale note's case was the
            // mirror (leaving a CEILING) and there is no swing-on-a-ceiling
            // take-off anywhere in the current corpus to measure, so that half
            // keeps the old behaviour -- and it is load-bearing: dropping it
            // too takes reach_check's lv22 t=3,300 swing case from SOLVED to
            // PARTIAL. Measure it (a ceiling swing + a tap, injected) before
            // touching this half.
            const bool ceilTakeoff = s.rHover && groundedNow && s.flip;
            if (ceilTakeoff) {
                vpS = -1.0;                    // no gravity step on this tick
                VYSET(c.vy) = (float)(qVy(vpS) * gsS);
                YSET(c.y) = s.y;
                yFree = c.y;
            } else {
                // The TIME WARP scales the swing's step too. It was missing
                // here because this branch does its own integration: measured
                // on lv22 t=3,324 inside the 0.2x warp, GD steps vy by -0.017
                // and y by -0.089 where the model stepped -0.086 and -0.905
                // (5x and 10x). The terminal is a velocity, so it is NOT
                // scaled.
                vpS -= swingG(c.mini != 0) * tScale;
            }
            if (!ceilTakeoff) {
                // The cap is SYMMETRIC in the WORLD frame: |vy| <= 8, a hard
                // clamp, and y integrates with the CLAMPED value. Probed
                // directly (2026-08-17, lv22 free swing at t~4,300, up-accel
                // phase, no taps):
                //   - approach from below: 7.939 -> 8.000 exactly (7.939 +
                //     0.086 = 8.025 clamped), then dvy=0 for 27 ticks
                //   - inject vy=+11 -> next tick 8.000, y steps 1.8 (the
                //     clamped 8, not 11)
                //   - inject vy=-11 -> next tick -8.000, y steps -1.8, then
                //     the ordinary +0.086/tick decay
                // The one-sided version this replaces was generalized from a
                // dump statistic (solution_lv22r24: 49 ticks > +8.0001, up to
                // 11.636, zero below -8.0001). Those >8 ticks cannot be THIS
                // branch -- a state this integration touches snaps to 8 in one
                // tick -- so they were rings/dash states that bypass it, and
                // the 8.283 the uncapped model reached (32-record fixup family
                // in the 2026-08-17 all-green run, x=6,160 / 9,414) was the
                // cost of the missing + side.
                // [2026-08-25] ...and those bypass states now have a name: the
                // clamp is GATED on GD's velocity-limit exemption
                // (State::boost; disassembly at its declaration). All three
                // 2026-08-17 probes above were taken with the flag clear, so
                // they measured the clamp, not its gate.
                double vyW = qVy(vpS) * gsS;
                if (!c.boost) {
                    if (vyW < -kSwingTerm)      { vyW = -kSwingTerm; vpS = vyW * gsS; }
                    else if (vyW > kSwingTerm)  { vyW = kSwingTerm;  vpS = vyW * gsS; }
                }
                // FORCE BOX (id 2069): the swing rides the field too -- and the
                // push lands AFTER the terminal clamp. Measured on lv22 t=3,459
                // (free fall at the clamped -8 into the cy=105 carpet): the
                // first tick inside is -8 + 0.216 = -7.784 exactly (a
                // clamp-then-add; the single-stage clamp(vp+g+F) gives -7.870),
                // then a constant +0.130/tick = F - kSwingG. Same start-of-tick
                // position convention as every other force. The world frame is
                // the natural one here since the clamp above is already in it.
                if (!g_forceBoxes.empty()) {
                    const double fb =
                        forceBoxAcc(modX, modY, pHalf,
                                    forceUnitFor(s.mode, useDx));
                    if (fb != 0.0) { vyW = qVy(vyW + fb); vpS = vyW * gsS; }
                }
                VYSET(c.vy) = (float)vyW;
                YSET(c.y) = (float)((double)s.y + kYScale * (double)c.vy * tScale);
                yFree = c.y;
            }
        } else {
            c.grounded = 0;
            // A CARRIED grounded state (vy = the floor's velocity, see the
            // catch below) thrusts ON TOP of that velocity, not from rest:
            // GD t=21,814 shows 1.173 = 1.046 (carried) + 0.127 (one thrust
            // step). Only the resting slide (vy == 0) restarts from 0.
            // [2026-08-21 r88] The ladder during a ride is also a "carried vy"
            // (measurements at the declaration of ridingCarry).
            const double vp = (groundedNow && !ridingCarry)
                                  ? 0.0 : (double)s.vy * gsign;
            // GD's velocity-limit exemption (State::boost) clears at the HEAD
            // of updateJump's flying branch, on the INCOMING gravity-frame vy,
            // before the press handling, the acceleration and the clamp
            // (0x38c527-0x38c59e). The band is (-6.4, +8.0)/chi and the clear
            // runs BEFORE the per-mode dispatch, so it is the same test the
            // swing branch above already ran -- what was missing here is that
            // the ship and the UFO reach that dispatch too. NOTE the fall-side
            // edge is 6.4 and not the clamp's 8: a ramp launch at 6.4..8 keeps
            // the flag alive for as many ticks as the decay needs to come back
            // inside, which is the whole of lv16 8,913-8,919.
            // The raw s.vy is read, not `vp`: GD reads m_yVelocity, so a
            // CARRIED grounded body is judged on the velocity it carries
            // rather than on the 0 the resting branch substitutes.
            if (boostLatchMode(c.mode)) {
                const double bandChi = (c.mini != 0) ? 0.85 : 1.0;
                const double vpIn = (double)s.vy * gsign;
                if (vpIn > -6.4 / bandChi && vpIn < 8.0 / bandChi) c.boost = 0;
            }
            // While it is up, the terminal clamp is skipped outright
            // (0x38ca9f) -- for the UFO that is the whole of the latch's
            // effect, and for the SHIP the acceleration selector reads it too
            // (0x38c5be / 0x38c5d8; the reading is in ShipModel::stepVy).
            // A byte scan of the whole flying branch 0x38c4f0-0x38cb36 finds
            // exactly four references to [+0x952]: the clear at 0x38c59e, the
            // ship's two, and the clamp gate -- so the UFO's own block
            // (0x38c701-0x38c8df) and the swing's (0x38c8e4-) are
            // latch-independent in their acceleration.
            const bool boostNow = (c.boost != 0);
            // the 4th argument mirrors the accel-switch threshold; leaving it at
            // its default picked the wrong branch for an inverted ship, which is
            // how lv8 t=21137 got +0.069/tick where GD had +0.103
            // In a DUAL the threshold is the flipped one for BOTH bodies.
            // Injected on lv16's second dual (mini UFO, t=12,418, p1 upright):
            //   vy=+0.37..-0.69: -0.152/tick (strong)   single-player: weak
            //   vy=-1.5: 3 strong steps then 3 weak = crosses -1.9165 exactly
            //   vy=-2.2 / -3.0: -0.101/tick (weak)
            // -> p1's threshold is -1.9165 while dual, i.e. the flipped side,
            // and it snapped to strong on the very tick `dual` went 1.
            // The mirrored second body (flip2=1) already gets -S from its own
            // flip, which is what the measured p1+p2=const mirror requires --
            // so the rule that fits both is "dual => flipped threshold".
            const bool thrFlip = s.dual ? true : (s.flip != 0);
            // FORCE BOX (id 2069): applies to the ship/UFO under the same
            // convention (start-of-tick position, world->player via gsign).
            // Measurements at the declaration of kFF2069 (a ship passing through
            // has a constant dvy +0.056 = 0.125 - 0.069).
            // The flight modes' gravity is not one number: both switch between
            // a weak and a strong acceleration at accelSwitchVy, and the force
            // scales with whichever is acting. Reading it off the model that is
            // about to integrate is NOT how it is done: the ship's and UFO's
            // per-unit push is a measured constant (kForceUnitShip /
            // kForceUnitUfo), because their gravity switches mid-flight and
            // deriving the push from it reproduces neither lv22 entry. The two
            // notes at those constants say what was measured.
            const double fbAcc = g_forceBoxes.empty()
                ? 0.0 : forceBoxAcc(modX, modY, pHalf,
                                     forceUnitFor(s.mode, useDx)) * gdSign;
            double vpNew = qVy(
                (isUfo ? gdapprox::UfoModel::stepVy(
                            vp, act, ufoParamsFor(useDx, c.mini, K), thrFlip,
                            boostNow)
                       : gdapprox::ShipModel::stepVy(
                            vp, act, shipParamsFor(useDx, c.mini, K), thrFlip,
                            boostNow))
                + fbAcc);
            // A normal UFO flapping off a floor ramp leaves at kUfoRampFlap,
            // not at its plain flap -- see the constant for the rig and for why
            // mini is left wrong.
            //
            // THE GATE IS THE PREVIOUS TICK'S SEAT, and that matters. `onSlope`
            // is cleared at the top of every tick and re-established by the
            // slope block, so on the flap tick itself it is 0 even for a player
            // that has been riding for 24 ticks -- gating on it would fire
            // never. `s.onSlope` is the carried value, and it is also what
            // separates riding from flying past: of the 25 UFO flap edges in
            // the corpus whose x lies inside a slope's span, exactly ONE has
            // s.onSlope set (lv19 t=14,620, slopeT 24, entry vy 0.000). The
            // other 24 are arcs crossing over a ramp with entry vy 2.2..6.5,
            // and GD gives every one of them the plain flap -- they are correct
            // today and must not move. A geometric gate would have changed all
            // 25 and broken 24 of them.
            //
            // Force boxes are excluded rather than guessed: the rig had none,
            // so what GD does when a push and this assignment meet is unmeasured.
            if (isUfo && act && s.onSlope && !c.mini
                && fbAcc == 0.0)
                vpNew = kUfoRampFlap;
            VYSET(c.vy) = (float)(vpNew * gsign);
            YSET(c.y) = (float)((double)s.y + kYScale * (double)c.vy);
            yFree = c.y;
            // [2026-08-21 r86] **The flight modes also carry over "the half gravity
            // step of the tick they sat on a block".** The cube side held it in
            // pinnedOnBlock, but the flight branch had none, and on the tick it
            // launches off a ramp's top end only the model's y failed to move.
            // Measured on the calibration rig ceilrel07's 4 UFO runs: on the launch
            // tick GD first drops y by **0.019 = 0.225x0.086 (the UFO's weak
            // gravity)** and then sets vy to the launch value. The convention of
            // releasePin restoring prePinY can be used as is (same shape as the
            // cube).
            // Arming is read from **start-of-tick grounding** (s.grounded).
            // groundedNow is dropped by the support scan, so it was false on **the
            // very tick of the launch** (the tick the ramp's window closed), which
            // is exactly where it was needed most.
            if (s.grounded && !pinnedOnBlock
                && (s.flip || (double)s.y > (kGroundY + pHalf) + 0.5)) {
                pinnedOnBlock = true;
                prePinY = c.y;
            }
            // A RISING FLOOR CATCHES a ship that cannot outclimb it -- and the
            // catch imparts the floor's OWN velocity. Measured on lv19
            // t=21,806..21,820 (mini ship on the +0.2616/tick lift, taps at
            // 21,808/21,812, hold from 21,815; dump rows):
            //   - resting slide (no press yet): g=1, vy=0        (the hold)
            //   - press lands (t=21,810): vy = 1.047 = 0.2616/0.25 EXACTLY
            //     -- the floor's velocity in GD's internal dt=0.25 units, NOT
            //     the from-rest thrust (0.127, the corpus' 8-of-11 value).
            //     The 1.047/1.046 alternation is dcy's own float wobble.
            //   - press effect on a CARRIED state (t=21,814): 1.173 =
            //     1.046 + 0.127 -- thrust on top, catch keeps the LARGER vy
            //     (max toward the push direction), y still glued.
            //   - released: vy decays, falls back to floorVel on re-catch
            //     (21,816: 1.092 -> 1.046).
            //   - escape (21,818): the tick the thrust-move outruns the
            //     floor's rise, the foot ends above the face and there is no
            //     catch -- the ship leaves WITH its carried vy (1.3, 1.427,
            //     +0.127/tick from there).
            // So the catch condition is simply "after the move the foot is
            // at/below THIS tick's face", and vy := max(vy, floorVel) in the
            // gravity frame. The carried no-press ticks re-enter here through
            // the `s.vy == 0` gate on the hold above.
            if (groundedNow && flyRide) {
                const double newFoot = (double)c.y - gsign * pHalf;
                const bool caught = (newFoot - flyRideFace) * gsign <= 0.0;
                const double floorVelD = flyRideDcy / 0.25;
                if (g_dcyDbg)
                    std::printf("dcystamp site=flyride t=%lld uid=%d dcy=%.17g "
                                "stamp=%.17g vy=%.9f took=%d caught=%d "
                                "foot=%.9f face=%.9f\n",
                                (long long)K.t, flyRideUid, flyRideDcy,
                                floorVelD, (double)c.vy,
                                (caught && (double)c.vy * gsign
                                 < floorVelD * gsign) ? 1 : 0,
                                caught ? 1 : 0, newFoot, flyRideFace);
                if (caught) {
                    YSET(c.y) = (float)(flyRideFace + gsign * pHalf);
                    c.grounded = 1;
                    const double floorVel = flyRideDcy / 0.25;
                    if ((double)c.vy * gsign < floorVel * gsign)
                        VYSET(c.vy) = (float)floorVel;
                }
            }
        }
        // The ground plane blocks an INVERTED ship too. The old comment here
        // said "an inverted one falls toward the ceiling instead", which is true
        // of falling but not of flying down: measured on lv11 t=9793, an
        // inverted mini ship descending at vy = -3.424 is stopped at y = 99.000
        // (ground 90 + mini half 9) and held there for two ticks before its own
        // gravity carries it back up. The model let it sink out of the world and
        // the whole tail of the level was solved for a player GD had killed.
        // The flying band's floor, where the section has one, replaces the
        // world's ground line entirely: on lv12 the UFO is put back at y=195
        // (floor 180) with nothing underneath, and 90 never comes into it.
        // (floorY is declared at the top of this branch)
        // `c.frame == 0` on BOTH band clamps and the carry, for the same reason as
        // fly/out-of-play below: the band is a world-Y quantity and in a turned
        // frame `c.y` is derived from world x, so the comparison is meaningless.
        // Ungated, the floor clamp SEATED a freshly rotated ship at those nonsense
        // coordinates and held it there -- measured lv22 t=16,429+: GD un-grounds
        // on the rotation tick (onGround 1 -> 0) and falls to its death at
        // t=16,437 on the wall at (20145,645), while the model kept grounded=1,
        // pinned y, and sailed on immortal. Every [SOLVED] tail the game refuted
        // at that wall was this: the DP can never prefer the robot branch while
        // the ship branch cannot die.
        if (c.frame == 0
            && !c.grounded && c.y <= floorY + pHalf && c.vy <= 0) {
            YSET(c.y) = (float)(floorY + pHalf);
            VYSET(c.vy) = 0; CLAMP0("fly/bandfloor");
            if (!c.flip) c.grounded = 1;
        } else if (c.frame == 0 && btFlyOn && !c.flip && s.grounded
                   && c.y < floorY + pHalf) {
            // `s.grounded`: it carries a ship IT HAD ALREADY SEATED, which is
            // exactly what the measurement below covers (t=16,409 is the catch,
            // by the landing clamp above; 16,410-16,427 is the carry). Without
            // that gate the branch also fires on any flying state that happens
            // to be under the recorded floor -- and once the in-process loop
            // began passing --bandtrack (81f2a09) that became every ship in the
            // level, pinned and grounded against a floor the camera moves.
            //
            // Bisected 2026-08-25 on lv22's in-process cold run, with the
            // earlier 2900 regression held reverted at every point:
            //   8107314 (the commit before)  x=9,890, climbing
            //   81f2a09 (this branch added)  x=3,633, stuck
            // and the four commits between 0a1e8b6 and it are all good. That is
            // the second half of the 84% -> 41% drop.
            // A RISING recorded floor CARRIES the ship it seated. The landing above
            // is gated on vy <= 0, so one thrust tick after touchdown the clamp went
            // dead and the model hovered in place while the floor rose through it.
            // Measured (lv22 t=16,410-16,427, the shaft entrance, camera panning up
            // at +1.44/tick): GD keeps y = seat on every single tick while vy just
            // carries the taps' own wobble (0..0.46) -- so the seat is written and
            // vy is left alone, which is also how it differs from the object-floor
            // catch (that one stamps the face's speed into vy; the band floor
            // demonstrably does not, or vy would read 6.4). Unreachable over a
            // static floor: the landing clamp never lets y get below the seat in
            // the first place, so only a floor that moved up can put a ship here.
            // The INVERTED mirror (a falling recorded ceiling) is unmeasured and
            // left alone.
            YSET(c.y) = (float)(floorY + pHalf);
            c.grounded = 1; CLAMP0("fly/bandcarry");
        }
        // GD clamps the CENTRE to ceil - 15*vsize (checkCollisions, 0x213c38).
        // The WAVE never reaches this line -- it has its own branch and its own
        // kWaveClamp (10.0, already correct); this one is ship / UFO / ball,
        // whose half IS 15*vsize, so pHalf is right for all of them.
        // ...and the band's HEIGHT is 270 / camScale, not a per-mode constant
        // (see ZoomTrig: the product is 270.000 exactly in every mode GD was
        // sampled in). The stored bandCeil is the camScale == 1 value, so it is
        // only rewritten where the level actually zooms -- lv1-21 own no id 1913
        // and keep the old number bit-for-bit.
        double bandCeilNow = btFlyOn ? btFlyC : (double)s.bandCeil;
        if (!btFlyOn && !g_zoomTrigs.empty() && bandCeilNow < 1e8) {
            const double cs = camScaleAt(x, useDx);
            if (cs > 0.0) {
                // The band derived from the zoom sometimes disagrees with GD's
                // measurement. Near x=18,000 on lv22 GD's band is [405.7, 905.7]
                // = **500**, yet the model gave 255 and the ship topped out at
                // y=660.67. The step's top is 674, so this section **had become
                // impassable in principle inside the model** (cannot be cleared
                // even holding). The coefficient is calibrated **once only** from
                // the height of the band GD was asked for at the anchor
                // (--startband). The zoom's relative changes still apply as is.
                // ...and the numerator is the height the PORTAL wrote, not a
                // constant. GD's is `[+0x2ec]`, set by animateInDualGroundNew
                // out of getGroundHeightForMode -- 300 for ship/UFO/wave/swing,
                // 240 for ball, 270 otherwise -- which is exactly what
                // bandCeil - bandFloor already holds. The old 270 was right
                // only where that height happened to be 270, and on lv22's
                // ship section (H = 300, zoom 0.6) it was 50 px short of GD's
                // 500. This needs the Free Mode gate to be correct: without it
                // the model applies portals GD ignores and the stored height
                // is not GD's -- see g_freeModeCol for the ball case that
                // proves the two cannot be separated.
                double numer =
                    (g_freeModeCol && (double)s.bandCeil > (double)s.bandFloor
                     && (double)s.bandCeil < 1e8)
                        ? (double)s.bandCeil - (double)s.bandFloor
                        : kBandBase;
                // ...and in BRANCH A the band is not that height at all: it
                // is the two ground sprites, which carry the animation, so it
                // runs between the mode's H and the screen itself.
                //   numer = 322 - (322 - H) * p
                // Measured against GD's own sprite column over lv22's 21,140
                // ticks: with p from bandAnim this is exact through the wave
                // section (322.00 against 322.00), where the height alone is
                // 22 short -- 36.7 px of ceiling once the 0.6 zoom is applied.
                // Branch A is `staticY && !fromMode`; every level without a
                // Static Camera stays in branch B and keeps the line above.
                if ((c.bandBranch & 3) == 1)
                    numer = kBandRetracted
                          - (kBandRetracted - numer) * bandProgress(c.bandAnim);
                // The calibration below exists only to absorb the wrong
                // constant (it measures the band GD was asked for at the
                // anchor and folds the ratio in), so with the real numerator
                // in hand it would correct a correct number twice.
                if (!g_freeModeCol && g_bandK <= 0.0 && startBandUsable())
                    g_bandK = (g_startBandCeil - g_startBandFloor) * cs
                              / kBandBase;
                const double k = (g_bandK > 0.0) ? g_bandK : 1.0;
                bandCeilNow = (double)s.bandFloor + numer * k / cs;
            }
        }
        const double yMax = bandCeilNow - pHalf;
        if (g_bandDbg && c.mode == 4 && (double)c.y > yMax - 6.0)
            std::printf("banddbg t=%lld x=%.1f y=%.2f band=[%.0f,%.0f] yMax=%.1f\n",
                        (long long)K.t, x, (double)c.y, (double)s.bandFloor,
                        (double)s.bandCeil, yMax);
        // ...and the SWING is not clamped by it at all, the same way the wave
        // has its own branch. Measured on lv22 t=4,497: GD's band is
        // [90, 428.444] so `ceil - 15` is 413.44, and GD's swing sits at
        // 416.769 and keeps climbing with no clamp of any kind. With the clamp
        // on, the model pinned it and lost 5 px within four ticks.
        if (c.frame == 0 && c.mode != 7 && (double)c.y > yMax) {
            YSET(c.y) = (float)yMax; VYSET(c.vy) = 0; CLAMP0("fly/bandceil");
        }
        // In a rotated frame `c.y` is the frame's vertical (= derived from world x),
        // while floorY and g_yBound are world-y quantities, so this comparison is
        // meaningless. lv22 t=14,307 (frame 3, ship, world x=15,465) was dying
        // instantly on this: GD flies on to 14,632, yet only the model dropped 325
        // ticks short. "Left the level" on the rotated side is handled by
        // out-of-play (g_yBoundTurned). Same family as escapee-prune -- a predicate
        // becomes a lie the moment it crosses coordinate systems.
        if (c.frame == 0
            && (c.y < (floorY + pHalf) - 40 || c.y > g_yBound))
            DIE("fly/out-of-play", nullptr);
        // The flying body's hazard test for one object -- a lambda for the same reason the
        // cube's is one (--flyhazaftersolid below): the statements are the ones that ran
        // inline, unchanged.
        auto sweepFlyHazard = [&](const Obj* o) {
                if (outOfSweepReach(o, xPrev, (double)s.y, x, (double)c.y, pHalf))
                    return;
                for (int si = 0; si <= kSubSteps && !dead; ++si) {
                    const double f = si / (double)kSubSteps;
                    if (g_hazEndpoint && si < kSubSteps) continue;   // --hazendpoint: endpoint only
                    const double sx = xPrev + (x - xPrev) * f;
                    const double sy = (double)s.y + ((double)c.y - (double)s.y) * f;
                    if (hazardHit(o, sx, sy, pHalf, kHazMargin,
                                  sawMarginFor(s.mode), s.mode, c.mini)
                        && (!g_obbAll || !o->obbOk
                            || obbOverlap(*o, sx, sy, pHalf, (double)s.rot)))
                        DIE("fly/hazard", o);
                }
        };
        std::vector<const Obj*> solidOrd;   // --solidorder
        bool ceilPushedThisTick = false;    // --flyreland
        for (const Obj* const& o : solidWalk(K, solidOrd)) {
            if (dead) break;
            noteSolidVisit(K, o, x, (double)c.y, pHalf);   // --solidorddbg
            if (o->type != 0) {
                // --flyhazaftersolid leaves it to the second walk below, after the solids
                // have placed the body. GD's checkCollisions runs its hazard stage after the
                // solid loop for EVERY mode, not only the cube (0x2137f0; the rect is re-read
                // at 0x214752) -- the cube side of that is --hazaftersolid, default since
                // ab0bdf7, and this is the same change on the flying branch.
                if (!g_flyHazAfterSolid)
                    sweepFlyHazard(o);
                continue;
            }
            // face = the surface the ship rests ON, head = the one it bumps
            // into, both in the PLAYER frame so a flipped ship swaps them.
            // FIRST ATTEMPT, REVERTED: "lands while its centre is still above
            // the surface" (dropping the tolerance entirely), inferred from a
            // single landing at penetration 3.019 and a single death at 38.293.
            // It made things worse -- lv5 went from cleared to stuck at
            // x=16,166 -- because the model then landed where GD does not.
            // One data point does not pin a rule; the sweep behind
            // kShipLandTol does (see its comment).
            const double face = c.flip ? (o->cy - o->hh) : (o->cy + o->hh);
            const double head = c.flip ? (o->cy + o->hh) : (o->cy - o->hh);
            const double vpNow = (double)c.vy * gsign;
            const double prevFootP = ((double)s.y - gsign * pHalf - face) * gsign;
            const double newFootP = ((double)c.y - gsign * pHalf - face) * gsign;
            const double prevHeadP = ((double)s.y + gsign * pHalf - head) * gsign;
            const double newHeadP = ((double)c.y + gsign * pHalf - head) * gsign;
            const bool xOver = std::fabs(x - o->cx) <= o->hw + pHalf;
            // GD also resolves an OVERLAP the ship did not fly into, but only
            // once it is deep enough horizontally. Read straight off the hooked
            // collidedWithObject return (cfg `hitboxtrace=1`), which reports
            // false for every tick the rects overlap shallowly and true on the
            // tick it snaps. Both 0->1 transitions in the lv11 replay:
            //   mini   (half 9)  last false at xpen 14.670, true at 15.970
            //   normal (half 15) last false at xpen 25.930, true at 27.230
            // so the gate is xpen > 1.75 * half: 15.75 and 26.25 both land
            // inside their bracket. The ratio xpen/ypen does NOT work (the two
            // brackets are 3.01..3.30 and 7.49..8.00, which do not intersect).
            // A first attempt without this depth gate broke lv10 -- the ship got
            // pinned to ceilings it was merely passing under.
            const double xPen = (o->hw + pHalf) - std::fabs(x - o->cx);
            const bool deepIn = xPen > kSolidResolveX * pHalf;
            // does the SURFACE climb away from the head faster than the head
            // climbs into it? (see the ceiling-ride branch below)
            const bool overtaking = ((double)o->dcy * gsign) > vpNow * kYScale;
            // [2026-08-19] **While riding a ramp, landing is strict.** The flight
            // version of the cube side's `landTol = c.onSlope ? 0.001 : kLandTol`
            // (the "While riding a slope the ordinary landing test must be strict"
            // above). The flight branch lacked this gate, and the 6.0 reach-back
            // let a neighbouring plate steal the ramp ride.
            // Measured lv18 t=3,008 (mini ship, hang-riding ceiling ramp uid1807):
            // against the neighbouring solid uid1814 (box x[4050,4065] y[420,435])
            // at prevFootP -5.826 (just inside the -6.0 tolerance), only the model
            // landed on the underside 420 (y 411, vy 0). GD's hitboxtrace hbox line
            // says **hit=0** -- it does not grab even at 4.2px penetration (xPen is
            // 1.06). That false landing dropped the ride for 1 tick, uphillExit's
            // -2.762 came out on the next tick, and it became the census family
            // clamp:fly/land/uid1814. The flight branch runs before the slope loop
            // (below), so the ride test reads the previous tick's `s.onSlope`.
            // **Rejected: "deepIn for landings that did not cross"** (same day): as
            // a general rule it regressed lv13 19,383->18,907 and lv14
            // 20,000->19,597, families 29->30 (+4 in the air group). GD does grab
            // a shallow reach-back when not riding.
            // [2026-08-21 r53] **Penetrating a moved actual object pushes out to the
            // face.** The landing gate (below) only looks at "came down" or "the
            // face overtook", so a player **already penetrating** while rising
            // passes straight through. GD returns the foot to the face even while
            // rising, as long as the centre is above the face (no grounding, vy
            // untouched). Measured lv20 t=21,452 (UFO, sp1.1, moving solid uid18338
            // (30x30, rising +0.15 every tick, top 193.425)) -- the MOD's `hbox:`
            // line names the resolved amount directly:
            //   ppre=(32070.73,**191.03**,30,30) -> player=(32070.73,**193.43**,30,30)
            //   = the foot pushed up 2.40px (the x overlap is only 0.73px)
            //   GD stays onGround=0 and leaves vy at 6.871
            // The model passed through, left census `m3/mini0/g0/gdg0/sp1.1/air`
            // edy +2.399, and from then on ran a parallel -2.399 to the end.
            // Limited to **moved actual objects only** (o->dcy != 0): penetration
            // of static objects is measured by the existing landing / head bonk /
            // side kill, and those are left alone.
            // All three gates come from measurement: **the face is rising toward
            // the player** (dcy*gsign > 0), **already penetrating at the start of
            // the tick** (prevFootP < 0 = a resolution, not a new landing), **the
            // centre is above the face**. Loosening these (dcy != 0 alone, or not
            // looking at prevFootP) raises families 19->22 (lv19 regresses 3
            // sections, lv21 1 section; new are ship 2 + UFO 2).
            // [2026-09-06] **The catch is a REACH-BACK, and it grows with the
            // face's own speed.** The gates above are the geometry; GD also has
            // a depth limit, and this branch had none -- it seated at any
            // penetration. In PlayerObject::collidedWithObjectInternal the
            // top-face block is entered only if
            //     foot + tol >= objMaxY  ||  footPrev + tol >= objMaxY
            //                                        (0x39249d / 0x3924a4)
            //     tol = sign * (flight ? 6.0f : 10.0f)     (0x391bc1 / 0x391c48)
            //         + sign * m_slopeHalfHeight  if m_wasOnSlope     (0x391c6d)
            //         + sign * |objPos.y - objLastPos.y| / dt
            //                     if the object moved TOWARD the player
            //                                        (0x391db5-0x391dfb)
            // with foot the POST-INTEGRATION, PRE-RESOLUTION rect bottom (= this
            // branch's newFootP measured from the face) and dt = 0.25 frames per
            // physics step (GJBaseGameLayer::update 0x237850 hands
            // checkCollisions (frameSeconds*60)/nSteps). This is the flight loop,
            // so the base is kShipLandTol = 6.0, and the mover term is the same
            // `dcy / 0.25` the seat's velocity already uses below.
            // **Nothing scales with the vehicle size** (0x391a70-0x393c21 reads
            // m_vehicleSize zero times); the mini enters only through pHalf = 9.
            //
            // Witness -- lv20, a mini UFO rising inside solid uid 6225 whose top
            // climbs 0.25 px/tick (the model's dcy 0.2562 -> tol 7.025):
            //   dump t   objMaxY   free foot   penetration   GD
            //    6,553   323.700    315.926      7.774       no pop  <- the defect
            //    6,554   323.950    316.738      7.212       no pop
            //    6,555   324.200    317.520      6.680       pop -> y = 333.200
            // The three ticks bracket the constant to [6.680, 7.212) and 7.025
            // is inside it; a bare 6.0 fires on none of them and kLandTol = 10.0
            // on all three. The model used to seat on the FIRST of them and ran
            // 8 px above GD from there to its death. The other corpus firing,
            // lv19 t=21,572 (uid 15031, penetration 0.545, dcy 0.261), is deep
            // inside the reach and is untouched.
            // Measured 2026-09-06.
            //
            // NOT modelled, each one a leaf:
            //  * the `m_wasOnSlope -> + m_slopeHalfHeight` term. It cannot reach
            //    THIS branch: the seat at 0x392546 is behind `!m_wasOnSlope`
            //    (0x392508-0x392519), so a player that was on a ramp is refused
            //    whatever the tol. The model has s.onSlope but no ramp half
            //    height, and the widened tol would only matter for the OTHER
            //    consumers of the top-face block, which are not this rule.
            //  * the |dcy/dt| <= 5.0 cliff (0x391dd7, i.e. a face climbing faster
            //    than 1.25 px/tick), which hands the contact to the ordinary
            //    landing instead. Unwitnessed: the corpus's two firings are at
            //    1.02 and 1.04.
            //  * the half-step (GJBaseGameLayer::update l.385 halves dt on a tick
            //    split by a button), which would double the mover term. Neither
            //    witness tick has a press.
            //  * the cube/ball/robot/spider side is untouched. Its mover contact
            //    is the ride support test near the top of this function
            //    (kSupportTol + |dcy|), a different rule; GD's base there is
            //    10.0, not 6.0.
            const bool mpushGeom = o->dcy * gsign > 0.0 && !c.grounded && xOver
                && prevFootP < 0.0
                && ((double)c.y - face) * gsign > 0.0 && newFootP < 0.0;
            const double mpushTol =
                kShipLandTol + std::fabs((double)o->dcy) / 0.25;
            // GD's `foot + tol >= objMaxY || footPrev + tol >= objMaxY`, in the
            // player frame where a foot below the face reads negative. For a
            // RISING player the current foot is the higher of the two, so the
            // previous-foot arm is slack here; it is kept because it is GD's,
            // and it is what catches a falling player one tick early.
            const bool mpushReach =
                newFootP >= -mpushTol || prevFootP >= -mpushTol;
            if (g_slopeDbg && mpushGeom && !mpushReach)
                std::printf("mpush-out-of-reach t=%lld uid=%d face=%.3f "
                            "dcy=%.4f tol=%.3f prevFootP=%.3f newFootP=%.3f\n",
                            (long long)K.t, o->uid, face, o->dcy, mpushTol,
                            prevFootP, newFootP);
            if (mpushGeom && mpushReach) {
                if (g_slopeDbg)
                    std::printf("mpush t=%lld uid=%d ocy=%.3f ohh=%.3f face=%.3f "
                                "dcy=%.4f pHalf=%.3f y %.3f->%.3f\n",
                                (long long)K.t, o->uid, o->cy, o->hh, face, o->dcy,
                                pHalf, (double)c.y, face + gsign * pHalf);
                YSET(c.y) = (float)(face + gsign * pHalf);
                // [2026-08-21 r59] **The push-out also carries the face's velocity**
                // (same convention as the ceiling pin's `dcy/0.25`, but max).
                // Measured lv20 t=21,718..21,722 (UFO, moving solid uid18453 rising
                // ~1.0 px every tick):
                //   t      GD vy   model vy   that tick's dcy   dcy/0.25
                //   21719  3.945    2.356        0.9862           3.9448
                //   21720  3.985    2.227        0.9963           3.9852
                //   21721  4.026    2.098        1.0064           4.0256
                //   21722  4.066    1.969        1.0165           4.0660
                // y matches exactly on all 4 ticks (both stuck to the top face), and
                // **only vy** becomes the face's velocity itself in GD.
                // **max, not assignment**: at t=21,453 in the same branch (uid18338,
                // dcy 0.151 -> 0.604) GD leaves vy 6.742 alone. A fast player keeps
                // its own velocity even when pushed out.
                const double surfVp = (double)o->dcy * gsign / 0.25;
                // --mpushsign [2026-09-19]: GD picks the arm on the SIGN of the
                // updated vy (comisd xmm11=0, xmm7=vy at 0x392508): vy > 0, not
                // m_wasOnSlope (0x9b1) and |c6| <= 5.0 (0x391dd7) take the seat
                // at 0x392536, which restores vy and then maxsd's it with c6
                // (0x3926b7); anything else takes 0x393821, where hitGround
                // leaves vy = 0 and c6 is written but never applied. lv19
                // t=21,556 (ship falling at -1.432 onto uid15031, face +0.2617)
                // is 0 in GD and 1.047 in the old max; 21,557 (pressed, +0.127)
                // is the max arm, 1.047. The |c6| > 5 arm also launches the
                // player one tick later from +0x638 in postCollision
                // (0x38eb5c) -- NOT modelled, it needs last tick's c6 in State.
                // GD writes c6 := dcy/dt on either arm (0x39269a / 0x393b0b). (The
                // unconditional max above was the --no-mpushsign arm, gone since the
                // flag clean-up.)
                c6Now = (double)o->dcy / 0.25;
                const double vr = (double)c.vy * gsign;
                const bool seatArm = vr > 0.0 && !s.onSlope
                    && std::fabs(surfVp) <= 5.0;
                VYSET(c.vy) = (float)(seatArm ? std::max(vr, surfVp) * gsign
                                              : 0.0);
                CLAMP0O("fly/mpush", o);
                continue;
            }
            // [2026-08-31 REJECTED, kept as a warning] **"A moving surface
            // reaches further, by its own speed."**
            // collidedWithObjectInternal (base+0x391a70) really does build
            //   dVar45 = sign * (10.0, or 6.0 for the four flight flags,
            //                    or 15.0 when param_1[0x15e] > 0)
            //   ...and then, only when the object moved this frame,
            //   local_190 = (edge now - edge before) / dt
            //   dVar45   += sign * ABS(local_190)
            // and dt = 0.25 is pinned by lv20 t=19,365 (dcy 1.961 against GD's
            // own vy 7.845 = 0.25000). The mechanism is not in doubt.
            // WHAT WAS WRONG WAS THE PLACE IT WAS MAPPED TO. dVar45 offsets the
            // edges GD then uses to pick WHICH SIDE the contact is on
            // (`dVar37 = playerY - h/2*sign + dVar45`, compared against the
            // object rect's MinY/MaxY to set CVar29 = ground vs ceiling). It is
            // not this file's reach-back tolerance, which answers a different
            // question -- "was the foot within tol ABOVE the face last tick, so
            // treat it as a landing". Adding it here let the model land from
            // 6.0 + 1.961/0.25 = 14 px away from a fast mover, which GD does
            // not do. Measured: lv20 alone went 37 -> 105+ iterations and 61 ->
            // 336 fixups, still climbing, grinding at x=25,760. Reverted.
            // Both static harnesses said "identical on all 22 levels" for it,
            // which is worth remembering: neither can reach a moving-surface
            // contact, so on this family they have no detection power at all.
            const double shipLandTol = s.onSlope ? 0.001 : kShipLandTol;
            // THE LANDING IS DECIDED IN THIS TICK'S GRAVITY FRAME, NOT THE ONE
            // THE TICK STARTED IN. `gsign` is `s.flip` (step.hpp's decl), but a
            // swing's tap has already flipped `c.flip` by the time this runs --
            // the rHover block above says so in its own comment, "apply the
            // previous tick's edge now", and it keeps a local `gsS` for exactly
            // this reason. GD orders a substep buttons -> player update ->
            // checkCollisions (survey A5), so on a tap tick the contact is
            // resolved in the NEW frame.
            //
            // lv22 t=4,592 is the disagreement. GD lands on the block at
            // y=390: it clamps to 405.000 = 390 + 15, zeroes vy through
            // hitGround, and holds through the taps at 4,594 and 4,595. The
            // model, still reasoning as flipped, takes its "foot" to be the
            // HEAD at 405.403 + 15 = 420.403 -- 30 px from the face -- so
            // prevFootP reads -30.403, the tolerance rejects it, and it lands a
            // tick late at 4,593, by which time the same tap has become a
            // launch to vy = +2.000. It ends 12.8 px out by t=4,632.
            //
            // Counted before landing (worktree swingland's counting arm, which
            // evaluated the gate both ways on all 22 replays): the two frames
            // disagree on exactly ONE tick in the whole corpus, this one, and
            // `face` is already 390 there -- the frame changes the foot and the
            // velocity, not which face was chosen. Only a swing's tap flips
            // gravity mid-tick; a ship, UFO or wave flips from a portal or a
            // pad, which is a different path, and lv22 is the only level with a
            // swing.
            const double gsL = c.flip ? -1.0 : 1.0;
            // The same veto as the cube/ball path (see the site by `landTol`).
            // It has to be repeated here because flight resolves solids in its
            // OWN loop: with the call only on the other one, the veto fired on
            // the three `solid/land` ticks of the corpus and on none of the five
            // `fly/land` ones -- including lv16 t=8,696, the only row where GD
            // and the model actually disagree in y. Same LEAF on the face as
            // there: gravity stands in for GD's "which side did the contact
            // enter from".
            // --ceilveto [2026-09-19]: the veto has a FACE, and this call asks
            // the foot's only. GD's adjacency veto for the underside (0x392a9b)
            // is evaluated on the head's face, so a ceiling ride against a
            // solid that abuts a ceiling ramp is vetoed there while the foot's
            // question says nothing. lv16 t=19,104: a mini ship's head under
            // block uid9664 beside ceiling ramp uid9662 -- GD leaves y free
            // (921.6734) and seats on the ramp's extended line next tick; the
            // model's ceilride pinned it at 921.000. With the flag each branch
            // reads the veto of its own face.
            const bool vetoFootL = vetoOf(K, o, x, (double)c.y,
                                          pHalf, pHalf, gsL > 0, xPrev,
                                          (double)s.y, c.slopeUidNow);
            const bool vetoHeadL =
                vetoOf(K, o, x, (double)c.y, pHalf, pHalf,
                       gsL < 0, xPrev, (double)s.y, c.slopeUidNow);
            if (vetoFootL && vetoHeadL)
                continue;
            const double prevFootL = ((double)s.y - gsL * pHalf - face) * gsL;
            const double newFootL = ((double)c.y - gsL * pHalf - face) * gsL;
            const double vpL = (double)c.vy * gsL;
            // --dyndbg <uid>: the flight landing gate, printed whether or not it
            // fires. The cube/ball loop has had `land?` for a while; this side
            // had nothing, so a seat taken here could not be attributed to a
            // site at all (lv20 t=6,553, a mini UFO onto the rising solid 6225).
            if (g_dynDbg >= 0 && o->uid == g_dynDbg)
                std::printf("flyland? t=%lld uid=%d pHalf=%.2f face=%.3f "
                            "gsL=%.0f grounded=%d vpL=%.3f over=%d xOver=%d "
                            "prevFoot=%.3f (tol %.2f) newFoot=%.3f -> %s\n",
                            (long long)K.t, o->uid, pHalf, face, gsL,
                            (int)c.grounded, vpL, (int)overtaking, (int)xOver,
                            prevFootL, shipLandTol, newFootL,
                            (!c.grounded && (vpL <= 0 || overtaking) && xOver
                             && prevFootL >= -shipLandTol && newFootL <= 0)
                                ? "LAND" : "no");
            // --flyreland (speed.hpp): after a ceiling pushed the player down this tick, being
            // grounded already does not stop a floor from landing it again
            if ((!c.grounded || ceilPushedThisTick)
                && (vpL <= 0 || overtaking) && xOver && !vetoFootL
                && prevFootL >= -shipLandTol && newFootL <= 0) {
                // Used by the flight version of item 14 (seatFromPreLand). lv20
                // t=21,983: on the UFO's landing tick, onto the ramp seat 222.90
                // rather than the plate 222.35.
                if (!landedThisTick) preLandY = c.y;
                landedThisTick = true;
                YSET(c.y) = (float)(face + gsL * pHalf);
                if (vpL <= 0) {
                    VYSET(c.vy) = 0; CLAMP0O("fly/land", o);
                } else {
                    // A rising floor RE-CATCHING a climbing ship (overtaking:
                    // the face gains on the foot) is not a landing -- it
                    // imparts the floor's own velocity instead of zeroing.
                    // Measured on lv19 t=21,816: the tap's vy decays 1.173 ->
                    // 1.092 -> and the catch puts it back to 1.046
                    // (= dcy/0.25), y glued to the lift again. See the
                    // carried-state catch in the flight integration above.
                    const double fv = (double)o->dcy / 0.25;
                    if (g_dcyDbg)
                        std::printf("dcystamp site=floorcatch t=%lld uid=%d "
                                    "dcy=%.17g stamp=%.17g vy=%.9f took=%d\n",
                                    (long long)K.t, o->uid, o->dcy, fv,
                                    (double)c.vy,
                                    (double)c.vy * gsL < fv * gsL ? 1 : 0);
                    if ((double)c.vy * gsL < fv * gsL)
                        VYSET(c.vy) = (float)fv;
                }
                c.grounded = 1;
            // (A one-way plate's underside is a flying body's ceiling like any other solid's:
            // speed.hpp, the note that was --onewayceil's. The transparency branch that
            // stood here is gone with the flag.)
            // [2026-08-31] **A RISING CEILING STILL CATCHES A RISING SHIP.**
            // `!overtaking` used to lead this gate, under the heading "a rising
            // platform that overtakes the ship is not a ceiling": a head
            // crossing an underside is only a contact if the two are CLOSING,
            // so a surface climbing faster than the player was said to pass
            // through it. For a player that is itself rising, GD does not do
            // that -- it pins, however fast the surface is climbing.
            //
            // The old rule rested on ONE site (lv20 2026-08-09,
            // `clamp:fly/ceilride/uid4627`): a 30x30 solid rising ~2.05 px/tick,
            // a mini ship climbing 1.64, GD 6.20 px above the model's pin and
            // still rising. lv20 t=19,365 is the same shape, MORE extreme in
            // that very variable, and GD pins:
            //   uid16320 30x30, rising 1.961 px/tick, cy 371.239
            //   full ship climbing 1.140 * 0.225 = 0.257 px/tick (ratio 7.6x)
            //   GD y = (371.239 - 15) - 15 = 341.2394 exactly, and
            //   GD vy = 7.845 = dcy / 0.25, then rides for 12 ticks
            // The x overlap is 0.133 px, the shallowest contact there is, and GD
            // still resolves it.
            //
            // Swept over the run's own recordings rather than argued: every tick
            // of every attempt where a flight-mode player's box overlapped a
            // recorded MOVING solid in x and its free-flight head would have
            // ended inside the underside -- 37 of them, 17 with `overtaking`
            // true -- GD pinned, and there is no tick in the level where it did
            // not. uid4627 is not reachable in the current corpus (no attempt
            // puts that ship's head inside that block while the boxes overlap in
            // x), and a single unreproducible sample is the shape of a mis-phased
            // recording rather than of a rule.
            //
            // WHAT THE FLAG WAS REALLY DOING, and why it stays below. A STATIC
            // object has dcy = 0, so `!overtaking` reads `vpNow >= 0` -- the flag
            // was also, silently, the "no ceiling ride while DESCENDING" gate for
            // every static ceiling in the corpus, and the `prevHeadP > 0 &&
            // deepIn` arm next to it was dead for them (with vpNow < 0 the flag
            // itself was already false). Dropping it outright costs three levels
            // in the offline fidelity table -- lv3 (clean -> diverges at t=9,991,
            // dy -4.08), lv14 (t=13,363 -> 6,124, and the model then dies) and
            // lv19 (t=5,465 -> 5,071, dies). lv3 and lv14 report **0 moving
            // objects**, so for them this can only be the descending-static case;
            // lv19 has 847 movers and is restored by the same arm. Keeping the
            // flag exactly where it was doing that work and releasing only the
            // RISING player puts all three back to the digit.
            //
            // `overtaking` also still gates the LANDING branch above, where it
            // means what it says: a rising floor catching a foot from below.
            //
            // Cold on lv20 afterwards: CLEARED, and the fixup log's whole
            // x=29,054..29,199 cluster is gone (16 records with the band class
            // off, 38 with it on). Nothing else in the level's fixup map moved.
            // --ceilrideslope: no ceiling ride while a ceiling ramp is pressing the
            // player (s.ceilT > 0 = GD's m_wasOnSlope on that side). Two readings,
            // same slab (id468 30x1.5): lv19 t=14,805 riding ceiling ramp uid9662,
            // head 5.77 px into the slab -> GD hit=0 every tick and follows the
            // ramp line; calib_slabside, no ramp, 2/4/6 px -> GD pushes the head
            // out (hit=1), 6.1 px and deeper -> hit=0 (the 6.0 below). The top
            // face's seat has an explicit !m_wasOnSlope (0x392508); the head side
            // is read as the same, unconfirmed in the disassembly.
            // --ceilpinmin: a ceiling that moved toward gravity into the head is
            // resolved at any horizontal depth -- GD takes that arm on the
            // object's own motion flag ([rsp+0x39], set at 0x391e26), not on
            // deepIn (see the clamp inside the branch).
            } else if ((vpNow >= 0 || (prevHeadP > 0 && deepIn && !overtaking)
                        || (gsign * o->dcy < 0.0
                            && prevHeadP > 0
                            && !(g_pinMinNoSwing && c.mode == 7)))
                       && xOver
                       && prevHeadP <= kShipLandTol && newHeadP >= 0
                       && !(g_ceilRideSlope && s.ceilT > 0)
                       && !vetoHeadL) {
                // Ceiling ride. The ship stops dead against a block's underside
                // and slides along it -- it does NOT die and it does NOT pass
                // through. The model had no ceiling case at all (the header's
                // "no floor/ceiling rides" under-approximation), so the ship
                // flew straight through solids from below. Measured on lv6
                // t=11091: block x[14430,14460] y[330,360], GD pinned the ship
                // at y = 330 - 15 = 315.00 with vy = 0 and onGround = 0, while
                // the model sailed on to 315.06 and kept climbing.
                if (g_slopeDbg)
                    std::printf("ceilride t=%lld uid=%d x=%.3f ocy=%.3f "
                                "ohh=%.3f head=%.3f dcy=%.4f vp=%.4f "
                                "prevH=%.4f newH=%.4f xpen=%.3f pHalf=%.2f "
                                "mini=%d y %.4f->%.4f\n",
                                (long long)K.t, o->uid, x, o->cy, o->hh, head,
                                o->dcy, vpNow * kYScale, prevHeadP, newHeadP,
                                xPen, pHalf, (int)c.mini, (double)c.y,
                                head - gsign * pHalf);
                YSET(c.y) = (float)(head - gsign * pHalf);
                // [2026-08-19 item 13] **A moving ceiling's pin carries the face's
                // velocity** (dcy/0.25, same convention as the floor catch). The
                // identity of "only vy grows while held, y matches exactly" at lv19
                // t=21,350 uid14543 (+0.576) and lv15 uid3211 (+0.432). A static
                // ceiling (dcy=0) stays 0 as before -- trying "free vy integration
                // while pinned" made 8 static-ceiling sites at sp0.9 spring up at
                // once (GD does zero it on a static one).
                // [2026-08-31] ...FOR ALL FOUR FLIGHT MODES, not the ship alone.
                // Read off collidedWithObjectInternal (base+0x391a70), the arm
                // that ends in didHitHead:
                //   if (m_isShip || m_isBird || m_isDart || m_isSwing) && bVar14
                //       { if (ceiling) setYVelocity(this, this[0xc6]); }
                //   didHitHead(this);
                // where +0xc6 is the surface velocity the same function stored
                // earlier as `(edge delta) / dt`, and 0x9b9/9ba/9bc/9c4 are the
                // four flight flags (ship / UFO / wave / swing) this file
                // already names at the one-way plate above. It is a plain
                // ASSIGNMENT there -- no max, no epsilon.
                // The ship-only gate was what the corpus happened to show when
                // this was fitted from lv19/lv15 sites, and lv20 t=22,158 is the
                // disagreement it left: a full-size UFO pinned under moving
                // block uid18743 (dcy +0.380), GD's own dump row carries
                // vy = 1.520 = 0.380 / 0.25 exactly, and the model zeroed it.
                // dt = 0.25 is confirmed by the same run's t=19,365 ship pin:
                // dcy 1.961 against GD's vy 7.845 is 0.25000.
                const bool flyMode = (c.mode == 1 || c.mode == 3
                                      || c.mode == 4 || c.mode == 7);
                if (g_dcyDbg)
                    std::printf("dcystamp site=ceilpin t=%lld uid=%d dcy=%.17g "
                                "stamp=%.17g vy=%.9f took=%d\n",
                                (long long)K.t, o->uid, o->dcy,
                                (double)o->dcy / 0.25, (double)c.vy,
                                (flyMode && o->dcy != 0.0) ? 1 : 0);
                // [2026-09-06] **GD holds this pin for FOUR ticks; the model
                // enters here once.** Its dump at lv19 t=21,401 -- the tick the
                // pin is established -- reads yvel exactly 0, then -1.000 for
                // 21,402..21,405, and the model has no decision on those four.
                // Shifting the phase alone (write 0 on the contact tick, stamp
                // after) was implemented and reverted: it makes 21,401 exact
                // and then FREE-FALLS, dvy +0.919 and +1.000 at 21,402/21,403
                // against the old arm's -0.085 and +0.042. quick_regress read
                // that as an improvement (lv19 tracked 22003 -> 22004, and the
                // only changed line in 22 levels), because `tracked` is a
                // y-based summary and absorbs a vy regression -- the per-tick
                // column is what decides.
                // The real fix is to make the pin PERSIST, which needs a State
                // bit and therefore a serial cold. Reach was counted on the vy
                // column first: 3 ticks on lv19 (4 counting 21,402), ZERO on
                // lv20, and this site decides on no other level, so that is the
                // whole corpus. Not worth the cold. Left as a leaf.
                // [2026-09-19] SUPERSEDED by --ceilpinmin below: nothing
                // persists. The slab over lv19 t=21,401 is a ceiling moving
                // with gravity, and GD's -1.000 is min(vy, -1) taken afresh on
                // every tick of contact (0x392e35). lv20 t=21,660 is the same
                // arm (a UFO under block uid18404), so the reach was not zero.
                // --ceilpinmin [2026-09-19]: the stamp above is the RISING
                // ceiling's. For a ceiling that moved toward gravity this tick,
                // collidedWithObjectInternal restores the updated vy and then
                // clamps it: minsd vy, (+0x630 - 1.0) at 0x392e35..0x392e53
                // (the 1.0 is [0x140622e18], loaded into xmm8 at 0x392466), and
                // +0x630 is zeroed by postCollision every tick and written only
                // by rising objects and slopes -- so a descending face gives
                // min(vy, -1) when the updated vy points with gravity, 0 when it
                // does not. Mirrored under flipped gravity (max(vy, +1) at
                // 0x392815). lv19 t=21,401..21,416 (ship under slab uid14854,
                // face -0.2506/tick): 0 on contact, then -1.000 held by the min
                // against the +0.127 press steps, -1.081 on release steps.
                // UNVERIFIED: a same-tick rising-object or slope contact that
                // writes +0x630 first.
                const bool faceWithGrav = gsign * o->dcy < 0.0;
                if (flyMode && faceWithGrav
                    && !(g_pinMinNoSwing && c.mode == 7)) {
                    const double vr = gsign * (double)c.vy;
                    VYSET(c.vy) = (float)(vr < 0.0 ? gsign * std::min(vr, -1.0)
                                                   : 0.0);
                } else if (flyMode && o->dcy != 0.0)
                    VYSET(c.vy) = (float)((double)o->dcy / 0.25);
                else
                    VYSET(c.vy) = 0;
                CLAMP0O("fly/ceilride", o);
                ceilPushedThisTick = true;
            // SWING PUSH-OUT. A swing that merely CLIPS a solid is not killed:
            // GD shoves it out along y to the nearer face, keeps vy and sets
            // onGround. Measured on lv22 t=3,669 with the pre-resolution rect
            // (the `ppre=` field, added to the MOD for exactly this):
            //   block  x 5,160.00..5,190.00  y 326.31..356.31
            //   player x 5,131.18..5,161.18  y 302.38..332.38   (PRE)
            //   player x 5,131.18..5,161.18  y 296.31..326.31   (POST)
            // so x overlaps by 1.18 and y by 6.07, and GD resolves the DEEPER
            // axis -- "least penetration" is NOT the rule here. What decides it
            // is the same `deepIn` bracket the ship's snap uses: 1.18 is far
            // under 1.75*pHalf = 26.25, so this is not a side hit, and a
            // non-side hit is resolved vertically. vy is untouched (GD's -1.171
            // carries straight through) and the face picked is the NEARER one
            // (6.07 px down against 53.9 px up).
            // Gated to mode 7 because only lv22 has a swing portal, so nothing
            // already green can move.
            // ...and only on the FIRST tick of the x contact. The measured case
            // is a fresh clip: at t=3,669 the previous x was 30.44 px from the
            // centre (outside hw + pHalf = 30) and this one is 28.82 (inside).
            // Without that, the rule fired on every tick of a long-standing
            // overlap and teleported the player 9 px at lv22 t=4,580, where GD
            // does nothing at all.
            // [2026-08-19 rejected] **Extend to the UFO**. Measured lv20 t=21,453
            // (UFO, rising at vy=+6.742) is indeed this shape: on the tick the
            // box's lower-right corner catches the upper-right corner of moving
            // block uid18338 (box x[32100,32130] y[163.43,193.43]) at xPen 0.73 /
            // yPen 2.40, GD pushes y up to **193.43+pH=208.425** (hbox ppre 191.03
            // -> player 193.43, return value hit=0). The census family
            // m3/mini0/g0/gdg0/sp1.1/air edy +2.399 is exactly this.
            // But no gate can be found:
            //   * adding the UFO plainly -> families 27->**39**, lv12/13/14/19/20
            //     regress. The additions are all over-push-outs
            //     `clamp:fly/swingpush/...`
            //   * `o->dcy != 0.0` (moving blocks only) -> families stay at 27, lv20
            //     gains +217 but **lv19 goes 21,942->21,612** (the t=19,800 section
            //     400->70), red
            // There is a residual too: the push-out target is 0.744 higher than
            // GD's = **the moving block's y itself is off** (uid18338, separate
            // issue).
            // --swingpushtol: ...and only when a face is within reach. GD picks
            // the face a contact resolves to by where the player entered from,
            // with the tolerance kLandTol measures on the cube (playerBottom +
            // tol >= top, bottom >= playerTop - tol); with neither face in
            // reach the contact is a side hit. The swing's two witnesses fit it:
            //   lv22 t=3,669  nearer face 6.07 px   -> pushed onto it (above)
            //   lv22 t=8,194  nearer face 21.4 px   -> NOT pushed: GD holds y
            //                 383.7, runs into uid8807's side and dies at 8,198
            //                 (x penetration 10.5, killer obj=NULL)
            // Without the bound the model lifted the player 21 px onto the top
            // and planned on, and a cold paid six iterations at x=11,366.
            } else if (c.mode == 7 && !deepIn && xOver
                       && std::fabs(xPrev - o->cx) > o->hw + pHalf
                       && std::fabs((double)c.y - o->cy) < o->hh + pHalf
                       && (!g_swingPushTol
                           || std::min(std::fabs(o->cy + o->hh + pHalf - (double)c.y),
                                       std::fabs(o->cy - o->hh - pHalf - (double)c.y))
                                  < kLandTol)) {
                const double above = o->cy + o->hh + pHalf;
                const double below = o->cy - o->hh - pHalf;
                const double yNow  = (double)c.y;
                const double tgt = (std::fabs(above - yNow) <= std::fabs(below - yNow))
                                   ? above : below;
                // ...and only when the push goes the way the player is ALREADY
                // moving, i.e. GD is helping it out of a face it is leaving.
                // Measured both ways on lv22:
                //   t=3,669 near face is BELOW (6.09 px) and vy = -1.257 -> GD
                //           pushes, y 302.38 -> 296.31
                //   t=4,580 near face is ABOVE (9.45 px) and vy = -0.157, i.e.
                //           the player is heading INTO it -> GD does not move it
                //           at all (`ppre` equals the post rect for four ticks
                //           running); what actually happens there is a SLOPE
                //           ride plus the swing's own tap flips, and the push
                //           was stealing it.
                if ((tgt - yNow) * (double)c.vy < 0.0) {
                    for (int si = 0; si <= kSubSteps && !dead; ++si) {
                        const double f = si / (double)kSubSteps;
                        const double sx = xPrev + (x - xPrev) * f;
                        const double sy = (double)s.y + ((double)c.y - (double)s.y) * f;
                        if (std::fabs(sy - o->cy) < o->hh + pInner + kHazMargin
                            && std::fabs(sx - o->cx) < o->hw + pInner + kHazMargin)
                            DIE("fly/solid-side", o);
                    }
                    continue;
                }
                YSET(c.y) = (float)tgt;
                // NOT grounded. GD's dump does report onGround=1 for the ticks
                // that follow, but it keeps integrating freely (t=3,671 onward
                // is a plain swing step: vy -1.171 -> -1.085 -> -0.999 and y
                // follows it), so the flag is cosmetic here. Setting it made
                // the model's own grounded short-circuit zero vy and the push
                // then re-fired every tick, pinning the player to the face.
                CLAMP0O("fly/swingpush", o);
            } else if (!o->oneway) {
                // **A one-way plate never kills** (the note at the `oneway` branch
                // above). When the flipped-side transparency was removed (made
                // world-based), things began falling through to this last else, and
                // a flipped ship slipping past the side of a plate started dying at
                // `fly/solid-side`. **Add the push-out but not the kill** is the
                // correct shape.
                // Measured, lv18 cold run (hp18, r13): 13 iterations CLEARED (r12)
                // worsened to ITER-CAP(39) / 75 minutes, bouncing between x=11,006
                // and x=4,318. The death at x=11,006 is a different route ("climb
                // the y=345 corridor and run into wall uid5427"); the cause was the
                // low route (through the row of plates to the wedge at 195) being
                // blocked by this kill.
                // ENDPOINT ONLY, no sweep. GD splits a
                // 240 Hz step in two only when a click timestamp falls in its
                // second half (survey A4), so on a tick with no button event it
                // makes exactly ONE collision evaluation, at the end. Neither
                // lv6 t=12,177 (nearest inputs 12,165 / 12,209) nor lv11
                // t=12,243 (12,240 / 12,247) is a click tick, so every sample
                // but f=1 is a position the player never occupied.
                // --faceclass (speed.hpp): a foot within the landing tolerance of the face is a
                // ground contact, not a side one, and does not kill
                const bool faceContact = footFaceContact(*o, c, pHalf);
                for (int si = kSubSteps; si <= kSubSteps && !dead && !faceContact; ++si) {
                    const double f = si / (double)kSubSteps;
                    const double sx = xPrev + (x - xPrev) * f;
                    const double sy = (double)s.y + ((double)c.y - (double)s.y) * f;
                    if (std::fabs(sy - o->cy) < o->hh + pInner + kHazMargin
                        && std::fabs(sx - o->cx) < o->hw + pInner + kHazMargin)
                        DIE("fly/solid-side", o);
                }
            }
        }
        // --flyhazaftersolid: the hazards the loop above skipped, tested where the solids left
        // the body. A second walk of the same K.near, in the same order, with the same gate --
        // the cube's form (--hazaftersolid), which has no x window here because the loop above
        // has none either.
        if (g_flyHazAfterSolid) {
            for (const Obj* o : *K.near) {
                if (dead) break;
                if (o->type == 0) continue;
                sweepFlyHazard(o);
            }
        }
    }
    // Slopes (see slopeXOffset / slopeExitVy), for EVERY mode: measured on
    // lv18 t=2761, a mini SHIP rides a 45 degree slope with vy reported as 0
    // and y climbing exactly dx per tick, the same way the cube does. Only the
    // upright case is modelled; GD's downhill and ceiling slopes are left alone
    // until a level needs them.
    //
    // This runs after the per-mode collision code on purpose. lv19's first
    // slope has a 1.5 px slab (id 468) sitting at its top, and while the cube
    // is still climbing its foot is 5.5 px below that slab -- inside kLandTol,
    // so the ordinary landing test used to teleport it up onto the slab at
    // t=245 where GD stayed on the slope until t=253 (the landing test is
    // tightened to a strict crossing while c.onSlope, see landTol there).
    {
        // [2026-08-19] The spider's slope half-width is 13.5 (kSpiderHalf). lv21
        // t=16,710: GD's seat 155.066 = line(140) + 13.5*sqrt(1.25) exactly (with
        // 15 it is 1.68 too high). The corpus has no other spider ride family, so
        // only this moves (the regression is the judge).
        const double pH = (c.mode == 6)
            ? (c.mini ? kSpiderHalfMini : kSpiderHalf)
            : (c.mini ? kMiniHalf : kCubeHalf);
        c.onSlope = 0;
        // Is the player still inside SOME ramp's window this tick? That is what
        // tells "jumped off the middle of a ramp" apart from "ran off its top",
        // and GD gives those two different velocities (see the launch below).
        bool rampWindowHere = false;
        // On the tick a mode portal ends a swing's ride, GD leaves with this free y
        // without taking the seat's step (measurements at the rule's site).
        yFreeBeforeSlope = c.y;
        if (K.slopes) {
            // --slopedbg: what the layer actually handed this tick. `slopewin`
            // can only report ramps that ARE in the set, so a ramp missing from
            // the set leaves no trace at all -- lv22 t=4,630 looked like a
            // window rejection when uid4359 was simply not there.
            if (g_slopeDbg) {
                std::printf("slopeset t=%lld x=%.2f n=%zu uids=", (long long)K.t,
                            x, K.slopes->size());
                for (const Obj* sp : *K.slopes) std::printf("%d ", sp->uid);
                std::printf("\n");
            }
            // --ceilcont [2026-09-19]: GD's CONTINUING contact with a ceiling
            // ramp has no x window. preSlopeCollision returns at once for the
            // ramp whose uid is in player+0x688 (0x38f2f0 / 0x38f309; the seat
            // writes it at 0x3905e7), so neither the end-face probe nor the
            // rect test runs, and the body is seated on the line EXTRAPOLATED
            // to its centre x with the continuing band (2 while a flight mode
            // holds the button). lv16 t=19,105..19,109: a mini ship past
            // uid9662's x1 (29,100) follows 9662's line to 4e-7 -- 0.5234/tick
            // with vy 0 -- while uid9683 (m +1) is in range; the model's window
            // dropped 9662 and it flew free. Only outside the span here, since
            // inside it the upceil branch already carries the continuing band,
            // and only on an unclamped target that moved (GD refuses a clamped
            // target at 0x390637 and an unchanged one at 0x390415). Once a
            // ramp seats, every other ceiling ramp this tick is strict
            // (m_isOnSlope in the band gate, 0x38fffd).
            bool ceilContNow = false;
            if (!c.flip && !s.flip && c.mode == s.mode
                && (c.mode == 1 || c.mode == 3 || c.mode == 4 || c.mode == 7)) {
                for (const Obj* sp : *K.slopes) {
                    if (!slopeIsCeiling(sp->slopeDir) || sp->slopeHazard) continue;
                    const double x0C = sp->cx - sp->hw, x1C = sp->cx + sp->hw;
                    if (x1C <= x0C || (x >= x0C && x <= x1C)) continue;
                    if (std::fabs(x - sp->cx) > 2.0 * sp->hw + pH
                        || std::fabs((double)c.y - sp->cy) > 2.0 * sp->hh + pH)
                        continue;
                    // Seated on this ramp last tick: s.y is its seat at xPrev.
                    if (std::fabs((double)s.y
                                  - slopeSeatTarget(sp, xPrev, pH, true, 0.0))
                        > 0.001)
                        continue;
                    const double mC = (sp->sy1 - sp->sy0) / (x1C - x0C);
                    const double tC = sp->sy0 + mC * (x - x0C)
                        - pH / std::cos(std::atan(std::fabs(mC)));
                    if (tC < sp->cy - sp->hh - pH || tC > sp->cy + sp->hh)
                        continue;
                    if (tC == (double)s.y) continue;
                    // "Seated on it last tick" is read off s.y, which cannot
                    // tell collinear ramps apart: along a chain of 45-degree
                    // ceilings (lv16 uid7217/7229/7220, t=14,308..14,349) s.y
                    // is the seat of the ramp behind as well, and taking it
                    // here stole the tick from the in-span ramp's upceil and
                    // with it the press bookkeeping (a spurious ceil/release
                    // at 14,319). A ramp whose span holds x and whose seat is
                    // this one is the ramp GD is holding; leave it to upceil.
                    bool collinearHeld = false;
                    for (const Obj* o2 : *K.slopes) {
                        if (o2 == sp || !slopeIsCeiling(o2->slopeDir)
                            || o2->slopeHazard)
                            continue;
                        if (x < o2->cx - o2->hw || x > o2->cx + o2->hw) continue;
                        if (std::fabs(slopeSeatTarget(o2, x, pH, true, 0.0) - tC)
                            <= 0.001) {
                            collinearHeld = true;
                            break;
                        }
                    }
                    if (collinearHeld) continue;
                    const double tolC =
                        (input && !slopeBVar22(false, sp->slopeDir)) ? 2.0 : 0.0;
                    if (!((double)c.y > tC - tolC)) continue;
                    if (g_slopeDbg)
                        std::printf("ceilcont t=%lld x=%.3f uid=%d y=%.6f -> %.6f "
                                    "tol=%.0f\n", (long long)K.t, x, sp->uid,
                                    (double)c.y, tC, tolC);
                    YSET(c.y) = (float)tC;
                    if ((double)c.vy > 0.0) VYSET(c.vy) = 0;
                    c.grounded = 0;
                    CLAMP0O("slope/ceilcont", sp);
                    ceilContNow = true;
                    // The seat sets m_isOnSlope (0x390750), so on a ramp that
                    // descends in the travel direction this is a press, as it
                    // is in upceil.
                    const bool revC2 = ((double)K.dxF < 0.0 || s.rev != 0);
                    if ((revC2 ? -mC : mC) < 0.0) {
                        ceilPressedNow = true;
                        ceilPressM = mC; ceilPressMode = c.mode;
                    }
                    break;
                }
            }
            // Two passes over the slopes, and the ORDER is the whole point.
            // The ride is resolved first: on the tick a falling player reaches
            // a ramp its foot is genuinely below the surface, so an inside-test
            // run before the ride reads a legitimate landing as a kill.
            // Measured on lv16 t=4678 -- the ball comes down at vy=-10.13, ends
            // 2.59 px under the ramp's rest height, and GD puts it ON the ramp
            // at y = 300.3406 and rides it for the next 66 ticks. The model
            // killed it there instead, and that single tick was the lv16 wall:
            // the frontier died at x=6,687 while GD sails past on the same
            // input (one extra tap anywhere in a 55-tick window clears the saw
            // beyond it, so the search was never short of moves).
            // After the ride c.y is the resting height, whose foot sits on the
            // surface at the CONTACT point -- which is at or above the surface
            // at the centre on both an uphill and a downhill ramp -- so a rider
            // can never trip the inside-test in the second pass.
            // A ball that taps OFF a ramp still takes this tick's ride
            // position: GD moves it to the ramp's resting height and only lets
            // the flip own the velocity. Measured on lv16 t=4379 -- riding a
            // 0.5 ramp at +0.8071 px/tick, the tap tick goes 360.4255 ->
            // 361.000 (the ramp's own top + 15, clamped at its right edge)
            // while vy is already the flipped 3.7056. Freezing y the way a cube
            // jump does left the model 0.57 px low for the whole flight, and
            // that was the first divergence of the lv16 run.
            // ...and the same holds for a cube's jump, which is the other
            // discrete impulse off a ramp. Only the ball case is measured.
            const bool impulsedOffSlope = impulsedThisTick && s.onSlope;
            const bool tappedOffSlope = ballFlippedThisTick && s.onSlope;
            // Already riding? Then the player STAYS on the surface, even when a
            // free fall would leave it above one. A DOWNHILL ramp drops 0.807
            // px/tick (m=0.5 at speed 1.1) while gravity only moves the player
            // 0.049 px in its first tick, so the acquisition test -- "the foot
            // has reached the surface" -- can never fire again once the surface
            // is running away downwards, and the model simply fell off the top
            // of every downhill ramp. Measured on lv16 t=6296..6316: GD keeps
            // onGround=1 and y dropping at exactly 0.8071/tick for the whole
            // ramp, and this is what killed the frontier at x=9,372.
            // (flipped riders stick too -- they could not ride at all before,
            // so allowing them here cannot change any upright behaviour)
            // --stickground [2026-09-19]: ...and only a body GD has LANDED on the
            // ramp. A contact above the 5.0 landing gate still seats and sets
            // onSlope (the CONTACT IS NOT LANDING note in the ride), but it
            // leaves the body airborne, and GD does not hold an airborne body
            // to the line next tick. lv22 t=18,606..18,607: a mini cube jumps
            // off a -2 ramp at vy 13.06, touches uid16681 (m -1) at 12.85 and
            // is seated once without landing; on 18,607 GD flies free (y
            // 2,024.791 = 2,021.949 + 12.634 * 0.225) while the model pulled
            // it back onto the line (2,023.564) and rode on.
            const bool stickToSlope =
                s.onSlope && !impulsedThisTick && !stepLandedThisTick
                && s.grounded;
            // At the seam of an equal-gradient chain both the old and the new ramp
            // pass acquisition and it becomes "last one wins". The loop runs in cx
            // order, so **going forward the new one (in-span) comes last and is
            // smooth; in reverse the old one (the end-clamped flat) comes last**,
            // and a 1-tick flat enters at the seam (lv22 t=18,526; GD keeps
            // climbing smoothly at 1840.48). Direction-independent rule: a tick
            // acquired from an in-span sample is not overwritten by an acquisition
            // from an end-clamped sample. The end of the chain (a tick with no
            // in-span candidate) still takes the clamp as before -- that is what
            // provides the "last 1 tick" lingering before the slope-exit launch.
            // [2026-08-18]
            bool slopeTookInside = false;
            // [r33] The "highest face under the box" (ridge) on a tick grabbed by
            // push-out. So as not to depend on loop order: whichever ramp made this
            // seat, later `top` values never fall below it.
            bool pushOutSeat = false;
            double pushOutTop = -1e18;
            // --slopelaw's candidate. Recorded here and applied AFTER the loop,
            // for the reason pushOutSeat is deferred too: a seat written in the
            // middle of the loop is read by everything that runs after it. The
            // first version wrote y in place and cost lv20 t=5,278 -- where the
            // existing path already seats the ball exactly as GD does (all three
            // agree at 285.000 / vy 0) and then launches it at +2.762 on the next
            // tick. Writing y first took the contact away from that path, and,
            // because this block sets no state, every following tick looked like
            // a fresh contact again: the body stayed pinned at 285.000 with vy 0
            // for the rest of the level. The guard below is therefore not "did
            // some particular rule fire" but "did the body move at all" --
            // order-independent, and it cannot go stale when a rule is added.
            bool lawSeat = false;
            double lawTop = 0.0;
            int lawUid = -1;
            bool lawUnder = false;
            const float yBeforeSlopes = c.y;
            const uint8_t gBeforeSlopes = c.grounded;
            for (const Obj* sp : *K.slopes) {
                // the wave does not ride anything -- it only ever dies
                if (c.mode == 4) break;
                // A SPIKED ramp is not a surface. m_slopeIsHazard (the `shz`
                // column) was being loaded and then never read anywhere, so the
                // model happily rode the spikes: lv18 lines its ramp tunnel
                // with them (a hazard ramp 4 px under every solid one -- e.g.
                // (5115,405) carries a solid 420->390 and a hazard 416->386),
                // and the search flew a UFO down the tunnel that GD kills at
                // x=5,119. 154 of lv18's 759 ramps are spiked, 192 of lv17's,
                // 139 of lv19's, 88 of lv16's; lv20-22 have none.
                if (sp->slopeHazard) continue;
                // Riding: an upright player rides the line from above, a
                // FLIPPED one hangs under it. The flipped case used to be
                // skipped outright, and that was lv16's wall: at t=4111 an
                // upside-down ship falls UPWARD into the V-shaped ceiling made
                // by the ramps at (5730,435) 450->420 and (5790,435) 420->450,
                // and GD stops it dead at y=405.000 = 420 - 15. The model flew
                // straight through.
                const double x0 = sp->cx - sp->hw, x1 = sp->cx + sp->hw;
                const double m = (sp->sy1 - sp->sy0) / (x1 - x0);
                if (m == 0.0) continue;
                // ...but "flipped" does NOT mean "ceiling". A FLOOR ramp blocks
                // an inverted player from below exactly as the ground plane does
                // ("GD's ground plane blocks the player from BELOW whatever its
                // gravity is", see the kGroundY clamp) -- and the comment at the
                // ceiling branch already says it: slopeDir says which side of the
                // ramp is SOLID, not which face a player may land on.
                //
                // Measured 2026-08-09, lv20 t=14005..14013, an INVERTED
                // (upsideDown=1) full-size ship at speed 1.1. GD names the ramp
                // itself (`standtrace=1`):
                //   stand: t=14005 y=204.529 onG=0
                //          slope=[uid11804 id652 type25 @20722,181 60x30]
                // sy0=166 -> sy1=196 over 60 px, so m = 0.5 exactly, and GD holds
                //   y - line(x) = 16.7705  at every tick of the ride
                // which is this file's own upright resting height, unchanged:
                //   m*slopeXOffset(m,15) + 15 = 0.5*3.5410 + 15 = 16.7705
                // (= 15/cos(atan 0.5) -- the box rotated onto the surface with
                // its centre one pHalf off it). NO new constant.
                //
                // The model routed flip=1 to the hang-under branch, so its y kept
                // integrating 0.225*vy while GD slid it along the line: dy 0.4653
                // -> 0.5739 against GD's flat 0.8066 (= 0.5*dx). That family was
                // 16 of the 80 fixups in lv20's cold run (11 as a delta, 5 as the
                // kill the accumulated offset then missed) -- the biggest single
                // cause at the x=28,867 wall.
                //
                // STRICTLY ADDITIVE: upright is untouched (ridesTop is true, as
                // before) and flipped-under-a-ceiling-ramp is untouched. The only
                // new case is flipped ABOVE a floor ramp, which previously took
                // the hang-under geometry, failed the came-from-above gate by
                // ~32 px and `continue`d -- i.e. no ride at all.
                // ...and the SWING gets the full set too. Measured on lv22
                // uid4359 (slopeDir = 5, so `slopeIsCeiling` says ceiling but
                // the {1,3} subset does not): at t=4,633 the player's gravity
                // flips and the model, thinking this was a floor ramp, moved it
                // from hanging under (419.7) to standing on top (460.5) -- a
                // 40.8 px teleport. GD stays under at 418.077 = the line minus
                // pH*sqrt(1+m^2), i.e. **the side is the ramp's, not the
                // player's**, which is what slopeDir has always meant.
                // [2026-08-21 r63] **Remove the mode whitelist.** It grew one mode at
                // a time, ship -> swing -> cube, but the reason was the same every
                // time, "a slopeDir=5 ramp looks like a floor under the {1,3}
                // subset", and has nothing to do with the player's mode. The spider
                // showed the same picture: at lv22 t=8,250 (uid9296, sdir=5, m=-2,
                // line 570->510) only the model **jumped +85.8px** to the top face
                // 523.500 (GD passes straight through at 437.670). Same shape as
                // uid4359's 40.8px.
                const bool ceilRampSide = slopeIsCeiling(sp->slopeDir);
                // SHIP ONLY. The first attempt let every mode take this branch
                // and lv16 went from CLEARED in 32 iterations to STUCK at
                // x=19,711 in 60 (2026-08-09, same pool, same everything else).
                // The reason is `ceilRampSide`: only the ship is converted to
                // GD's full {1,3,5,6} set, so for cube/ball/UFO/wave a large
                // share of genuine CEILING ramps still read as "floor" here, and
                // the new branch then offered them a top ride they must not have.
                // The measurement is a ship's; keep the rule where the side test
                // is known to be right.
                // **The contact side is decided by the gravity from before the
                // press** (GD's tick order is update -> collisions -> buttons). The
                // ball's tap IS the gravity flip, so reading c.flip on the tap tick
                // reinterprets the ramp it is still riding as "ceiling side" and
                // discards the candidate outright (--slopedbg: lv16 t=4,730 shows
                // ridesTop=0 / gs=-1 / reject=1). That loses the last one step GD
                // carries it (m*|dx| = 0.807px). This is the identity of this
                // family.
                // It only applies on the tappedOffSlope tick = "tapped" and "was on
                // the ramp at the start of the tick".
                const bool flipForRide =
                    tappedOffSlope ? (s.flip != 0) : (c.flip != 0);
                bool ridesTop = !flipForRide;
                // ...and the SWING needs it as much as the ship. It toggles its
                // gravity every couple of ticks, so `!c.flip` made it lose and
                // re-find the same ramp on alternating ticks. Measured on lv22
                // uid5430 (m=2) with --slopedbg's candidate lines: t=4,572 and
                // 4,573 have ridesTop=1 and a sensible top of 368.021, while
                // t=4,570/4,571/4,574/4,575 have ridesTop=0, top=315.000 and
                // reject=1 -- the flip is the only thing that changed. GD rides
                // it right through, because slopeDir says which side is SOLID,
                // not which way the player's gravity points.
                // [2026-08-21 r60] **Remove the mode whitelist.** As the note above
                // says, "slopeDir says which side is SOLID, not which way the
                // player's gravity points", so this is not a property of
                // ship/swing. Measured lv22 t=8,232 (spider, flip=1, floor ramp
                // uid17788 m=+1): GD's `slp:` line has onSlope=1 and lifts y from
                // the free-fall 413.728 to the seat 414.592, then carries it at the
                // face's own 1.614/tick until 8,239. The model, with mode 6 not on
                // the whitelist, got ridesTop=0 / gs=-1 / reject=1 (--slopedbg's
                // slopecand lines print gs=1 at 8,231 -> gs=-1 at 8,232 just so),
                // free-fell for 7 ticks, and left census
                // `m6/mini0/g0/gdg0/sp1.1/air` edy +0.864. The whitelist had been
                // growing one mode per family (ship -> swing), so it is folded
                // here.
                if (flipForRide && !ceilRampSide) {
                    // came from ON or ABOVE the upright resting height?
                    const double ru = xPrev + (m > 0 ? slopeXOffset(m, pH)
                                                     : -slopeXOffset(m, pH));
                    const double topPrevUp =
                        sp->sy0 + m * (std::min(std::max(ru, x0), x1) - x0) + pH;
                    ridesTop = ((double)s.y - topPrevUp) >= -kLandTol;
                }
                const double gs = ridesTop ? 1.0 : -1.0;
                // GD's `off` (0x38fd2b-0x38fd34): 0 except on a slope SWITCH,
                // where it shifts the target by m_vehicleSize * 20.0f. See
                // slopeSeatOff in slopes.hpp for bVar9 and for why this arm has
                // no corpus witness.
                const double seatOff = g_noSlopeSeat
                    ? 0.0
                    : slopeSeatOff(sp, K.slopes,
                                   s.onSlope ? (int)s.slopeUidNow : -1,
                                   s.onSlope != 0, c.mini != 0);
                // Downhill ramps hold the player up exactly the same way; the
                // contact point is just on the other side of the box, because
                // GD tilts the player the other way. lv18 x=3,615 is a 210->180
                // ramp immediately followed by a 180->210 one, and skipping the
                // first is what stopped the search at x=3,716.
                // Where the surface is sampled. Upright: the rotated box's
                // lowest corner (measured, see slopeXOffset). Flipped: a
                // CEILING binds at the LOWEST point of the surface over the
                // player's width, so take the better of the two box edges
                // clamped into the ramp. Measured on lv16 t=4111 -- the ship's
                // box spans x[5759.3,5789.3] and GD pins it at 420 - 15, which
                // is the surface at 5760 (its left edge, the ramp's own corner)
                // and not at the centre (427.15) nor at the rotated contact
                // point (428.9).
                // `ok` is "this ramp is in play for the ride" (1.5 px of slack
                // past the right edge keeps the last tick on the surface);
                // `inside` is the strict version, for telling "still on it"
                // apart from "just ran off the top" (see rampWindowHere).
                struct Smp { double xr; bool ok; bool inside; };
                auto sampleAt = [&](double cx) {
                    // ridesTop, not !c.flip: an inverted player standing on a
                    // FLOOR ramp contacts it with the same rotated corner an
                    // upright one does (see the note at ridesTop).
                    if (ridesTop) {
                        const double r = cx + (m > 0 ? slopeXOffset(m, pH)
                                                     : -slopeXOffset(m, pH));
                        // [2026-08-19] A continued ride that is **downhill** in the
                        // travel direction keeps descending the extrapolated line
                        // past the low end (GD slopeYPos extrapolates outside the
                        // box -- the implementation difference surfaces here,
                        // measured 2026-08-01). og drops where the centre has
                        // descended to the low end's line value sy1 = end + off/|m|
                        // (slopeland rig measured k3/k6: x-x1 = 33.97/34.77 vs
                        // formula 33.54; k12/k15: 21.34/22.31 vs 21.21). The
                        // identity of lv16 t=6,316 (running flat at 165.000 at
                        // uid2580's end while GD descends to 164.900).
                        // Only the upright cube's continuation was measured, so it
                        // is limited to that.
                        {
                            const bool revE =
                                ((double)K.dxF < 0.0 || s.rev != 0);
                            const double mTravS = revE ? -m : m;
                            if (mTravS < -0.01 && stickToSlope && s.onSlope
                                && !c.flip && c.mode == 0) {
                                double extC =
                                    pH * std::sqrt(1.0 + m * m)
                                    / std::fabs(m);
                                // [2026-08-21 r79] The extrapolated descent (extC)
                                // is the measurement for **air past the end**
                                // (slopeland). When a **flush flat** (an actual top
                                // face within +-0.5 of the end's line) continues
                                // past the low end, GD's slope state lasts only
                                // until "the tick the rotated box's rear corner
                                // (centre - (pH-xoff)) exits the end", and the
                                // release pulse (mTravel*dx/0.25) comes out there.
                                // Measured lv16 t=6,972 (cube m=-0.5, x1=10,380,
                                // 1.5px slab top 449.95): the pulse is on the tick
                                // cx crosses x1+11.459 (=pH-xoff). Keeping extC
                                // (33.54) is 1 tick late (census nearceil edvy
                                // -3.229).
                                if (K.near) {
                                    const double xEndF = revE ? x0 : x1;
                                    const double yEndF = revE
                                        ? (double)sp->sy0 : (double)sp->sy1;
                                    const double probeX =
                                        xEndF + (revE ? -1.0 : 1.0);
                                    for (const Obj* nb : *K.near) {
                                        if (nb->type != 0) continue;
                                        if (std::fabs((nb->cy + nb->hh)
                                                      - yEndF) > 0.5)
                                            continue;
                                        if (nb->cx - nb->hw <= probeX
                                            && probeX <= nb->cx + nb->hw) {
                                            // [r83] The boundary is "until the
                                            // extrapolated seat is kStickGap px
                                            // below" = the continuation's gap rule
                                            // itself (same formula as the general
                                            // window below; settled by the seam rig
                                            // at 3 speeds)
                                            extC = slopeXOffset(m, pH)
                                                 + kStickGap / std::fabs(m);
                                            break;
                                        }
                                    }
                                }
                                const bool okE = revE
                                    ? (r <= x1 && cx >= x0 - extC)
                                    : (r >= x0 && cx <= x1 + extC);
                                return Smp{r, okE, r >= x0 && r <= x1};
                            }
                        }
                        // The 1.5 px of grace keeps the ride alive on its
                        // LAST tick -- which is past x1 travelling forward
                        // but past x0 in a REVERSE section. Without the
                        // mirror the reverse rider loses the ramp one tick
                        // before the top and the uphill exit (below) never
                        // fires: lv22 t=18,567, mini cube riding the 30x60
                        // at x-decreasing travel, GD launches at 13.064 and
                        // the model kept riding with vy pinned (the
                        // ride24+ fixup family). Forward runs are
                        // bit-identical (useDx >= 0 keeps the old window).
                        // [2026-08-18] `useDx < 0` was a dead test:
                        // useDx = (s.dx > 0) ? s.dx : K.dxF, and s.dx is the
                        // speed's absolute value, so via an anchor that carries dx
                        // it is always positive. It lives on a cold run (s.dx=0 ->
                        // K.dxF's sign gets through) and dies silently only in
                        // anchored replays -- a "written but never effective" rule
                        // of the same shape as tappedOffSlope. The true travel
                        // direction is K.dxF's sign or s.rev.
                        const bool rev = ((double)K.dxF < 0.0 || s.rev != 0);
                        // [2026-08-19 item 4, both proposals rejected] Tried
                        // widening the exit-side window to take lv18@20,467
                        // (edy +28.359, the largest remaining error). GD keeps the
                        // player standing at y=405.000 (=line(x1)+pH) with og=1
                        // even when the centre is 12.5 past the high end of ramp
                        // uid13971 (m=+2, x1=27,720), and launches at vy=+5.226 the
                        // next tick (the model's launch value already matches).
                        //   Proposal 1, "while the box overlaps the end"
                        //     (x-pH <= x1): families 27->**44**, lv16 tracking
                        //     17,926->16,124, plus 5 more levels regress
                        //   Proposal 2, 1 + "the box bottom below the end's line
                        //     (penetrating the object)": families 27->**31**,
                        //     lv16/lv18/lv20 regress
                        // Both add **over-retention** in the
                        // `slope+0.50|+1.00/ride...` group. What GD does here is a
                        // push-out from the object, not a ride continuation, so the
                        // rule belongs on the push-out side, not the window.
                        // **And the true first divergence is not here**: GD fires
                        // the same portal pair (cube uid14052 @27,755.8 and size
                        // uid14055 @27,757.6, both rot=51, 34x86) **both on the
                        // same tick (20,466)**, while the model fires the size one
                        // at 20,467. For that 1 tick pH stays 9, so no window
                        // whatsoever keeps the acquisition from being 1 tick late.
                        // **Fix the size portal's same-tick firing first.**
                        // [2026-08-19 rejected] Widening the entry side by xoff
                        // ("grab with the high end's flat clamp even when the
                        // contact point is short of the end"): lv19@15,113 (note
                        // below) disappears, but lv16's tracking regresses
                        // 17,926->17,226 (400->41 at t=6,200), lv19 21,942->21,814,
                        // families 27->30 (+5/-4). Too wide as a general rule --
                        // the grab appears to happen only "when at the flat
                        // clamp's height on the landing tick".
                        // [2026-08-20 rig ramps, 48 units] This grace is not the
                        // constant 1.5 but **one tick's movement**. Solving jointly
                        // for each of the rig's 44 units (the 4 ball m=0.5 ones
                        // never launch at all) "the tick before the launch is
                        // still riding / the launch tick is off" brackets
                        //     1.2181 <= G < 1.3082
                        // The rig's one-tick movement is **1.29825** (sp0.9), which
                        // is inside the interval. That is, `r_new <= x1 + dx` <=>
                        // **`r_prev <= x1`** -- the window is the bare end seen at
                        // the start-of-tick x, and no grace constant exists (same
                        // convention as the portals' "the contact side is decided
                        // at the start-of-tick position").
                        // The constant 1.5 is outside the interval, and 4 of the 48
                        // rigs were 1 tick late (robot m2 mini n1 / spider m1 mini
                        // n3 / spider m0.5 mini n1 / spider m2 mini n3 -- all rigs
                        // whose end phase is borderline).
                        const double rideGrace = std::fabs(useDx);
                        bool ok = rev
                            ? (r >= x0 - rideGrace && r <= x1)
                            : (r >= x0 && r <= x1 + rideGrace);
                        // [2026-08-20] **On the landing tick only, grab if at the
                        // height of the high end's flat clamp.** Puts in, in that
                        // narrow form, the note from when "widen the entry side by
                        // xoff" was tried as a general rule and rejected on
                        // 2026-08-19 (lv16 tracking 17,926->17,226, families
                        // 27->30): "the grab appears to happen only when at the
                        // flat clamp's height on the landing tick".
                        // Measured lv19 t=15,112 (UFO, sp1.1, plate uid9970's top
                        // 270 flush with the high end of ramp uid9899 (x0=21,480,
                        // sy 270->240)): on the landing tick GD grabs **the ramp**
                        // and seats at y=285 (=270+pH), releases the next tick
                        // (vy=-6.457 = -1.6143/0.25) and starts descending. The
                        // model's contact point (21,475.5) fell 4.5px short of x0,
                        // so it stayed landed on the plate, frozen; from there GD
                        // descends while the model runs level, opening to the end.
                        // Limited to a ramp that **descends** in the travel
                        // direction (high end on the entry side). Without that it
                        // grabs lv20 t=13,800 (`slope+0.50/ride0`, the uphill side)
                        // and becomes an over-acquisition, edvy=-1.492.
                        const double mTravHi = rev ? -m : m;
                        // And it also needs to have **crossed** the flat clamp's
                        // height from above (at/above the cap at the start of the
                        // tick, at the cap after landing).
                        // lv16 t=7,059 is walking the flat 464.950 where og drops
                        // for just 1 tick, and its start-of-tick y (464.952) is
                        // **below** the cap (465.000) -- GD does not grab. Without
                        // this, `slope-1.00/ride0` produces an over-launch,
                        // edvy=+6.457.
                        if (!ok && c.grounded && !s.grounded
                            && mTravHi < 0.0) {
                            const double capHi =
                                std::max((double)sp->sy0, (double)sp->sy1) + pH;
                            if ((double)s.y >= capHi - 0.02
                                && std::fabs((double)c.y - capHi) <= 0.6
                                && cx + pH >= x0 && cx - pH <= x1)
                                ok = true;
                        }
                        // [2026-08-21 r79] **When a flush flat continues past the
                        // downhill end, the ride (= the time of the release pulse)
                        // stays alive until "the tick the rotated box's rear corner
                        // (centre -/+ (pH-xoff)) exits the end".**
                        // rideGrace (based on r) is the measurement for a launch
                        // into air (slopeland rig).
                        // Measured lv18 t=12,280 (ball m=-1, x1=16,590, flush slab
                        // top 210): GD's pulse (-6.457 = mTravel*dx/0.25) is on the
                        // tick cx crosses x1+8.787 (=pH-xoff). The model fired 1
                        // tick early with the r window (census
                        // `m2/.../slope-1.00/ride24+` edvy +6.457).
                        // The cube side has the same rule in the extC branch above
                        // (lv16 t=6,972).
                        // [2026-08-21 r83] **The boundary turned out to be the same
                        // thing as the continuation's gap rule**: the ride lasts
                        // "until the extrapolated seat falls kStickGap px below" =
                        // cx <= x1 + xoff + kStickGap/|m|. The seam rig at 3 speeds
                        // (seam/seam07/seam11, dx 1.047/1.298/1.614, cube+ball x
                        // |m|{1,0.5} x 12 phases = 132 runs) agrees on 130 of them.
                        // r79's provisional form (pH - xoff + c, c=1.1) was 0.36px
                        // too narrow at |m|=1, and on the rig a quarter of the
                        // phases released 1 tick early.
                        if (!ok && stickToSlope && s.grounded && K.near
                            && (rev ? -m : m) < -0.01) {
                            const double xEndF = rev ? x0 : x1;
                            const double yEndF = rev
                                ? (double)sp->sy0 : (double)sp->sy1;
                            const double probeX = xEndF + (rev ? -1.0 : 1.0);
                            for (const Obj* nb : *K.near) {
                                if (nb->type != 0) continue;
                                if (std::fabs((nb->cy + nb->hh) - yEndF)
                                    > 0.5)
                                    continue;
                                if (nb->cx - nb->hw <= probeX
                                    && probeX <= nb->cx + nb->hw) {
                                    const double cornB =
                                        slopeXOffset(m, pH)
                                        + kStickGap / std::fabs(m);
                                    ok = rev ? (cx >= x0 - cornB)
                                             : (cx <= x1 + cornB);
                                    break;
                                }
                            }
                        }
                        // ...and THIS is the one that answers for a ball on a
                        // floor ramp -- the other two stay silent, which is how
                        // the three prints together name the branch. lv22
                        // uid6949 (m=-0.5, x1=8850, dx=1.6143):
                        //   t=6,679  r=8850.858  ok=1
                        //   t=6,680  r=8852.473  ok=0
                        // so the ride runs while the contact point r = cx - xoff
                        // is inside x1 + one tick's movement, i.e. cx <= 8855.16
                        // -- which is what the bisection saw (accepts 8854.40,
                        // rejects 8856.01) after three hand-readings of the
                        // source had produced three different wrong cutoffs.
                        // GD leaves at t=6,682, r in (8854.09, 8855.70], and no
                        // constant grace fits it because GD's continuing-contact
                        // test has no x window at all: it ends when the extended
                        // lower edge passes objMaxY, and this ramp is a MOVER
                        // descending out from under the player.
                        // `stick` is not the thing to widen -- it is already 1
                        // on the rejecting tick and did not rescue it.
                        if (g_slopeDbg)
                            std::printf("slopeform t=%lld uid=%d mode=%d m=%.3f "
                                        "cx=%.3f x0=%.1f x1=%.1f r=%.3f "
                                        "stick=%d ok=%d  [rot-branch]\n",
                                        (long long)K.t, sp->uid, (int)c.mode, m,
                                        cx, x0, x1, r, stickToSlope ? 1 : 0,
                                        ok ? 1 : 0);
                        return Smp{std::min(std::max(r, x0), x1), ok,
                                   r >= x0 && r <= x1};
                    }
                    const double a = std::min(std::max(cx - pH, x0), x1);
                    const double b = std::min(std::max(cx + pH, x0), x1);
                    const double sa = sp->sy0 + m * (a - x0);
                    const double sb = sp->sy0 + m * (b - x0);
                    // The SWING has to have its CENTRE inside the ramp, not
                    // just a box edge. Measured on lv22 uid4359 (a static
                    // 30x30 at cx=6,705, rot=-90, m=-1, so x0=6,690):
                    //   t=4,623  centre 6,684.57  GD onSlope=0  -- model GRABBED
                    //   t=4,627  centre 6,691.03  GD onSlope=1  -- first grab
                    // The box-edge test fires a full pH early, and the point it
                    // then picks is the lowest surface over the box width
                    // (6,699.57 -> 440.43), which hangs the player at 425.43
                    // while GD's own line at the centre is 453.8 -- 28 px out.
                    // Ship/UFO keep the box-edge rule: it is what lv16 t=4,111
                    // was measured with (the ship pinned by its LEFT edge on the
                    // ramp's own corner).
                    // ...and it samples the surface at the CENTRE, not at the
                    // lowest point over the box width. Measured on the same
                    // ramp at t=4,627 (centre 6,691.03, line there 448.97):
                    // GD rests the player at 427.763 = 448.97 - 21.21, and
                    // 21.21 is pH*sqrt(1+m^2) -- the same rotated-box quantity
                    // the upright ride uses. Taking the box's lowest point
                    // (6,706 -> 434) would have put it at 419.
                    // ...and the CUBE hang needs the centre rule as much as
                    // the swing. With the box-edge rule the flipped dual body
                    // of lv16's first dual "landed" on the NEXT ramp of the
                    // chain while only its outer 2.3 px column overlapped it:
                    // t=7,774, p2 riding uid3341's line at 559.6, grabbed
                    // uid3357 (x0=11,700, 13 px ahead) at top=553.835 -- a
                    // 5.73 px downward teleport (the prevTop gate passed by
                    // 0.27 px against kLandTol). GD keeps the body on the
                    // current line and only moves at the seam. Ship/UFO keep
                    // the box-edge rule (measured, lv16 t=4,111).
                    // ...the BALL's hang uses the centre rule too (2026-08-19, lv16
                    // t=13,115's 12.728 is exact against line(centre x). This
                    // branch only sees the hang side (gs<0), so the upright ball is
                    // unaffected).
                    // [2026-08-21 r71] swing moved from centre to contactPt.
                    // Calibration rig ceilramp unit36 (flipped swing, m=-1): GD
                    // follows the line from the tick the contact point (x+xoff)
                    // enters x0 (the centre is 5px short). The lv22 uid4359
                    // "centre rule" measurement is at m=1, where
                    // line(centre)-pH*sqrt(2) == line(contact)-pH degenerate and
                    // could not be told apart. The ball stays centre (the ball
                    // column is bit-identical with centre).
                    const bool centre = (c.mode == 2
                                         || (c.mode == 0 && s.dual));
                    // [2026-08-20] **The cube's and UFO's hang grab at the contact
                    // point.** Lining up "the x where it leaves the flat ceiling
                    // and starts descending" against GD on the calibration rig
                    // ceilramp (5 modes x |m| 3 x normal/mini = 30 units, after
                    // the header fix): ship 6/6 and ball 4/4 are exact under the
                    // current box-edge/centre rules, while **only cube 6/6 and
                    // UFO 6/6 are 2.6-11.7px early**. In all 12 cases that
                    // earliness matches **pH - slopeXOffset(m,pH)** within 1 tick
                    // (1.298px):
                    //   cube m1   15-6.213=8.787 vs measured 9.085
                    //   cube m0.5 15-3.541=11.459 vs 11.681
                    //   cube m2   15-9.271=5.729 vs 5.195
                    //   UFO  m1   8.787 vs 7.793 ...(and so on; mini agrees too)
                    // The hang's contact point is "the upright one mirrored in y"
                    // = the sign of m flips, so `cx - (m>0 ? xoff : -xoff)`. This
                    // is the same formula as the rc the ceiling push-out branch
                    // (ceilpush) already uses.
                    // Keeping the ship at the box edge is supported both by the
                    // lv16 t=4,111 measurement (the left edge digging into the
                    // ramp's corner) and by the rig's 6/6 agreement.
                    // [2026-08-21 r70] robot/spider added. Calibration rig
                    // ceilramp unit24 (flipped robot, m=-1 chain) measured:
                    //   acquisition: GD follows the line from the tick the contact
                    //     point (x+xoff ~= 6.2) enters x0. The model started
                    //     descending 15px early at the box edge
                    //   release: on the tick the contact point exits x1,
                    //     vy=-7.405 = slopeExitVy's cube value (robot=cube, no
                    //     0.75, matches the table). There is **no** flat corner
                    //     tick like the ship's, so the bare contactPt window fits
                    //     both ends
                    const bool contactPt = (c.mode == 0 || c.mode == 3
                                            || c.mode == 5 || c.mode == 6
                                            || c.mode == 7);
                    const double rcH =
                        cx + (m > 0 ? -slopeXOffset(m, pH)
                                    : slopeXOffset(m, pH));
                    // [r71c] Only the swing gets grace on the exit side (the end
                    // in the travel direction) = the corner flat's 1 tick (same
                    // shape as ship r68b / ball okHi).
                    // Measured unit36/40: GD stops for 1 tick at 185.000
                    // (= line(x1)-pH) on the first tick the contact point exits
                    // x1, and launches on the **next** tick (-5.554/-7.880 -- the
                    // values already match, only the time was 1 tick early in the
                    // model). robot/spider have no corner tick (unit24 measured),
                    // so bare contactPt.
                    // [2026-08-21 r74] The grace is not the constant 1.5 but **one
                    // tick's movement** (= "the previous tick's contact point is
                    // still inside the end"). Same conclusion as the ride window's
                    // rideGrace (2026-08-20 rig ramps, 1.2181<=G<1.3082). ceilramp
                    // unit41's (mini m=2, dx=1.297) release tick has the contact
                    // point at x1+1.36 -- falling in the (dx,1.5] gap, so only the
                    // model lingered one more tick on the corner (unit4's ship is
                    // the same phase).
                    const bool revT7 = ((double)K.dxF < 0.0 || s.rev != 0);
                    const double cornG = std::fabs((double)useDx);
                    const bool ok = centre
                        ? (cx >= x0 && cx <= x1)
                        : contactPt
                        ? ((c.mode == 7)
                           ? (revT7 ? (rcH >= x0 - cornG && rcH <= x1)
                                    : (rcH >= x0 && rcH <= x1 + cornG))
                           : (rcH >= x0 && rcH <= x1))
                        : (cx + pH >= x0 && cx - pH <= x1);
                    // --slopedbg: WHICH of the three forms answered, with its
                    // inputs. The ball takes none of the shapes its comments
                    // suggest -- it is not in `contactPt`, and the mode-2 block
                    // below never runs on the floor side -- so on lv22 uid6949
                    // the ride ends at a cx the source does not obviously
                    // produce (accepts 8854.40, rejects 8856.01, x1 = 8850).
                    // Reading it off the code by hand gave three different wrong
                    // answers, so it prints instead.
                    if (g_slopeDbg)
                        std::printf("slopeform t=%lld uid=%d mode=%d m=%.3f "
                                    "cx=%.3f x0=%.1f x1=%.1f pH=%.1f "
                                    "centre=%d contactPt=%d rcH=%.3f "
                                    "cornG=%.3f ok=%d\n",
                                    (long long)K.t, sp->uid, (int)c.mode, m, cx,
                                    x0, x1, pH, centre ? 1 : 0,
                                    contactPt ? 1 : 0, rcH, cornG, ok ? 1 : 0);
                    // [r71b] The swing's xr is the contact point too (clamped).
                    // Kept at the centre clamp, the acquisition tick jumps 5.1px
                    // down to line(x0)-rotated distance (unit36: GD 273.881 =
                    // line(rc)-pH / M 268.787). At m=1, line(rc)-pH ==
                    // line(centre)-pH*sqrt(2) (the lv22 uid4359 measurement), so
                    // this is consistent with the existing corpus measurements.
                    if (c.mode == 7)
                        return Smp{std::min(std::max(rcH, x0), x1), ok, ok};
                    if (c.mode == 2) {
                        // The hang's window is cut at the contact point (cx+-xoff)
                        // only at "the low end descending in the travel direction"
                        // -- GD ends the ride on the tick the contact point leaves
                        // the end, and stands on the flat clamp for the 1 tick
                        // just before (lv16 t=13,116-13,117; the counterpart of
                        // the top side's max clamp).
                        const bool revB = ((double)K.dxF < 0.0 || s.rev != 0);
                        const double xoffB = slopeXOffset(m, pH);
                        // [2026-09-06] The exit grace is ONE TICK'S MOVEMENT,
                        // not the constant 1.5 -- the conclusion r74 reached on
                        // the rig and applied to the ship (r68/r74) and the
                        // swing (r71c/r74) on 2026-08-21, leaving the ball's
                        // 1.5 behind. Two corpus witnesses now bracket the
                        // grace `G` (measured against `x1 - xoff`) from
                        // opposite sides, and they have no constant in common:
                        //   lv17 t=18,571/18,572  full ball, uid9160 m=-1,
                        //     x1=24,120, xoff 6.213, dx 1.29825. Last riding
                        //     cx 24,113.838, first dropped cx 24,115.137
                        //     => 0.051 <= G < 1.350
                        //   lv16 t=13,116/13,117  mini ball, uid6592 m=-1,
                        //     x1=19,872, xoff 3.728, dx 1.614258. Last riding
                        //     cx 19,869.660, first dropped cx 19,871.273
                        //     => 1.388 <= G < 3.001
                        // |useDx| gives 1.298250 and 1.614258, inside both. The
                        // brackets are 1 tick of dx wide because a sweep is
                        // what produced them, so this is not "1.5 was nearly
                        // right": lv17's tick sits in the (dx, 1.5] gap r74
                        // names, and the model rode the corner one tick longer
                        // than GD (GD fires at 18,572 with ramp factor 16/24,
                        // the model at 18,573 with 17/24, and the model's y at
                        // 18,573, 225.0290222, is GD's y at 18,572 to every
                        // digit gdref records).
                        // The reverse mirror below is deliberately NOT
                        // converted: `revB && m > 0` has ZERO witnesses in the
                        // whole 22-level corpus (a census of all 1,714 ball
                        // `slopeok` decisions), so changing it would be a
                        // symmetry argument carried untested. It stays at the
                        // 1.5 it was measured under.
                        const double graceB = cornG;
                        double okLo = x0, okHi = x1;
                        if (!revB && m < 0) okHi = x1 - xoffB + graceB;
                        else if (revB && m > 0) okLo = x0 + xoffB - 1.5;
                        // --slopedbg: which numbers ended the ball's ride. The
                        // window is the model's proxy for GD's continuing-contact
                        // test, and reading the proxy off the source by hand got
                        // the wrong answer: lv22 uid6949 (m=-0.5, x1=8850) has
                        // xoff=3.541 so this reads okHi=8847.96, while the model
                        // plainly accepts cx=8854.40. One of the inputs is not
                        // what it looks like, and nothing printed them.
                        if (g_slopeDbg)
                            std::printf("slopeok t=%lld uid=%d m=%.3f cx=%.3f "
                                        "x0=%.1f x1=%.1f xoff=%.3f rev=%d "
                                        "okLo=%.3f okHi=%.3f ok=%d\n",
                                        (long long)K.t, sp->uid, m, cx, x0, x1,
                                        xoffB, revB ? 1 : 0, okLo, okHi,
                                        (cx >= okLo && cx <= okHi) ? 1 : 0);
                        return Smp{std::min(std::max(cx, x0), x1),
                                   cx >= okLo && cx <= okHi,
                                   cx >= x0 && cx <= x1};
                    }
                    // [2026-08-19 D7b] In a ship's hang, **once the centre passes
                    // the high end**, the binding is that corner (the flat at
                    // line(end) - pH). Kept at the box edge's lower side, it
                    // "lands" 4-5px lower at the exit: lv16 t=4,142-4,145, GD
                    // stays at 435.000 = line(x1) - pH while the model dropped to
                    // the box left edge's 430.48. The entry corner (t=4,111's 405)
                    // is equivalent to the box-edge rule, so behaviour there is
                    // unchanged. Measured for the ship only.
                    // The window ends on the tick **the contact point (centre -/+
                    // (pH - xoff)) leaves the end** (same shape as the ball's hang
                    // window okHi): GD releases at t=4,147 (x=5,832.4 > x1 + pH -
                    // xoff = 5,831.5) and emits +3.229. Box overlap would be 2
                    // ticks late.
                    if (c.mode == 1 && (m > 0 ? (cx > x1) : (cx < x0))) {
                        const double rel = pH - slopeXOffset(m, pH);
                        const bool okC = (m > 0) ? (cx <= x1 + rel)
                                                 : (cx >= x0 - rel);
                        return Smp{(m > 0) ? x1 : x0, okC, okC};
                    }
                    // [2026-08-21 r68] **The hang's exit at forward x m<0 (reverse
                    // x m>0) closes at the contact point.** D7b above covers only
                    // the "past the high end" side; the **low end** in the travel
                    // direction stayed at box overlap (cx-pH <= x1) = a window
                    // 15px too long, so the model kept sitting on the flat corner
                    // and the launch (uphillExit) never fired.
                    // Measured, calibration rig ceilramp unit0 (flipped ship, m=-1
                    // chain end x1=780): GD is at the flat corner 185.000 on the
                    // first tick the contact point (cx+xoff) exits x1 (781.27),
                    // and **vy=-5.554 on the next tick** = exactly what the
                    // existing uphillExit emits. The grace is the same "corner
                    // flat's 1 tick" as the ball's okHi.
                    // [2026-08-21 r74] That 1 tick is not the constant 1.5 but the
                    // movement |useDx| (see the note at the swing side's cornG;
                    // unit4 was 1 tick late at a (dx,1.5] phase). Consistent with
                    // unit0's measurement too: the corner tick's contact point is
                    // x1+1.27 <= dx=1.298.
                    // [2026-08-24] **...and the hang's ENTRY closes at the contact
                    // point too.** The two rules above end the ride at the far end;
                    // nothing guarded the near one, so a ramp whose surface RISES
                    // away from the player was grabbed on the tick the box merely
                    // reached it, and `xr`'s clamp then read the ramp's low end --
                    // a phantom flat ceiling extending backwards out of the box.
                    // Measured on lv16's ceiling V at x=13,220 (uid3763 m=-1 into
                    // uid3765 m=+1, both sdir ceiling, flipped ship, forward):
                    //   t=8,715  centre 13,206.35, box edge 1.35px past x0
                    //            GD 546.441 = uid3763's line - pH*sqrt(2). The
                    //            model took uid3765 at 539.000 = sy0 - pH, 7.44
                    //            px early, and never left it again
                    //   t=8,719  centre 13,212.80  GD 539.984  (still uid3763)
                    //   t=8,720  centre 13,214.42  GD 539.000  -- which uid3763's
                    //            own end already gives, so this tick does not
                    //            decide anything on its own
                    // The gate is the SAME contact point the two exits above use,
                    // and its sign is not free: the seat is written as
                    // line(xr) + gs*pH, and for it to come out at the measured
                    // line(centre) + gs*pH*sqrt(1+m^2) the hang's contact must sit
                    // at `centre - sign(m)*xoff` -- which is exactly the point the
                    // exits test (m<0 forward uses centre+xoff at x1). So the
                    // entry mirrors them: centre-xoff against x0 when m>0 forward.
                    // t=8,720's launch is the third measurement and it is what
                    // fixes the sign: GD leaves at -6.330 = the m=-1 mirror of
                    // uid3763's own launch (6.905 x 22/24), so GD is still on
                    // uid3763 on that tick and uid3765 must not be held yet -- the
                    // looser `centre+xoff` reading takes it 0.63px too early and
                    // flips slopeM, which turns the launch off.
                    // Only the rising-away side can produce the phantom (on the
                    // falling side the clamp reads the HIGH end, which is not the
                    // binding ceiling for a hang), which is why the sign gates
                    // match the two exits' mirrors.
                    // Ship only, as the two exits above are -- this is where it is
                    // measured. ([[gd-hang-side-mirrors-floor-rules]])
                    if (c.mode == 1) {
                        const bool revH =
                            ((double)K.dxF < 0.0 || s.rev != 0);
                        const double xoffH = slopeXOffset(m, pH);
                        const double cornGS = std::fabs((double)useDx);
                        if (!revH && m < 0 && cx + xoffH > x1 + cornGS)
                            return Smp{x1, false, false};
                        if (revH && m > 0 && cx - xoffH < x0 - cornGS)
                            return Smp{x0, false, false};
                        if (!revH && m > 0 && cx - xoffH < x0)
                            return Smp{x0, false, false};
                        if (revH && m < 0 && cx + xoffH > x1)
                            return Smp{x1, false, false};
                    }
                    return Smp{(sa <= sb) ? a : b, ok, ok};
                };
                const auto smp = sampleAt(x);
                // Which half of the box is solid is slopeDir's business, not
                // the line's -- see slopeIsCeiling, derived from
                // collidedWithObjectInternal. Only the SHIP is converted to the
                // full {1,3,5,6} set so far; every other mode keeps the {1,3}
                // subset it was validated with.
                const bool ceilRamp = ceilRampSide;
                // ---- CEILING ramp met from UNDERNEATH ------------------------
                // slopeDir says which half is solid (slopeIsCeiling; this test
                // predates it and still uses the {1,3} subset for the non-ship
                // modes). m_slopeDirection was loaded and never read, so every ramp
                // was treated as ridable-from-above only and an upright player
                // rising into a ceiling one simply passed through it. That is
                // lv20's wall at x=6,343: a mini ship rises into the 340->310
                // ramp at (6195,325) and GD presses it DOWN along the surface
                // while the model sails on.
                //
                // Measured on that ride (lv20 t=4339..4344, mini ship, pH 9):
                // contact 12.72 px below the surface line, then y tracks the
                // line exactly (-1.6143/tick = -dx), vy snapped to 0 on the
                // contact tick, and GD reports onGround=0 throughout -- a BLOCK,
                // not a ride, so `grounded` stays clear (a cube must not get its
                // jump back by touching a ceiling).
                // 12.72 is not a new constant: it is pH + slopeXOffset(m,pH),
                // the same rotated-box contact the floor ride uses, sampled from
                // the other side of the box. At m=1 that equals pH*sqrt(2) --
                // an identity at 45 degrees only, so do NOT simplify it to that
                // (lv20 has four |m|=0.5 ceilings too).
                //
                // GATED ON COMING FROM BELOW, and it does NOT skip the ride
                // below. The first attempt clamped and `continue`d, which threw
                // away the ordinary ride for every ceiling-flagged ramp: lv16
                // went from CLEARED in 17 iterations to STUCK at x=19,435 in 60,
                // and lv18 from 3.5 to 17.2 minutes. slopeDir says which side of
                // the ramp is solid, not which face a player may land on -- an
                // upright player landing on a ceiling ramp's other face is
                // ordinary, and those levels are full of it.
                // CONTIGUOUS ceiling ramps are ONE surface. Clamping the
                // reference point to [x0,x1] flattens the line at a ramp's
                // edge, and the came-from-below gate then tests against the
                // FLATTENED line, so the next ramp of a chain is never
                // adopted: lv16 t=15,338 (uid7606, x0=23,460, sy0=570) has
                // the model parked at the flat 555.000 while GD keeps
                // descending along the extension (554.420), and the model's
                // y in the 2026-08-17 fixup families sits FLAT at 475.9 /
                // 585.0 / 525.0 across ticks -- three ramp chains, one bug
                // (43 records + 4 kills, the census #2/#3 families).
                // When the reference point leaves this ramp's span, the
                // constraint is the LOWEST solid point over the box, so the
                // neighbour's line only takes over where it is LOWER than
                // the flat corner value: a down->down seam follows the
                // extension (lower), while a down->up VALLEY keeps the flat
                // corner -- measured on the same chain, t=15,367 of the
                // 2026-08-17 lv16 reference: GD contacts the V at exactly
                // 525.000 = the corner (540) - pH, NOT the rising line.
                // (An unconditional extension broke that acquire: the
                // rising line outruns the ship's climb and `c.y > lim`
                // never fires.) Neighbour = same ceiling side, meets at the
                // shared edge, not a hazard twin (the twin sits on a
                // DIFFERENT line 4 px off, so the y-continuity test rejects
                // it as well). First match wins; ramps are sorted by x.
                // `gdSeat` picks GD's own target (slopeSeatTarget in slopes.hpp:
                // the line at the UNCLAMPED centre x, minus the secant half,
                // with the bounds on the target y) over the old x-clamped
                // sample. The chain extension below is untouched by it: where
                // the contact point has left this ramp's span and a contiguous
                // neighbour of the same side continues the surface, GD's answer
                // is that NEIGHBOUR's own target, which is what `ext` already
                // computes -- this ramp's own target is capped at its objMinY
                // there and would stop the descent (lv16 t=8,702, uid3741,
                // GD 567.426 against this ramp's floor 584-15 = 569.000).
                auto ceilLimSeat = [&](double cx, bool gdSeat) {
                    const double r = cx + (m > 0 ? -slopeXOffset(m, pH)
                                                 : slopeXOffset(m, pH));
                    const double rc = std::min(std::max(r, x0), x1);
                    const double flat =
                        gdSeat ? slopeSeatTarget(sp, cx, pH, true, seatOff)
                               : sp->sy0 + m * (rc - x0) - pH;
                    // SHIP ONLY, like everything else measured here: letting
                    // the extension serve every mode moved lv19's UFO at
                    // t=14,799 onto a ceiling it never touches in GD (58 px,
                    // vy pinned 0) and shrank lv20 too.
                    if (c.mode == 1 && (r > x1 || r < x0)) {
                        for (const Obj* nb : *K.slopes) {
                            if (nb == sp || nb->slopeHazard) continue;
                            const double nx0 = nb->cx - nb->hw;
                            const double nx1 = nb->cx + nb->hw;
                            if (nx1 <= nx0) continue;
                            const double nm = (nb->sy1 - nb->sy0)
                                            / (nx1 - nx0);
                            if (nm == 0.0) continue;
                            const bool nbCeil =
                                (c.mode == 1 || c.mode == 7 || c.mode == 0)
                                ? slopeIsCeiling(nb->slopeDir)
                                : (nb->slopeDir == 1 || nb->slopeDir == 3);
                            if (!nbCeil) continue;
                            // [2026-08-19] At a same-sign seam (the line continues)
                            // follow the neighbour's line directly. Keeping the
                            // flat corner via min is **only for a valley where the
                            // sign reverses** (lv16 t=15,367: GD contacts the V's
                            // corner 525.000 = corner(540)-pH and does not use the
                            // rising line -- that measurement is min's
                            // justification and is correct). In a rise->rise chain
                            // ext > flat, so min stops early at the flat corner:
                            // at lv19 t=5,460 (uid3205->3207, 540->570->600) only
                            // the model stuck to 555.000 while GD climbs to the
                            // next ramp's line (contact 561.461 = line(x-off)-pH)
                            // -- the identity of the census m1/.../clamp:slope/
                            // ceillim family. A descending chain has ext < flat,
                            // equivalent to min (no change).
                            if (r > x1 && std::abs(nx0 - x1) <= 0.5
                                && std::abs((double)nb->sy0
                                            - (double)sp->sy1) <= 0.5) {
                                const double rr = std::min(r, nx1);
                                const double ext = nb->sy0
                                    + nm * (rr - nx0) - pH;
                                return (nm * m > 0.0) ? ext
                                                      : std::min(ext, flat);
                            }
                            if (r < x0 && std::abs(nx1 - x0) <= 0.5
                                && std::abs((double)nb->sy1
                                            - (double)sp->sy0) <= 0.5) {
                                const double rr = std::max(r, nx0);
                                const double ext = nb->sy0
                                    + nm * (rr - nx0) - pH;
                                return (nm * m > 0.0) ? ext
                                                      : std::min(ext, flat);
                            }
                        }
                    }
                    return flat;
                };
                auto ceilLimAt = [&](double cx) {
                    return ceilLimSeat(cx, !g_noSlopeSeat);
                };
                // ...and a FLIPPED player meets that same ceiling from the other
                // side. GD does not hang it under the line -- it pushes it OUT of
                // the solid half, down to the very limit the upright case uses.
                //
                // Measured on lv21 t=19,837 (cfg `standtrace=1` names the object:
                // `slope=[uid26823 id1338 type25 @26415,315]`, sy 330->300,
                // slopeDir 1): a flipped cube falling at vy=-9.884 through
                // y=330.9276 is placed at **y=314.8259**, with vy UNTOUCHED and
                // onGround 0 -- a push-out, not a ride. And
                //   ceilLimAt(26393.9609) = 330 + m*(26400.1741 - 26400) - 15
                //                         = 314.8259
                // to four decimals, i.e. exactly the pH + slopeXOffset contact the
                // ship's ceiling measurement produced. Nothing new to fit.
                //
                // The model sailed straight through and ran **13.9265 px HIGH for
                // the rest of the level** (dy constant, dvy 0). That one tick is
                // the whole of lv21's wall at x=26,516: every tail the DP built
                // was solved for a trajectory GD does not fly. Proof it was not
                // the search: from the ladder's own anchor (t=19,834) the DP
                // returns SOLVED at x=27,505 in 8 edges, and splicing that tail on
                // still dies at t=19,930 in GD.
                //
                // The upright branch's `came from below` gate cannot be reused
                // here: this player arrives from ABOVE the limit, which is exactly
                // why it is inside the solid. The gate is the overlap itself.
                // The window is the CONTACT POINT being genuinely inside the ramp,
                // not the box overlapping it. Tried the box first and it fired two
                // ticks early: at lv21 t=19,835 the player's box already reaches
                // x0 while its contact point is 2.4 px left of the ramp, and GD
                // does nothing until t=19,837 -- the tick rc crosses x0 (26,400.17
                // against x0 = 26,400). Clamping early put the model at y=315 and
                // then dropped it into the ordinary ride, 8.8 px below GD.
                // NOT a spiked slope. GD pairs a plain ramp with a hazard twin at
                // the same cx (lv16 x=28,425: id309 sy 780->750 shz=0 and id366
                // sy 776->746 shz=1), and only the plain one is solid. Pushing
                // against the twin's line -- 4 px lower -- drove lv16's flipped
                // dual body from GD's 770.38 (= the PLAIN ramp's own limit, to
                // the digit) down to 766.38, straight into the spikes, and the
                // segment at t=18,200 fell from 296 followed ticks to 236.
                // NOT the swing. "A flipped player never HANGS from a ceiling
                // ramp" was measured on lv20's mini SHIP (uid26823, listed as
                // m_currentSlope on exactly one tick of a whole pass), and the
                // swing does the opposite: lv22 t=4,627..4,635 hangs from
                // uid4359 (slopeDir=5) for nine ticks, sliding down it at
                // exactly -dx per tick, and GD's own y is the line minus
                // pH*sqrt(1+m^2) throughout. Letting this skip fire cost the
                // ride and the model free-fell 3 ticks early.
                // [2026-08-20] **An upright player is also pushed out of a ceiling
                // ramp's solid.** The branch below was `c.flip`-only, but the
                // geometry is the same: the clearance of an axis-aligned box
                // against a tilted line is **pH + slopeXOffset(m,pH)**, not the
                // box's top edge (pH). The "when coming from below" gate above
                // rejects a player that entered from above.
                // Measured lv20 t=18,826 (upright ship, right after wave->ship,
                // vy=-1.046, ceiling ramp uid15572 x[28,290,28,320] line 300->270
                // sdir=1):
                //   line(28,300.8) = 289.2, lim = 289.2 - 21.213 = 267.99
                //   GD  y=271.812 -> **268.021** (vy=-2.000), then follows the
                //       line at -dx/tick
                //   the model passed straight through and stayed 3.5px high from
                //   then on (census edy -3.540)
                // The gate is "the box's top edge inside the ramp's rect" --
                // without it, an upright player **standing on the rect's top
                // face** also gets picked up and dropped below the line.
                // [2026-08-21 r65] **Remove the swing exclusion (upright side
                // only).** `c.mode != 7` merely copied the flipped side's (branch
                // below) "the swing hangs" measurement here; there was no evidence
                // for the upright side. Calibration rig ceilpush8 (one situation x
                // 7 modes) measured: on the tick an upright swing falls off an
                // edge and is caught by a descending ceiling ramp (m=-1), GD sets
                // **vy := -2.000** (same value as ship/cube) and y follows the
                // line at -dx/tick. From then on the swing's own g (-0.086/tick)
                // accumulates. The model, because of the exclusion, passed through
                // and floated +2.5px/3 ticks. The flipped-side exclusion (the
                // swing hangs, lv22 uid4359) stays.
                if (!c.flip && ceilRamp && !sp->slopeHazard
                    && (double)c.y + pH <= sp->cy + sp->hh + 0.001) {
                    const double rcU = x + (m > 0 ? -slopeXOffset(m, pH)
                                                  : slopeXOffset(m, pH));
                    const double limU = ceilLimAt(x);
                    const bool inYU = ((double)c.y + pH >= sp->cy - sp->hh)
                                   && ((double)c.y - pH <= sp->cy + sp->hh);
                    if (g_slopeDbg)
                        std::printf("upceil t=%lld x=%.2f uid=%d y=%.3f "
                                    "lim=%.3f rc=%.2f x0=%.1f x1=%.1f inY=%d\n",
                                    (long long)K.t, x, sp->uid, (double)c.y,
                                    limU, rcU, x0, x1, inYU ? 1 : 0);
                    // [2026-08-21 r40] **No grace on the exit side.** The push-out
                    // is a geometric constraint, not a "ride", so it no longer
                    // applies on the tick the contact point exits the span. The
                    // constant 1.5 can be smaller than one tick's movement
                    // (dx=1.613 here), grabbing one extra tick GD has let go.
                    // Measured lv18 (upright cube, ceiling ramp uid13979
                    // span [27,750, 27,780], line 450->390, pH=15):
                    //   t=20,490 x=27,769.62 rc=27,778.89 (in span) -> both clamp
                    //   t=20,491 x=27,771.24 rc=27,780.51 (**0.51 outside**) ->
                    //     GD free-falls (376.182 = 377.213 - 0.225x4.580); the
                    //     model grabbed via the grace and pulled down 1.178px to
                    //     lim=375.000 (= line(x1) - pH), then ran a parallel
                    //     -1.182 to the end
                    //   (census `m0/mini0/g0/gdg0/sp1.1/air` edy +1.179)
                    // [2026-08-21 r66b] **The flight modes' exit is "until y comes
                    // out below the line".** Measured ceilrel (ship d4 / UFO d0,d4
                    // / swing d0): on the tick rc exits the low end, GD pushes one
                    // more step to **the corner flat (line(x1) - pH = ceilLimAt's
                    // rc-clamped value)** before releasing (169.000 / 165.000
                    // exactly). The push only moves y down, so on the next tick
                    // the free-fall y drops below lim and the contact ends
                    // naturally = the release tick. Cutting the window at rc drops
                    // the corner's 1 tick, the pressed-tick count k also comes up
                    // 1 short, and the release vy (ceil/release) shifts with it.
                    // The cube has no corner tick (lv18 t=20,491, the r40
                    // measurement: GD free-falls on the tick rc is 0.51 out) --
                    // keeps the rc window.
                    // **Only past the exit**: right after rc exits "the low end in
                    // the travel direction", until the centre reaches end + pH.
                    // This was written wrongly twice:
                    //   1) a one-sided condition (x <= x1+pH) -> another ramp
                    //      ahead also enters the window
                    //   2) picking the end by m's sign -> in lv20's W-shaped chain
                    //      (alternating m) the **approach to the next uphill
                    //      ramp** (rc < its x0) was misread as "the reverse exit"
                    //      and jumped 9px to that corner's flat 255.000
                    // The end is decided by the **travel direction**, not m (useDx
                    // is a speed, always positive -- the true direction is K.dxF's
                    // sign or s.rev). Downhill (mTrav<0) only.
                    const bool revU = ((double)K.dxF < 0.0 || s.rev != 0);
                    // [2026-08-21 r80] spider (mode 6) added. Measured lv22
                    // t=8,262 (spider, m=-2 push-down, sp1.1): on the tick rc
                    // exits the span, GD takes the corner flat 436.500
                    // (= line(x1) - pH) for 1 tick before letting go (vy stays
                    // plain gravity, -0.387). Off the whitelist the push ends 1
                    // tick early and that tick alone free-falls (census
                    // `m6/.../sp1.1/air` edy -0.686, re-converges next tick).
                    const bool contU =
                        (c.mode == 1 || c.mode == 3 || c.mode == 6
                         || c.mode == 7)
                        && s.ceilT > 0 && (revU ? -m : m) < 0.0
                        && (!revU ? (rcU > x1 && x <= x1 + pH)
                                  : (rcU < x0 && x >= x0 - pH));
                    // --cubeceilgrace [2026-09-19]: the cube family's underside
                    // branch of collidedWithSlopeInternal (0x3900e9..0x390297)
                    // seats a body that is inside the ramp while `now - mode
                    // switch < 0.1` or `now - gravity flip < 0.1`: setPosition
                    // to the seat, vy := min(vy, -2.0) (0x390276), and it
                    // returns WITHOUT setting m_isOnSlope, so postCollision's
                    // exit launch fires the same tick. No rc window -- lv16
                    // t=9,880 seats at 525.000 with rc outside the span. A
                    // cube arriving there from the ramp's underside
                    // (s.ceilT > 0) is what the model can see of GD's
                    // m_wasOnSlope, which lets it skip the 1-px-inset test.
                    // Which ramp receives it is decided before the seat, by
                    // preSlopeCollision (0x38f2e0): a ramp whose tall edge is
                    // on the side the body has not reached is treated as a
                    // 1-px wall and the slope call returns at once (0x38f499 ->
                    // 0x38f88e) -- the same end-face probe as `vertProbe` in
                    // the acquisition below. Then the boxes must meet, and a
                    // body that was not on a slope last tick (GD's
                    // m_wasOnSlope; the model's s.onSlope / s.ceilT) has to
                    // overlap the ramp by more than the 1-px inset. lv18
                    // t=20,186..20,190 (hitboxtrace): uid13979 (sdir 5)
                    // seats, uid13982 (sdir 6, minX 27,780 ahead of the
                    // centre) only ever shows its 1-px probe band.
                    const uint8_t dG = sp->slopeDir;
                    const bool leftFaceG =
                        (dG == 2 || dG == 3 || dG == 4 || dG == 6);
                    const bool goingLeftG =
                        ((double)K.dxF < 0.0 || s.rev != 0);
                    const bool probeG = leftFaceG ? (x < sp->cx - sp->hw)
                                                  : (goingLeftG
                                                     && sp->cx + sp->hw < x);
                    const bool wasOnSlopeG = s.onSlope || s.ceilT > 0;
                    const double overlapG =
                        ((double)c.y + pH) - (sp->cy - sp->hh);
                    const bool cubeGraceU =
                        (c.mode == 0 || c.mode == 5 || c.mode == 6)
                        && !probeG
                        && std::fabs(x - sp->cx) < sp->hw + pH
                        && (wasOnSlopeG || overlapG > 1.0)
                        // The age THIS tick, not last tick's: modeT/flipT are
                        // written at the step's end, so s.* is one tick old.
                        // lv18: cube from dump row 20,165, GD seats through
                        // 20,189 (age 24) and not at 20,190 (age 25).
                        && (((c.mode != s.mode) ? 0 : (int)s.modeT + 1)
                                < kFlipGraceTicks
                            || ((gdUpOf(c) != gdUpOf(s)) ? 0 : (int)s.flipT + 1)
                                < kFlipGraceTicks);
                    const bool winU = (rcU >= x0 && rcU <= x1) || contU
                                      || cubeGraceU;
                    // [2026-09-05] **GD ACQUIRES FROM BELOW THE LINE, this does
                    // not.** `c.y > limU` only ever acts once the player is
                    // already through the ceiling; GD takes it while still under
                    // it and LIFTS the player onto the line.
                    // Witness lv19 t=5,465 (ship, sp0.9, ramp uid 3205): GD's y
                    // is this model's OWN limU to three decimals for two ticks
                    // (562.759, then 564.058) while the model is still 0.79 below
                    // and flying on at vy 8.000. It only clamps at 5,467, 1.3 px
                    // and two ticks late, which is lv19's first divergence.
                    // The band and its width are GD's, not fitted: acquisition is
                    // `s*y > s*targetY - tol_u`, and tol_u is 0 unless the mode is
                    // a flight one AND the button is held, in which case it is 1
                    // fresh / 2 continuing (m_wasOnSlope). There is no velocity
                    // test on this side and +0xa1c is not read.
                    // WHY THE PRESS IS THE WHOLE GATE HERE. Every tick in the
                    // corpus where a band of 1.0 could newly seat a player was
                    // tabulated -- 23 of them -- and the press separates them
                    // perfectly: lv19 5,465 is the only one with the button down
                    // and the only one where GD is on the line. The gap does not
                    // discriminate at all; three of the 22 sit CLOSER to the line
                    // (0.063, 0.424, 0.448) than the one real seat at 0.792.
                    // NOT MODELLED: bVar22 and bVar9, the other two terms of GD's
                    // band gate. Neither separates anything in this corpus (the
                    // press already accounts for all 23), so they are left out
                    // rather than guessed at.
                    // FRESH vs CONTINUING is read off the previous tick's seat,
                    // not off a flag. Setting State::onSlope from here was tried
                    // and is wrong: that field drives the FLOOR ride machinery
                    // (slopeM / slopeT / slopeUid and the exit launch), so a
                    // ceiling seat marked with it produced a spurious
                    // slopeExitVy -- lv19 first divergence 5,467 dvy +2.291 and
                    // the level died at 5,568 having previously completed.
                    // The block below already has the idiom: while stuck, s.y is
                    // exactly the previous tick's line, which is what `freshU`
                    // tests a few lines down. Same test, no new state.
                    const bool flightU = (c.mode == 1 || c.mode == 3
                                          || c.mode == 4 || c.mode == 7);
                    const bool seatedPrevU =
                        std::fabs((double)s.y - ceilLimAt(xPrev)) <= 0.001;
                    const double tolU =
                        (flightU && input && !c.onSlope
                         && !ceilContNow)
                            ? (seatedPrevU ? 2.0 : 1.0)
                            : 0.0;
                    if (inYU && winU
                        && (double)c.y > limU - tolU) {
                        // Reached from UNDER the line: the branch below is the
                        // push-out, which assumes the player was through it.
                        const bool seatU = ((double)c.y <= limU);
                        YSET(c.y) = (float)limU;
                        // GD's write on the underside is `vy := min(vy, 0)`
                        // upright -- it cuts the climb and does not land (no
                        // hitGround, so the +-5.0 gate is the floor's business).
                        // lv19 5,465: vy 8.000 -> 0.000 on the seat tick, then
                        // plain gravity -0.069 / -0.138 once the press ends.
                        // --upceilv3: V3 (`min(vy, 0)`) is the underside
                        // branch's write on EVERY contact (the 2026-09-06 note
                        // below: V3 and V4 are its only velocity writes), not
                        // only on one reached from under the line. lv16
                        // t=14,307..14,316: an upright ship held up against a
                        // descending 45-degree ceiling ramp (uid7217) is pushed
                        // out each tick; GD reads vy 0 throughout, the model
                        // kept the hold's +0.108/tick because the push-out
                        // skipped V3. UNVERIFIED in the bytes for this arm.
                        if (!seatU && (double)c.vy > 0.0)
                            VYSET(c.vy) = 0;
                        if (cubeGraceU && (double)c.vy > -2.0) {
                            VYSET(c.vy) = -2.0f;           // 0x390276's min
                            CLAMP0O("slope/cubegrace", sp);
                        }
                        if (seatU) {
                            if ((double)c.vy > 0.0) VYSET(c.vy) = 0;
                            // ...and GD clears m_isOnGround / m_isOnGround2 on
                            // the underside branch. It does NOT call hitGround,
                            // so nothing here lands.
                            c.grounded = 0;
                        }
                        // r66: the release vy counts. **Downhill only (the line
                        // descends in the travel direction)**: on leaving the hang
                        // of a rising ceiling (slope/ceillim's hang) GD emits no
                        // release set -- lv16 t=3,281 / lv19 t=5,465 (both
                        // rise->hang; GD just droops from vy 0 under plain g)
                        // became new families from the mark alone.
                        // (useDx is a speed, always positive, so direction is revU)
                        // The grace seat leaves m_isOnSlope clear, so it is not
                        // a press: the exit launch fires on this very tick.
                        if ((revU ? -m : m) < 0.0 && !cubeGraceU) {
                            ceilPressedNow = true;
                            ceilPressM = m; ceilPressMode = c.mode;
                        }
                        // [2026-08-20 r36] **The push-out drops vy to the face's
                        // value too.** The lv20 t=18,826 measurement above says so
                        // ("GD y=271.812 -> 268.021 (**vy=-2.000**)"), yet only y
                        // was applied. Second example lv18 t=20,479 (upright cube,
                        // ceiling ramp uid13979 m=-2, charging into the line at
                        // vy=+3.076): GD sets vy=-2.000 on the same tick, then
                        // plain gravity at -0.215/tick (20,480 -2.215 / 20,481
                        // -2.430 ...) while the clamp pulls y along and continues.
                        // The identity of family `m0/mini0/g0/gdg0/sp1.1/air`
                        // edvy=-4.861.
                        // Value and sign follow the same rule as the ceiling-ramp
                        // acquisition's +-2.000 (the `slope/ceillim` note, dir
                        // following the face).
                        // **Written as "capped at -2.000" so it only takes effect
                        // on the acquisition tick** -- while riding, gravity is
                        // already below -2.
                        // [2026-08-21 r64] **"Capped at -2" fires every tick.**
                        // The note above expected "while riding, gravity is
                        // already below -2", but **while pressing it never goes
                        // below**. Measured lv20 t=18,826..18,830 (ship, sp0.7,
                        // held=1):
                        //   GD  -2.000 -> -1.892 -> -1.784 -> -1.676 -> -1.568
                        //       (+0.108/tick = the ship's holdStrong)
                        //   the model reset to -2.000 every tick (census
                        //   `m1/.../clamp:slope/upceil/uid15572/air` edvy +0.108)
                        // GD places it **once, on the contact tick**. The gate is
                        // whether it was below the previous tick's line
                        // (ceilLimAt(xPrev)) -- while stuck, s.y is exactly that
                        // line, so it never fires again.
                        // The value is 0 **for the spider only**. 3 measurements:
                        //   lv20 t=18,826 ship   vy -1.046 -> **-2.000**
                        //   lv18 t=20,479 cube   vy +3.076 -> **-2.000**
                        //   lv22 t=8,259  spider vy +3.440 -> **0.000**
                        const double dirU =
                            (m * (double)useDx >= 0.0) ? 1.0 : -1.0;
                        const double limUPrev = ceilLimAt(xPrev);
                        // The gate is "did **this clamp place it** on the previous
                        // tick too", not "was it below the line". lv20 t=18,826's
                        // player is already 1.67px below the line (270.14) at the
                        // start of the tick, but the previous tick did not clamp
                        // (rcU outside the span) -- written as "was below", it
                        // stopped firing.
                        // While stuck, s.y is exactly the previous tick's lim.
                        const bool freshU =
                            std::fabs((double)s.y - limUPrev) > 0.001;
                        // [2026-08-21 r66e] **While being pressed down, re-clamp on
                        // the input's release edge too.** Measured lv20
                        // t=18,826..18,842 (ship, sp1.1, a pressed-down section
                        // with holds mixed in): after the catch's -2.000,
                        // holdStrong brings vy back up to -1.568, but on the held
                        // 1->0 tick (18,831) GD **places -2.000 again**. The
                        // release edges at 18,836 / 18,842 have vy already below
                        // -2, no-ops -- consistent at 3 points. No re-clamp while
                        // pressing continues (e.g. the press edge at 18,833).
                        const bool holdRelU = s.held && !input;
                        // [2026-09-06] **The +-2.000 is GD's V4 (bVar24), and
                        // none of the three gates above is GD's.** This site is
                        // `!c.flip && ceilRamp`, i.e. m_isUpsideDown=0 and
                        // isTop=1, so it is always the UNDERSIDE branch, where
                        // the only velocity writes are V3 (`min(vy,0)`, already
                        // done at the seat above) and V4 @0x3909d5. V4 is
                        // signed by m_isUpsideDown alone -- -2.0 upright, along
                        // gravity -- and is gated on `!m_jumpBuffered &&
                        // flight-mode && bVar22`, not on the gradient (`dirU`),
                        // not on the contact being fresh and not on a
                        // hold-release edge.
                        // Witnesses, all from GD's own dump of the shipped
                        // lv16/lv18 plans (button = the plan's press tick plus
                        // the mode's latency, which is what `input` already is
                        // here; the phase is 100% of 4,156 free-flight ship
                        // ticks in lv9/lv10/lv11/lv16 against the thrust sign):
                        //   lv16 p2 8,875/8,876 held  -> 0.000 (V3 only)
                        //   lv16 p2 8,877     released -> **-2.000**
                        //   lv16 p1 14,307..14,343 held -> 0.000 every tick
                        //   lv16 p1 14,344/14,350/14,352/14,355 released ->
                        //        **-2.000** each time, the SAME contact firing
                        //        four times ("once" is not a latch)
                        //   lv16 p1 14,358 released -> **no write**: the tick's
                        //        own gravity step had already taken vy to
                        //        -2.030, past the gate's -2.0
                        //   lv16 p1 14,588 released -> -2.000 from vy=+7.387
                        // The three witnesses the old comment above cites
                        // (lv20 18,826 / lv18 20,479 / lv22 8,259) are all
                        // outside the current corpus or no longer fire, so the
                        // `mode == 6` value and the `freshU || holdRelU` gate
                        // had no live evidence left.
                        // The CUBE FAMILY keeps the old branch: a cube/ball/
                        // robot/spider can set neither nudge flag, and what it
                        // gets on the underside is the crush push V0
                        // (0x39028b), which lv18 t=20,178's -2.000 is.
                        if (slopeNudgeMode(c.mode)) {
                            const float vN = slopeNudge(c.vy, c.flip != 0,
                                                        sp->slopeDir, c.mode,
                                                        input);
                            if (vN != c.vy) {
                                VYSET(c.vy) = vN;
                                CLAMP0O("slope/upceil", sp);
                            }
                        } else {
                            const double vClampU = (c.mode == 6) ? 0.0 : -2.0;
                            if (dirU < 0.0 && (freshU || holdRelU)
                                && (double)c.vy > vClampU) {
                                VYSET(c.vy) = (float)vClampU;
                                CLAMP0O("slope/upceil", sp);
                            }
                        }
                    }
                }
                if (c.flip && ceilRamp && !sp->slopeHazard && c.mode != 7) {
                    const double rc = x + (m > 0 ? -slopeXOffset(m, pH)
                                                 : slopeXOffset(m, pH));
                    const double lim = ceilLimAt(x);
                    // ...and the player has to be IN the object, not merely over
                    // its x span. rc alone teleported lv16's flipped dual body
                    // from y=877.57 down to 770.38 (the ramp's limit, 107 px away)
                    // because the ramps at x=28,425 sit under it: the same segment
                    // fell 296 -> 236 followed ticks. The y test is the ramp's own
                    // box, which is what "inside the solid half" needs.
                    const bool inY = ((double)c.y + pH >= sp->cy - sp->hh)
                                  && ((double)c.y - pH <= sp->cy + sp->hh);
                    if (g_slopeDbg)
                        std::printf("ceilpush t=%lld x=%.3f uid=%d y=%.3f "
                                    "vy=%.3f lim=%.3f rc=%.2f x0=%.1f x1=%.1f "
                                    "inY=%d sOn=%d sG=%d cOn=%d\n",
                                    (long long)K.t, x, sp->uid, (double)c.y,
                                    (double)c.vy, lim, rc, x0, x1,
                                    inY ? 1 : 0, (int)s.onSlope,
                                    (int)s.grounded, (int)c.onSlope);
                    // [2026-08-21 r74] The exit-side +1.5 is the "corner flat's 1
                    // tick" grace, and that 1 tick is not a constant but the
                    // **movement |useDx|** (same conclusion as rideGrace / the
                    // sampleAt-side cornG). ceilramp unit4 (flipped ship m=2,
                    // dx=1.297): the release tick's rc is x1+1.365 -- falls in the
                    // (dx,1.5] phase, and only this window grabbed 1 extra tick,
                    // keeping the y pin and vy=0, so the launch (-7.880) was 1
                    // tick late (the swing never reaches this branch, mode!=7, so
                    // the sampleAt-side fix closed it first).
                    if (inY && rc >= x0
                        && rc <= x1 + std::fabs((double)useDx)) {
                        // Inside the ramp the flipped player is either pushed out
                        // of the solid half or in free flight -- it never HANGS
                        // from a ceiling ramp. GD's own standtrace says so: over
                        // the whole pass it lists uid26823 as `m_currentSlope` on
                        // exactly ONE tick (19,837) and `[-]` on every other.
                        // Without the skip the ordinary ride grabs the player two
                        // ticks later (t=19,842, sampling the ramp's far edge) and
                        // parks it at 299.54 where GD is still falling at 304.68.
                        // THIS is the branch that lv22's last divergence block
                        // runs through (2026-08-14, t=4,636, x=6,705, a cube one
                        // tick after the swing->cube portal, ramp uid4359
                        // (id1743, (6705,435), m=-1). The push-out is already
                        // RIGHT: line(6704.98) = 435.02 and 435.02 - (pH +
                        // slopeXOffset(m,pH)) = 413.81, which is GD's 413.802.
                        // What GD does and this does not is call it STANDING --
                        // it reads onGround=1 and JUMPS off the underside the
                        // next tick at vy=-2.390, while the model stays airborne
                        // and falls for 739 ticks.
                        // Setting `c.grounded = 1` here alone is a NO-OP
                        // (measured: 749 divergent ticks before and after): the
                        // flag does not survive, because the next tick's support
                        // scan only re-acquires a ramp when `!s.flip` and only
                        // when `s.onSlope` is already set -- neither holds. The
                        // three have to move together, and the `!s.flip` half is
                        // the one that took lv16 from CLEARED to STUCK once
                        // before, so it needs its own A/B.
                        // [2026-08-19 D7b] A flipped ship's hang acquisition is
                        // **the gravity mirror of the seat +1.0 snap**: lv16
                        // t=4,128, GD lifts a free climb 423.26 by +0.85 to
                        // lim=424.102 (= the hang line), og=1, vy=0. The model
                        // waited for the crossing and was 2 ticks late.
                        // The gate is the same shape as slopeland: mirrored
                        // downhill only (uphill in the world along travel), rising
                        // along gravity, within 1.0px short of lim, entry side
                        // +0.8.
                        // ...the **ride** after acquisition follows the line by
                        // the same lift (vy=0 while riding, so with only a vy>0
                        // gate the final +0.405 to 4,142's high-end corner
                        // (line(x1)-pH = 435.000) never appears -- GD stands at
                        // 435.000 until 4,146).
                        const bool hangSnap =
                            c.mode == 1
                            && ((double)c.vy > 0.0
                                || (s.onSlope && s.grounded))
                            && ((((double)K.dxF < 0.0 || s.rev != 0) ? -m : m)
                                > 0.01)
                            && ((((double)K.dxF < 0.0 || s.rev != 0))
                                    ? (rc <= x1 - 0.8) : (rc >= x0 + 0.8))
                            && (double)c.y <= lim
                            && lim - (double)c.y <= 1.0;
                        if ((double)c.y > lim || hangSnap) {
                            YSET(c.y) = (float)lim;
                            // vy: TWO cases share this pin. A body moving AWAY
                            // from the surface (falling through from above,
                            // lv21 t=19,837, vy=-9.884) keeps its vy -- the
                            // original measurement. A body moving INTO it
                            // (the flipped body rising onto the ramp's
                            // underside -- its own floor) is LANDING and GD
                            // zeroes the velocity: lv16 first dual, t=7,755,
                            // p2 (flipped cube) hits uid3341's underside at
                            // exactly 574.900 with vy 12.23 -> 0, then rides
                            // the line down at vy=0 for 50+ ticks. The model
                            // kept the +12 and rocketed off at the release,
                            // which is where the dual section's plans and GD
                            // split (the model's p2 ran 5.7 px high in
                            // parallel and the spike-row deaths at t=8,80x
                            // were planned around a p2 world that was wrong).
                            // CUBE ONLY -- the measurement is a (dual) cube's.
                            // Letting the BALL take it froze lv22's rotated
                            // ball section at t=6,010 for 8 straight
                            // iterations (proof run 3): the ball's underside
                            // contact keeps its momentum (it bounces/rolls),
                            // and zeroing it erased the route the same build
                            // had cleared with in the morning.
                            // ...and DUAL only: both measurements are the
                            // dual p2's, and letting the single-player
                            // flipped cube of lv22's rotated complex take
                            // them (with the centre rule below) erased the
                            // route the same-day 44-iteration run had used
                            // (t=6,010 pin, proof runs 3-5). quick_regress
                            // cannot see rotated frames, so "no regressions"
                            // was blind here.
                            // [2026-08-18] The BALL is the same **in a non-rotated
                            // world**. The basis of the exclusion above was "lv22's
                            // rotated ball section (t=6,010) froze for 8
                            // iterations", and that is frame != 0. Measured lv16
                            // t=13,104 (a flipped mini ball hits uid6592's
                            // underside at 4.418): GD zeroes vy and just slides
                            // down the line for 50+ ticks. The model held the
                            // 4.547 for 1 tick.
                            // The frame==0 gate means "no positive evidence in
                            // rotated sections", preserving lv22's counter-example
                            // as is.
                            // [2026-08-19 D7b] The SHIP too: hitting the underside
                            // while **rising** is a landing = vy to 0 (lv16
                            // t=4,128: vy +6.35 -> 0.000, and vy stays 0 through
                            // the 13 riding ticks after -- the census edvy -6.400
                            // was the model holding the 6.4). The side falling
                            // away (lv20 uid26823, vy -9.884 kept) is outside the
                            // vy>0 gate, as before. frame==0 restriction for the
                            // same reason as the ball (no positive evidence in
                            // rotated sections).
                            // [2026-08-21 r72] The UFO too. The calibration rig
                            // ceilramp's 6 UFO cells (unit18-23, all |m| x mini)
                            // share the signature: y stays bit-identical to the
                            // line while vy alone accumulates +g (0.129, mini
                            // 0.152)/tick (GD is 0.000 throughout the ride). The
                            // pin here places y and grounding every tick, yet
                            // mode 3 was missing from vy's whitelist, and for
                            // flight modes the grounded flag does not stop gravity
                            // integration -- another mouth of the ship's hole.
                            // robot/spider are symptom-free because grounding
                            // stops their gravity.
                            // [2026-08-21 r88] **The hanging ride, too, runs the
                            // ship's ladder "only while pressing"** -- the mirror
                            // of the floor side's r39a (`c.mode==1 && input` ->
                            // acquisition 2.000 x dir, then its own g). The
                            // calibration rig **ceilhold** (ceilramp's geometry
                            // plus one press window) has all 6 ship cells
                            // (|m| 1/0.5/2 x normal/mini) in the same shape:
                            //   press-start tick   GD vy = **-2.000** exactly
                            //   after              -2.086 / -2.172 ...
                            //                      (mini -2.101 / -2.202 ...
                            //                       = that mode's own g itself)
                            //   from the release tick GD vy returns to **0.000**
                            // The corpus's lv18@3,010 (mini ship, m=-1, in=1,
                            // edvy -1.899) is this one tick of pressing.
                            // The ladder is left to its own integration
                            // (accumulating g from s.vy is bit-identical to GD).
                            // **The entry marker is s.vy==0** -- an unpressed ride
                            // keeps vy pinned at 0, so the same discriminator as
                            // the floor side works.
                            // [r89] The release-to-0 applies to the **UFO too**
                            // (the rig's 6 UFO cells: while pressing, plain decay
                            // from its own jump -6.871/-6.648 is bit-identical to
                            // GD, and on the release tick only GD returns to
                            // 0.000). A pressing UFO gets nothing = left to its
                            // own decay.
                            const bool contH =
                                s.onSlope && c.slopeM == (float)m;
                            bool flyHangRide = false;
                            // [2026-09-06] **This block is `c.flip &&
                            // ceilRamp`, so it is always the GRAVITY-FACING
                            // side** (m_isUpsideDown=1, isTop=1, XOR=0), and
                            // there GD does exactly two things: `hitGround`
                            // @0x3907ad zeroes vy every ride tick, UNLESS
                            // bVar3/bVar20 is set (`m_jumpBuffered && flight &&
                            // !bVar22`), in which case the landing block is
                            // skipped entirely and V5 @0x390a19 assigns
                            // -2.0 flipped / +2.0 upright once the gate lets it.
                            // The ladder that used to live here (2.0 * dirH,
                            // then kShipRampG) was the gradient's sign and a
                            // rule of its own; GD has neither -- what follows a
                            // V5 write is the mode's own updateJump step,
                            // because hitGround is not running.
                            // Witness, GD's dump of the shipped lv16 plan:
                            //   p1 8,699..8,719 (flipped ship, ceiling ramp
                            //   uid3763, released) -> vy 0.000 for 21 ticks;
                            //   8,720, the first held tick -> **-2.000**, and
                            //   the seat still writes y (539.000) on that tick.
                            //   p2 18,689 held -> -2.000; 18,690 held but
                            //   vy=-2.101 already past -> **no write and no
                            //   zeroing** (hitGround stayed skipped);
                            //   18,691/18,692 released -> 0.000; 18,693 and
                            //   18,695 held -> -2.000 again.
                            // The `contH` guard on the zeroing is the model's,
                            // not GD's: a body merely falling through the line
                            // (lv21 t=19,837) keeps its velocity here, and that
                            // is measured. Only the ride continuation is zeroed.
                            const bool nudgeHere =
                                slopeNudgeMode(c.mode);
                            if (nudgeHere
                                && slopeSkipsHitGround(c.flip != 0,
                                                       sp->slopeDir, c.mode,
                                                       input)) {
                                VYSET(c.vy) = slopeNudge(c.vy, c.flip != 0,
                                                  sp->slopeDir, c.mode, input);
                                flyHangRide = true;
                            } else if (nudgeHere && contH) {
                                VYSET(c.vy) = 0.f;       // V1, hitGround @0x39c164
                                flyHangRide = true;
                            } else if (nudgeHere) {
                                // nothing to continue: the generic clamp below
                                // --hangland [2026-09-19]: ...but a FRESH
                                // contact on this side is hitGround's too, and
                                // its 5.0 gate (in the gravity frame) decides
                                // it. lv16 t=9,270 (dual p1, flipped ship): the
                                // ramp uid4032 comes down 0.807/tick onto a
                                // body moving 0.77/tick the same way, s*v =
                                // 3.42 -> GD lands it, vy 0, onGround 1; the
                                // model kept -3.42 for a tick. lv21 t=19,837's
                                // kept -9.884 (above) is s*v = 9.884, the
                                // other side of the same gate.
                                if ((double)c.vy * (c.flip ? -1.0 : 1.0)
                                    <= kSlopeLandV) {
                                    VYSET(c.vy) = 0.f;
                                    flyHangRide = true;
                                }
                            } else if (c.mode == 1 && input) {
                                const double dirH =
                                    (m * (double)useDx >= 0.0) ? 1.0 : -1.0;
                                if (!(contH && s.vy != 0.0f))
                                    VYSET(c.vy) = (float)(2.0 * dirH);
                                flyHangRide = true;
                            } else if ((c.mode == 1 || c.mode == 3)
                                       && !input && contH) {
                                // Release returns to 0. **Limited to a ride
                                // continuation** -- a craft falling from above
                                // through the line (lv21 t=19,837's vy=-9.884)
                                // has s.onSlope unset, so as before.
                                VYSET(c.vy) = 0.f;
                                flyHangRide = true;
                            }
                            if (!flyHangRide
                                && ((c.mode == 0 && s.dual)
                                    || ((c.mode == 2 || c.mode == 1
                                         || c.mode == 3)
                                        && c.frame == 0))
                                && (double)c.vy > 0.0) VYSET(c.vy) = 0.f;
                            // ...and GD calls that STANDING (onGround=1 at
                            // t=4,636, then a jump at vy=-2.390). The flag only
                            // survives if the ramp is remembered too -- the
                            // next tick's support scan needs `s.onSlope` and,
                            // for a flipped player, a CEILING ramp (see there).
                            // [2026-08-21 r91] **A jump tick folds the ride.** The
                            // y step (the seat) is taken (GD's jump-tick y also
                            // follows the line -- the same asymmetry as the floor
                            // side's 9878), but keeping onSlope makes **the uphill
                            // launch overwrite the jump velocity on the next
                            // tick**. Calibration rig ceilhold's cube: GD decays
                            // under plain gravity, -13.031 -> -12.815, while the
                            // model wrote -7.405 (= slopeExitVy(1,cube)) on the
                            // next tick and fell back onto the ramp (dy 46px).
                            if (!impulsedThisTick) {
                                c.grounded = 1;
                                // grounded here IS the landing, so the ride
                                // carries it (State::rideLanded). Setting the
                                // flag only at the main seat left this path
                                // writing onSlope with rideLanded clear, and
                                // the exit then refused a launch GD makes --
                                // lv16 t=13,117, mini ball, GD -5.179.
                                c.rideLanded = 1;
                                c.onSlope = 1;
                                c.slopeM = (float)m;
                                // the ramp the ride began on (State::slopeUid0)
                                c.slopeUid0 =
                                    s.onSlope ? s.slopeUid0 : sp->uid;
                                c.slopeUidNow = sp->uid;
                            }
                        }
                        continue;
                    }
                }
                if (!c.flip && ceilRamp) {
                    // The ceiling's contact point is the MIRROR of the floor's,
                    // so `smp` is the wrong window to open this test with. On
                    // lv20's (6195,325) 340->310 the mini ship reaches x=6182.6
                    // while the floor sample is still at 6178.9, left of the
                    // ramp -- the test was skipped, and by the next tick the
                    // ship was already 1.4 px past the limit, so the
                    // came-from-below gate failed too and the ride below lifted
                    // it 22.5 px onto the ramp's top. Ship only; the other
                    // modes keep the floor window.
                    const double rc = x + (m > 0 ? -slopeXOffset(m, pH)
                                                 : slopeXOffset(m, pH));
                    // TWO CONTACT REGIMES, with different timing (both
                    // measured on the 2026-08-17 references):
                    //  - IN-SPAN: the contact point rc is inside the ramp's
                    //    span; the LINE presses the ship. Resolves on the
                    //    tick that CROSSES the (moving) limit -- lv20
                    //    t=14,404 (uid12025, m=-0.5): s.y is 0.28 BELOW
                    //    lim(xPrev) and GD still snaps to lim=185.584 /
                    //    vy=-2.000 that tick, because the descending line
                    //    came down onto it. The old came-from-below gate is
                    //    exactly right here.
                    //  - CORNER: rc has left the span but the BOX still
                    //    overlaps the ramp's LOW corner (a V-valley: lv16
                    //    x=23,490, 570->540 meets 540->570). GD contacts
                    //    the corner at exactly corner-pH = 525.000, and
                    //    only on the tick whose START y is already inside
                    //    (t=15,366 sits 0.889 inside, still free; snap at
                    //    t=15,367). With the rc-only window this test was
                    //    skipped outright and the valley was bought by
                    //    fixups on every solve.
                    const bool inSpan = (rc >= x0 && rc <= x1 + 1.5);
                    // ...but the ramp's low END is only a CORNER if the line
                    // actually turns there. Two ceiling ramps of the SAME sign
                    // laid end to end share an edge and a y exactly like a
                    // V-valley does, and the shared-edge test in ceilLimAt
                    // above (which exists to EXTEND the line across that join)
                    // cannot tell them apart -- only the neighbour's SIGN can.
                    //
                    // lv16 t=3,281 (x=4,433) is the straight case: uid1077
                    // (4380..4440, 330->360) is continued by uid1065
                    // (4440..4500, 360->390), both m=+0.5, and the model called
                    // uid1065's left end a corner while the ship was still
                    // being carried by uid1077's line. It then fired the corner
                    // RELEASE and left at vy=-2.762 where GD simply free-falls
                    // from 0 (-0.069/tick, its own gravity). That is the whole
                    // of this family: the same three lines in fixcensus
                    // (lv16 t=3,281 / t=4,024, lv20 t=14,018).
                    //
                    // The real valley at lv16 x=23,490 is uid7606 (m=-1.0)
                    // meeting uid7640 (m=+1.0): opposite signs, so the surface
                    // just before the corner is ABOVE it and the ship really
                    // does separate there. No neighbour at all = an exposed low
                    // tip, which is a corner too -- that is why the default is
                    // "corner" and only a same-sign continuation cancels it.
                    auto cornerContinued = [&](void) {
                        const double edge = (m < 0) ? x1 : x0;
                        const double edgeY = (m < 0) ? sp->sy1 : sp->sy0;
                        for (const Obj* nb : *K.slopes) {
                            if (nb == sp || nb->slopeHazard) continue;
                            const double nx0 = nb->cx - nb->hw;
                            const double nx1 = nb->cx + nb->hw;
                            if (nx1 <= nx0) continue;
                            const double nm = (nb->sy1 - nb->sy0) / (nx1 - nx0);
                            if (nm == 0.0) continue;
                            if (!slopeIsCeiling(nb->slopeDir)) continue;
                            // meets at the same edge, at the same height, and
                            // keeps going the same way -> no turn, no corner
                            const bool joins = (m < 0)
                                ? (std::abs(nx0 - edge) <= 0.5
                                   && std::abs((double)nb->sy0 - edgeY) <= 0.5)
                                : (std::abs(nx1 - edge) <= 0.5
                                   && std::abs((double)nb->sy1 - edgeY) <= 0.5);
                            if (joins && (nm > 0.0) == (m > 0.0)) return true;
                        }
                        // [2026-08-19] **A flat solid also continues the ceiling.**
                        // Even when the neighbour is not "a ramp of the same
                        // sign", if a **plate with an underside at the same
                        // height** abuts the low end, the ceiling is not
                        // interrupted and the player does not separate from the
                        // face there = not a corner.
                        // Measured lv18 t=8,461 (upright ship, sp0.9): flat slab
                        // uid5599 (box (11310,360,30,14), underside 360, right
                        // edge 11,340) sits exactly against the low end of ceiling
                        // ramp uid5597 (sy0=360 @ x0=11,340, sdir=3). GD stops at
                        // y=345.000 (=360-pH) with vy=0; the next tick is plain
                        // gravity (-0.069) only.
                        // The model read the low end as "an exposed corner" and
                        // fired the corner release (-2.762) -- the "neighbour is a
                        // plate" case of the same family as lv16 t=3,281 above.
                        if (K.near) {
                            for (const Obj* nb : *K.near) {
                                if (nb->type != 0) continue;
                                const double face = nb->cy - nb->hh;
                                if (std::fabs(face - edgeY) > 0.5) continue;
                                const bool touches = (m < 0)
                                    ? (std::fabs((nb->cx - nb->hw) - edge) <= 0.5)
                                    : (std::fabs((nb->cx + nb->hw) - edge) <= 0.5);
                                if (touches) return true;
                            }
                        }
                        return false;
                    };
                    const bool cornerReg = (c.mode == 1) && !inSpan
                        && (m < 0 ? (rc > x1 && (double)x - pH <= x1 + 0.5)
                                  : (rc < x0
                                     && (double)x + pH >= x0 - 0.5))
                        && !cornerContinued();
                    // [2026-08-21 r41] **The cube is gated on the mirrored contact
                    // point too.** The note at 8386 above says "the ceiling's
                    // contact point is the **mirror** of the floor's, so smp is
                    // the wrong window to open this test with", yet only the ship
                    // was fixed and the cube stayed on `smp.ok` (the floor-side
                    // window). The floor-side r is off from the ceiling-side rc by
                    // 2*slopeXOffset = 18.5px, so **the floor window stays open
                    // even after the contact point exits the span**.
                    // Measured lv18 (upright cube, ceiling ramp uid13979
                    // span [27,750, 27,780], line 450->390, pH=15, dx=1.613):
                    //   t=20,490 rc=27,778.89 (in span)  GD and the model both clamp
                    //   t=20,491 rc=27,780.51 (**0.51 outside**); the floor-side
                    //     r=27,761.97 is still inside the span -> only the model
                    //     grabs and pulls down 1.178px to lim=375.000
                    //     (=line(x1)-pH). GD free-falls (376.182 = 377.213 -
                    //     0.225x4.580). A parallel -1.182 remains to the end
                    //     (census `m0/.../sp1.1/air` edy +1.179)
                    // The exit grace 1.5 goes too: the push-out is a geometric
                    // constraint, not a ride, and here it is a constant smaller
                    // than one tick's movement (1.613), so it can only ever "grab
                    // one extra tick GD has let go".
                    // **The window stays `smp.ok`**. This branch not only clamps
                    // but `continue`s at the end to **suppress the ride below**,
                    // so tightening the window makes the ceiling ramp be grabbed
                    // as a floor (the r41 measurement: at lv18 t=20,491 the model
                    // bounced 65px up to 441.064 = line+pH -- exactly the
                    // "came-from-below gate falls too and the ride lifts onto the
                    // ramp's top" that the 8386 note foretold).
                    const bool ceilOk = (c.mode == 1)
                        ? (inSpan || cornerReg) : smp.ok;
                    // [2026-08-21 r42] ...but **the push-down itself** applies only
                    // while the contact point is inside the span. The cube opens
                    // on the floor-side window (`smp.ok`), and the floor's r is
                    // off from the ceiling's rc by 2*slopeXOffset (18.5px here),
                    // so **the push-down keeps going after rc exits the span**.
                    // Measured lv18 (upright cube, uid13979 span
                    // [27,750, 27,780], line 450->390, pH=15, dx=1.613):
                    //   t=20,490 rc=27,778.89 (inside)   GD and the model to 377.21
                    //   t=20,491 rc=27,780.51 (0.51 out) GD free-falls
                    //     (376.182 = 377.213 - 0.225x4.580); only the model pulls
                    //     down 1.178px to lim=375.000 (=line(x1)-pH), and a
                    //     parallel -1.182 remains to the end
                    //   (census `m0/mini0/g0/gdg0/sp1.1/air` edy +1.179)
                    // The ship is measured separately via inSpan/cornerReg, so it
                    // is untouched.
                    const bool rcInSpan = (rc >= x0 && rc <= x1);
                    const double lim = ceilLimAt(x);
                    // The tolerance was 0.001 and that is far too tight for a
                    // player that is ALREADY pressed against the ceiling: it sits
                    // exactly at the limit, so any residual between GD's y and
                    // this formula's throws the gate. Measured on lv16 t=15,270
                    // (ship, sp1.1, ramp uid7585 (23355,675) sy 690->660): GD has
                    // y=664.4371 and ceilLimAt(xPrev)=664.4352 -- the gate missed
                    // by **0.0019 px**, the model free-fell (dy -0.44 against GD's
                    // -1.61 = the line's own slope) and never re-acquired. That
                    // one tick is 26 of lv16+lv20's fixups.
                    // 0.5 was the first try and it OVER-GRABS. The case this gate
                    // exists to exclude (a player riding the ramp's TOP) is
                    // 2*pH = 30 px away, so half a pixel looked free -- but the
                    // player that is merely PASSING under a ceiling ramp comes
                    // within half a pixel of the line all the time. Measured on
                    // lv16 x=4563..4581 (ship, ramps uid1093/1103 sdir 1/3): with
                    // 0.5 the model acquires the ramp and slides while GD flies
                    // on (gdg0 against the model's g1), costing 13 fixups one per
                    // tick across iterations 3-6 and 57 iterations for the level.
                    // 0.05 is 26x the residual this gate has to survive (0.0019)
                    // and 10x tighter than the over-grab: lv16 27 iters / 44
                    // fixups, lv19 26->19, lv21 34->21, lv20 28->37, 21/21 green.
                    // TRIED (2026-08-14) and it is a NO-OP: adding `!c.flip`
                    // here, on the theory that a flipped player hanging under a
                    // ceiling ramp is standing on it and must not be skipped.
                    // The lv22 case it was aimed at (t=4,636, x=6,705, a cube
                    // one tick after the swing->cube portal, ramp uid4359
                    // (6705,435) m=-1) is NOT thrown out here: the replay's
                    // divergence count was 749 ticks before and after, and the
                    // model's y at that tick already equals GD's 413.802.
                    // What is missing there is the GROUNDING, not the height --
                    // GD reads onGround=1 and leaves at vy=-2.390 the next tick
                    // while the model stays airborne at vy=+0.447. The ramp
                    // stops being a candidate at some OTHER gate; `slopeset`
                    // lists uid4359 and neither `slopecand` nor `slopewin`
                    // prints it.
                    // GD resolves the press on the tick whose START position
                    // is already inside the solid, one tick after the move
                    // that crossed the line: the 2026-08-17 lv16 reference
                    // has y=525.889 (0.889 INSIDE) at t=15,366 still free,
                    // and the snap to 525.000 / vy=-2.000 at t=15,367. The
                    // old `s.y <= lim + 0.05` fired on the crossing tick
                    // itself (one early) AND would grab a ship passing just
                    // under the line; requiring s.y to be AT or INSIDE the
                    // limit keeps the ride ticks (s.y == lim exactly) and
                    // the 0.0019 px residual case, and the +2.0 bound (max
                    // penetration is 0.225*8 = 1.8) keeps excluding a ship
                    // riding the ramp's TOP, 2*pH away.
                    const double limPrev = ceilLimAt(xPrev);
                    // Start-inside timing is the CORNER regime's; in-span
                    // (and every non-ship mode) keeps the old
                    // came-from-below gate. Using start-inside for in-span
                    // broke lv20 t=14,404; using came-from-below for the
                    // corner fired the valley one tick early.
                    const bool pressGate = cornerReg
                        ? ((double)s.y >= limPrev - 0.05
                           && (double)s.y <= limPrev + 2.0)
                        : ((double)s.y <= limPrev + 0.05);
                    if (ceilOk && pressGate) {
                        if ((double)c.y > lim
                            && (c.mode == 1 || rcInSpan)) {   // r42: see the rcInSpan note
                            YSET(c.y) = (float)lim;
                            // --ceillimrelease [2026-09-19]: this contact sets GD's
                            // m_isOnSlope like any other, so the tick it ends runs
                            // postCollision's slope-exit launch (0x38d837..0x38d966:
                            // vy := min(vy, sv * max(0.4, 10 * ride seconds))). The
                            // release below (`ceil/release`) already is that
                            // formula, but only `slope/upceil` fed it. lv16
                            // t=14,588: a ship grazes the tip of ceiling ramp
                            // uid7291 (V4 -2.000 here), leaves it at 14,589 and GD
                            // writes -2.762 = 6.906 x 0.4 after the move.
                            if (m * (double)useDx < 0.0) {
                                ceilPressedNow = true;
                                ceilPressM = m; ceilPressMode = c.mode;
                            }
                            // ...and GD does NOT stop the player dead here: it
                            // SETS the velocity to the ride's own +-2.000, the
                            // same number the swing's ordinary ride is set to on
                            // acquisition (see the `2.0 * dir` below) and with
                            // the same sign rule -- it follows the SURFACE.
                            // The `vy > 0` gate is what makes this the
                            // ACQUISITION tick: the player is still rising into
                            // the line, and every later tick of the ride comes
                            // in already descending along it.
                            // Measured on lv16 (GD's own dump for
                            // solution_lv16A, ship, sp1.1, ramp uid7606
                            // (23475,555) sy 570->540, slopeDir 1):
                            //   t=15,319  vy = +6.355  (free flight, rising)
                            //   t=15,320  vy = -2.000  <- SET, y on the line
                            //   t=15,321  vy = -2.069  (its own gravity from there)
                            // The model wrote 0 and then free-fell from 0, so it
                            // ran the whole 37-tick ride 2.0 of velocity light
                            // and left the ramp with the wrong number.
                            // SHIP ONLY -- that is where it is measured, and the
                            // other modes say it is not universal. Applying the
                            // 2.000 to every mode costs follow length in three
                            // places at once (quick_regress, this build):
                            // lv16 t=3,000 400->277, lv18 t=8,200 400->314,
                            // lv22 t=600 400->333 -- all of them cube/ball
                            // sections, i.e. exactly the family the generic
                            // ride's `c.vy = 0` was measured on.
                            if ((double)c.vy > 0.0) {
                                // [2026-09-06] Same site, same rule as
                                // `slope/upceil`: `!c.flip && ceilRamp` is the
                                // UNDERSIDE, so V3 (`min(vy,0)`, and vy > 0
                                // here, hence 0) runs first and V4 @0x3909d5
                                // then places -2.000 while the button is NOT
                                // held. The old form read the SHIP off the
                                // gradient (`dir < 0`), which is the one factor
                                // the disassembly says the sign does not have.
                                // The witness the old comment cites, lv16
                                // t=15,320 (upright ship rising into ceiling
                                // ramp uid7606, GD sets -2.000), is a released
                                // tick, so it survives the change.
                                if (slopeNudgeMode(c.mode)) {
                                    VYSET(c.vy) = slopeNudge(0.f, c.flip != 0,
                                                      sp->slopeDir, c.mode,
                                                      input);
                                } else {
                                    const double dir =
                                        (m * (double)useDx >= 0.0) ? 1.0 : -1.0;
                                    VYSET(c.vy) = (c.mode == 1 && dir < 0.0)
                                               ? (float)(2.0 * dir) : 0.f;
                                }
                                CLAMP0("slope/ceillim");
                            }
                        // [2026-08-21 r78] **While still being pressed on the same
                        // tick, do not fire the valley's corner release.** lv20
                        // t=18,835 (ship, W-shaped chain, sp1.1): uid15572's
                        // (m=-1) exit-continuation window is still pressing on
                        // this tick (ceilPressedNow; GD's release is r66's
                        // ceil/release emitting -2.877 the next tick, 18,836 --
                        // the model matches), yet the corner of the next uphill
                        // ramp uid15570 alone caught cornerReg and double-fired
                        // -2.762 one tick early (census
                        // `m1/mini0/g0/gdg0/sp1.1/air/in1` edvy +0.840 =
                        // 2.762-1.922, a half y step 0.189 to the end).
                        // The original measurement site lv16 t=15,368 (V valley)
                        // fires on the tick the press has ended, so
                        // ceilPressedNow=0 there -- unchanged.
                        } else if (cornerReg && !ceilPressedNow
                                              && (double)s.vy >= -2.05
                                              && (double)s.vy <= 0.05) {
                            // RELEASE tick: the press ends (the ceiling no
                            // longer reaches the free c.y) and GD SETS the
                            // velocity to -2.762 AFTER the move -- the y of
                            // this tick still steps with the lift-updated vy.
                            // Measured on the 2026-08-17 lv16 reference,
                            // t=15,368 (the valley at x=23,490): y goes
                            // 525.000 -> 524.574 = 0.225*(-1.892), i.e. the
                            // ordinary -2.000+0.108 step, while vy comes out
                            // -2.762. The fixup families say the same number
                            // regardless of the press's own vy or the button:
                            // vy=-2 -> -2.762 (dvy -0.762, in0 AND in1) and
                            // vy=0 -> -2.762 (dvy -2.762) across the y=585 /
                            // 525 / 475.9 clusters. Gated to the measured
                            // pressed band [-2.05, +0.05] -- a ship separating
                            // at some other speed is unmeasured. Speed/mini
                            // scaling UNVERIFIED (all measurements are sp1.1
                            // full-size).
                            VYSET(c.vy) = -2.762f;
                        }
                        // ...and this ramp is now DONE with this player. The
                        // ride below must not run: its `insideSolid` branch
                        // assumes the solid is under the line and would lift a
                        // player that came from below onto the ramp's top
                        // (measured here: the clamp put the mini ship at
                        // line-12.73 and the ride then teleported it to
                        // line+12.73, 25 px up). The skip is inside the
                        // came-from-below gate on purpose -- doing it for every
                        // ceiling ramp is what took lv16 from 17 iterations to
                        // STUCK, because a player ABOVE such a ramp rides it
                        // perfectly ordinarily.
                        continue;
                    }
                }
                // ...and print the ones the WINDOW throws away too. The
                // `slopecand` line below sits after this `continue`, so a ramp
                // rejected here left no trace at all -- lv22 t=4,633 spent a
                // diagnosis cycle looking like "the model never sees the ramp".
                // [2026-08-19 corner-stand] While a grounded cube's tip touches
                // the span of a slope that is "downhill in the travel direction",
                // and its centre is still short of the entry-side end, GD **stands
                // it on the top corner (the entry-side line value + pH)**.
                // gdref lv16 measured t=7,048-7,057: a cube walking the slab (top
                // 449.95) sits at exactly y=465.000 from the tick its right edge
                // touches uid3026 ([10530,10560], line 450->420), and returns to
                // the slab's 464.95 on the tick the centre crosses x0 (with a
                // 1-tick fall of vy=-0.215).
                // Item 10's "0.05px sunk-in" (t=6,231 and others) is this corner
                // being missed. The step-height cap 1.0 is the same thematic
                // constant as the acquisition tolerance (only 0.05 is measured;
                // the upper side is unconstrained -- if layer 4 rejects, suspect
                // this). Corner contact from the air is a separate rule (lv20
                // t=5,269's "no landing until penetration > 1.000"), hence the
                // s.grounded gate.
                if (ridesTop && !c.flip && c.mode == 0 && s.grounded
                    && !s.onSlope) {
                    const bool revC = ((double)K.dxF < 0.0 || s.rev != 0);
                    const double mTravC = revC ? -m : m;
                    const double cxE = revC ? x1 : x0;
                    const double cyE = sp->sy0 + m * (cxE - x0);
                    const bool edgeIn = revC
                        ? (x > cxE && x - pH <= cxE + kContactEps)
                        : (x < cxE && x + pH >= cxE - kContactEps);
                    if (mTravC < -0.01 && edgeIn) {
                        const double d = (cyE + pH) - (double)c.y;
                        if (d > 0.0005 && d <= 1.0) {
                            if (g_slopeDbg)
                                std::printf("slopedbg t=%lld x=%.2f uid=%d "
                                            "cornerstand y=%.3f (d=%.3f)\n",
                                            (long long)K.t, x, sp->uid,
                                            cyE + pH, d);
                            YSET(c.y) = (float)(cyE + pH);
                            VYSET(c.vy) = 0; c.grounded = 1;
                            continue;
                        }
                    }
                }
                if (g_slopeDbg && !smp.ok)
                    std::printf("slopewin t=%lld x=%.2f uid=%d m=%.3f "
                                "x0=%.1f x1=%.1f xr=%.2f ridesTop=%d ceil=%d "
                                "REJECTED-BY-WINDOW\n",
                                (long long)K.t, x, sp->uid, m, x0, x1, smp.xr,
                                ridesTop ? 1 : 0, ceilRamp ? 1 : 0);
                // [2026-08-20 r33] **Even when the window drops it, push out if
                // the box is penetrating the ramp's solid.** On 2026-08-19 two
                // "widen the window itself" proposals were tried and rejected
                // (families 27->44 / 27->31; the additions are **over-retention**
                // of `slope+0.50|+1.00/ride...`), and as that conclusion said,
                // what GD does here is a **push-out from the solid**, not a ride
                // continuation, so the rule is needed only on the acquisition
                // side. Over-retention is closed structurally by `!s.onSlope` --
                // a player already riding some ramp never reaches this branch.
                // Measured lv18 t=20,465 (after r32 made the size portal fire on
                // the same tick and the box became 30x30. GD's `slp:` line names
                // uid13971): the centre 27,732.52 is 12.5px past the high end of
                // uid13971 (m=+2, span [27,690, 27,720]), but the box's left edge
                // 27,717.5 is still inside the span and the box bottom 361.64 is
                // below the face (390 at the end) = inside the solid. GD stands
                // it, y 376.641 -> 405.000 (= line(x1) + pH), and emits the m=2
                // launch 5.226 the next tick.
                // Requires **the centre to have already passed "the high end seen
                // along the travel direction"**. The mirror of the existing
                // corner-stand (standing on the entry-side corner); this one is
                // **the exit-side corner**. It is the gate that keeps from
                // grabbing a ramp being merely approached from before it, and the
                // measured pair is:
                //   lv18 t=20,465  m=+2 travel+ -> high end x1=27,720, centre
                //                  27,732.52 = passed -> GD stands it on the
                //                  corner (390+pH)
                //   lv16 t=10,802  m=-1 travel+ -> high end x0=16,590, centre
                //                  16,576.80 = still short -> GD names uid5229 in
                //                  its `slp:` line while never moving y a single px
                // (penetration cannot split them: lv16's is 2.291px, over 1.0)
                const double sgnPO =
                    ((double)K.dxF < 0.0 || s.rev != 0) ? -1.0 : 1.0;
                const double xHiPO = (m > 0) ? x1 : x0;
                bool okHere = smp.ok;
                // [2026-09-08] `!c.flip` REMOVED. It was the only orientation
                // test in this gate, and GD has no counterpart to it.
                //
                // Measured: across lv16/18/20 the +/-2.000 slope-contact
                // assignment fires on an INVERTED body at six of its ten sites,
                // and five of those are mirrored dual rows where the SAME tick
                // carries the assignment on an upright body and an inverted one
                // at once (lv16 t=8,720 / 8,877 / 9,244 / 9,246 / 9,248: p1
                // up=1 and p2 up=0, |vy| = 2.000 on both). A same-tick pair
                // under one input is as close to a control as this corpus gets,
                // and GD does not split on the flag.
                //
                // The restriction the flag was carrying is carried already, by
                // conjuncts that do not mention orientation: `!ceilRamp` keeps
                // this to floor ramps, and `ridesTop` (a position test,
                // `s.y - topPrevUp >= -kLandTol`) keeps it to a player ON TOP of
                // one. The body is shaped for exactly that and needs no mirror:
                // the ridge loop skips ceilings (:6613) and drops a face above
                // the box (:6623), and the seat is `best + pH` (:6628) -- push
                // UP off a floor surface, which is right for a body on top of it
                // whichever way its gravity points. The nudge downstream is
                // already flip-aware (slopes.hpp:180, `gs = flip ? -1 : 1`).
                //
                // Worked at lv16 t=8,732 before this was written, from objrects
                // and the recorded dumps, no run: uid 3748 is sdir=0/sup=1 with
                // x [13190,13220] and sy0=376, so line(x1) = 406; the model's
                // own free y is 419.574707 against GD's pre-write 419.575, so
                // pLo = 404.5747 < 405.0 and the 1.0px penetration gate passes
                // with 1.425. The seat is then 406 + 15 = 421.000 and the nudge
                // -gs*2.0 = +2.000 -- GD's y and vy on that tick, exactly.
                //
                // THIS IS A MEASURED CHANGE, NOT A BUG FIX. The known cost of
                // opening this family is over-retention (the two 2026-08-19
                // proposals above cost families 27->44 and 27->31), and what
                // closes it structurally is `!s.onSlope` (:6540-6541), which
                // still stands. That it does not bite AT THIS SITE was
                // established by enumeration (the nearest ceiling ramp is 133px
                // away against a 15px half); nothing was established about any
                // other level. The regression suite arbitrates.
                // [2026-09-08] The gate's own conjuncts, one field each, so
                // "the branch did not fire" names WHICH conjunct refused
                // instead of leaving a choice between seven. `slopepush` below
                // sits inside the penetration test, so its absence is equally
                // consistent with the gate failing and with the penetration
                // failing -- that ambiguity is what this print removes.
                if (g_slopeDbg)
                    std::printf("pogate t=%lld uid=%d flip=%d y=%.6f notok=%d ridesTop=%d "
                                "notceil=%d notonslope=%d past=%d inx0=%d inx1=%d "
                                "x=%.3f xHiPO=%.1f sgnPO=%.0f x0=%.1f x1=%.1f pH=%.2f\n",
                                (long long)K.t, sp->uid, c.flip ? 1 : 0, (double)c.y,
                                !okHere ? 1 : 0, ridesTop ? 1 : 0,
                                !ceilRamp ? 1 : 0, !s.onSlope ? 1 : 0,
                                ((x - xHiPO) * sgnPO > 0.0) ? 1 : 0,
                                (x + pH > x0) ? 1 : 0, (x - pH < x1) ? 1 : 0,
                                x, xHiPO, sgnPO, x0, x1, pH);
                // --ceilpush (default off): the CEILING push-out the window drops.
                // Measured 2026-09-11/12 from GD's `slp:` lines: a body overlapping a
                // ceiling ramp's rect, and still UNDER its line, is seated at
                // line(x) - pH*sqrt(1+m^2), the line EXTRAPOLATED to the centre x
                // (GD's syAtX) -- also while this window still rejects the ramp
                // (lv22 t=4,622, uid 4359: GD pushes 8 ticks before the window accepts
                // it). The body is under a ceiling line whichever way its gravity
                // points; a body ABOVE the line is on the other face and is not pushed
                // (lv16 t=8,715, uid 3765: GD leaves it where it is, and the first
                // version of this branch dropped it 27.3 px). |m| <= 1 only: at
                // |m| = 2 neither candidate factor fitted.
                // vy: the SWING takes min(vy, -2) -- GD writes -2.000 on the first
                // contact and then lets the ride integrate (-2.086, -2.172, ...), so a
                // ride tick must not rewrite it. That rests on ONE swing episode in the
                // corpus. Every other mode's vy is left alone: the ship's zeroing looks
                // like a separate press mechanism (1468: +0.103 -> 0, but 3868's p2
                // keeps -2.582) and has not been measured. grounded is left alone.
                // The seat is the one slopeSeatTarget computes; --slopedbg prints both
                // (the print is behind g_slopeDbg: in a search stepOne runs on every
                // child from the worker threads).
                // `!s.onSlope`: the same over-retention guard the floor push-out below
                // uses. A body already riding a ramp is the ride code's business: lv16
                // t=8,717, the ship rides the descending neighbour of uid 3765 at a V
                // and GD lets it pass straight through 3765's line (y never moves),
                // while this branch dropped it 20.85 px. On the corpus the guard removes
                // that one misfire and seven firings that changed nothing.
                if (g_ceilPush && !okHere && ceilRamp && !s.onSlope && std::fabs(m) <= 1.0) {
                    const double lineCP = sp->sy0 + m * (x - x0);
                    const double seatCP = lineCP - pH * std::sqrt(1.0 + m * m);
                    const bool boxX = (x + pH > x0) && (x - pH < x1);
                    const bool boxY = ((double)c.y + pH > sp->cy - sp->hh)
                                      && ((double)c.y - pH < sp->cy + sp->hh);
                    if (boxX && boxY && (double)c.y > seatCP && (double)c.y < lineCP) {
                        const double yWas = (double)c.y, vyWas = (double)c.vy;
                        YSET(c.y) = (float)seatCP;
                        if (c.mode == 7 && (double)c.vy > -2.0) VYSET(c.vy) = -2.0f;
                        if (g_slopeDbg)
                            std::printf("ceilpush: t=%lld p%d uid=%d mode=%d m=%.3f "
                                        "x=%.3f y=%.4f->%.4f vy=%.3f->%.3f "
                                        "seatTarget=%.4f\n",
                                        (long long)K.t, g_halfNow + 1, sp->uid,
                                        (int)c.mode, m, x, yWas, seatCP, vyWas,
                                        (double)c.vy,
                                        slopeSeatTarget(sp, x, pH, true, seatOff));
                    }
                }
                // slope law (default on since v0.1.4, --no-slopelaw): GD's OWN acquisition, in place of
                // --ceilpush's one-sided push-out. The predicate is not new
                // here -- `slopeWouldAcquire` (slopes.hpp) has carried it since
                // the 09-05 disassembly, for the solid-veto question. It was
                // never asked the acquisition question, and the ride window
                // `ok` was asked it instead.
                //
                // WHY THE WINDOW IS THE WRONG GATE FOR A FRESH CONTACT. GD's
                // two-stage predicate (measured 2026-09-05) contains no
                // contact point at all:
                //   1. the fresh rect test, playerRect vs the object rect inset
                //      1px top and bottom            0x38fc73 / 0x38fc7b je
                //   2. `s*targetY > s*y` (floor) / `s*y > s*targetY` (underside),
                //      both strict, with targetY built from slopeYPos at the
                //      player's CENTRE x, EXTRAPOLATED past the span
                //                                    0x38fea5 / 0x39000c
                // Both reduce to one inequality: with sigma = isTop ? -1 : +1,
                // acquire iff sigma*(targetY - y) > 0, which is exactly what
                // slopeWouldAcquire returns. The ride window fits the rig
                // (calib_ceilramp cube 6/6, UFO 6/6) because THERE the two
                // candidates cross on the same tick -- stage 2 is what binds
                // there, while on lv21 t=19,724 stage 1 binds and the window is
                // 7 ticks late. 883 fresh calls in the rig's own `slp:` trace
                // agree with this predicate 883/0, and its 20 acquisitions match
                // the seat 20/0.
                //
                // `preVeto` is stage 0: preSlopeCollision's horizontal 1px probe
                // (0x38f887 ... 0x38f88e jne). Reaching a probe makes the WHOLE
                // routine a no-op, and the guard is `isTop ? objMaxY <= pos.y :
                // pos.y <= objMinY + 1` -- the player's centre already past the
                // rect's far edge. It is what keeps this off lv16 t=14,073's
                // uid7124 (objMaxY 473.8 <= y 476.779), where --ceilpush seats
                // 9.86px that GD does not and moves that reference's death 302
                // ticks early. GD takes the ASCENDING neighbour uid7125 there
                // instead, at line(extrapolated) + pH/cos t = 480.679 -- GD's own
                // value to three decimals, and the level's pre-existing first
                // divergence.
                //
                // `freeSide` is UNEXPLAINED-BUT-MEASURED: the body must be on the
                // ramp's non-solid side. lv16 t=8,715 refutes the law without it
                // (uid3765, the ship 6.09px ABOVE that ceiling ramp's line: the
                // law seats it 7.44px down while GD leaves it riding the
                // descending neighbour). The plausible counterpart is
                // preSlopeCollision's OTHER probe -- the vertical strip at the
                // high end, which routes the player through
                // collidedWithObjectInternal as a wall -- but that path is not
                // traced, so this conjunct is empirical. Do not read it as
                // derived.
                //
                // Writes only y, exactly as --ceilpush does, so the two arms
                // differ in the predicate and not in what they do. GD's
                // acquisition also sets m_isOnSlope and enters the ride; that is
                // a separate and much larger change.
                if (!okHere && !s.onSlope) {
                    const double oMinSL = sp->cy - sp->hh;
                    const double oMaxSL = sp->cy + sp->hh;
                    const double lineSL = sp->sy0 + m * (x - x0);
                    const bool preVeto = ceilRamp ? ((double)c.y >= oMaxSL)
                                                  : ((double)c.y <= oMinSL + 1.0);
                    // ...and preSlopeCollision's OTHER probe, the 1px VERTICAL
                    // strip at the ramp's flat face. Same effect -- reaching it
                    // returns 1 and the routine writes nothing -- and the face's
                    // side is read off the direction: {2,3,4,6} carry it on the
                    // LEFT, {0,1,5,7} on the right. The third term of each guard
                    // (`m_isGoingLeft || m_isPlatformer || objDelta.x <>
                    // speed*dt`) collapses on static geometry, where objDelta.x
                    // is 0: the left-face form is then always satisfied, and the
                    // right-face form only for a player travelling left.
                    //
                    // THIS REPLACES `freeSide`, which the first version of this
                    // block carried as UNEXPLAINED-BUT-MEASURED. Its witness is
                    // derived after all: lv16 t=8,715's uid3765 is sdir=3, a
                    // left-face ramp whose minX 13,220 the ship's centre
                    // (13,206.35) has not reached. The `--nofreeside` arm that
                    // dropped the empirical conjunct is gone since the flag
                    // clean-up; the conjunct is part of the rule.
                    //
                    // It costs nothing at the three acquisitions: lv21's uid26823
                    // and the rig's uid34 are both sdir=1 (right face, and the
                    // player is travelling right, so the guard is false), and
                    // lv16's uid7125 is sdir=0 with its maxX ahead of the player.
                    // It vetoes lv16 t=10,806's uid5229 (sdir=4, minX 16,590
                    // against a centre of 16,581.64) -- the seat that starts the
                    // 67-tick chain ending in the spiked death at t=10,875, and
                    // the case the push-out gate below already records GD
                    // refusing ("GD names uid5229 in its slp: line while never
                    // moving y a single px").
                    const uint8_t dSL = sp->slopeDir;
                    const bool leftFace =
                        (dSL == 2 || dSL == 3 || dSL == 4 || dSL == 6);
                    const bool goingLeftSL =
                        ((double)K.dxF < 0.0 || s.rev != 0);
                    const bool vertProbe =
                        leftFace ? (x < sp->cx - sp->hw)
                                 : (goingLeftSL && sp->cx + sp->hw < x);
                    const bool freeSide =
                        ceilRamp ? ((double)c.y < lineSL)
                                 : ((double)c.y > lineSL);
                    if (!preVeto && !vertProbe && freeSide
                        && slopeWouldAcquire(sp, x, (double)c.y, pH, false)) {
                        const double tgtSL =
                            slopeSeatTarget(sp, x, pH, ceilRamp, seatOff);
                        if (g_slopeDbg)
                            std::printf("slopelaw: t=%lld p%d uid=%d mode=%d "
                                        "m=%.3f x=%.3f y=%.4f->%.4f line=%.4f "
                                        "isTop=%d\n",
                                        (long long)K.t, g_halfNow + 1, sp->uid,
                                        (int)c.mode, m, x, (double)c.y, tgtSL,
                                        lineSL, ceilRamp ? 1 : 0);
                        // RECORDED, NOT WRITTEN -- applied after the loop, and
                        // only if nothing else moved the body (see lawSeat's
                        // declaration). The writes themselves are below.
                        lawSeat = true;
                        lawTop = tgtSL;
                        lawUid = sp->uid;
                        lawUnder = slopeUnderside(c.flip != 0, sp->slopeDir);
                        // ...and what the acquisition writes BESIDES y. Two
                        // independent witnesses, one per side, both of them the
                        // measurement that produced this rule rather than a
                        // consequence of it:
                        //   floor  lv16 t=14,073 (uid7125, upright ship, vy
                        //          -4.138): GD's dump turns onGround AND
                        //          onGround2 to 1 and vy to 0 on the acquiring
                        //          tick, and rides +1.613/tick from there. That
                        //          is hitGround, reached from the floor branch,
                        //          whose only gate is the SIGNED s*vy <= 5.0
                        //          (0x39bfc0 vs the double at 0x622E98).
                        //   under  calib_ceilramp dt=528 (uid34, upright cube,
                        //          vy +0.103): GD's `slp:` line reads
                        //          `vy=0.000 dvy=-0.103` -- the underside's
                        //          `vy := min(vy,0)` at 0x390931, which needs no
                        //          velocity gate.
                        // lv21 t=19,724 is the third case and it constrains the
                        // SIGN: flipped on a ceiling ramp is the FLOOR branch
                        // (m_isUpsideDown XOR isTop = 0), s*vy = +9.452 > 5.0, so
                        // GD seats without grounding and leaves vy alone -- which
                        // is what its dump shows. A rule written with |s*vy| or
                        // with the underside's clamp here would have moved that
                        // tick's vy and been wrong.
                    }
                }
                if (!okHere && ridesTop && !ceilRamp && !s.onSlope
                    && (x - xHiPO) * sgnPO > 0.0
                    && x + pH > x0 && x - pH < x1) {
                    const double lineHere =
                        sp->sy0 + m * (std::min(std::max(x, x0), x1) - x0);
                    // [2026-08-22 r98] Penetration is measured with **the y from
                    // before this tick's landing**. Measured lv16 t=17,627: under
                    // a falling cube, a 1.5px slab (top 599.95) and ramp uid8864's
                    // high-end corner (600.000) overlap, and once **the solids
                    // loop that runs first seats it on the slab**, only 0.05 of
                    // penetration remains here and the 1.0px gate fails (GD stands
                    // at 615.000 = corner + pH and emits, the next tick, the m=0.5
                    // launch x the 1-tick-ride factor 0.4 = **+1.989**). With the
                    // pre-landing y there is 1.17px and it passes.
                    const double yPO = landedThisTick ? (double)preLandY
                                                      : (double)c.y;
                    const double pLo = std::max(yPO - pH,
                                                (double)(sp->cy - sp->hh));
                    const double pHi = std::min(yPO + pH, lineHere);
                    // **No push-out until the penetration exceeds 1.0px.** Merely
                    // touching a corner from the air does not land in GD -- the
                    // same constant already in the ball's corner landing (the
                    // ballCornerM note, worker98's bisection 0.9955/1.0055, same
                    // origin as preSlopeCollision's 1px end strip). Put in at
                    // 0.001, the census went 23->24, and the 3 added items' edy
                    // were exactly the then-current penetration amounts:
                    //   lv16 t=10,802 pen 0.362 / lv20 t=5,269 pen 0.230
                    //   (the lv20 one is the ball's corner landing itself, which
                    //    this branch was hijacking from the existing rule)
                    // lv18 t=20,467's ridge has pen 28.359, so it passes.
                    if (pLo < pHi - 1.0) {
                        okHere = true;
                        // **The ridge is decided by "the highest face under the
                        // box".** A single ramp's rotated-box formula cannot
                        // handle an apex: lv18's uid13971 (uphill) and uid14050
                        // (downhill) form an apex at x=27,720, and with the window
                        // merely opened, the later-coming 14050's seat 398.50 wins
                        // and falls 6.5px short of GD's 405 (r32's census kept
                        // exactly that value).
                        double best = -1e18;
                        for (const Obj* nb : *K.slopes) {
                            if (nb->slopeHazard) continue;
                            const bool nceil = (c.mode == 1 || c.mode == 7
                                                || c.mode == 0)
                                ? slopeIsCeiling(nb->slopeDir)
                                : (nb->slopeDir == 1 || nb->slopeDir == 3);
                            if (nceil) continue;
                            const double a0 = nb->cx - nb->hw;
                            const double a1 = nb->cx + nb->hw;
                            if (a1 <= a0) continue;
                            if (x + pH <= a0 || x - pH >= a1) continue;
                            const double nm = (nb->sy1 - nb->sy0) / (a1 - a0);
                            if (nm == 0.0) continue;
                            const double sfc = nb->sy0
                                + nm * (std::min(std::max(x, a0), a1) - a0);
                            // a face sticking out above the box is not a ride surface
                            if (sfc > (double)c.y + pH) continue;
                            if (sfc > best) best = sfc;
                        }
                        if (best > -1e17) {
                            pushOutSeat = true;
                            pushOutTop = best + pH;
                        }
                        if (g_slopeDbg)
                            std::printf("slopepush t=%lld x=%.2f uid=%d m=%.3f "
                                        "line=%.3f y=%.3f ridge=%.3f\n",
                                        (long long)K.t, x, sp->uid, m,
                                        lineHere, (double)c.y, pushOutTop);
                    }
                }
                if (!okHere) continue;
                const double xr = smp.xr;
                // `top` is the resting y: the surface plus the player's half in
                // the PLAYER's frame, so a flipped player hangs under a ceiling
                // ramp at surface - pH.
                // ...and the SWING hangs at the ROTATED-box distance, not at a
                // flat pH. Measured on lv22 uid4359 at t=4,627 (centre
                // 6,691.02, line 448.98): GD rests it at 427.763, i.e.
                // line - 21.21 = line - pH*sqrt(1+m^2) -- the same quantity the
                // upright ride uses, and 6.21 px away from the flat line - 15
                // the ship's branch was measured with (lv16 t=4,111).
                // ...the BALL's hang is the rotated amount too (2026-08-19). lv16
                // t=13,108-13,115: a flipped mini ball slides along the underside
                // of uid6592 (sdir1, line 622->592, m=-1) at line - 12.728 =
                // line - 9*sqrt(2) = line - pH*sqrt(1+m^2) (mini pH=9), and at the
                // end emits slopeExitVy(1) x (13/24) x sp = 3.741 in the flipped
                // direction (the exit machinery's existing flip handling emits it
                // as is). The ceilpushball rig's upright push-down pin is the same
                // amount (16.771/21.213).
                const double hangOff =
                    // [r71b] swing removed from the rotated distance (xr is now
                    // the contact point, so flat pH -- same as the old formula at
                    // m=1, splits first at m=2)
                    (c.mode == 2 && gs < 0.0)
                    ? (pH + std::fabs(m) * slopeXOffset(m, pH))
                    : pH;
                // [2026-09-06] GD's own seat: the line at the player's centre x,
                // NOT clamped to the ramp's span, minus/plus the SECANT half
                // playerRect.h/(2 cos t), with the bounds applied to the target
                // y (slopeSeatTarget in slopes.hpp; 0x38fd42-0x38fdf0, written
                // by setPosition 0x39074a on every acquiring tick). It is the
                // same number as the line below wherever the rotated contact
                // point stays inside the span -- `pH + |m|*slopeXOffset` IS
                // pH*sec t, and the far end's flat corner IS the y clamp GD
                // reaches there -- so only the ENTRY side moves. The mode-2
                // hang's own `lowLine - pH` floor is that same clamp
                // (objMinY - h/2) and is subsumed. Witness lv16 t=9,243, ceiling
                // ramp uid4032: 585.000 (the corner) -> 588.893, which is
                // gdref's y to the digit.
                double top;
                // [2026-09-07] Which branch actually produced `top`, named at
                // the branch rather than inferred from the value. The first
                // rampwin run showed `top` IDENTICAL under --no-slopeseat and
                // without it, which cannot happen if these two branches differ
                // here -- so the question is which one ran, and that is not a
                // thing to settle by arithmetic on the printed value.
                const char* topSrc = "?";
                if (!g_noSlopeSeat) {
                    top = slopeSeatTarget(sp, x, pH, gs < 0.0, seatOff);
                    topSrc = "seatTarget";
                } else {
                    top = sp->sy0 + m * (xr - x0) + gs * hangOff;
                    topSrc = "flatOld";
                    if (c.mode == 2 && gs < 0.0) {
                        // The hang's low end is bounded by the **flat** at
                        // line(end) - pH (lv16 t=13,116: 583.000 = sy1 - 9, not
                        // the rotated amount 581.6).
                        const double lowLine = (m < 0)
                            ? (sp->sy0 + m * (x1 - x0)) : sp->sy0;
                        top = std::max(top, lowLine - pH);
                    }
                }
                // [r33] On a tick pushed out at the ridge, no ramp's seat drops
                // below the apex height (measurements at pushOutSeat's declaration).
                if (pushOutSeat && !c.flip) {
                    const double beforePush = top;
                    top = std::max(top, pushOutTop);
                    if (top != beforePush) topSrc = "pushOutSeat";
                }
                // ...and it only counts as "a ramp still has me" if its resting
                // height is where the player actually is. The window alone is
                // far too coarse: at lv16 t=6516 the player runs off the top of
                // the 330->360 ramp at (9645,345) while the 300->330 one at
                // (9675,315) -- 30 px lower and never touched -- still passes
                // the window and suppressed the launch.
                // ...AND the sample point has to be genuinely inside the ramp.
                // `sampleAt` allows 1.5 px past the right edge so that the ride
                // survives the last tick on the surface, and that slack made the
                // EXIT tick look like a ramp that still holds the player: the
                // sample is clamped back to x1, so `top` is exactly the top of
                // the ramp, which is exactly where the player is. The launch was
                // then suppressed and a jump taken on that tick stood instead.
                // Measured on lv18 t=10,640 (full-size cube, speed 0.9, the
                // 60x30 ramp 674 at (14,520,225) 210->240): GD leaves at
                // vy = 3.999 -- the ramp's own exit for m=0.5 -- and the model
                // left at 11.180, the cube's jump. That is the whole x=14,673
                // wall: 7 vy of difference on the tick the corridor starts.
                // |useDx|: in a reverse section useDx is negative and the old
                // form made the bound negative, so the window (and the stick
                // below) could never hold -- one of the forward-only signs the
                // reverse family keeps finding.
                // [2026-08-18] **A convex seam is a launch, not a connection.** At
                // a seam in an uphill chain where the next ramp becomes
                // "shallower" (convex), GD fires the previous ramp's launch as
                // is. Measured lv22 t=18,583 (reverse travel, mini robot sp1.1):
                // m=-1 (uid16681) joins exactly onto the end of m=-2 (uid17074),
                // yet GD takes off at vy=13.064 (= the m2 launch 10.507 x
                // sp1.243) while the model spliced onto the next ramp and kept
                // climbing.
                // The floor-side mirror of the ceiling ramps' "corner vs seam"
                // (also measured that day): convex (next is shallower) = the face
                // folds away under the foot = launch; concave / equal gradient =
                // connection.
                // This skip must come **before** rampWindowHere -- a shallow-seam
                // ramp not only (a) is no transfer target but also (b) must not
                // act as the launch-suppression window (rampWindowHere). Placed
                // after, (b) remained and the launch was silently suppressed.
                // Only the floor side / upright was measured, so limited to
                // ridesTop && !flip. Equal gradient (difference under 0.01) still
                // connects as before. sgnT is the true travel direction (useDx is
                // always positive -- the rev note at sampleAt).
                {
                    const double sgnT =
                        ((double)K.dxF < 0.0 || s.rev != 0) ? -1.0 : 1.0;
                    const double mTravOld = (double)s.slopeM * sgnT;
                    const double mTravNew = m * sgnT;
                    if (s.onSlope && ridesTop && !c.flip
                        && mTravOld > 0.01 && mTravNew > 0.0
                        && mTravNew < mTravOld - 0.01) {
                        // Named so absence at the predicate below has ONE cause.
                        // See the rampwin comment: a candidate dropped here and
                        // a candidate never in K.slopes are indistinguishable
                        // from the predicate's own silence.
                        if (g_slopeDbg)
                            std::printf("rampwin: t=%lld uid=%d id=%d "
                                        "dropped=convex-seam mTravOld=%.3f "
                                        "mTravNew=%.3f\n",
                                        (long long)K.t, sp ? sp->uid : -1,
                                        sp ? sp->id : -1, mTravOld, mTravNew);
                        continue;
                    }
                }
                // [2026-08-21 r68] **At a hang's equal-gradient seam, do not move
                // to the neighbour until the previous ramp lets go.** Calibration
                // rig ceilramp unit0 (flipped ship, m=-1 3-ramp chain) measured:
                // GD keeps sliding on ramp1's line until t=551, when the contact
                // point (x+xoff = 717.6..718.9) exits ramp1's span, but at t=549
                // the model's neighbour (uid2037) became a landing candidate at
                // **the approach-side corner value (line(x0)-pH = 245.000)**,
                // stole the ride, and froze the line for 2 ticks (GD 247.34 /
                // M 245.00). The lines are colinear, so this skip is
                // value-neutral -- it removes only the corner-value theft.
                if (!ridesTop && s.onSlope && s.slopeUidNow >= 0
                    && s.slopeUidNow != sp->uid
                    && std::fabs((double)s.slopeM - m) < 0.01) {
                    const double xoffH = slopeXOffset(m, pH);
                    const double rcH2 = x + ((m > 0) ? -xoffH : xoffH);
                    bool prevHolds = false;
                    for (const Obj* pv : *K.slopes) {
                        if (pv->uid != s.slopeUidNow) continue;
                        const double px0 = pv->cx - pv->hw;
                        const double px1 = pv->cx + pv->hw;
                        const bool adj = std::fabs(px1 - x0) <= 0.5
                                      || std::fabs(x1 - px0) <= 0.5;
                        if (adj && rcH2 >= px0 && rcH2 <= px1)
                            prevHolds = true;
                        break;
                    }
                    if (prevHolds) {
                        // The exit worth watching: it turns on s.slopeUidNow,
                        // the PREVIOUS ride's identity, so a model that never
                        // entered a ride carries it differently from one that
                        // did -- and the predicate's own fields would not show
                        // that. Named for the same reason as the one above.
                        if (g_slopeDbg)
                            std::printf("rampwin: t=%lld uid=%d id=%d "
                                        "dropped=prev-holds slopeUidNow=%d\n",
                                        (long long)K.t, sp ? sp->uid : -1,
                                        sp ? sp->id : -1, (int)s.slopeUidNow);
                        continue;
                    }
                }
                // [2026-09-07] `rampwin:` -- the ramp-window predicate's OWN
                // INPUTS, for every candidate ramp examined, whether or not it
                // holds. It prints the FAILING branch deliberately: cli.hpp:257
                // records that a diagnostic which is silently off is worse than
                // one that is missing, because the empty output reads as "the
                // model never even looks at this object" -- and a print gated on
                // rampWindowHere would reproduce that trap at this very site.
                // Nothing here is derived or judged; the verdict shown is the
                // same expression the line below evaluates, so a reader can
                // check the arithmetic rather than take it. Opened for lv16
                // t=8,728-8,731, where GD has onGround=1 for four ticks and the
                // model has grounded=0 and onSlope=0 throughout, and the first
                // divergence is the tick after (t=8,732, GD vy -> exactly +2.000).
                if (g_slopeDbg) {
                    const double tol = 3.0 * std::fabs((double)useDx);
                    const double gap = std::fabs(top - (double)s.y);
                    std::printf("rampwin: t=%lld uid=%d id=%d inside=%d "
                                "top=%.4f y=%.4f gap=%.4f tol=%.4f useDx=%.4f "
                                "pH=%.2f m=%.3f gs=%.1f seatOff=%.4f seat=%s "
                                "topSrc=%s xr=%.4f hangOff=%.4f sy0=%.1f "
                                "x0=%.1f verdict=%d\n",
                                (long long)K.t, sp ? sp->uid : -1,
                                sp ? sp->id : -1, smp.inside ? 1 : 0,
                                top, (double)s.y, gap, tol, (double)useDx,
                                pH, m, gs, seatOff,
                                g_noSlopeSeat ? "flat" : "secant",
                                topSrc, smp.xr, hangOff, (double)sp->sy0, x0,
                                (smp.inside && gap <= tol) ? 1 : 0);
                }
                if (smp.inside && std::fabs(top - (double)s.y)
                                      <= 3.0 * std::fabs((double)useDx))
                    rampWindowHere = true;
                // Only ride it if the player came from ON or ABOVE the surface.
                // Without this a ship flying INTO the slope from below gets
                // lifted onto it, which GD does not do -- it dies. Measured as
                // a regression: lv18's wall went backwards from x=5,115 to
                // x=3,716 the moment the ship branch got the unconditional
                // version, because the search then planned through the ramp.
                // sampleAt already clamps to [x0,x1] on the normal path. The outer
                // re-clamp was redundant and killed the prevTop of the
                // extrapolated ride continuation (the new branch above), so it was
                // removed (2026-08-19).
                const double xrPrev = sampleAt(xPrev).xr;
                // ...and the previous tick's seat is the SAME formula one step
                // back -- GD re-evaluates slopeYPos at the advanced centre x on
                // every acquiring tick (0x39072c-0x39074a), which is where the
                // measured -0.807 px/tick descent (m*dx) comes from.
                const double prevTop = g_noSlopeSeat
                    ? (sp->sy0 + m * (xrPrev - x0) + gs * pH)
                    : slopeSeatTarget(sp, xPrev, pH, gs < 0.0, seatOff);
                // Came from the wrong side? Normally not a ride -- but if the
                // player is INSIDE the ramp's solid slice, GD lifts it out onto
                // the surface rather than letting it through, and that is the
                // whole reason a plain ramp does not need to kill.
                // Measured on lv16's untwinned (6708,293), line 278->308, whose
                // resting height at x=6708 is 308+... = 311.385: the ball
                // injected at y = 262, 270, 278, 285, 293, 300 and 308 -- from
                // under the box to deep inside the triangle -- comes out at
                // y=311.385, vy=0, onGround=1 in EVERY case.
                // Dropping the kill without this made the model plan straight
                // through ramps and took lv16 from x=11,895 back to x=5,024.
                // (the lift only applies to the upright case -- a flipped
                // player under a ceiling ramp is BLOCKED, not pushed through,
                // and its resting height is already what `top` says)
                const double sLo = std::max((double)c.y - pH, sp->cy - sp->hh);
                const double sHi = std::min((double)c.y + pH,
                                            sp->sy0 + m * (std::min(std::max(x, x0), x1) - x0));
                // ...and the slice it tests -- box floor up to the line -- is
                // the FLOOR ramp's solid half. On a ceiling ramp that region is
                // empty air, so a ship flying through it was "lifted out" onto
                // line + pH, 22.5 px above where GD keeps it (lv20 t=4761,
                // y 326.0 -> 348.5 with grounded set, then sliding down the
                // wrong face at dx/tick). Ship only; the other modes keep the
                // slice they were validated with.
                // ridesTop, not !c.flip: the "solid is under the line" slice is
                // the FLOOR ramp's, and that is exactly the case an inverted
                // player standing on one is in.
                // [2026-08-21 r43] **The ceiling ramp's "solid slice" is not used
                // for any mode.** This test looks at "box bottom up to the line =
                // the floor ramp's solid side", and on a ceiling ramp that region
                // is air. Only the ship had been excluded, but the cube had the
                // same hole: the moment r42 correctly cut off the ceiling
                // push-down, the ride grabbed that ramp as a floor and at lv18
                // t=20,492 **bounced 62.7px up** to 437.838 (=line+pH).
                // (The same picture the 8386 note foretold for the ship)
                const bool insideSolid = ridesTop && !ceilRamp
                    && (x + pH > x0 && x - pH < x1) && (sLo < sHi - 0.001);
                // --slopedbg also prints the ramps that were CONSIDERED and
                // rejected. Without it the flag only ever shows acquisitions,
                // so "the model never even looks at this ramp" and "it looks
                // and throws it away" are indistinguishable -- which is exactly
                // where lv22's uid5430 (m=2) stalled the diagnosis.
                if (g_slopeDbg)
                    std::printf("slopecand t=%lld x=%.2f uid=%d m=%.3f "
                                "sy=%.3f prevTop=%.3f top=%.3f y=%.3f sy0=%.3f "
                                "gs=%.0f inside=%d ridesTop=%d ceil=%d "
                                "reject=%d\n",
                                (long long)K.t, x, sp->uid, m, (double)s.y,
                                prevTop, top, (double)c.y, sp->sy0, gs,
                                insideSolid ? 1 : 0, ridesTop ? 1 : 0,
                                ceilRamp ? 1 : 0,
                                (!insideSolid
                                 && ((double)s.y - prevTop) * gs < -kLandTol)
                                    ? 1 : 0);
                if (!insideSolid && ((double)s.y - prevTop) * gs < -kLandTol)
                    continue;
                // A ship lands on a ramp from slightly ABOVE it, exactly as it
                // does on a flat surface. Measured on lv16
                // t=3027: the ship is 0.63 px above the ramp's surface and GD
                // puts it down at 239.770 = the surface + 15; the strict test
                // left the model falling and it was 6.4 vy out one tick later.
                // ...but only DOWNWARD. The tolerance applied to a ceiling pins
                // the ship 6 px before its head gets there. Measured on lv16
                // t=4108: GD is at y=399.0 still rising freely and the model
                // had already clamped to 405.0 (= the ramp's 420 minus 15).
                // Direction gate, UFO ONLY (2026-08-05, second attempt): GD
                // leaves a RISING UFO arcing above the line alone (lv19's
                // staircase, 5.15 px at x=20,631/t=14,585, rejoins by itself 4
                // ticks later) -- grabbing it built the whole x=21,386 wall
                // and burned the fixup budget one delta per tick. The SHIP
                // keeps the unconditional grab: gating it too is what broke
                // lv16 (stuck at x~4,909 -- its ships genuinely settle onto
                // ramps while rising). Mode is the distinguishing condition
                // we have measurements for on both sides; if a rising-ship
                // arc ever shows up, this needs a finer rule.
                // TRIED AND REVERTED (2026-08-19): "leave a riser alone only when
                // more than 1.0 above the line" -- aimed at lv20 t=21,983 (GD
                // grabs a rising UFO 0.55px above), but the target site did not
                // move (the grab goes through a different path entirely) and it
                // wrongly grabbed the rising UFO at lv19 t=14,936, regressing
                // 400->336. 21,983 is a different mechanism (still unexplained).
                const bool ufoRising =
                    (c.mode == 3) && (double)c.vy * gs > 0.0;
                // kShipLandTol (6.0) is the LEDGE sweep's penetration limit;
                // as an above-the-surface allowance on an ASCENDING ramp it
                // grabs a falling ship 2-3 ticks before GD, because the
                // resting height climbs 1.6 px/tick into the gap. Measured
                // on the 2026-08-17 lv16 reference, t=15,521..15,523
                // (uid7702, m=+1): the model snapped DOWN 4.7 px onto the
                // ramp at a 3.78 px gap while GD stays free until its own y
                // sinks below the rising line (lands t=15,523 at 464.04,
                // vy=0). The early land also poisons the slope-exit charge:
                // 23/24 ride ticks against GD's 21/24 = the +0.767 cube
                // launch at t=15,544.
                // ...and 0.65 was still too generous. It was kept for a
                // "0.63 above and GD lands anyway" reading at lv16 t=3027, but
                // that tick no longer involves a ramp at all in the current
                // geometry (model and GD agree there to the digit, both free
                // at vy=-4.651) -- the reading was an artefact of an older
                // `top`, from before slopeXOffset and the ceiling-ramp work.
                // What is measurable NOW says the ASCENDING ramp takes NO
                // allowance at all: lv20 t=14,018 (uid11804, m=+0.5, resting
                // centre 211 at the ramp's right end) has the ship 0.1955 px
                // above and GD stays free, landing the next tick when its own
                // free y sinks 0.331 px THROUGH the line. 0.001 reproduces
                // both ticks exactly.
                // kShipLandTol (6.0) stays for the DESCENDING side: there it
                // is a penetration limit (the line drops onto the ship), which
                // is a different quantity from an above-the-surface gap.
                // [2026-08-28] ...and that reading of it is wrong. The test this
                // feeds is `(c.y - top) * gs <= landAllow`, in which penetration
                // is the NEGATIVE side and passes whatever the constant is; all
                // 6.0 buys is a grab from up to 6 px ABOVE a line that is
                // falling away from the ship. GD does not do that: measured on
                // lv16 t=9,402 (dual ship, uid4070 m=-0.5, sy0=390 sy1=360) p2's
                // foot is 0.989 px above the seat and the gap GROWS 0.807 px a
                // tick, and GD leaves it alone -- its two bodies stay exact
                // mirrors, p1 + p2 = 960.000 to the digit.
                // So a SHIP acquires either side of a ramp the same way, by
                // crossing the seat. Both sides of the price were measured cold
                // on builds identical but for it:
                //   lv16  55 iterations / 120 fixups  ->  118 / 296
                //   lv20  DOES NOT CLEAR (walled 70+  ->  35, clears
                //         iterations at t=17,123)
                // lv16's 63 iterations are the cost of being right; lv20 is why
                // it was never worth keeping the 6 px reach-back for. Both
                // numbers are about the SAME corridor as the dual-birth work of
                // the same day, and with that corridor closed both levels clear
                // cold with this unconditional (lv16 at 69, lv20 at 33). The
                // corpus's replay never visits a case that still wants the
                // reach-back on the downhill side, so there is no reading left
                // that a switch here could select between.
                // kShipLandTol (6.0) stays for the UFO, whose own acquisition
                // has not been measured this way.
                // The UFO's 6.0 is the one width here that was never measured --
                // the comment above says so in as many words. GD's floor gate
                // has no 6.0 at any setting: its widths are 0 / 1 fresh / 2
                // continuing (@0x38fea5), and `m_wasOnSlope` picks between the
                // last two. `s.onSlope` is this model's proxy for that flag --
                // the previous tick's seat, not this tick's, which is the
                // distinction the fresh-rect site spells out at 6979-6983.
                // lv19 t=14,587 is the missing measurement (the flat kShipLandTol
                // it replaced was the --no-ufolandtol arm, removed in the flag clean-up).
                const double ufoAllow = s.onSlope ? 2.0 : 1.0;
                const double landAllow =
                    (ridesTop && (c.mode == 1 || c.mode == 3) && !ufoRising)
                        ? (c.mode == 1 ? 0.001 : ufoAllow)
                        : 0.001;
                // The stick must stay CONTINUOUS. It bypasses the acquisition
                // test entirely, so with several ramps stacked in the same x
                // window it could snap a rider onto whichever one the loop
                // happened to reach last -- measured on lv16 t=6515, a cube
                // riding to a ramp's top at y=374.577 was teleported to
                // y=316.192 (58 px down, still `grounded`) instead of launching,
                // and the DP then planned around a move GD cannot make. A real
                // rider's resting height moves by dx*|m| per tick, so anything
                // beyond a couple of ticks' worth is a different surface.
                // ...and the continuity glue obeys the same UFO-only gate: an
                // uphill UFO arcing away from the line is launching, not
                // riding (see the landAllow note above).
                // [2026-08-21 r83] **This tolerance is a px constant, not a tick
                // count.** The seam rig (seam / seam07 / seam11 = dx
                // 1.047/1.298/1.614, cube+ball x |m| 1/0.5 x 12 phase points =
                // 144 units) measured: where a flush flat continues past the
                // downhill low end, the position at which GD ends the ride is
                // **speed-independent**. Rereading the same boundary as
                //   D = |m|*(cx - xoff - x1)   [px]     -> all 11 columns 4.03+-0.06
                //   k = D/dx                   [ticks]  -> 3.82 / 3.10 / 2.50
                // only the px form is a constant (3.0*dx at 1x is 3.895 = merely
                // coincidentally close; at sp1.1 it is 4.84, too loose, and in
                // the 0.7 band 3.14, too strict, releasing 1 tick early).
                // The value takes the |m|=0.5 columns' intersection [4.031,
                // 4.037) (the |m|=1 columns prefer 4.07, but those scatter by
                // 0.04 across cube/ball/3 speeds).
                // [2026-08-24] **A pressing ship leaves the ramp the moment the
                // surface stops keeping up with it** -- the same claim the UFO
                // clause below makes, on the mode where the ride is a thrust.
                // The gap test alone cannot see this: the seat re-pins y every
                // tick, so `s.y` is always the seat and the 4.034 px never opens.
                // The two measured ship presses are told apart by kinematics
                // alone, with no constant of their own:
                //   lv16 t=8,720 (flipped, ceiling ramp uid3765 m=+1, dx=1.6143):
                //     the surface climbs +1.614 px/tick, the press drives the
                //     player -0.500 px/tick the other way -> 2.11 px/tick apart.
                //     GD drops onGround on the very next tick and emits the ramp's
                //     own launch, -6.330; the model laddered 2.000 -> 2.086 -> ...
                //     and sat on the seat for the remaining 480 ticks
                //   x=23,148 (upright, floor ramp m=+1, sp1.1): the surface climbs
                //     +1.776 px/tick against the press's +0.500 -> the surface
                //     OUTRUNS the player, contact is remade every tick, and GD
                //     ladders 2.000 -> 2.086 -> ... -> 2.430 (the ladder's own
                //     measurement, at the branch that writes it)
                // Written as the state the kinematics produce rather than as the
                // rates themselves: past the seat on the free side AND still
                // moving away. The x=23,148 ladder never gets past the seat, so it
                // is untouched. ([[gd-hang-side-mirrors-floor-rules]])
                // TRIED AND REVERTED (2026-08-24): folding this off the ship.
                // lv16's p2 shows the same two ticks at t=13,264 (mini ball: GD
                // and the model launch together at vy=7.680, the model then writes
                // vy=0 twice and returns at 4.604 against GD's 7.293), so the
                // family looked foldable. It is not reachable from here -- p2 is
                // the dual body and carries its own y/vy, so dropping the mode
                // gate cannot touch it: lv16 came out **bit-identical** (1,853
                // diverging ticks, same death), and lv22's first divergence went
                // from t=3,806 dy +0.000 to t=3,800 dy **+7.754** (426 -> 432).
                // Fix p2's copy where p2 lives. ([[gd-dual-p2-fidelity]])
                const bool shipLeaving =
                    c.mode == 1 && (double)c.vy * gs > 0.0
                    && ((double)c.y - top) * gs > landAllow;
                const bool stickHere =
                    stickToSlope
                    && std::fabs(top - (double)s.y) <= kStickGap
                    && !(ufoRising && m > 0.0
                         && ((double)c.y - top) * gs > landAllow)
                    && !shipLeaving;
                // an end-clamped sample never overwrites an in-span acquisition
                // (note at the loop head)
                if (slopeTookInside && !smp.inside) continue;
                // ---- [2026-08-19 slopeland calibration rig] A falling cube's
                // acquisition starts 1.0px above the seat. GD snaps it downward
                // and seats it 1 tick before "the centre crosses the seat" (the
                // identity of lv16 t=5,923's 0.68 downward snap). Of 37 units,
                // every fast-approach unit agrees at tolerance 1.0 (+-0.07, the
                // same value as preSlopeCollision's constant 1.0). The entry-side
                // gate is the sample point r 0.5px inside the end (measured
                // window (0.49, 0.90], constrained by the m=-1/-2 grazing
                // entries). Measured only for cube / upright / normal size /
                // falling from the air, so limited to that scope. Only the 3
                // relative-rise grazing units (arc gradient ~= m) seat 1-2 ticks
                // later in GD and do not fit this formula -- left unexplained.
                // Purely additive: the tick seated under the old
                // condition (landAllow) is unchanged; only the earlier side is
                // added.
                // ...and **limited to ramps downhill in the travel direction**.
                // The rig's 4 uphill control units all had seat-tick gaps <= 0
                // and never actually constrained a positive tolerance. lv18
                // t=11,023 (uid7232 m=+0.5, gap 0.151 and GD does not seat) is
                // the uphill counter-example = uphill still waits for the
                // crossing, as before. Same asymmetry as the ship landAllow's
                // "no tolerance on an uphill ramp (lv20 t=14,018)".
                // ...the ball shares the same rule (slopelandball rig 19u: 17/19
                // at a=1.0/b=1.0; the old crossing rule was 6/19. The misses are
                // only the same 2 relative-rise grazes as the cube). The entry
                // gate takes a=0.8 from both datasets' common window
                // (cube (0.49,0.90] with ball (~0.6,1.0]).
                const double rRaw = x + (m > 0 ? slopeXOffset(m, pH)
                                               : -slopeXOffset(m, pH));
                const bool revT = ((double)K.dxF < 0.0 || s.rev != 0);
                const bool seatTolOk =
                    ridesTop && !c.flip && (c.mode == 0 || c.mode == 2)
                    && !s.dual
                    && !s.grounded && (double)c.vy * gs <= 0.0
                    && (revT ? -m : m) < -0.01
                    && (revT ? (rRaw <= x1 - 0.8) : (rRaw >= x0 + 0.8))
                    && smp.inside
                    && ((double)c.y - top) * gs <= 1.0;
                // [2026-08-19 item 14] When landing on a flat on the same tick,
                // but the pre-clamp position (preLandY) had already crossed the
                // seat, GD lands on the slope's seat (the slope beats the plate).
                // lv19 t=15,514: caught on plate uid10342 (right edge 22,110, top
                // 360) with the centre +7.33 while crossing ramp uid10385's seat
                // 373.88 -- GD is at 373.88, the model stood on the plate's 375.
                // The edgeland rig confirmed "a plain plate catches even at 12.3
                // overhang", so this is not a rule rejecting the plate but one
                // where the seat side overwrites. Upright cube only (that is
                // where it was measured).
                // ...the SPIDER has the same mechanism (lv21 t=16,710: the model
                // standing on the plate 150+13.5=163.5 vs GD's ramp seat 155.066,
                // edy 8.43).
                // ...the UFO too (lv20 t=21,983: on the landing tick, onto the
                // ramp seat rather than the plate 222.35, edy +0.55. preLandY
                // wired in from the fly/land side).
                const bool seatFromPreLand =
                    landedThisTick && !stepLandedThisTick && ridesTop && !c.flip
                    && (c.mode == 0 || c.mode == 6 || c.mode == 3) && !s.dual
                    && ((double)preLandY - top) * gs <= landAllow;
                // [2026-08-19] A non-riding player **standing supported by an
                // actual flat** is not dragged down by a seat below. lv19
                // t=14,074: a UFO on a platform (landAllow 6.0) was pulled to a
                // seat 0.89 below, but GD keeps standing on the platform. The
                // gate is "a flat exists at foot height" -- with a bare
                // s.grounded it also blocked lv21 t=18,088 (right after a portal
                // seating, with only a slope for support; GD keeps descending
                // the m=-2 line) and regressed. The lift when buried
                // (insideSolid) stays as before.
                if (s.grounded && !s.onSlope && !insideSolid
                    && ((double)c.y - top) * gs > 0.001) {
                    bool flatSup = false;
                    const double footG = (double)c.y - gs * pH;
                    for (const Obj* fo : *K.near) {
                        if (fo->type != 0) continue;
                        if (std::fabs(x - fo->cx) > fo->hw + pH + kContactEps)
                            continue;
                        const double ff = (gs > 0.0) ? (fo->cy + fo->hh)
                                                     : (fo->cy - fo->hh);
                        if (std::fabs(footG - ff) <= 0.6) {
                            flatSup = true;
                            break;
                        }
                    }
                    if (flatSup) continue;
                }
                // **A FRESH CONTACT HAS TO REACH THE RAMP'S INSET RECT.**
                // collidedWithSlopeInternal splits its reach test on
                // m_wasOnSlope at 0x38fc0e. A CONTINUING contact takes the cheap
                // edge test (0x38fc0e-0x38fc2c), which is untouched here; a NEW
                // one takes a rectangle test against the OBJECT rect inset 1 px
                // at the top and 1 px at the bottom, and returns from the whole
                // routine when it fails:
                //   0x38fc3c  h' = objRect.h - 2.0f   (2.0f @0x622E58)
                //   0x38fc4a  y' = objRect.y + 1.0f   (1.0f @0x622C24)
                //   0x38fc65  CCRect(objRect.x, y', objRect.w, h')
                //   0x38fc73  playerRect.intersectsRect(that)
                //   0x38fc7b  je 0x390b60             ; no overlap -> nothing
                // Nothing is inset in x, and nothing on the player -- the
                // opposite convention from the solid resolver, which insets the
                // player. slopeWouldAcquire already carries these same three
                // lines for the veto's bypass; this is the acquisition itself.
                //
                // Witness lv19 t=7,553 (cube, one tick after the wave->cube mode
                // portal at 7,552). Ramp uid4991's rect is y[450,480], inset
                // y[451,479]; the free y is 494.819, so the foot at 479.819 sits
                // 0.182 px inside the bare rect and 0.819 px ABOVE the inset
                // top. GD's `slp:` line is called on every tick of the approach
                // with onSlope=0 and never moves y, while the model seated at
                // 495.000 (`why=land`, allow=0.001) -- the level's first
                // divergence.
                //
                // THE Y IS THE FREE ONE. GD's call gets the post-integration,
                // pre-collision y, which is what yFreeBeforeSlope holds; `c.y`
                // here has already been moved by whatever ran earlier in the
                // tick, and feeding the seat's own output back in as its input
                // is one of the two errors that sank the first attempt at this
                // rule (retracted 2026-09-05, never committed -- it also read
                // lv20 t=5,278 off a y lifted by a solid landing there and took
                // that level's death from 15,124 to 5,348. `9c1a4f8` has since
                // closed that solid's door, so the free y here IS GD's call-time
                // y). [[gd-take-the-value-from-the-deciding-source]]
                //
                // "Fresh" is GD's own field: m_wasOnSlope is the PLAYER's flag
                // carried from the previous tick, not a per-ramp one, so a
                // hand-over between two ramps of a chain is a CONTINUING contact
                // for this test and keeps the edge test. s.onSlope is the
                // model's proxy for it.
                //
                // Necessary for the WHOLE gate, not only its `land` branch: the
                // return at 0x38fc7b is ~180 instructions ahead of the
                // acquisition gate at 0x38fea5, so every way in below it is
                // downstream of the same return. `alt=` on the trace line below
                // is exactly "one of the other four disjuncts would have taken
                // this ramp anyway", i.e. the ticks on which this placement and
                // a narrower one gating only `land` disagree: **1 of the 9,367
                // refusals in the 22 replays**, lv19 t=14,850, a UFO whose foot
                // sits exactly on ramp uid9716's rect top (270.000 against the
                // inset 269.0) -- and 263 ticks past that level's first
                // divergence, so it is evidence for neither. The witness itself
                // comes in on `land` alone (its `slopecand` line reads
                // inside=0, seatTolOk is false because the cube is rising, and
                // stickHere cannot fire on a fresh contact). So the wide
                // placement is written because the disassembly says so, not
                // because a tick asked for it.
                bool freshRectOk = true;
                if (!s.onSlope) {
                    const double ry0 = sp->cy - sp->hh;
                    const double ry1 = sp->cy + sp->hh;
                    const double py = (double)yFreeBeforeSlope;
                    // closed-interval overlap, as cocos CCRect::intersectsRect
                    freshRectOk = (x + pH >= x0) && (x - pH <= x1)
                               && (py + pH >= ry0 + 1.0)
                               && (py - pH <= ry1 - 1.0);
                    if (!freshRectOk && g_slopeDbg)
                        std::printf("sloperect t=%lld x=%.2f uid=%d yfree=%.3f "
                                    "prect=[%.3f,%.3f] inset=[%.1f,%.1f] "
                                    "alt=%d NO-FRESH-CONTACT\n",
                                    (long long)K.t, x, sp->uid, py,
                                    py - pH, py + pH, ry0 + 1.0, ry1 - 1.0,
                                    (seatTolOk || seatFromPreLand || stickHere
                                     || insideSolid) ? 1 : 0);
                }
                if (freshRectOk
                    && (((double)c.y - top) * gs <= landAllow || seatTolOk
                        || seatFromPreLand || stickHere || insideSolid)) {
                    // [2026-08-19] On the tick a downhill rider's centre crosses
                    // the slope rect's top edge (cy+hh), GD clamps **to there for
                    // exactly 1 tick** and returns to the line the next tick.
                    // 3 gdref lv16 measurements: t=5,945 (uid2292,
                    // 270.152->**270.000**->268.538), t=5,982 (uid2293,
                    // 240.288->**240.000**->238.674), t=6,948
                    // (480.602->**480.000**->478.987). Every clamp value is
                    // sp->cy + sp->hh, not a face or line value (matching
                    // preSlopeCollision's "player.y vs rect top" gate). Measured
                    // only for the cube, so the scope is limited.
                    // ...but **only when the descent since mounting exceeds the
                    // hang amount pH*sqrt(1+m^2)** (slopeland3 calibration rig,
                    // 2026-08-19). The first rTop crossing after seating on one's
                    // own ramp (descent <= 16.77 is the geometric upper bound)
                    // passes through; only seam-crossing / long-ride crossings
                    // clamp. Measured boundary (16.0, 17.1): lv16 uid2580 passes
                    // at descent 9.1, uid2292 clamps at 17.1. The descent is
                    // reconstructed from slopeT (a new state dimension cannot be
                    // carried by anchors -- slopeT is already transported). One
                    // known counter-example: the rig's unit1 (K=6, descent 33.9)
                    // passed through -- unexplained by phase or ride length. 1
                    // tick is 0.8px, so recorded and moved on.
                    // [2026-08-19, night-3] Settled: **the descent amount is not
                    // the discriminator.** Extending to the ball and dropping the
                    // descent gate removes the 3 target families (lv16@6,948 /
                    // lv18@12,250 / lv19@15,537) but 4 families spring up
                    // instead. Ordered by descent, correct hits and false firings
                    // **alternate perfectly**:
                    //   clamps:  8.07 (lv18@12,250) / 14.53 (lv16@6,948)
                    //            / 28.55 (lv19@15,537)
                    //   passes:  8.88 / 12.98 / 19.37 / 38.7 (false-firing sites)
                    //            + 9.1 (lv16 uid2580) + 33.9 (rig unit1)
                    // So the gate below is merely "happening to be right on the
                    // current corpus", and **some other geometric/phase quantity
                    // is the true discriminator**. Re-sweep with a calibration
                    // rig (a slopeland3 variant).
                    // [2026-08-19, night-3] **It was the seam hand-over.**
                    // Calibration rig slopeland4 + calib_sl4seam.py measured: on
                    // the tick **just before** standtrace's slope uid changes
                    // from ramp 1 to ramp 2, at |m|=1 GD's centre y is, 6/6,
                    // **the seam's line value itself** (21.21px below the normal
                    // seat line+pH*sqrt(2)).
                    // The corpus has the same shape -- lv16@6,948's 480.000 is
                    // uid2791's low end = uid2865's rect top = the seam (GD's
                    // stand goes t=6,929 uid2791 -> t=6,949 uid2865, and the
                    // clamp is 1 tick before the boundary); lv18@12,250's 270.000
                    // is the uid8272/8273 seam too. **It never happens at the
                    // high end of ramp 1 (the ramp one landed on), 12/12** = it
                    // does not happen where no ramp connects just before.
                    // So the gate is not the descent but "does this rect top
                    // coincide with **the preceding ramp's low end**". A
                    // geometric test of the same shape as cornerContinued.
                    const double rTopHere = sp->cy + sp->hh;
                    bool rTopIsSeam = false;
                    {
                        const bool revT = ((double)K.dxF < 0.0 || s.rev != 0);
                        const double entryEdge = revT ? x1 : x0;
                        for (const Obj* nb : *K.slopes) {
                            if (nb == sp || nb->slopeHazard) continue;
                            const double nx0 = nb->cx - nb->hw;
                            const double nx1 = nb->cx + nb->hw;
                            if (nx1 <= nx0) continue;
                            const double nedge = revT ? nx0 : nx1;
                            const double nlo = revT ? (double)nb->sy0
                                                    : (double)nb->sy1;
                            if (std::fabs(nedge - entryEdge) <= 0.5
                                && std::fabs(nlo - rTopHere) <= 0.5) {
                                rTopIsSeam = true;
                                break;
                            }
                        }
                    }
                    // **The seam test alone is not enough** (same day, retracted):
                    // with `(c.mode == 0 || c.mode == 2) && rTopIsSeam` the 2
                    // target families (lv16@6,948 / lv18@12,250) disappear, but 3
                    // families spring up in the same section (slope-0.50/ride11,
                    // slope-0.50/ride24+/nearceil, slope-1.00/ride24+).
                    // The rig drops 6/6 at |m|=1 seams but not at |m|=0.5 -- yet
                    // the corpus's lv16@6,948 drops at m=-0.5. The rig (1x) and
                    // the corpus (sp1.1) differ in **speed**, so next: sweep
                    // speed on the rig.
                    // (`rTopIsSeam` is kept -- it does become part of the gate.)
                    // **The geometric seam alone is not enough either** (same
                    // day's measurement): lv16 uid2580's (x[9270,9330], sy0=180)
                    // 180 coincides with the preceding ramp's low end -- a
                    // "geometric seam" -- but the player **landed on that ramp
                    // itself** (ride11 = 17.8px earlier; x~=9,287 is inside x0),
                    // so GD does not clamp (t=6,298 GD 179.428 / model 180.000).
                    // Same as the rig's 12/12 -- **it does not happen on the ramp
                    // the ride began on**. So the gate is "current ramp != the
                    // ramp the ride began on".
                    // [2026-08-20] The "not on the ramp the ride began on" gate is
                    // **cube only**. The ball clamps even on the ramp it began on:
                    //   lv18 t=12,250 (ball, landed on uid8273, ride5, rect top
                    //     270): GD stops at exactly y=270.000 for 1 tick and
                    //     returns to the line the next. The model stayed on the
                    //     line (edy +0.695)
                    //   lv16 t=6,298 (cube, landed on uid2580, ride11, rect top
                    //     180): GD does **not** stop, 179.428
                    // Removing the gate entirely makes lv16@6,298 spring up
                    // (measured, families -2/+3).
                    if (ridesTop && !c.flip && (c.mode == 0 || c.mode == 2)
                        && rTopIsSeam && s.onSlope && s.slopeUid0 >= 0
                        && (c.mode == 2 || sp->uid != s.slopeUid0)) {
                        const double rTop = rTopHere;
                        if ((double)s.y > rTop + 0.0005 && top < rTop - 1e-9) {
                            if (g_slopeDbg)
                                std::printf("slopedbg t=%lld x=%.2f uid=%d "
                                            "recttop=%.3f (top=%.3f)\n",
                                            (long long)K.t, x, sp->uid,
                                            rTop, top);
                            YSET(c.y) = (float)rTop;
                            VYSET(c.vy) = 0; c.grounded = 1;
                            c.rideLanded = 1;   // as above: grounded is the landing
                            c.onSlope = 1; c.slopeM = (float)m;
                            c.slopeUid0 = s.onSlope ? s.slopeUid0 : sp->uid;
                    c.slopeUidNow = sp->uid;
                            continue;
                        }
                    }
                    if (smp.inside) slopeTookInside = true;
                    // --slopedbg: WHICH condition acquired the ramp, and with
                    // what numbers. The three are very different claims (landed
                    // / still riding / lifted out of the solid half) and the
                    // trace's onslope column cannot tell them apart, so a false
                    // acquisition reads as "the model zeroed vy for no reason".
                    if (g_slopeDbg)
                        // ...and the FREE y, which is the one GD's own test sees.
                        // `y` here is c.y at this point in the tick, already
                        // moved by whatever ran before; reading the rect test off
                        // it fed the seat's own output back in as its input, and
                        // lv20 t=5,278 then read `gap 0.000` and looked like a
                        // counterexample when GD plainly acquires there
                        // (collidedWithSlopeInternal, onSlope 0->1, y 283.216 ->
                        // 285.000). yFreeBeforeSlope is the post-integration,
                        // pre-collision value the call actually gets.
                        std::printf("slopedbg t=%lld x=%.2f y=%.3f yfree=%.3f "
                                    "pH=%.1f "
                                    "uid=%d m=%.3f top=%.3f gap=%.3f allow=%.3f "
                                    "why=%s\n",
                                    (long long)K.t, x, (double)c.y,
                                    (double)yFreeBeforeSlope, pH, sp->uid,
                                    m, top, ((double)c.y - top) * gs, landAllow,
                                    (((double)c.y - top) * gs <= landAllow)
                                        ? "land"
                                        : (seatTolOk
                                               ? "seat1"
                                               : (stickHere ? "stick"
                                                            : "inside")));
                    // [2026-08-20] **While being caught by a flat solid, do not
                    // transfer to another ramp.**
                    // A ride following a descending ramp's line was passing
                    // through a flat solid whose top face is above the line. GD
                    // seats on that top face and stops, and **the ride continues
                    // on the same ramp** (a single release blip on the tick the
                    // window runs out). 3 measurements, all census families:
                    //   lv16 t=6,967 (cube, thin plate uid2937 top 449.95,
                    //     m=-0.5): GD y=464.950, vy=-3.229 at t=6,972
                    //     (=-0.5x1.6143/0.25). edy +0.491
                    //   lv19 t=15,537 (cube, solid uid10386 top 330, m=-1):
                    //     GD y=345.000, vy=-5.193 at t=15,540. edy +0.992
                    //   lv21 t=18,098 (mini UFO, thin plate uid24225 top 180,
                    //     m=-2): GD y=189.000, vy=-12.914 at t=18,099.
                    //     edy +2.223
                    // **Not applied to a continuation on the same ramp** --
                    // applied there, lv16 releases abruptly at t=6,967 (GD is 5
                    // ticks later). Stopping only the transfer, the release comes
                    // out matching GD on the tick the current ramp's window runs
                    // out. The y side is aligned by the flat clamp below.
                    if (ridesTop && !c.flip && K.near && s.onSlope
                        && sp->uid != s.slopeUidNow) {
                        bool blockedByFlat = false;
                        for (const Obj* nb : *K.near) {
                            if (nb->type != 0 || nb->oneway) continue;
                            // The player's **centre** must be over that solid.
                            // Allowing out to the box edge (+pHalf) picks up a
                            // block that ends short and stops the descent at lv16
                            // t=6,316 (GD descends past 150 there).
                            if (std::fabs(x - nb->cx) > nb->hw) continue;
                            const double face = nb->cy + nb->hh;
                            if (face > (double)c.y + pHalf) continue;
                            if (face + pHalf > top + 0.001) {
                                blockedByFlat = true;
                                break;
                            }
                        }
                        if (blockedByFlat) {
                            if (g_slopeDbg)
                                std::printf("slopeblock t=%lld x=%.2f y=%.3f "
                                            "uid=%d top=%.3f - a flat solid is "
                                            "holding it up, no seat\n",
                                            (long long)K.t, x, (double)c.y,
                                            sp->uid, top);
                            continue;
                        }
                    }
                    if (g_slopeDbg)
                        std::printf("slopeseat t=%lld x=%.2f uid=%d y %.3f -> "
                                    "%.3f\n",
                                    (long long)K.t, x, sp->uid, (double)c.y, top);
                    YSET(c.y) = (float)top;
                    // the impulse tick takes the POSITION only -- the jump or
                    // flip already set vy and cleared grounded, and the player
                    // is leaving. Without this the ride simply cancelled a cube
                    // jump taken off an UPHILL ramp: the jump freezes y, the
                    // ramp's next resting height is 0.8 px ABOVE that, so the
                    // acquisition test fired and put vy back to 0.
                    // ...and the ball's TAP is the same story as the cube's
                    // jump: take the ride POSITION only and leave the velocity
                    // (and grounded/onSlope) to the flip, which already ran.
                    // `tappedOffSlope` has carried this meaning in a comment
                    // since it was written but was never read anywhere -- the
                    // compiler had been warning C4189 about it the whole time.
                    // WHICH WAY THIS GATE WENT, and on what.
                    //
                    // The comment above justifies skipping the vy work with "the
                    // jump or flip already set vy". At lv22 t=18,568 the vy
                    // writer was measured as the ordinary integrator, not a jump
                    // and not a flip -- so either the gate did not fire and
                    // something else spared vy, or it fired on a premise that
                    // does not hold there. The two inputs and their own inputs
                    // are printed rather than reasoned about.
                    ++g_seatGateSeen;
                    g_seatImpulsedOff = impulsedOffSlope ? 1 : 0;
                    g_seatTappedOff = tappedOffSlope ? 1 : 0;
                    g_seatOnSlope = s.onSlope ? 1 : 0;
                    g_seatTook = (impulsedOffSlope || tappedOffSlope) ? 1 : 0;
                    if (impulsedOffSlope || tappedOffSlope) {
                        // [2026-08-19] On a **downhill** (travel-direction) ride,
                        // the jump tick also takes the seat's step first
                        // (collisions before buttons, and a falling seat does not
                        // cancel the jump). lv16 t=5,991: GD y=232.217 = the seat
                        // one more step down, vy=11.42 = the jump value. Uphill
                        // stays frozen as before (measurement in the 8273 note).
                        // Position only; vy/grounded stay the jump's.
                        const double sgnT2 =
                            ((double)K.dxF < 0.0 || s.rev != 0) ? -1.0 : 1.0;
                        if (ridesTop && !c.flip && c.mode == 0
                            && m * sgnT2 < -0.01)
                            YSET(c.y) = (float)top;
                        continue;
                    }
                    // The SWING does not have its vy zeroed by the ride. GD
                    // starts it at 2.000 on acquisition and then integrates the
                    // swing's own gravity every riding tick. Measured on lv22
                    // uid5430 with the presses REMOVED from the plan (they were
                    // what made the earlier probe look like two families):
                    //   2.000 2.086 2.172 2.258 2.344 ... 3.376   (+0.086/tick)
                    // It only shows on the tick the player LEAVES -- the ride
                    // overwrites y anyway -- but there it is the whole 0.4 px:
                    // GD steps y by 0.225*1.652 = +0.372 where the model, with
                    // vy at 0, stepped -0.019.
                    // Sign follows the surface: the ramp climbs as x advances
                    // here, and vy is positive. The 2.000 itself is measured,
                    // not derived -- it is neither didHitHead's +-2 nor the
                    // take-off's -1.000.
                    // [2026-08-20 r39] **The ship's ride is the same as the
                    // swing's.** The census shows just one
                    // `m1/.../slope+0.50/ride0` edvy=+2.000, but **on a cold run
                    // the same family becomes a 19-item grind** (hp32's lv16, the
                    // main cause of 22->55 iterations): iterations 24-48 are a
                    // grind moving a few px at x=22,631-23,364, and fixups_log
                    // contains nothing but
                    //   `m1/mini0/g1/gdg1/sp1.1/slope+1.00/rideNN, edy=0, edvy=+2`
                    // The post-correction ladder also has the swing's shape
                    // (2.000 -> 2.086 -> 2.172 -> 2.258 -> 2.344 -> 2.430,
                    //  6 consecutive ticks x=23,148-23,156, +0.086/tick).
                    // So **2.000 x dir on acquisition, then +0.086 x dir every
                    // tick** -- the swing's rule itself.
                    // ([[gd-fixup-grind-means-missing-rule]]: a few-px/iteration
                    //  grind is not a "point" but a missing rule)
                    // Measured at **normal size / sp1.1 / uphill**. The mini
                    // acquisition 2.000 does **not scale**: the census's lv16
                    // `mini1/sp0.7/slope+0.50/ride0` emits the same +2.000.
                    // The downhill (dir=-1) ladder is unmeasured -- lv18's
                    // `mini1/slope-1.00/ride2` is -1.899, 0.27 off this formula's
                    // -2.172. The coefficient may differ by direction.
                    // [2026-08-20 r39a] **The gate is the press.** Applied to
                    // every ship in r39, the acceptance gate fell (families
                    // 22->24; all 5 new ones are `m1/.../g0/gdg1/.../air` with
                    // edvy exactly **-2.000** = only the model holds the 2.000).
                    // gdref splits on the input:
                    //   lv16 t=9,847  in=0  GD rides at vy=**0.000** (stays 0 after)
                    //   lv16 t=15,514 in=0  lands from terminal -6.400, GD vy=0.000
                    //   lv16 x=23,148 **in=1** GD's ladder 2.000->2.086->...->2.430
                    //   the census lv16 `mini1/sp0.7/slope+0.50/ride0` is **in=1**
                    // So the ride itself pins vy to 0, and the ladder rises from
                    // 2.000 **only while pressing**.
                    // The velocity as it stands ENTERING this block, i.e. after
                    // the tick's own integration. GD's restore at 0x3907dd puts
                    // back the value hitGround was called with, which is this
                    // one and not the previous tick's: restoring s.vy instead
                    // left lv22 t=18,606 exactly one gravity step out
                    // (edvy -0.2150, the model on 13.0645 where GD is 12.849).
                    const float vyPreRide = c.vy;
                    // [2026-09-06] **The ride's velocity is decided by the
                    // contact SIDE, and the two ladders below are not GD's.**
                    // `m_isUpsideDown XOR isTop` (0x38fe00) picks one of two
                    // regimes, and neither of them has a gradient factor, a
                    // per-mode coefficient or a "carried is 0" entry test:
                    //   GRAVITY-FACING  hitGround @0x3907ad zeroes vy every
                    //                   tick, unless bVar3 (`m_jumpBuffered &&
                    //                   flight && !bVar22`) skips the landing
                    //                   block, and then V5 @0x390a19 assigns
                    //                   +2.0 upright / -2.0 flipped once the
                    //                   gate lets it and the rest is the mode's
                    //                   own updateJump step
                    //   UNDERSIDE       no hitGround at all: V3 @0x390942/49
                    //                   (`min(vy,0)` upright / `max(vy,0)`
                    //                   flipped) and then V4 @0x3909d5, -2.0
                    //                   upright / +2.0 flipped while the button
                    //                   is NOT held. In between, vy
                    //                   free-integrates.
                    // The ship's kShipRampG ladder and the swing's walkIn0 are
                    // both descriptions of "free integration on the side where
                    // hitGround does not run" plus "0 on the side where it
                    // does", fitted per mode; the side test replaces both.
                    // Witnesses (GD's dump of the shipped plans, `input` here
                    // is already the plan's press plus the mode's latency):
                    //   lv16 p1 8,875/8,876 held, flipped above floor ramp
                    //        uid3820 = underside -> V3 gives 0.000, 0.000
                    //   lv16 p1 8,877 released -> V4 -> **+2.000**, then plain
                    //        integration for the remaining 35 ride ticks
                    //   lv16 p2 8,877, the mirror half (upright under ceiling
                    //        ramp uid3819) -> **-2.000**
                    //   lv16 both halves 9,244/9,246/9,248 held, gravity-facing
                    //        -> V5 (-2.000 p1 / +2.000 p2), and 9,245/9,247
                    //        released -> 0.000, the same contact alternating
                    //   lv20 p1 14,016 released, flipped above floor ramp
                    //        uid11804 = underside -> **+2.000** (the model
                    //        wrote nothing here at all)
                    if (slopeNudgeMode(c.mode)) {
                        const double gsN = c.flip ? -1.0 : 1.0;
                        if (slopeUnderside(c.flip != 0, sp->slopeDir)) {
                            if (gsN * (double)c.vy > 0.0) VYSET(c.vy) = 0.f;   // V3
                            VYSET(c.vy) = slopeNudge(c.vy, c.flip != 0, sp->slopeDir,
                                              c.mode, input);
                        } else if (slopeSkipsHitGround(c.flip != 0,
                                                       sp->slopeDir, c.mode,
                                                       input)) {
                            VYSET(c.vy) = slopeNudge(c.vy, c.flip != 0, sp->slopeDir,
                                              c.mode, input);
                        } else {
                            VYSET(c.vy) = 0.f;                                 // V1
                        }
                    } else if (c.mode == 1 && input) {
                        // [2026-08-24] ...and the ladder is MIRRORED BY GRAVITY. A ship's
                        // press acts toward the player's own "up", which is world-down when
                        // it is flipped, so the entry value follows the flip and not the
                        // ramp's world sign alone. The note above already says the dir=-1
                        // side was unmeasured; here is a measurement of it.
                        // lv16 t=8,720 (ship, flip=1, ceiling ramp uid3763 slopeDir=1 at
                        // x=13,205, m=+1, travelling forward, the press tick):
                        //   GD    vy = -2.000, and it leaves the ramp next tick (onGround
                        //         1 -> 0) with the ramp's own launch, -6.330
                        //   model vy = +2.000 -- pressed INTO the ceiling, stayed attached,
                        //         and sat at y=539.000 for the rest of the level
                        // That single tick is where lv16's wall comes from: by the death at
                        // t=8,768 the two are 113 px apart, which is what refuses the kill
                        // record the loop needs there.
                        // The one exit that contradicts a flip mirror elsewhere (t=4,147,
                        // same level, same flip=1) is not this branch at all -- it has
                        // input=0 and leaves through the release.
                        const double dir = ((m * (double)useDx >= 0.0) ? 1.0 : -1.0)
                                         * (c.flip ? -1.0 : 1.0);
                        // The ladder's entry is "carried is 0" = was not pressing
                        // until just now (same shape as the swing's walkIn0
                        // keying continuation on vy==0)
                        VYSET(c.vy) = (s.onSlope && c.slopeM == (float)m
                                && s.vy != 0.0f)
                                   ? (float)qVy((double)s.vy + kShipRampG * dir)
                                   : (float)(2.0 * dir);
                    } else if (c.mode == 7) {
                        const double dir = (m * (double)useDx >= 0.0) ? 1.0 : -1.0;
                        const double gRide = swingG(c.mini != 0);
                        // TRIED AND REVERTED (2026-08-14): basing the step on
                        // `s.vy` instead of `c.vy`. `c.vy` already carries the
                        // airborne branch's own `vpS -= kSwingG`, so the ride
                        // integrates the swing's gravity TWICE per riding tick,
                        // and GD does not: measured on lv22's ride
                        // t=3,774..3,805, GD is SET to 2.000 on acquisition and
                        // reads 4.666 thirty-one ticks later (0.086/tick) where
                        // the model reads 7.418 (0.172/tick).
                        // Fixing it alone makes the replay WORSE -- the
                        // divergence block from t=3,806 goes 223 -> 760 ticks --
                        // because the doubling was silently paying for a
                        // MISSING RELEASE IMPULSE. GD adds one on the tick the
                        // swing leaves the ramp, and it is not a constant:
                        //   t=3,806  vy 4.666 -> 6.906  (+2.240)
                        //   t=4,585  vy 2.000 -> 4.899  (+2.899)
                        // Those are the only two same-gravity jumps in the
                        // whole swing stretch that are not the ride's own
                        // "set to +-2.000" or its landing "set to 0.000", so the
                        // release is a real rule with a variable of its own
                        // (the ramp's gradient and/or the ride's length -- cf.
                        // slopeExitVy). The two have to land TOGETHER.
                        // ...but a WALK-IN rides with vy pinned at 0, the
                        // cube's convention, not the airborne 2.000. Measured
                        // on lv22 t=3,490-3,494: the swing is pushed along the
                        // band floor into this ramp by the 2069 carpet (GD's
                        // g stays 1 through the lift AND the ride) and GD
                        // reports vy 0,0,0,0,0 while the y climbs the ramp
                        // bit-exactly. The model's own grounded flag is
                        // already 0 here (the lift integration cleared it),
                        // so the gate below uses "inside a lifting force box"
                        // as a PROXY for "came in grounded" -- the only
                        // measured walk-in is the force-box lift, and the
                        // 2.000 site (uid5430) has no boxes anywhere near it.
                        // If a walk-in without a force box (or a fast flier
                        // crossing a box onto a ramp) ever shows up in the
                        // census, replace this with a real came-in-grounded
                        // bit. Continuation keys on vy == 0: the airborne
                        // convention starts at 2.000 and integrates AWAY from
                        // zero, so the two cannot alias.
                        // [2026-08-20] The case the note above predicted appeared
                        // on a rig. **A walk-in with no force box**: on the new
                        // calibration rig flyramps (a swing sliding along the
                        // floor into a ramp, zero input) GD stays vy=0.000 for
                        // all 70 riding ticks, yet the model accumulated from
                        // 2.000 up to 7.934 and on the departure tick flew up by
                        // that much (7.934x0.225 = **+1.785px**). The launch
                        // velocity itself (5.554) already matches; the offset is
                        // only the departure tick's y, then a permanent parallel
                        // shift. 8 units (m=1,2 x normal/mini x 2 ride lengths)
                        // give the same 1.785 / 0.895 / 1.937. **Replace the
                        // proxy with the real "entered grounded"** -- lv22's 2069
                        // carpet has the grounded flag down, so the force-field
                        // proxy stays as an OR.
                        const bool walkIn0 =
                            (s.onSlope && c.slopeM == (float)m)
                                ? (s.vy == 0.0f)
                                : (s.grounded
                                   || (!g_forceBoxes.empty()
                                       && forceBoxAcc(modX, modY, pHalf,
                                                      forceUnitFor(s.mode, useDx))
                                                  * (s.flip ? -1.0 : 1.0)
                                              > kSwingG));
                        VYSET(c.vy) = walkIn0
                                   ? 0.0f
                                   : (s.onSlope && c.slopeM == (float)m)
                                   ? (float)qVy((double)s.vy + gRide * dir)
                                   : (float)(2.0 * dir);
                    // [2026-08-21 r61] **A ride pushed out onto a floor ramp with
                    // gravity still pointing the other way does not zero vy.**
                    // Measured lv22 t=8,233..8,235 (spider, flip=1, floor ramp
                    // uid17788 m=+1): GD keeps y stuck to the seat while **vy
                    // stays in free integration** (2.891 -> 3.020 -> 3.149 ->
                    // 3.278 = +0.129/tick = the spider's g) for 3 ticks, and vy
                    // first becomes 0 at t=8,236, the tick flipGravity(false) ran
                    // (the MOD's `pfg:` line, slopeUp=1 = m_maybeUpsideDownSlope).
                    // Once r60 made the ride acquirable, y matched exactly for 15
                    // ticks, but zeroing here merely morphed the family from
                    // edy +0.864 to edvy +3.020.
                    // **The mode-specific ladders (the ship's 2.000/+0.086, the
                    //   swing's walkIn0) apply even when flipped** -- 6 ticks
                    // earlier on the same ramp (t=8,227, still swing, flip=1) GD
                    // emits the swing's acquisition value, 1.234 -> **2.000**.
                    // Skipping this else entirely made that a new family,
                    // `m7/.../air` edvy +0.680.
                    // [2026-08-21 r67] **r61's gate is "push-out onto the top
                    // face" only.** r61 was written as `!flipForRide`, but that
                    // keeps accumulating vy even for the **hang (ridesTop=0 =
                    // sliding a ceiling ramp's underside)**. GD maintains vy=0
                    // during a flipped ship's hang (calibration rig ceilramp
                    // unit0: vy=0.000 on every riding tick -- r61 floated 21px
                    // and became a regression where the model dies).
                    // The lv22 spider measurement is only flipForRide **and**
                    // ridesTop=1 (the case pushed out onto a floor ramp's top
                    // face by r60's hatch).
                    } else if (!(flipForRide && ridesTop)) {
                        VYSET(c.vy) = 0;
                    }
                    // CONTACT IS NOT LANDING. collidedWithSlopeInternal does
                    // setPosition(x, targetY) @0x39074a and m_isOnSlope = 1
                    // @0x390750 unconditionally, and only decides about landing
                    // ~180 instructions later: hitGround always zeroes vy
                    // (0x39c164) but sets m_isOnGround only when the
                    // gravity-frame speed is <= 5.0 (comisd against the double
                    // @0x622E98), and the caller PUTS THE OLD VELOCITY BACK when
                    // it is above (comiss against 5.0f @0x623010 / -5.0f
                    // @0x6237C0, then setYVelocity at 0x3907dd).
                    // So above the threshold the ramp still corrects the
                    // position and still counts as onSlope; it simply is not a
                    // landing. lv22 t=18,606 is that case in GD's own trace: it
                    // sets onSlope=1 for uid 16681 and moves y 2021.843 ->
                    // 2021.949 while keeping vy=12.849 and staying ungrounded,
                    // where the model zeroed vy and grounded on the tick after a
                    // jump.
                    // Measured over all 1,016 ramp acquisitions, split by GD's
                    // grounded TRANSITION (the value alone is no evidence: the
                    // non-landing path does not clear the flag, so 912 rows sit
                    // in 1->1 and say nothing):
                    //   0->1  GD lands       23 rows, ALL s*v <= 5   23/23
                    //   0->0  GD refuses     66 rows, ALL s*v <= 5    0/66
                    // so the threshold is sufficient to refuse and not necessary
                    // -- the 66 belong to the other three refusal causes (the
                    // underside branch 0x390931, the re-acquisition suppression
                    // 0x390488, the two contact-test forms) and are untouched.
                    // On this corpus the gate is therefore NEUTRAL: every
                    // informative row is below it. What it changes is lv22
                    // t=18,606 at s*v = +13.06, which the whole-run census
                    // cannot reach because lv22 dies at t=6,350.
                    // The entering velocity is used, matching the census; GD
                    // tests the integrated one, a gravity step away, and no row
                    // is near enough to 5.0 for that to matter (the largest is
                    // +2.6). For the same reason the corpus cannot say whether
                    // the deciding compare is the double or the caller's float.
                    const double svRide =
                        (double)vyPreRide * (c.flip ? -1.0 : 1.0);
                    const bool rideLands = svRide <= kSlopeLandV;
                    // [2026-09-06] **V2 is the GRAVITY-FACING branch's restore.**
                    // 0x3907dd sits behind `hitGround` on the XOR == 0 path
                    // (0x390790 jumps the underside past it), so on the
                    // underside there is nothing to undo -- the min/max clamp
                    // and the nudge above ARE the write, and putting vyPreRide
                    // back would erase them for any contact entered above 5.0
                    // (lv16 t=14,588 arrives at +7.387 and GD still reads
                    // -2.000 on that tick).
                    const bool undoneBySide =
                        slopeNudgeMode(c.mode)
                        && slopeUnderside(c.flip != 0, sp->slopeDir);
                    if (!rideLands && !undoneBySide)
                        VYSET(c.vy) = vyPreRide;               // 0x3907dd's restore
                    // ...and **it is not grounded either**. GD's onGround stays 0
                    // throughout this ride (the measurement table above, every
                    // tick of 8,227..8,235). Setting it lets the next tick's
                    // "standing = vy 0" apply directly and the carefully kept vy
                    // vanishes in 1 tick (r61b's remainder: only t=8,233 matches
                    // at 3.020, and from 8,234 only the model is 0). r67: this
                    // too is limited to the push-out case.
                    if (rideLands && !(flipForRide && ridesTop)) c.grounded = 1;
                    else if (rideLands) rodeFlipped = true;
                    // Record the landing for the launch to read on the way out
                    // (State::rideLanded). It has to be remembered here rather
                    // than reconstructed at the exit: `grounded` misses the
                    // flipped-on-a-top case one line above, which is a landing
                    // GD does launch from (lv16 t=8,875 -> 8,913). Carried
                    // through a chain of ramps the same way slopeUid0 is, so a
                    // seam does not look like a fresh unlanded contact.
                    // --stickground: ...but a contact that does not land does
                    // not carry an earlier landing either. lv16 t=13,264..13,266
                    // (dual p2, mini ball): launched off uid m +1 at 7.68, it
                    // meets the line once more at 7.551 without landing, and GD
                    // then flies free at 7.422 with no exit launch; carrying the
                    // earlier landing through that contact made the model emit
                    // one (4.316) on the way out.
                    c.rideLanded = (uint8_t)rideLands;
                    c.onSlope = 1;
                    c.slopeM = (float)m;
                    c.slopeUid0 = s.onSlope ? s.slopeUid0 : sp->uid;
                    c.slopeUidNow = sp->uid;
                }
            }
            // --slopelaw's seat, applied only if the loop above left the body
            // where it found it. Everything that resolves a ramp contact writes
            // y (the ride's `top`, the push-out, the corner stands, the
            // came-from-below clamp), so "y and grounded are untouched" is the
            // one test that means "no ramp took this contact", without naming
            // any of them. The state writes ride along here for the same reason
            // the seat does: a landing applied mid-loop is read by the rules
            // after it.
            if (lawSeat && c.y == yBeforeSlopes && c.grounded == gBeforeSlopes) {
                if (g_slopeDbg)
                    std::printf("slopelawapply: t=%lld p%d uid=%d y=%.4f->%.4f\n",
                                (long long)K.t, g_halfNow + 1, lawUid,
                                (double)c.y, lawTop);
                YSET(c.y) = (float)lawTop;
                const double gsSL = c.flip ? -1.0 : 1.0;
                if (lawUnder) {
                    if (gsSL * (double)c.vy > 0.0) VYSET(c.vy) = 0.0f;
                } else if (gsSL * (double)c.vy <= kSlopeLandV) {
                    VYSET(c.vy) = 0.0f;
                    c.grounded = 1;
                }
                if (!lawUnder) lawSeatedNow = true;
            }
            // Pass 2: only a SPIKED ramp kills. A plain one does not -- it lifts
            // the player out.
            //
            // This whole test used to fire for every ramp, and all the evidence
            // for that came from lv18, where 116 of the 154 spiked ramps sit on
            // TOP of a plain one at the same (cx,cy). Every "GD kills a player
            // inside a ramp" observation was the spiked twin.
            // Measured on lv16's (6708,293) 60x30, line 278->308, which has no
            // twin: injecting the ball at y = 262, 270, 278, 285, 293, 300 and
            // 308 -- from under the box to inside the triangle -- GD puts ALL of
            // them at y = 311.385 with vy = 0 and onGround = 1, i.e. on the
            // surface. None dies. Scanning y in 2.5 px steps across three x
            // inside that ramp and the one at (6768,323), the only lethal band
            // is at a CONSTANT y (the spike row at 244), nowhere near the line.
            //
            // The old "solid slice = box floor to the line" also cannot be the
            // rule even for the spiked ones. Point-probed on lv18's (5115,405)
            // pair (solid 420->390, spiked 416->386), 1 tick per point, x and y
            // both injected:
            //   x=5096  line 424.0  alive top<=410.45  dead top>=410.47
            //   x=5100       420.0             406.45            406.47
            //   x=5104       416.0             402.45            402.48
            //   x=5108       412.0             398.45            398.48
            //   x=5112       408.0             394.46            394.48
            // The boundary is exactly PARALLEL to the line (9.54 px under the
            // spiked one), while the old rule's lower edge is the box floor -- a
            // HORIZONTAL line. The two only agree near the middle of the box,
            // which is why lv16 (ridden across the middle) worked and lv18's
            // tunnel (flown through near the ends) did not. Left as-is for the
            // spiked ramps because it errs toward killing, which only costs
            // reachability; the parallel form needs one more sweep to pin down
            // (gradient and mini are unmeasured).
            // [2026-09-14] **THE KILL BOX OF THIS MODE, NOT THE RIDE BOX.**
            // `pH` above is the RIDE box, and it is kCubeHalf for every mode
            // but the spider -- including the wave, which rides a ramp on the
            // cube's 15.0 but is killed by a solid on 1.5 (kWaveKillHalf,
            // bisected to 0.01 px on two levels, two ids, both sizes, both
            // faces). Reusing the ride box here gave the wave a lethal slice
            // 13.5 px taller than the one GD kills it in.
            // Witness lv17_t11814, a dual section whose p2 is a wave climbing
            // a spiked 45-degree ramp (uid5595): on 15.0 the model died at
            // t=11,828 on the RAMP, 8 ticks before GD, which killed p2 at
            // t=11,836 on the small spike uid5596 (id720, 2.4x3.2) past its
            // top. On 1.5 the ramp no longer reaches p2 and the model dies at
            // GD's own tick on GD's own object -- the death reference's match
            // column reads `same`, not merely the same tick. 39/47 -> 40/47,
            // nothing else moves, and the replay suite is row-identical.
            // The ride box is deliberately left alone: seating a wave on 1.5
            // is a different claim and no rig has measured it.
            //
            // [2026-09-15] **1.5 IS TOO SMALL, AND 15.0 WAS TOO BIG. THE
            // BOUNDARY IS BRACKETED, NOT CHOSEN.** Both bounds are GD's own
            // testimony about lv17:
            //   upper  14.67  lv17_t11814, the floor ramp above. Above this the
            //          model kills p2 before GD does (15.0 misses by 0.33 px).
            //   lower   7.864 twenty kill=1 fixups from the cold run at
            //          x=22,780..22,827 (uid 8727) and x=23,201..23,248
            //          (uid 8844), every one a CEILING spiked ramp. A kill
            //          fixup is GD ending the run on a transition the model
            //          flew through, so at 1.5 the model under-kills there --
            //          which the replay suite and the death references both
            //          missed (the corpus has no death for a loosened rule to
            //          fail to reproduce; only the loop sees it).
            // 9.54 sits inside that window and is not picked out of it: it is
            // the offset the lv18 point-probe measured for the lethal boundary
            // of a spiked ramp (the five points in the note above -- the
            // boundary runs PARALLEL to the line, 9.54 px under it). Using it
            // as a half is still the wrong SHAPE; what is claimed here is only
            // that it is inside a window derived from two independent sides.
            // [2026-09-15] **THE OUTLINE IS MEASURED, ON calib_slopespike.**
            // The bracketed 9.54 is gone, and so is the interval overlap: the
            // lethal region of a spiked ramp is
            //
            //   x window   sx0 - ph  <=  x  <=  sx1 + ph        (ph = CONTACT half)
            //   sloped side  the perpendicular distance from the player's CENTRE
            //                to the surface LINE is at most ph, i.e. a boundary
            //                parallel to the line, ph*sqrt(1+m^2) away in y --
            //                and the line is EXTRAPOLATED past the box, not
            //                clamped
            //   capped       at the line's own high (floor ramp) or low (ceiling
            //                ramp) end: the boundary never leaves
            //                [min(sy0,sy1), max(sy0,sy1)]
            //   flat side    the box's other face plus the INNER kill box
            //
            // ph is the contact half -- playerHalf, so 5.0 for a wave -- NOT the
            // ride box pH this used to borrow, which is kCubeHalf for every mode
            // but the spider. That single substitution is most of the old error:
            // for a wave the x window was 10 px too wide on each side.
            //
            // The outline, floor ramp id 366 (box x 600..630, line 229->259):
            //   x    595   596   ...  600   ...  615   ...  621   624   630   635
            //   y_b  231.1 232.1      236.1     251.1     257.1 259.0 259.0 259.0
            //   alive at x=594 and x=635.5 -> the window is 600-5 .. 630+5
            // slope 1.000 through the box AND past its left edge (so the line is
            // extrapolated), flat at 259 = sy1 from x=624 (where the parallel
            // boundary would pass it). The ceiling unit is the mirror: its low
            // edge sits at 221 = sy1 at both x=1886 and x=1892.
            // Perpendicular, not vertical: d = 5.031 / 5.039 / 5.031 at
            // |m| = 0.5 / 1.0 / 2.0 (ratio 1.579 against sqrt(5/2) = 1.581), and
            // 14.955 for the ship. Two predictions registered before the run
            // landed inside their brackets (|m|=0.5 at 230.37, ship at 214.8).
            // The flat side: box top 255, wave dies to 256.50 and lives at
            // 256.75 (+1.5 = kWaveKillHalf), ship to 259.5 and lives at 260.0
            // (+4.5 = kCubeInner).
            // A FIRST ATTEMPT AT THIS WENT 40/47 -> 38/47 because it dropped the
            // x window and the caps and kept the clamped surf: the centre test
            // then kills outside the triangle, which is what the note below
            // about a zero-height slice at the low corner is about.
            // STILL UNMEASURED: the spider's halves; the two |m|=2 FLOOR units
            // disagree by 1.0 px (d 5.42 vs 4.98 around 5.03), 19 of the corpus'
            // 573 spiked ramps being that steep; and the flat side of a FLOOR
            // ramp is taken by symmetry with the ceiling one.
            // --waveslopeside: a mini wave's measured distance is its rect's half (frames.hpp)
            const double ph = (c.mode == 4 && c.mini)
                ? kWaveHazHalfMini : playerHalf(c.mode, c.mini != 0);
            const double inner = (c.mode == 4) ? kWaveKillHalf : kCubeInner;
            // [2026-09-15] **A PLAIN RAMP KILLS A WAVE.** GD's gate is
            //   if ((m_slopeIsHazard == 0 && (A || B)) || player+0xc44) -> live
            //   A = !bVar9 && (m_isDart == 0 || m_stateDartSlide > 0)
            //   B = m_isPlatformer != 0 || m_stateHitHead > 0
            // so the hazard flag only decides for the modes A||B covers.
            // [2026-09-16] THE LINE THAT USED TO STAND HERE WAS WRONG: "+0xc44
            // is written once, to 0, in PlayerObject::PlayerObject and by
            // nothing else -- a dead field". It is not dead. The game layer
            // writes it, on both players:
            //   0x14020b7f2  mov byte [rax + 0xc44], 1   ; rax = [rdi + 0xda8]
            //   0x14020b80b  mov byte [rax + 0xc44], 0
            //   0x1402d2fc6  mov byte [rcx + 0xc44], al  ; rcx = [rbx + 0xda0]
            //   0x1402d2fda  mov byte [rcx + 0xc44], al  ; rcx = [rbx + 0xda8]
            //                                            ; al = [rbx + 0x886]
            // The claim came from scan_field_offset.py, which FAILS a
            // known-answer control: the 09-05 underside note names two writes of
            // 0 to +0xa0c at 0x390297 / 0x39095d, both confirmed with
            // gddisasm_min (canary 2/2), and that script reports neither -- while
            // also reporting eleven hits that are really 0xa0cb8 / 0xa0cbf /
            // 0xa0c9e. Its counts are unusable in both directions. The sites
            // above come from disp32_sites.py, which passes that control.
            // WHAT THIS DOES NOT TOUCH: the rule below is measured directly on a
            // rig (a wave dies on plain 309 at d = 4.985, a cube does not, and
            // lv21's own 1338/1339 match 484 to 0.012px), so it does not rest on
            // +0xc44 at all. WHAT IT DOES TOUCH: "the spiked kill is
            // unconditional because the only escape hatch is dead" is no longer
            // supported. When +0xc44 is set GD does not kill, and whether that
            // happens on the corpus is UNMEASURED.
            // Measured on calib_slopespike's plain
            // 309 (box 4215..4245, line 225->255, so 240 at the middle):
            //   wave   247.00 dead / 247.10 alive -> d = 4.985, the same offset
            //          the spiked ramps gave (5.031..5.039)
            //   cube   seventeen points 230..262, EVERY ONE ALIVE
            // which is also why the note at this test could quote a lv16 probe
            // of seven heights on a plain ramp with no death: it was a BALL.
            // The exemption is real and it has to be modelled, or a wave riding
            // a plain ramp dies: its seat IS this boundary (surf + ph/cos), so
            // without `m_stateDartSlide > 0` GD would kill every slide. onSlope
            // is the model's name for that state.
            const bool plainKillsHere = (c.mode == 4) && !c.onSlope;
            for (const Obj* sp : *K.slopes) {
                if (!sp->slopeHazard && !plainKillsHere) continue;
                const double sx0 = sp->cx - sp->hw, sx1 = sp->cx + sp->hw;
                const double sm = (sp->sy1 - sp->sy0) / (sx1 - sx0);
                // The solid half is the TRIANGLE inside the object's box, not
                // the whole half-plane under the line -- so the box's y range
                // is part of the test. Without it the model killed everything
                // under a floor ramp, which is most of a corridor, and lv18
                // lost its whole frontier 400 px early.
                // The window is the wave's measured one (dead at 595.0 and 635.0
                // against a box of 600..630, alive at 594 and 635.5) and, for
                // every other mode, exactly the open test it had -- so that the
                // modes whose outline is NOT measured keep their old behaviour
                // down to the boundary case.
                const bool inWin = (c.mode == 4)
                    ? (x >= sx0 - ph && x <= sx1 + ph)
                    : (x + pH > sx0 && x - pH < sx1);
                if (inWin) {
                    // sampled at the player's CENTRE (see the pass-1 note), and
                    // EXTRAPOLATED past the box: measured on the rig's left side,
                    // where the boundary keeps the line's slope out to sx0 - ph.
                    // The caps below are what stops that extrapolation running
                    // away, and they are measured too.
                    const double surf = sp->sy0 + sm * (x - sx0);
                    const double lineLo = std::min(sp->sy0, sp->sy1);
                    const double lineHi = std::max(sp->sy0, sp->sy1);
                    const double off = ph * std::sqrt(1.0 + sm * sm);
                    // The solid is the slice between the box's floor and the
                    // line, so the test is a real interval overlap, not "below
                    // the line". At a ramp's low corner that slice has ZERO
                    // height, and the half-plane version killed every ball that
                    // clipped the next ramp's leading edge -- lv16 t=4701,
                    // riding up one 60x30 ramp into the contiguous next one,
                    // 0.8 px into a slice of height 0.
                    // ...and WHICH slice is solid is slopeDir's business, exactly
                    // as it is for the ride (see slopeIsCeiling). This test had
                    // the floor ramp's answer hardcoded -- box floor up to the
                    // line -- so on a CEILING ramp, where the solid is the line
                    // up to the box's top, the interval came out empty and the
                    // model flew straight through the spikes.
                    // Measured on lv16 t=12,685 (mini UFO, pbox 18x18 so pH=9,
                    // injected y=590 at x=19,177.52): GD destroys the player on
                    // uid6404 (id367 shz=1, box (19142,613) 60x30, sy 624->594,
                    // slopeDir 1). The old form gave lo=598 (box floor)
                    // hi=594 (line) -> empty; the ceiling form gives lo=594
                    // (line) hi=599 (player top) -> hit, which is GD's answer.
                    // Same {1,3} vs {1,3,5,6} caveat as everywhere else: only the
                    // ship is on GD's full set so far.
                    // --killslopeside: GD's own set for every mode. This line is
                    // the LAST {1,3} subset in the tree -- the ride path dropped
                    // its mode whitelist in r63 (2026-08-21, "the reason was the
                    // same every time and has nothing to do with the player's
                    // mode") and the ceiling-ramp branch reads ceilRampSide, so
                    // the comments there that still say "ship only" are stale.
                    // 447 of the corpus's 3,091 type-25 slopes have slopeDir in
                    // {5,6}: GD calls them ceiling and this line calls them
                    // floor, which swaps which interval is solid. That moves
                    // kills in BOTH directions, so it was held off until the
                    // enumeration was read. lv20's p2 at t=17,288 is the witness
                    // that brought it up -- uid14063, slopeDir 6, GD carries
                    // both bodies on to the end of the level.
                    const bool ceilSlope = slopeIsCeiling(sp->slopeDir);
                    // [2026-09-15] **THE MEASURED OUTLINE IS THE WAVE'S ONLY.**
                    // The rig says the modes do NOT share d: against the same
                    // ceiling unit (line 236, box 225..255) the boundary is
                    //   wave  228.75 alive / 229.00 dead  -> d =  5.03
                    //   ship  214.80 alive / 214.90 dead  -> d = 14.96
                    //   cube  216     alive / 217     dead -> d = 13.79
                    // The ship lands on playerHalf and the cube does not, which is
                    // its own finding rather than noise: a cube ROTATES in the air
                    // and a turned square's perpendicular support runs from 15 to
                    // 21.2, so its d cannot be a constant at all. One column
                    // cannot say which angle it caught.
                    // Applied to every mode it cost lv16 six iterations and
                    // fourteen fixups on the cold run -- 19 of the 32 sites kill
                    // records, in cube/ship/ball/ufo and NOT ONE in a wave, which
                    // is the fingerprint of a rule taken past its measurement.
                    // So the wave keeps the measured outline and everything else
                    // keeps the interval overlap it had. The flat side (the inner
                    // kill box) IS measured for both, but it is not separable
                    // from the sloped side here, so it travels with it.
                    const double y0 = (double)c.y;
                    bool hit;
                    // --shipslopekill: the ship on the measured outline too. Its
                    // own rig numbers are above (d = 14.96, on playerHalf; flat
                    // side +4.5 = kCubeInner, both of which `ph` and `inner`
                    // already carry), and it was held back only with the cube.
                    // lv18 t=17,107 is what the interval form misses: a ship at
                    // (23404.77, 390.83) under spiked ceiling ramp uid12096
                    // (sy 416->386, line 411.23 there) is 14.42 px from the line
                    // perpendicular -- GD destroys it with no object, the
                    // interval test sees the ship's top at 405.83 below the line
                    // and does not. Same trajectory with --slopelaw on and off.
                    if (c.mode == 4 || c.mode == 1) {
                        // --waveflipkill: a FLIPPED wave's sloped edge sits
                        // further out. Measured on calib_slopespike_wave and its
                        // flipped-gravity twin (the same units at the same x, one
                        // gravity portal apart), ceiling-type spiked ramps, three
                        // columns each, 0.25 px steps:
                        //   367 rot180 (m=0.5)  normal d 4.94-5.16   flipped 5.83-5.97
                        //   366 rot180 (m=1)    normal d 4.98-5.16   flipped 5.69-5.86
                        // Both flipped columns run parallel to the line and share
                        // 5.83-5.86, so it is a constant perpendicular distance,
                        // not a shifted sample point (a 1.74 px x shift predicted
                        // 8.85 vertical on m=1; measured 8.04-8.29). The cap at
                        // lineLo is the same flipped or not. lv17 x=22,782 (a
                        // flipped wave under uid8727) measured 5.79-5.97, the
                        // same number, riding a plain twin -- so riding is not it.
                        // Only the ceiling-type branch: floor ramps under a flipped
                        // wave are not measured.
                        const double offW = (c.mode == 4 && c.flip
                                             && ceilSlope)
                            ? kWaveFlipSlopeKillD * std::sqrt(1.0 + sm * sm)
                            : off;
                        const double lo = ceilSlope
                            ? std::max(surf - offW, lineLo)   // sloped, capped
                            : sp->cy - sp->hh - inner;        // flat
                        // --waveslopeside: a descending floor ramp's boundary is 1.0 px
                        // higher than an ascending one's (frames.hpp); upright waves only
                        const double downDy = (c.mode == 4 && !c.flip
                                               && !ceilSlope && sm < 0.0)
                            ? kWaveSlopeDescendDy : 0.0;
                        // ...and the cap past the ramp's high end is not the line's top:
                        // measured flat at lineHi + 4.0 for a normal wave on 309 (m=1,
                        // uphill) and on 1338 (m=1, downhill, no +1 there) and on 1339
                        // rotated 90 (m=2). The source's cap is hP/2 + objMaxY (0x38fd73),
                        // one pixel above what the rig kills at, so the extra pixel is
                        // taken from the measurement, not the formula.
                        const double capHi = (c.mode == 4 && !c.flip)
                            ? lineHi + ph - kWaveSlopeCapInset : lineHi;
                        const double hi = ceilSlope
                            ? sp->cy + sp->hh + inner         // flat
                            : std::min(surf + off + downDy, capHi);   // sloped, capped
                        hit = (y0 >= lo && y0 <= hi);
                    } else {
                        const double sxc = std::min(std::max(x, sx0), sx1);
                        const double sf = sp->sy0 + sm * (sxc - sx0);
                        const double lo = ceilSlope
                            ? std::max(y0 - pH, sf)
                            : std::max(y0 - pH, sp->cy - sp->hh);
                        const double hi = ceilSlope
                            ? std::min(y0 + pH, sp->cy + sp->hh)
                            : std::min(y0 + pH, sf);
                        hit = (lo < hi - 0.001);
                    }
                    if (hit)
                        DIE(sp->slopeHazard ? "slope/spiked" : "slope/inside", sp);
                }
            }
        }
        // [2026-08-20] **A ride cannot descend below a flat solid.** The pair of
        // the "do not transfer" gate above; aligns the y side with GD. Limited to
        // rides descending in the travel direction (uphill is mid-push-up by the
        // face, and picking up a neighbouring solid's top face over-lifts).
        const double mTravRide = (double)c.slopeM
                               * (((double)K.dxF < 0.0 || s.rev != 0)
                                      ? -1.0 : 1.0);
        if (c.onSlope && !c.flip && K.near && mTravRide < 0.0) {
            double bestFace = -1e18;
            for (const Obj* nb : *K.near) {
                if (nb->type != 0 || nb->oneway) continue;
                if (std::fabs(x - nb->cx) > nb->hw) continue;   // centre over it
                const double face = nb->cy + nb->hh;
                if (face + pHalf <= (double)c.y + 0.001) continue;
                if (face > (double)c.y + pHalf) continue;   // a wall is a different story
                if (face > bestFace) bestFace = face;
            }
            if (bestFace > -1e17) YSET(c.y) = (float)(bestFace + pHalf);
        }
        // -------------------------------------------------------------------
        // [2026-09-06] **RAMP FIRST, THEN SOLID** -- GD's own order.
        //
        // GJBaseGameLayer::checkCollisions (0x2137f0) is TWO passes. The bucket
        // scan fires portals/orbs/triggers in place and resolves slopes (type
        // 0x19) and teleports (0x1c) THERE; solids (type 0 / 0x15) and hazards
        // are only PUSHED onto a list in that scan and resolved afterwards, in
        // the loop that calls PlayerObject::collidedWithObject (0x214687). So
        // in GD a solid always sees the seat the ramp has already written, and
        // a face that cuts that seat pushes the player back out of it.
        //
        // The model runs the two the other way round -- the per-mode solid
        // loops, then this whole slope block -- and never revisits a solid, so
        // a seat that climbs into a block simply keeps climbing.
        //
        // WITNESS lv16 t=4,142: a flipped ship hanging under floor ramp uid1468
        // ((5790,435) 60x30, m=+0.5, line 420->450), its centre already past
        // the ramp's high end x1=5820, and solid uid1480 ((5835,465) 30x30)
        // whose bottom face 450 is that ramp rect's own top -- which is how GD
        // builds these ceiling corridors.
        //   gdref        435.000 = 450 - 15, held from 4,142 to 4,146
        //   seat alone   435.402 436.209 437.016 437.823 438.631
        //                (the extrapolated line, m*dx = +0.807 a tick)
        // t=4,141 is untouched (434.594 against gdref's 434.595): there the
        // seat does not reach the face at all.
        //
        // SHAPE, and what it deliberately does not cover. This is a PUSH-OUT
        // and nothing else -- no landing, no grounding, no velocity, no kill,
        // no hazard, no orb/pad, no one-way plate. The solid loops above keep
        // all of that and keep running first; what is added is the second look
        // GD takes at the same solid after the seat. It fires only where the
        // SEAT ITSELF crossed the face on this tick (outside before, inside
        // after), so a penetration the solid pass already declined to resolve
        // stays that pass's business. That gate also bounds the correction: the
        // result always lies between the pre-seat y and the seat, and with no
        // seat there is no rule at all -- which is what made
        // `--no-slopeseat --no-rampfirst` the pre-2026-09-06 build byte for
        // byte (`--no-rampfirst` is gone since the flag clean-up).
        //
        // CENSUS, over the 22 whole-run replays (2026-09-06).
        // 171 ticks put a solid and a ramp seat on the same player; 6 of them
        // are a seat CROSSING a face and the other 165 are penetrations the
        // player was already in before the seat ran -- which is the solid pass's
        // business, and which the crossing gate leaves to it. Of the 6, one is
        // vetoed (below) and 5 fire, all lv16 4,142-4,146, all to GD's own
        // 435.000. Deepest penetration on a firing row: 3.63 px, i.e. inside
        // GD's 6.0 flight reach-back, which is why the tolerance gates of
        // collidedWithObjectInternal (6.0 flight / 10.0 ground, 0x391bc1 /
        // 0x391c48) are not modelled here.
        //
        // slopeVetoesSolid is applied with the same arguments the two solid
        // loops use, because it is a veto GD performs inside the solid
        // resolution itself (0x392520 / 0x392a9b) and this is that resolution
        // running a second time. It earns its place on the corpus's one other
        // crossing row: lv16 t=6,316, a cube riding uid2580 down past solid
        // uid2590's top face 150. The seat takes it from 165.707 to 164.900 and
        // gdref goes to 164.8999 -- GD descends past the face -- so without the
        // veto this rule would pin a tick that is exact today. (The `blockedByFlat`
        // gate further up names the same tick for the same reason.)
        if (K.near) {
            const double preY = (double)yFreeBeforeSlope;
            const double seatY = (double)c.y;
            if (seatY != preY) {
                const bool up = seatY > preY;
                double lim = seatY;
                for (const Obj* const& o : *K.near) {
                    if (o->type != 0 || o->oneway) continue;
                    if (std::fabs(x - o->cx) > o->hw + pHalf) continue;
                    // the blocking face, expressed as the centre y at which the
                    // player's box just touches it
                    const double f = up ? (o->cy - o->hh - pHalf)
                                        : (o->cy + o->hh + pHalf);
                    if (up ? !(preY <= f && seatY > f)
                           : !(preY >= f && seatY < f)) continue;
                    // `faceIsTop`: pushed UP means the contact is with the
                    // block's underside, pushed DOWN means with its top.
                    if (vetoOf(K, o, x, seatY, pHalf, pHalf,
                               !up, xPrev, (double)s.y, c.slopeUidNow))
                        continue;
                    if (up ? (f < lim) : (f > lim)) lim = f;
                }
                if (lim != seatY) YSET(c.y) = (float)lim;
            }
        }
        // Leaving the top launches. GD applies it like a pad: the y move for
        // this tick already happened with the old velocity.
        // Only an UPHILL exit launches; running off the bottom of a downhill
        // ramp just leaves the player falling.
        // The launch BEATS a jump taken on the same tick. Measured on lv16
        // t=6516: the plan presses at the top of the 330->360 ramp at
        // (9645,345) and GD comes out at 9.208 -- the ramp's own exit for m=1
        // at speed 1.1 -- not the cube's 11.420. The old `c.vy <= 0` guard let
        // the jump stand, and the model then ran 2.2 vy fast for the rest of
        // the section. `rampWindowHere` is what keeps a MID-ramp jump intact:
        // there a ramp still holds the player, so this is not an exit.
        // ...and a FLIPPED player leaving a CEILING ramp is the mirror of it:
        // "uphill" for it is m < 0, and the launch points the other way.
        // Measured on lv22 t=4,637 (cube, ramp uid4359 (6705,435) m=-1,
        // speed 0.7, one riding tick): GD leaves at vy = -2.390 and then decays
        // at +0.212/tick, which is the cube's own gravity -- the last press was
        // the release at t=4,635, so this is the RAMP's launch, not a jump.
        // "Uphill" is TRAVEL-relative, not a world-m sign: a reverse rider on
        // a world-descending ramp is climbing it. Measured on lv22 t=18,567
        // (mini cube, x-decreasing, world m<0, y rising +2*|dx|/tick): GD
        // launches at t=18,568 with vy=13.064 while the sign test read the
        // ride as downhill and never fired. sign(useDx) is +1 everywhere a
        // forward section runs, so nothing else moves.
        // [2026-08-18] sign(useDx) was another dead test (same reason as the rev
        // note at sampleAt: useDx is always positive via anchors). Redrawn with
        // the true travel direction.
        const double mTravel = (double)s.slopeM
                             * (((double)K.dxF < 0.0 || s.rev != 0)
                                    ? -1.0 : 1.0);
        // [2026-08-24] **A flipped player's "uphill" depends on WHICH SIDE it
        // rode, not on its gravity.** The mirror above was written as "flipped =>
        // uphill is m<0", and its stated evidence (lv22 t=4,637, flipped cube off
        // uid4359, -2.390) does not reproduce: replaying lv22's own solution, GD
        // is at t=4,637 upsideDown=**0**, mode=cube, yvel=**-0.454**. That note is
        // from an older lineage ([[gd-constant-justification-goes-stale]]).
        // What the corpus actually holds is one flipped launch on each side, and
        // the ride side tells them apart where the flip alone cannot:
        //   lv22 t=3,806  flipped swing on uid5387 **sdir=0** (a FLOOR ramp, ridden
        //                 on top: the offset is line + pH*sqrt(2) = 21.213 for
        //                 three ticks running, then the high-end flat 195.000),
        //                 mTravel=+1. GD launches at **6.906** = the m=1 non-cube
        //                 exit; the flip mirror called it downhill and emitted the
        //                 release pulse dx/0.25 = 6.457 instead, and lv22's model
        //                 then cannot replay its own solution past t=4,231
        //   lv16 t=8,721  flipped ship hanging under uid3763 **sdir=1** (a CEILING
        //                 ramp), mTravel=-1, GD launches at -6.330
        // So: hanging under a ceiling, uphill is m<0 (the mirror, kept); riding a
        // floor ramp's top, uphill is m>0 -- the same test an upright rider uses,
        // because "uphill" is a property of the surface being climbed. Non-flipped
        // players are left exactly as they were; only the flipped case splits.
        // The side is read off `s.grounded`, NOT off the ramp behind
        // s.slopeUidNow. That uid is documented as not carried by the anchor, and
        // keying physics on it splits the run in two: the loop re-anchors every
        // iteration, so it PLANS with the uid gone (-1 -> the old mirror) and
        // replays from t=0 with it present. lv22 cold went 84% -> 41% that way.
        // `grounded` says the same thing and is carried: the ride writes
        // `if (!(flipForRide && ridesTop)) c.grounded = 1`, so during a flipped
        // ride grounded==0 IS "riding a ramp's top" and grounded==1 is the hang.
        // Both measurements agree with it --
        //   lv22 t=3,803..3,805  flipped swing on the floor ramp, grounded 0,0,0
        //   lv16 t=8,717..8,720  flipped ship under the ceiling, grounded 1,1,1,1
        const bool rodeCeil = (s.grounded != 0);
        const bool uphillExit = (c.flip && rodeCeil) ? (mTravel < 0.0)
                                                     : (mTravel > 0.0);
        // [2026-08-19 rejected] "Launch only when s.grounded". Meant to stop the
        // false launch (-2.762) at lv18 t=8,461, but **the real fix there is the
        // flat solid's cornerContinued (below)**, and this gate never moved a
        // single px. And it broke lv16's cold run: an isolated A/B (lv16 only,
        // pool 96/97, same source on the same day) gave
        //   flatCorner only = **28 iterations 9.4 min CLEARED**
        //   both (flatCorner + this gate) = **ITER-CAP(81) 18.4 min, x=21,866**
        // An upright player hitting a ceiling ramp from below never sets
        // grounded, so gating here erases every launch of a "riding but not
        // standing" ride.
        // [2026-08-21 r89] **The UFO's jump beats the uphill launch.** The
        // calibration rig ceilhold's 4 UFO cells (|m| 1/0.5 x normal/mini,
        // pressing while hung flipped from a ceiling ramp): GD emits the plain
        // UFO jump **-6.871 / mini -6.648** as is, while the model overwrote it
        // with this launch, slopeExitVy(|m|,UFO) (-5.554 / -2.999). The 2 |m|=2
        // cells never entered the launch window, kept the plain value, and
        // matched GD = the difference was only the launch overwrite. The
        // downhill release side (just below) already carries !impulsedThisTick
        // ("loses to a same-tick jump"), so for the UFO the two sides now share
        // the same convention. ship/swing pressing is not an impulse, so
        // unrelated; cube/ball/robot are measured on the on-ramp jump's additive
        // side (kSlopeJumpBonus), so they are untouched here.
        // [2026-08-21 r91] The UFO-only gate was widened. The rig ceilhold's 12
        // cube/robot cells all show "the jump tick keeps the jump value (+ the
        // ramp bonus), then plain gravity decay from the next tick", and the
        // launch never appears.
        // [2026-08-21 r95] ...but **the hang (flipped) side only**. Widened to
        // every mode, lv16's cold run hit a wall at x=9,790 (at t=6,516's
        // `slope+1.00/ride24+` GD emits the launch 9.208 on the press tick =
        // on the floor side **the launch beats the jump**, exactly as the note
        // below says). The census stayed green -- an instance of "if you touch
        // acquisition/launch conditions, measure at layer 4 (cold)"
        // ([[gd-census-green-cold-broken]]).
        // The rig's cells are all flip=1, so the evidence covers the c.flip side
        // only.
        if (!c.onSlope && s.onSlope && uphillExit && !rampWindowHere
            && s.rideLanded
            && !(impulsedThisTick && (c.mode == 3 || c.flip))) {
            // ...and the SIGN follows the same ride side as uphillExit above: a
            // launch throws the player off the surface it climbed, so a flipped
            // rider on a floor ramp's TOP leaves upward exactly as an upright one
            // does. lv22 t=3,806 measures it: GD emits **+6.906**, and keyed on
            // the flip alone the model emitted -6.906 (dvy -13.812).
            VYSET(c.vy) = (float)rawQ(((c.flip && rodeCeil) ? -1.0 : 1.0)   // speed.hpp
                           * slopeExitVy(std::fabs((double)s.slopeM), c.mode,
                                         useDx, c.mini != 0)
                           * slopeRampFactor((int)s.slopeT + 1));
            c.grounded = 0;
            // The slope machinery sets GD's velocity-limit exemption
            // (postCollision +0x18ca, next to the launch record update). A
            // slow exit clears it at the next tick's band check; a fast one
            // (>= 6.4 on the fall side) is what removes the swing's terminal
            // -- lv22 x=5,391.
            // [2026-09-06] ...and it is not the swing's alone. postCollision
            // reaches boostPlayer (0x38d966 -> 0x39ff0a), which raises the byte
            // before it writes vy, with no mode test anywhere in the chain --
            // so a ship or UFO leaving a ramp carries it too. Witnessed on
            // lv16 t=8,913, both halves: the flipped ship leaves at 6.906 and
            // GD lets it decay 6.820 / 6.734 / 6.648 / 6.562 / 6.476 / 6.390
            // before the clamp touches it at all.
            if (boostLatchMode(c.mode)) c.boost = 1;
            // ...and "like a pad" includes the y: the ramp is a block, so the
            // tick's gravity step is in y and nothing re-seats the player.
            // Measured on lv19 t=254 (ramp uid=33 at (300,105), exit 3.999):
            // GD 135.000 -> 134.9514 while the model stayed at 135.000. That
            // 0.0486 rode the whole arc and made the landing at t=290 one tick
            // late, which is where lv19's 2,818 divergent ticks start.
            releasePin(false);
        }
        // [2026-08-19] **The downhill release stamps the face's velocity.** The
        // counterpart of the uphill launch: on the downhill release tick GD
        // assigns vy := mTravel*dx/0.25 (the slope version of "the rising-floor
        // catch stamps the floor velocity" = the dcy/0.25 convention).
        // The old note's "running off the bottom of a downhill ramp just leaves
        // the player falling" was a placeholder, not a quoted measurement.
        //
        // 2 measurements, both a **seam blip** of og=0 for exactly 1 tick
        // (standtrace's slope=[-] names it):
        //   lv16 t=4,147 (flipped ship, uid1468 m=+0.5, flat clamp 435.000):
        //     GD vy=+3.229 = 0.5x1.6143/0.25, y stays 435.000 (edy 0)
        //   lv19 t=15,113 (UFO, uid9899 m=-1, flat clamp 285.000):
        //     GD vy=-6.457 = -1.6143/0.25, y is 284.9807 (-0.0193)
        // Both re-grab onto the flat clamp the next tick, back to vy=0 / og=1.
        // The release gate is "the tick the contact point (centre -/+ (pH-xoff))
        // exits the ramp's end"; for lv16, the first tick where 5,832.42-11.459
        // = 5,820.96 > x1=5,820 holds.
        // **Loses to a same-tick jump** (the opposite of the uphill launch).
        // GD's order is update->collisions->buttons, so the vy written by the
        // release (collision phase) is overwritten by the button afterwards.
        // Removing the gate exposed itself at once: lv16's tracking
        // 17,872->17,427, lv21 -1, families +4 (all in1).
        // ...and the release needs the ride to have LANDED for the same reason
        // the launch above does: both come out of the ride, and a contact that
        // never landed has no ride to leave. Without this the tightening above
        // merely hands lv19 t=14,643 to this branch -- suppressing the launch
        // moved the model from -2.156 to +1.424 against GD, because control fell
        // through to here and stamped mTravel*dx/0.25 = 6.457 instead.
        // ([[gd-tightening-a-clamp-hands-it-over]])
        // --releaseceilpress [2026-09-19]: GD's m_isOnSlope is ONE bit for the
        // top and the underside, so a body that left the floor side of a ramp
        // but is pressed against a ceiling ramp this tick is still on a slope
        // and postCollision runs no release (0x38db07 wants isOnSlope == 0).
        // lv16 t=9,879: a ship leaves riding uid4293 into its underside (V4
        // -2.000), a cube portal halves that to GD's -1.000; the model stamped
        // the release's -3.2285 over the V4 first.
        else if (!c.onSlope && s.onSlope && !rampWindowHere
                 && s.rideLanded
                 && !impulsedThisTick
                 && !ceilPressedNow) {
            // **NO slopeRampFactor HERE, and this is measured, not an
            // oversight.** The uphill launch above scales by the ride's length
            // and the structure of GD invites the same conclusion for this
            // branch: collidedWithSlopeInternal deposits the slope impulse in
            // [0x9b4] (0x390a82 / 0x390ae8) and both consumers -- updateJump
            // 0x38bd27 and postCollision 0x38d869 -- apply the ramp before
            // writing vy. Reasoning from that alone says the downhill release
            // needs it too. The corpus says otherwise: of the SIX downhill
            // releases in 22 levels, two sit under the ramp's 24-tick knee and
            // GD pays neither of them.
            //   lv18 t=13,663  ride 1 tick  ramp would give 0.4 x 6.457 = 2.583
            //                               GD emits the full -6.457
            //   lv16 t=4,147   ride 21      ramp would give 0.875 x 3.2285
            //                               GD emits the full +3.229
            // Ride lengths read from GD's own columns, not the model's counter
            // (onGround turns 1 exactly one tick before 13,663; the run of
            // yvel==0 before 4,147 is exactly 21). So adding the ramp here
            // breaks two rows that are currently exact. The asymmetry is the
            // mechanism: the ramp scales an IMPULSE, and this branch stamps a
            // carried face velocity (dcy/0.25), which is not one.
            VYSET(c.vy) = (float)(mTravel * std::fabs((double)K.dxF) / 0.25);
            // THE TWO INPUTS, because the value they produce has been read off a
            // fixup record and could not be checked against them.
            //
            // lv22's robot release stamps 6.3952, while this line with the
            // record's own printed mdx (1.6143) and mTravel = 1 gives 6.4572 --
            // 0.062 apart. Only two quantities can absorb that and neither is on
            // a fixup line: mTravel, and whether K.dxF is the same dx the trace
            // prints. Guessing which would have been a fitted answer, so print
            // both and let the run say.
            //
            // ITS OWN FLAG, not --slopedbg. That one switches on forty-two print
            // sites at once: a lv22 cold run under it wrote 811 MB of stdout in
            // half an hour and had reached t=3,703 of 24,589 -- roughly six times
            // slower, and it would not have got here before the disk complained.
            // The branch itself is rare (six releases in twenty-two levels by the
            // note above), so a flag scoped to it costs nothing and finishes.
            if (g_slopeRelDbg)
                std::printf("sloperel: t=%lld mode=%d mini=%d slopeM=%.4f "
                            "mtrav=%.6f dxF=%.6f vy=%.6f\n",
                            (long long)K.t, (int)c.mode, (int)c.mini,
                            (double)c.slopeM, mTravel, (double)K.dxF,
                            (double)c.vy);
            c.grounded = 0;
            // same as the uphill launch above: the slope machinery sets the
            // velocity-limit exemption (State::boost), in every mode that
            // reads it (boostLatchMode)
            if (boostLatchMode(c.mode)) c.boost = 1;
            releasePin(false);
            // --stickrelease [2026-09-19]: ...and later in the same
            // postCollision (0x38e76f-0x38ea48) GD re-lands the player on a
            // solid that moved AWAY from it this tick, when the gap is under
            // 5*dt (0x623010, 1.25 px): collidedWithObject at dt=0, hitGround,
            // vy := 0. So the stamp above survives only onto a still floor.
            // lv22 t=6,680: a ball leaves a -0.5 ramp onto uid6067, a solid
            // sinking and slowing; GD reads onGround 1 / vy 0 at 341.5925,
            // the model left at -3.2285.
            if (K.near) {
                const double gsR = c.flip ? -1.0 : 1.0;
                const double reachR = 5.0 * 0.25;
                const Obj* stick = nullptr;
                double stickGap = 1e9;
                for (const Obj* o : *K.near) {
                    if (o->type != 0 || gsR * o->dcy >= 0.0) continue;
                    if (std::fabs(x - o->cx) >= o->hw + pHalf) continue;
                    const double face = o->cy + gsR * o->hh;
                    const double gap = ((double)c.y - gsR * pHalf - face) * gsR;
                    if (gap > -0.5 && gap < reachR && gap < stickGap) {
                        stick = o;
                        stickGap = gap;
                    }
                }
                if (stick) {
                    YSET(c.y) = (float)(stick->cy + gsR * (stick->hh + pHalf));
                    VYSET(c.vy) = 0;
                    c.grounded = 1;
                    CLAMP0O("slope/stickrelease", stick);
                }
            }
        }
        // --mpushlaunch [2026-09-19]: postCollision launches the player from
        // LAST tick's c6 (+0x638) at 0x38eb5c when prev != 0, |prev - c6| >
        // 0.5, prev > 5.0 and prev > c6 -- i.e. on the tick contact with a
        // face rising faster than 5.0 ends -- clamped to 20, and only if it is
        // >= vy (boostPlayer: vy := prev, onGround := 0). The seat under such
        // a face is the vy = 0 arm (--mpushsign), so without this the player
        // leaves it at rest. lv20 t=22,015..22,019: UFO carried at vy 0 on
        // uid18643 (face 5.36..5.48), GD leaves at 5.482 = the last tick's
        // dcy/0.25. UNVERIFIED: GD's [0xae4] <= 0 gate (assumed open), the
        // ramp writer of c6 (0x390927, not fed here), flipped gravity.
        const double prev = (double)s.prevC6q / 1000.0;
        if (prev != 0.0 && std::fabs(prev - c6Now) > 0.5 && prev > 5.0
            && prev > c6Now) {
            const double p = std::min(prev, 20.0);
            if (p >= (double)c.vy) {
                VYSET(c.vy) = (float)p;
                c.grounded = 0;
            }
        }
        c.prevC6q = (int16_t)std::lround(
            std::max(-32.0, std::min(32.0, c6Now)) * 1000.0);
        // Ride counter for the exit ramp above: 0 on the contact tick,
        // +1 per riding tick, saturated at 24 (factor is 1.0 from there on).
        // A chain of contiguous ramps keeps counting -- GD only writes
        // m_slopeStartTime on the air->slope transition.
        //
        // ...which it did not, because the seam between two ramps drops onSlope for a
        // single tick and that reset the counter. The player does not leave the ground
        // there, so GD keeps the start time and the ride is one ride.
        //
        // Measured on lv16 (the ball chain at x=7,770/7,815/7,845, m=0.5 -> 1 -> 1):
        //   t=5,377  onSlope=1 slopeT=14   GD onGround=1
        //   t=5,378  onSlope=0 slopeT=0    GD onGround=1, y=341.000 -- the seam
        //   t=5,379  onSlope=1 slopeT=0    counting again from nothing
        //   t=5,400  onSlope=1 slopeT=21 -> factor 22/24 -> exit 6.330
        // GD launches at 6.906 = the saturated value (cube 9.207 x 0.75 = 6.905), i.e.
        // its ride was >= 24 ticks: 14 + the seam + 21 = 36. Carrying the counter across
        // the seam reproduces that exactly. It is the only exit in the 22-level corpus
        // that is neither saturated nor short, which is why the other twelve all matched
        // to four decimals with the counter broken.
        //
        // Gated on slopeT > 0 as well as grounded, so that acquiring a ramp from flat
        // ground still starts at 0 -- the contact tick is not a seam.
        const bool rampSeam = (s.grounded != 0 && s.slopeT > 0);
        // ...and the seam does not require the player to have stayed GROUNDED. A TAP breaks a
        // ride the same way a chain's joint does -- the ball flips, onSlope drops for one tick,
        // and the SAME ramp is re-acquired on the next -- but it is airborne throughout, so
        // rampSeam is false and the count restarts from nothing.
        //
        // Two conditions, and both are needed. A live count is at most one tick old (the
        // off-slope branch keeps slopeT only while grounded, so the second airborne tick clears
        // it), AND the ramp has to be the one already being ridden: carrying on the age alone
        // also carries across a real launch that happens to land on a ramp a tick later, where
        // GD does restart the clock -- measured, and it cost lv16 66 -> 201 (stuck) and lv22
        // 50 -> 94 before this uid test was added.
        //
        // Measured on lv16's second dual, the corpus' largest grind (11 of 66 cold iterations at
        // t=13,017). p2 rides uid6532 from t=12,972; the plan taps at t=12,988:
        //   t=12,987  onSlope 1  slopeT 15  grounded 1
        //   t=12,988  onSlope 0  slopeT 15  grounded 0   (kept: s.grounded was still 1)
        //   t=12,989  onSlope 1  slopeT **0**            (s.grounded is 0 now, so it resets)
        //   t=12,992  exit at factor 3/24 -> vy2 2.762, where GD has 5.467
        // The same ramp ridden WITHOUT the tap (the solution's own replay) exits at 5.755 off a
        // 20-tick ride, and 5.755 x 19/20 = 5.4673 = GD's value to four decimals. Carrying the
        // count gives 5.466925, so this PREDICTS GD's number rather than being fitted to it.
        const bool sameRide = (s.slopeT > 0 && c.slopeUid0 >= 0
                               && c.slopeUid0 == s.slopeUid0);
        c.slopeT = c.onSlope
            ? (uint8_t)((s.onSlope || rampSeam || sameRide)
                            ? std::min<int>(24, (int)s.slopeT + 1) : 0)
            : (uint8_t)(rampSeam ? s.slopeT : 0);
        // --lawseatonslope: a ride that begins on a tick the --slopelaw seat has
        // already been holding the body on the ramp started THEN (State::seatT).
        if (g_lawSeatOnSlope) {
            if (c.onSlope) {
                if (!(s.onSlope || rampSeam || sameRide) && s.seatT > 0)
                    c.slopeT = (uint8_t)std::min<int>(24, (int)s.seatT);
                c.seatT = 0;
            } else {
                c.seatT = lawSeatedNow
                    ? (uint8_t)std::min<int>(24, (int)s.seatT + 1) : 0;
            }
        }
        (void)0;
    }
    // Out of play. The ship branch already had this; the cube branch had no
    // bound at all, so a flipped cube with nothing above it kept "falling" up
    // forever and the search followed it (lv10: the frontier was at y = 2,792
    // by t=1686, and GD agreed tick-for-tick -- it was not a fidelity bug, the
    // model simply had no reason to stop expanding a branch that can never come
    // back). The bound comes from the level's own highest surface.
    if (c.frame == 0) {
        // --goalspare: above the bound but alive to the goal (speed.hpp)
        if ((c.y > g_yBound
             && !reachesGoalUnderMaxPlayY(x, (double)c.y, (double)c.vy, (double)c.dx, c.rev != 0))
            || c.y < (kGroundY + pHalf) - 40)
            DIE("out-of-play", nullptr);
    } else if (std::fabs((double)c.y) > g_yBoundTurned) {
        // In a turned frame `y` runs along a world axis with either sign, so
        // the un-turned bounds mean nothing. This one only stops a branch that
        // has left the level entirely.
        DIE("out-of-play", nullptr);
    }
    // upside down, airborne, and above every surface still ahead: it can never
    // come down again (see g_topAhead). Sound for cube and ball, whose airborne
    // input does nothing -- but NOT for the ship, which flies back down by
    // holding. Including the ship broke lv8 (cleared -> stuck at t=3002).
    // ...and the WAVE is excluded for the same reason as the ship: it flies
    // back down the moment the input is released, so "above everything ahead"
    // is not a dead end for it.
    // ...and it is skipped in a turned frame, where BOTH sides of the test mean
    // something else: `x` is the frame's progress axis (= -world y) so
    // topAheadAt() is looking up a level column that does not exist, and `c.y`
    // is a world x. In lv22's rotated corridor that made every tap branch die
    // instantly ("flip -> airborne -> 8231 > topAhead(-744)"), which is why the
    // DP reported `0 edges` there -- a search bug wearing a physics costume.
    // In a rotated frame, the same test is done **in that frame's coordinates**
    // (topAheadAtF). 2026-08-15: it had been disabled by restricting to frame 0,
    // but that left never-returning branches and lv22's cold entrance regressed
    // (the old exe reached x=2,441 at iter 11; the disabled build 2,343 in 26
    // iterations). `flip` still means "flipped against that frame's vertical" in
    // a rotated frame, so it can be used as is.
    if (!dead && c.mode != 1 && c.mode != 4 && c.flip && !c.grounded
        && (double)c.y - pHalf > topAheadAtF((int)c.frame, x)) {
        // --escrotahead: the test above reads THIS frame's table and
        // cannot know the frame will change. lv22 t=5,096 (plan 598, frame 3):
        // topAhead is a real surface 444 px below (i=25 of 91), and GD rotates back
        // to frame 0 fourteen ticks later, falls and lands (alive to t=6,735). So
        // while a ROTATION is still ahead on the active queue channel -- the same
        // cursor and world-axis test the queue branch uses -- the prune is not
        // this table's to make. Every spared prune prints its distance to that
        // firing (--slopedbg): inside a turned section the return is nearly always
        // ahead, so this is close to switching the prune off there, which cost
        // lv22's entrance 2,441 -> 2,343 on 2026-08-15. A bound, if one is needed,
        // is to be derived from that distribution, not chosen.
        bool spareEsc = false;
        double escDist = 0.0;
        if (c.frame != 0 && g_rotQueue && !g_rotQ.empty()) {
            const int ch = (int)c.rotChan & 15;
            const int beg = g_rotQBeg[(size_t)ch], end = g_rotQEnd[(size_t)ch];
            const int done = popCount32(c.rotSpent & g_rotQChanMask[(size_t)ch]);
            // "Ahead" is judged at the PARENT's position, not this state's. Within a
            // tick the order is: stepBoth -> stepOne (THIS prune, old frame, child
            // already moved) -> applyRotation(child, uPrev = parent's position),
            // which consumes the entry (rotSpent, :457) and turns the frame (:834).
            // So on the tick the move crosses the firing point the entry is still
            // unconsumed and the frame still old, while the CHILD is already past
            // it -- testing the child let this table prune on exactly that tick
            // (plan 598 t=5,110, lv22 CLEARED t=5,119). Testing the parent reads
            // "pending or firing this tick", from the same start applyRotation uses.
            double wx, wy;
            fromFrame((int)s.frame, (double)s.xAbs, (double)s.y, wx, wy);
            const bool rev = ((c.rotRev >> ch) & 1u) != 0;
            const bool vertical = ((int)c.frame & 1) != 0;
            const double ref = vertical ? wy : wx;
            for (int idx = beg + done; idx < end; ++idx) {
                const RotQEntry& e = g_rotQ[(size_t)idx];
                if (!(e.id == 2900 && !e.chanOnly && e.rotIdx >= 0)) continue;
                const double p = vertical ? e.py : e.px;
                if (rev ? (p < ref) : (ref < p)) {
                    spareEsc = true;
                    escDist = std::fabs(p - ref);
                }
                break;   // the first ROTATING entry decides, fired or not
            }
            if (spareEsc && g_slopeDbg)
                std::printf("escspare: t=%lld frame=%d x=%.3f y-pH=%.3f "
                            "dist=%.3f ticks=%.1f\n",
                            (long long)K.t, (int)c.frame, x, (double)c.y - pHalf,
                            escDist,
                            escDist / std::max(1e-6, std::fabs((double)K.dxF)));
        }
        // --goalspare: it never comes down, but it does not have to (speed.hpp)
        if (!spareEsc && c.frame == 0
            && reachesGoalUnderMaxPlayY(x, (double)c.y, (double)c.vy, (double)c.dx, c.rev != 0)) {
            spareEsc = true;
            if (g_slopeDbg)
                std::printf("goalspare: t=%lld x=%.3f y=%.3f vy=%.3f goal=%.1f\n",
                            (long long)K.t, x, (double)c.y, (double)c.vy, g_goalX);
        }
        if (!spareEsc) {
            // --slopedbg: WHICH answer the table gave. `i >= size` means
            // topAheadAtF returned -1e9 from past the table's end, not a surface;
            // size 0 means the frame has no table (1e9, which cannot prune).
            if (g_slopeDbg) {
                long long bi = -1, bn = 0;
                topAheadIndex((int)c.frame, x, bi, bn);
                std::printf("escapee: t=%lld frame=%d x=%.3f y-pH=%.3f "
                            "topAhead=%.3f i=%lld size=%lld\n",
                            (long long)K.t, (int)c.frame, x, (double)c.y - pHalf,
                            topAheadAtF((int)c.frame, x), bi, bn);
            }
            DIE("escapee-prune", nullptr);
        }
    }
    // Portals fire when the player's box first OVERLAPS the portal's box, not
    // when it crosses the portal's centre column. Measured on lv4's gravity
    // portal at cx=8775 (rect 25 wide, so left edge 8762.5):
    //   t=6730 x=8747.16 -> right edge 8762.16, no overlap, GD does not fire
    //   t=6731 x=8748.46 -> right edge 8763.46, overlap,    GD fires
    // Centre-crossing put the model 27 px (~20 ticks) late, which on lv4 meant
    // the flip happened after the player had already run past the ledge.
    // ...and the test is a plain box OVERLAP, checked every tick the player is
    // inside the portal, not a one-tick crossing of its left edge. With the
    // crossing form, a player whose y did not line up on that exact tick missed
    // the portal FOREVER: lv7 t=15490 crossed the cube portal's edge 1.3 px too
    // high (|dy| = 59.26 vs the 58 limit) and the model stayed a ship for the
    // rest of the level, while GD entered four ticks later at |dy| = 57.57.
    // Re-firing is prevented by the no-change guard below, not by the geometry.
    // ...and the MINI WAVE tests portals with GD's own getObjectRect (6x6, half
    // 3.0), not with kWaveHalfMini. That 2.0 is a bracket off a SPEED portal's
    // firing (see the constant) and it is 1 px too small here -- the same gap the
    // hazard box already had to split out. Measured on lv20's stacked cube +
    // RegularSize portals (uid525/527 at (1139.11,177.23), rot 53, real box
    // 34x86), read off a plain replay of the verified solution:
    //   t=841 x=1090.539 y=162.853  GD does NOT fire -> half <  3.9988
    //   t=842 x=1091.837 y=165.449  GD DOES fire     -> half >= 2.7008
    // With 2.0 the model fires NEITHER portal and runs the whole rest of the
    // level as a mini wave: GD is a full-size cube from t=842 and the model is
    // still oscillating at t=20,000. The replay of lv20's own solution used to
    // die at t=965; with 3.0 it reaches t=4,601.
    const double pHalfPortal =
        (c.mode == 4 && c.mini) ? kWaveContactHalfMini : pHalf;
    // [night-3, rejected] Making the mini's portal contact half-width 7.5
    // (kMiniContactHalf). The rig ramps' "only the mini->normal size portal is 1
    // tick early, 8/8" is most likely **the timing of the re-seat after the size
    // change, not the contact half-width** (GD's dump still writes 99 on the
    // firing tick and becomes 105 the next tick).
    // Widened to all portals, families 27->64 (11 levels regress, gdm1/gdm2 =
    // missed mode portals); even limited to size portals, families 27->37
    // (8 levels regress). **The rig and the corpus contradict each other**, so
    // on hold.
    const double pHalfSize = pHalfPortal;
    // [2026-08-20 r32] **Only rotated objects are tested against a box rebuilt
    // within the same pass.** The disassembly in the note above says so: the
    // AABB is copied into 4 registers at call entry (0x2149b8), but for objects
    // with `[rdi+0x2e8]` set, 0x214BA1 **re-calls the player's getOrientedBox()
    // on the spot**. So axis-aligned portals keep seeing the entry box (the two
    // "shadow" cases, lv19 t=20,309 / lv18 t=14,612, are both axis-aligned),
    // while **a rotated portal sees the result of the mode/size portal that
    // fired just before it**.
    // Measured lv18 t=20,465 (mini wave, all 3 at rot=51):
    //   uid14052 cube  OBB 34x86 width axis 20.33 ... fires at half>2.377;
    //                                    not firing at 20,464 needs half<4.005
    //   uid14054 speed OBB 51x56 width axis 28.07 ... half>1.83; 20,464 needs
    //                                    half<3.46
    //   uid14055 size  OBB 31x90 width axis 22.80 ... needs **half>5.209**
    // No single half satisfies all (the cube demands <4.005). If the cube fires
    // first and the box becomes the mini cube's 9, then 15.5+9*1.4008=28.1 >
    // 22.80 passes, and at 20,464 the cube itself does not fire so the size one
    // does not fire either -- all 3 fit.
    double pHalfLive = pHalfPortal;
    // GD's collisionCheckObjects snapshots the player's rect ONCE at call
    // entry (disasm 0x2149b8: plain getObjectRect -> four AABB registers) and
    // nothing later in the pass refreshes it -- not a landing clamp, not a
    // size portal firing earlier in the same pass. Both measured mistimings
    // are exactly that shadow:
    //   lv19 t=20,309: mini ball (18x18, ccl/ptt-verified -- the dump's
    //     vsize column said 1.0 and lied) walks into a RegularSize portal,
    //     re-seats 264->270 mid-pass; the SPEED portal right behind it still
    //     sees the ENTRY box (top 273 < 275) and fires only next tick.
    //   lv18 t=14,612: the landing clamp seats the mini cube at 219 during
    //     the tick, but the registers hold the pre-clamp 217.1 (top 226.15 <
    //     226.4) -- the speed portal fires at 14,613 with the full box.
    // So the speed test reads THIS snapshot: tick-start y on a landing tick
    // (the clamp is inside GD's collision phase, after the registers), the
    // pre-pass y otherwise. The half is pHalf, which is tick-start by
    // construction (mode/size changes only happen inside the pass).
    const double yColl = (c.grounded && !s.grounded) ? (double)s.y
                                                     : (double)c.y;
    // A SPIDER that teleported on this tick has only just arrived: GD's tick is
    // update -> collisions -> buttons, so the landing spot's portal (and pad,
    // and orb -- see the `teleportedThisTick` breaks further down, which say the
    // same thing for the type-28 teleport portal) is read on the NEXT tick.
    // Measured on lv22 t=2,023: GD teleports to y=163.5 and leaves with the
    // teleport's own vy=-1.000, and only at t=2,024 does the yellow pad at
    // (2407,152) give it 9.600 and the ball portal uid1590 switch the mode.
    // The model did all of it in the one tick, so its y ran 2.385 px above GD's
    // for the next 182 ticks.
    // ...and the SAME rule applies to the destination's PORTALS, which this
    // loop was missing: the note above says so but nothing enforced it, and a
    // gravity portal sitting at the landing spot fired on the arrival tick.
    // Measured on lv21 t=4,710 (teleport uid5090 at (6147,275) -> y=415, with
    // the type-4 gravity portal uid5050 at (6129,415) waiting there):
    //   GD    t=4,710 y=415 vy=2.428 up=1   t=4,711 vy=1.322 up=0
    //   model t=4,710 y=415 vy=1.214 up=0   (halved and flipped a tick early)
    // GD's tick is update -> collisions -> buttons, so the collision pass for
    // t=4,710 already ran at the OLD y (254.95) where that portal is 160 px
    // away. edvy = +1.214, edy = 0 -- the family
    // `m0/mini0/g0/gdg0/sp0.9/air/in0` in fixcensus.
    //
    // Two passes rather than one `continue`, because the order the slice yields
    // is by cx and the teleport can sit AFTER the portal it should suppress
    // (here 6,147 vs 6,129). Pass 0 is the teleport, pass 1 is everything else
    // and is skipped entirely once one fired. With no teleport in the window
    // the two passes are the single old loop, unchanged.
    // It is a lambda so the order can be **swapped only on a teleport tick**
    // (measurements at teleUid's declaration). GD processes in uid order, so when
    // the landing site's pad has a smaller uid than the portal, the order becomes
    // pad -> portal. lv20 t=7,282: yellow pad uid7025 (vy := -16 with flip=1) is
    // followed by gravity portal uid7028 (flip + halve), giving -8.000. With the
    // model's fixed order (portal -> pad) it becomes flip=0 first, takes +16, and
    // flies opposite to GD from then on.
    auto runPortalPass = [&](int pport) {
    for (const Obj* p : *K.ports) {
        if (spiderWarpedThisTick) break;
        if ((p->type == 28) != (pport == 0)) continue;
        // uid-order gate (measurements at teleUid's declaration). Objects
        // processed before the teleport were judged at the old position = do not
        // fire at the landing site.
        if (pport == 1 && teleportedThisTick && p->uid < teleUid) continue;
        // only the size portal has the smaller contact half (pHalfSize note)
        // ...only rotated objects use "the current box" (pHalfLive note).
        // Axis-aligned ones keep the entry snapshot.
        const double pHalfP =
            p->oriented ? pHalfLive
                        : ((p->type == 17 || p->type == 18) ? pHalfSize
                                                            : pHalfPortal);
        if (std::fabs(x - p->cx) > p->hw + pHalfP) continue;
        // ...and a TURNED portal's bound is far wider than the portal. lv18's
        // cube portal at (27,755.8,371.162) is 51 degrees over, bounds 88 px and
        // is really 34: firing on the bound made the model a cube 48 px early,
        // it flew over the ramp that kills GD's wave, and the DP returned SOLVED
        // on a plan GD kills at x=27,713. See Obj::oriented / orientedHit.
        // ...at the rotation the state carries, `s.rot`, which is where the
        // previous tick ended.
        //
        // [2026-09-06] THE ONE-STEP ADVANCE IS DELETED HERE TOO (the pad site's
        // comment has the mechanism; `--no-satrotraw` restores it). All four
        // sites carried one expression and they move together.
        //
        // WHAT THE PARAGRAPH ABOVE USED TO SAY, AND WHY IT IS NOT SIMPLY GONE:
        // it read "the portal looks one step back: measured on lv22, s.rot sits
        // 1.706 deg past GD's value for the same tick and one step back matches
        // it to 0.025 deg". That measurement CANNOT BE RE-DERIVED from the
        // corpus as it stands: objrects_lv22.txt (2026-09-04) has 1,173 oriented
        // objects and NOT ONE of them is a pad, a portal or a speed object --
        // they are type 2 / 7, one non-speed type-20 and one type-37 dash ring,
        // none of which reaches this line. So whatever was measured, it was not
        // an lv22 object that passes through here, and the sentence cannot be
        // checked. It is recorded rather than deleted because "the evidence for
        // this line is not reproducible" is itself the finding; if a witness for
        // it turns up, it belongs here with the level and the tick named.
        // Note also that the two comments that justified this expression
        // disagreed with each other -- this one said the portal looks one step
        // BACK, the pad site said one step FORWARD -- for one shared line of
        // code, which is the shape of a rule nobody could re-measure.
        double pRotHere = (double)s.rot;
        if (g_noSatRotRaw && s.mode == 0)
            pRotHere += (s.rotNeg ? 1.0 : -1.0) * (s.mini ? 2.25 : 1.7307692);
        // --slopedbg: make "passed the x window but rejected by the OBB" visible.
        // Without this it cannot be told apart from "never entered the window"
        // (item 4's diagnosis stalled on whether the size portal's 1-tick delay
        // came from here or the x window).
        if (g_slopeDbg && p->oriented
            && !orientedHit(*p, x, (double)c.y, pHalfP, pRotHere))
        {
            const double thO = std::atan2(-p->rs, p->rc);
            const double a1 = -thO;
            const double a2 = -pRotHere * 3.14159265358979 / 180.0;
            const double ddx = x - p->cx, ddy = (double)c.y - p->cy;
            const double c1 = std::cos(a1), s1 = std::sin(a1);
            const double c2 = std::cos(a2), s2 = std::sin(a2);
            const double axv[4] = { c1, -s1, c2, -s2 };
            const double ayv[4] = { s1,  c1, s2,  c2 };
            double marg[4];
            for (int i = 0; i < 4; ++i) {
                const double ux = axv[i], uy = ayv[i];
                const double r1 = p->ohw * std::fabs(c1 * ux + s1 * uy)
                                + p->ohh * std::fabs(-s1 * ux + c1 * uy);
                const double r2 = pHalfP
                                  * (std::fabs(c2 * ux + s2 * uy)
                                     + std::fabs(-s2 * ux + c2 * uy));
                marg[i] = (r1 + r2) - std::fabs(ddx * ux + ddy * uy);
            }
            std::printf("portobb t=%lld uid=%d type=%d x=%.2f y=%.2f "
                        "pcx=%.2f pcy=%.2f ohw=%.2f ohh=%.2f pHalf=%.1f "
                        "pRot=%.3f thO=%.3f marg=%.3f/%.3f/%.3f/%.3f "
                        "REJECTED-BY-OBB\n",
                        (long long)K.t, p->uid, (int)p->type, x, (double)c.y,
                        p->cx, p->cy, p->ohw, p->ohh, pHalfP, pRotHere,
                        thO * 180.0 / 3.14159265358979,
                        marg[0], marg[1], marg[2], marg[3]);
        }
        if (p->oriented
            && !orientedHit(*p, x, (double)c.y, pHalfP, pRotHere))
            continue;
        // A portal sitting on the rotation trigger that put us in this frame
        // does not fire again (the measurements are at the function, which the
        // ground arm's pre-evaluation calls too).
        if (portalOnFrameRotTrigger(*p, (int)c.frame)) continue;
        // Would this portal change anything at all? An inert one is a no-op and
        // dodging it means nothing (see the halving note below).
        // A teleport's REAL target: the linked exit half (tpEy) for the 2902
        // family, the closed tpY formula for id 747 -- see Obj::tpEx/tpEy.
        // lv22's uid 6437 sits AT its own tpy (1905) and read as inert while
        // GD drops the player to its orange half at 645.000.
        const double tpTarg = (p->type == 28 && p->id != 747
                               && (p->tpEx != 0.0 || p->tpEy != 0.0))
                                  ? p->tpEy : p->tpY;
        const bool changes =
            (p->type == 23 || p->type == 24)
                ? (c.dual != (uint8_t)(p->type == 23 ? 1 : 0))
            // a teleport is inert only when the player is already at its
            // target AND its gravity mode asks for nothing new (teleportPlayer
            // itself has no inertness check -- it always moves and applies
            // m_gravityMode, so "inert" is only ever true when both halves are)
            : (p->type == 28) ? (std::fabs((double)c.y - tpTarg) > 0.01
                                 || (p->tpGrav == 3)
                                 || (p->tpGrav == 1 && gdUpOf(c) != 0)
                                 || (p->tpGrav == 2 && gdUpOf(c) == 0))
            // Gravity portals state GD's `upsideDown`, which is NOT the model's
            // `flip` inside a turned frame -- see gdUpOf.
            : (p->type == 3)  ? (gdUpOf(c) != 1)
            : (p->type == 4)  ? (gdUpOf(c) != 0)
            : (p->type == 17) ? (c.mini != 0)
            : (p->type == 18) ? (c.mini != 1)
                              : (c.mode != ((p->type == 5)    ? 1
                                            : (p->type == 16) ? 2
                                            : (p->type == 19) ? 3
                                            : (p->type == 26) ? 4
                                                              : 0));
        // ---- hairline dodges are not routes (user's call, 2026-08-03) -------
        // The physics is untouched: GD fires on box overlap and so does the
        // model. What is dropped here is the SEARCH BRANCH that slips past a
        // portal by less than g_portalDodgeMin -- such a portal is treated as
        // unavoidable. Real levels do not place traps that need a sub-pixel
        // dodge, so a hairline miss is a modelling artefact, not a plan.
        // WHY: lv18's RegularSize portal at (20,386.6, 266.992) is missed by
        // 0.01 px -- the plan rides the flying band's ceiling at y=321.000, so
        // its foot is at 312.00 against the portal's top edge of 311.99 -- and
        // the level cannot be played mini from there: the mini cube's jump
        // apex is +43.6 px where the corridor at x=24,660 needs +60.
        // (Widening the FIRING rule instead would be wrong: GD really does not
        // fire at 0.01 px, and the model would then plan a size change GD never
        // performs.)
        // y is **the pre-clamp position** (post-update, pre-collision = the
        // register snapshot of GD's collision pass, same mechanism as the 8862
        // note) [2026-08-19, settled with worker98's 6 injection points].
        // lv22 uid8743's (spider portal, cy=469 hh=43) y approach:
        //   riding a ramp: no fire at post-clamp 411.87 / fires at 412.40 (free
        //     y) -> measuring with the y the ride's clamp lifted is 1 tick early
        //   free flight: fires at post-move 411.357 (411.357+15=426.36 >= 426 OK)
        //   the x side is consistent at both sites with the post-move position
        //   (pH=15 unchanged):
        //     uid4445 @4,635 |dx|=31.06 <= 32 fires / 32.68 no fire
        //     uid8743 30.99 fires / 32.39 no fire
        // [2026-08-27] ...and that is `yFree`, which the tick now carries
        // outright (see its declaration). The two things this replaces were both
        // approximations of it: `c.y`, correct only when nothing in the
        // collision pass moved the player, and a slope-riding special case
        // `s.y + vy*kYScale` reconstructing the same number from the free
        // bookkeeping vy keeps while riding.
        // What the general value adds is every OTHER way the pass moves the
        // player. Measured on lv20 t=17,108/17,109 (a UFO pressed down a ceiling
        // ramp -- not a slope ride, so the old special case did not apply):
        //   t=17,108  seat 299.193 (fires, wrongly)   free 300.105 (does not)
        //   t=17,109  seat 297.580                    free 298.492 (fires)
        // and GD fires the dual portal uid13879 at 17,109. The seat runs ~0.9 px
        // ahead of the free y here, so the model was buying a mode change one
        // tick early and planning the rest of the section from it.
        // This is also what the "the dual portal's box is 0.7 px shorter than
        // objrects says" reading of 2026-08-27 really was: swept from the
        // player's post-clamp y it needs a shortened box, from the free y it
        // fires at the dump's own h=91.
        const double yPort = (double)yFree;
        const double gapY = std::fabs(yPort - p->cy) - (p->hh + pHalfP);
        // --slopedbg: `changes` and the y gap, the two things between a portal
        // being a candidate and it firing. `portfire` above only says "in the x
        // window", so a portal that reaches this line and dies here looked
        // identical to one the window never let in (lv22 t=5,110).
        if (g_slopeDbg)
            std::printf("portgate half=%d t=%lld uid=%d type=%d changes=%d gapY=%.3f "
                        "y=%.3f pcy=%.3f phh=%.2f pHalf=%.1f flip=%d frame=%d "
                        "prot=%.3f orient=%d\n",
                        g_halfNow, (long long)K.t, p->uid, (int)p->type,
                        changes ? 1 : 0,
                        gapY, (double)c.y, p->cy, p->hh, pHalfP,
                        (int)c.flip, (int)c.frame, pRotHere,
                        p->oriented ? 1 : 0);
        // GD's four comparisons in the AABB gate are all CLOSED (`comiss/ja`,
        // no epsilon), so edges that touch exactly do overlap and the portal
        // fires. The model had the open form and skipped that case.
        // [2026-09-03, from the disassembly of collisionCheckObjects 0x214960]
        if (gapY > 0.0) {
            if (changes && gapY < g_portalDodgeMin) {
                // A portal you are still CLOSING ON is not one you dodged.
                // [2026-09-03] The guard was asked on every tick of the
                // approach, so the last tick before a crossing -- where the gap
                // is small precisely because the player is about to enter --
                // read as a sub-pixel dodge. It killed two plans GD flies:
                //   lv12 t=12,358 uid2752 (id 11, 75x25) gap 0.084, falling
                //     2.42 px/tick. GD and the model both fire on the NEXT tick
                //     (12,359: up 0->1, vy -10.770 -> -5.493, y digit-identical
                //     either side). The guard was killing lv12's own VERIFIED
                //     solution 7,600 ticks from the end, and quick_regress
                //     cannot see it -- it replays 400-tick anchored sections,
                //     never the whole plan.
                //   lv22 t=6,921 uid6100 (id 1933, 33.5x85) gap 0.069, rising
                //     0.58 px/tick. The model enters at 6,922; GD enters at
                //     6,921, and that one tick is a SEPARATE defect in the
                //     firing predicate, not this guard's business.
                // Neither is a dodge: the distance to the portal's centre is
                // shrinking. The witness the guard was built for is not
                // (measured 2026-08-03: lv18's RegularSize portal at
                // x=20,386, missed by 0.01 px by a mini ship pinned against a
                // ceiling at y=321.000) -- a pinned or departing plan holds its
                // gap or grows it, and stays killed.
                // Census before/after over lv1-22 (gapy_census.py): the fatal
                // band held exactly one decision with `changes`, and it was
                // this false kill.
                const bool stillClosing =
                    // a frame change puts the two y's in different frames, so
                    // the guard abstains rather than kill on a number it cannot
                    // compare
                    s.frame != c.frame
                    || std::fabs(yPort - p->cy)
                           < std::fabs((double)s.y - p->cy);
                if (!stillClosing)
                    DIE("portal/hairline-dodge", p);
            }
            continue;
        }
        // GD LATCHES A GRAVITY PORTAL HERE -- the first tick it OVERLAPS, which
        // is this line and not the firing below. Everything above is the
        // overlap test (the x window, the oriented box, and the y gate that
        // just `continue`d), so a portal reaching this point is one GD's
        // activation pass has in hand.
        // Measured with the ccl probe on lv22 uid 13833: hasBeenActivated and
        // hasBeenActivatedByPlayer are both 0 through t=6,299 and both 1 from
        // t=6,300 -- a pass the player takes ALREADY in the polarity the portal
        // would set, so flipGravity is a no-op and the `changes` gate below
        // would have skipped it entirely. Coming back at t=6,327 with the
        // opposite polarity, GD does nothing: the latch is still up, the box
        // still reads 25x75, and grpOff / grpOffT / the +0x740 claim are 0.
        // Exclusion census over every gravity-portal overlap pass in the corpus
        // (132 passes, the flip read at the tick BEFORE each pass so a firing on
        // the pass's own first tick is not mistaken for the pre-state): 107
        // fire, 25 do not, and exactly two fail to fire while the polarity
        // differs -- lv22 uid 4360 (4,645..4,694) and uid 13833 (6,327..6,360).
        // BOTH GRAVITY PORTALS (type 4 normal, type 3 inverse). What carries
        // this is that GD's flag is GameObject's own and not a per-kind thing
        // (the ccl probe read it off the object), plus a tightening the corpus
        // is able to judge and does not reject.
        // NOT a witnessed double pass, and the retraction is worth keeping:
        // lv16 uid 3450 was read as a type 3 crossed twice (runs at t=8,016 and
        // t=8,062, the second with changes=1), and it is not. GD's own
        // per-player record says p2 activated it at 8,014 and p1 at 8,061 --
        // two halves, one pass each. The pass census counted portgate runs, and
        // a portgate line does not say which half it belongs to, so on every
        // dual level "the same portal twice" and "each half once" look
        // identical. No level in this corpus is known to cross a gravity portal
        // twice with the SAME body except lv22 uid 13833, which is type 4.
        // Still only the gravity pair: nothing has measured a second pass of
        // any other portal kind, so widening further would change firings on
        // no evidence at all.
        if ((p->type == 3 || p->type == 4) && p->gpBit >= 0) {
            const bool spent = s.portalLatch.test(p->gpBit);
            c.portalLatch.set(p->gpBit);
            // --slopedbg: which halves reach the latch, and with what mask. The
            // question this answers is whether a gravity portal can also be
            // handled by a LATER block that never sees this line -- lv16's p2
            // reaches the dual `wasInBoxPrev` skip 65 times on uid 3450, which
            // it could not do if the latch had already spent it here.
            if (g_slopeDbg)
                std::printf("gplatch half=%d t=%lld uid=%d bit=%d spent=%d "
                            "mask=%s\n",
                            g_halfNow, (long long)K.t, p->uid, (int)p->gpBit,
                            spent ? 1 : 0, gravLatchHex(s.portalLatch).c_str());
            if (spent) continue;
        }
        // A mode or size portal this body already overlapped on the previous tick was activated
        // then, whether or not it changed anything, and does not fire again (speed.hpp, the note
        // that was --portalonce's). The overlap is this loop's own test, in State::portSeen.
        if (isModePortalType(p->type) && p->uid >= 0) {
            bool seen = false;
            for (int i = 0; i < 3; ++i) seen = seen || s.portSeen[i] == p->uid;
            bool placed = false;
            for (int i = 0; i < 3; ++i)
                if (c.portSeen[i] < 0 || c.portSeen[i] == p->uid) {
                    c.portSeen[i] = p->uid;
                    placed = true;
                    break;
                }
            if (g_histStatOn) {   // --histstat (speed.hpp)
                if (!placed) ++g_hist.portFull;
                int k = 0;
                for (int i = 0; i < 3; ++i) k += c.portSeen[i] >= 0;
                g_hist.portMax = std::max(g_hist.portMax, k);
            }
            if (seen) continue;
        }
        // [2026-08-21 r52] **A gravity portal right after a rotation-frame
        // change does not fire if the player was already inside it.** Changing
        // up on frame entry/exit is not the portal's job, but the `changes` gate
        // only looks at "is the current up different from the wanted up", so a
        // portal being sat in comes to "correct" it the next tick.
        // Measured lv22 t=6,323 (exit of the rotated section, ball, sp1.1,
        // type-4 uid13833 (id10, 25x75, cy=395 hh=12.5)):
        //   t=6,310..6,322 inside the box the whole time (changes=0, no fire)
        //   t=6,322 both GD and the model leave the frame, up 0->1, vy=-7.813
        //   t=6,323 GD stays at -7.684 (=-7.813+0.129). Only the model re-fires,
        //     restores up, and halves vy to -3.842
        //     (census `m2/mini0/g0/gdg0/sp1.1/air` edvy -3.842)
        // **Generalising is already rejected** ("a gravity portal fires only on
        // the entry tick" regressed lv5/14/18/20/21. GD really does re-fire in
        // some situations). The test is the same geometry as the firing, at the
        // previous tick's position.
        //
        // [2026-09-05] DORMANT SINCE THE PORTAL LATCH, and kept anyway. This
        // rule is a compensation for the latch that was missing: "a portal you
        // were already inside does not fire" IS the latch, seen through lv22's
        // keyhole -- it was measured on uid 13833 at t=6,323, which the latch
        // now spends at 6,300. Counted with the r52hold print over all 22 whole
        // runs: 0 holds with the latch on, 30 with `--no-portallatch` (lv22
        // uid 4464, type 4, t=5,125..). The latch reaches every case the corpus
        // has and gets there first, because it sits above this block.
        // It is NOT provably dead, which is why deleting it needs a witness
        // this corpus does not hold:
        //   - type 3 is inside this test and outside the latch, and no level
        //     here crosses a reverse portal twice
        //   - the `s.frameChg` edge is exactly where the two can disagree. The
        //     tick before a frame change was evaluated in the OLD frame, where
        //     this portal may not have been a candidate at all and so left no
        //     latch bit, while portalWasInsideAtPrev re-reads that position
        //     through the NEW frame's mapping and can still say "inside".
        // And removing it is a LOOSENING, which a corpus of fixed plans cannot
        // judge (it only admits firings the plan never asked for), so the 22
        // byte-identical traces are not evidence either. The r52hold print is
        // the instrument that will say when this stops being dormant.
        if ((p->type == 3 || p->type == 4) && s.frameChg
            && s.frame == c.frame
            && portalWasInsideAtPrev(*p, xPrev, (double)s.y, pHalfP,
                                     pRotHere)) {
            // Whether this rule still does any WORK is not answerable from the
            // output: dropping it is a LOOSENING, and a loosening cannot show
            // up in a corpus of fixed plans (it only lets in firings the plan
            // never asked for). So say when the branch is taken.
            if (g_slopeDbg)
                std::printf("r52hold t=%lld uid=%d type=%d frame=%d\n",
                            (long long)K.t, p->uid, (int)p->type, (int)c.frame);
            gravHoldOver = true;
            continue;
        }
        // ---- TELEPORT portal (type 28) --------------------------------------
        // Below the y test, not above it: lv20 stacks two teleports at the SAME
        // x (four such pairs, 300 px apart) and firing on the x overlap alone
        // sent the player to the other one's destination every time -- 241
        // where GD lands on 335. It is the y that tells the pair apart.
        //
        // Separate from the mode-portal block that follows because a teleport
        // is not a mode change: it moves the player and touches NOTHING else.
        // Measured across the teleport tick on lv20's nodeath pass (four
        // portals: full cube, mini cube, wave): y becomes the portal's absolute
        // target, vy keeps stepping by its ordinary per-tick gravity with NO
        // halving, x keeps its uniform advance, the mode is unchanged. So it
        // must not fall through to the "every portal halves vy" rule.
        // Gravity is switched only when the portal asks (m_gravityMode); all
        // twenty of lv20's ask for nothing.
        // Grounded is dropped: whatever the player stood on is 200 px away now.
        // Every measured teleport was already airborne, so that part is
        // reasoning rather than measurement -- if a grounded one ever shows up,
        // check it.
        if (p->type == 28) {
            if (!changes) continue;   // already at the target
            // The destination's PADS and ORBS do not fire on the arrival tick.
            // GD's checkCollisions has already run for this tick at the old
            // position, so nothing at the target is touched until the next one.
            // Measured at lv20's own wall, t=2571 (teleport to y=136 with a
            // yellow pad under it): both sides agree on y=136, GD keeps its
            // incoming vy=5.858 (= 6.074 - 0.216, the ordinary gravity step)
            // and only reports 16.000 at t=2572, while the model fired the pad
            // on the arrival tick and left 2.3 px high from there on.
            // Hazards are deliberately NOT skipped: not killing where GD kills
            // is the dangerous direction, and no measurement covers it.
            const double vIn = (double)c.vy;   // for `telefire` below
            teleportedThisTick = true;
            c.tpSkip = 1;   // State::tpSkip
            if (g_touchCensus) g_tcBranch |= 4;
            teleUid = p->uid;      // uid-order gate (measured, see teleUid's decl.)
            YSET(c.y) = (float)tpTarg;   // exit half for 2902, closed tpY for 747
            // A teleport is the one thing in the pass that MOVES the player for
            // the objects behind it: the uid-order gate above exists because
            // lv20 t=7,295's pad and gravity portal (both larger uids) fire at
            // the landing site on the arrival tick. So the position the rest of
            // the pass judges from is the target, not the free y that got here.
            // Without this the gravity portal uid7028 stops firing and the
            // yellow pad's -16 is never halved to GD's -8.000.
            yFree = c.y;
            c.grounded = 0;
            c.snapObj = nullptr;
            c.snapDist = 0.f;
            c.onSlope = 0;
            c.slopeM = 0.f;
            // tpGrav states GD's upsideDown (flipGravity's argument), which is
            // the model's `flip` mirrored in frame 3 -- same conversion the
            // gravity portals make (gdUpOf). flipGravity is a NO-OP when the
            // player already has that gravity (disasm 0x39a1e9: early-out on
            // equality), and the vy halving below lives INSIDE that no-op
            // guard, so "did gravity actually change" is load-bearing.
            int wantUp = -1;
            if (p->tpGrav == 1) wantUp = 0;
            else if (p->tpGrav == 2) wantUp = 1;
            else if (p->tpGrav == 3) wantUp = gdUpOf(c) ? 0 : 1;
            const bool gravChanged =
                (wantUp >= 0 && gdUpOf(c) != (uint8_t)wantUp);
            if (gravChanged)
                c.flip = (c.frame == 3) ? (uint8_t)!wantUp : (uint8_t)wantUp;
            if (p->id == 747) {
                // A gravity-switching 747 ASSIGNS its exit vy -- it does not
                // carry the entry vy the way lv20's plain pairs (tpGrav=0) do.
                // Measured on lv22 uid6158 (x=13,035, tpy=605, tpg=1): entry vy
                // 8.000 and 15.000 (the flipped-rise cap; 20 was capped to 15
                // by GD itself first) both exit at EXACTLY +18.000 world-up on
                // the arrival tick, decaying by ordinary cube gravity from
                // there (GD 9079: 17.785 -- so no rise cap on the way out
                // either). The missing 3.000 lowered the arc 51 px and hid the
                // yellow orb at x=13,155 from the DP: press branches merged
                // with coasting everywhere (alive=1) and the frontier died in
                // the spike V at x=13,330. UNVERIFIED: tpGrav==2/3 (no
                // instance in lv1-22), mini scaling, non-cube modes.
                if (p->tpGrav == 1) VYSET(c.vy) = 18.0f;
                // --tpgroundvy [2026-09-19]: a body standing on an OBJECT
                // enters with the tick's gravity step still in vy -- the solid
                // clamp is in checkCollisions' solid loop, after the teleport
                // (the same collision-order story as the 2902 branch below and
                // the gravity portals' vAtPortal). lv20 t=8,156: an upright
                // robot on a block at y=375 takes 747 uid7698 (tpGrav 0) to
                // y=287, where gravity portal uid7702 fires on the arrival
                // tick; GD reads -0.097 = (-0.194) / 2, the model halved 0.
                // Cube and robot (the robot's g is the cube's x 0.9).
                else if (s.grounded
                         && (c.mode == 0 || c.mode == 5)) {
                    const bool onFloorT = !s.flip && s.frame == 0
                        && (double)s.y <= (kGroundY + pHalf) + 0.5;
                    if (!onFloorT) {
                        const double gT = std::fabs(cubePhysFor(useDx).g)
                            * (c.mode == 5 ? kRobotGScale : 1.0);
                        const double vT = (s.flip ? 1.0 : -1.0) * gT;
                        VYSET(c.vy) = (float)(gravChanged ? vT * 0.5 : vT);
                    }
                }
            } else {
                // The 2902 family carries vy through flipGravity instead:
                // *0.5 when gravity actually changes (PlayerObject::flipGravity
                // 0x39a2d4: m_yVelocity *= 0.5, world frame, sign kept),
                // nothing otherwise. Both lv22 crossings land EXACTLY:
                //   t=13,223 uid6425 airborne, up1->0: (-4.408+0.216)*0.5
                //            = -2.096, GD -2.096
                //   t=14,213 uid6437 grounded on blocks, up0 stays: one full
                //            old-gravity step -0.216, GD -0.216 (no halving)
                // The grounded value is the same collision-order story as the
                // gravity portals' (see the vAtPortal note below): standing on
                // a SOLID the clamp lives in checkCollisions and the teleport
                // gets the gravity-stepped vy; on the GROUND layer the update
                // already zeroed it. UNVERIFIED: non-cube grounded entry.
                double vTp = (double)c.vy;
                if (s.grounded
                    && (c.mode == 0 || c.mode == 5)) {
                    const bool onFloor = !s.flip && s.frame == 0
                        && (double)s.y <= (kGroundY + pHalf) + 0.5;
                    if (!onFloor)
                        vTp = (s.flip ? 1.0 : -1.0)
                            * std::fabs(cubePhysFor(useDx).g)
                            * (c.mode == 5 ? kRobotGScale : 1.0);
                }
                VYSET(c.vy) = (float)(gravChanged ? vTp * 0.5 : vTp);
            }
            // `portfire` below CANNOT SEE THIS BRANCH -- it sits after the
            // `continue`, so every teleport is invisible to it while ordinary
            // portals print. Measured: an anchored lv22 run emits 39 portfire
            // lines and none at t=9,866 / 10,089, where the model teleports
            // 57.5 px. A debug print that structurally excludes the branch you
            // are investigating reads exactly like "the branch did not fire".
            if (g_slopeDbg)
                std::printf("telefire t=%lld uid=%d id=%d type=%d tpg=%d "
                            "vIn=%.4f vOut=%.4f y=%.3f gravChanged=%d\n",
                            (long long)K.t, p->uid, p->id, p->type, p->tpGrav,
                            vIn, (double)c.vy, (double)c.y, gravChanged ? 1 : 0);
            continue;
        }
        {
            // EVERY portal halves vy, not just the gravity ones. Measured on
            // lv5's ship portal (cx=13793) at t=10584: the tick's normal cube
            // gravity takes vy to -8.044 and GD then enters the portal with
            // -4.022 -- exactly half. The model kept -8.044, hit the ship
            // terminal -6.400, and dived 4.5 px below GD within ten ticks.
            // A cube standing still has vy = 0 in the model (the grounded branch
            // skips gravity), but GD still applies that tick's gravity before
            // halving. Measured on lv6 t=13616: the cube sat grounded at y=195
            // with vy = 0, crossed the inverse gravity portal, and GD came out
            // at -0.1080 = (0 - 0.216)/2 -- exactly "gravity, then halve".
            // Without this the model leaves the portal 0.108 (half a gravity
            // step) high and stays parallel to GD forever after.
            // A portal that does not CHANGE anything is a no-op -- in
            // particular it does not halve vy. Measured on lv7 t=6439: an
            // already-upright ship crosses a normal-gravity portal (type 4) and
            // GD leaves vy at 6.817, while the model halved it to 3.409 and was
            // 6 px below GD eight ticks later.
            // --slopedbg doubles as the portal trace: which portal fired, on
            // which tick, in which frame, and at what coordinate. Without it a
            // portal that fires at the WRONG TIME in a rotated frame is
            // indistinguishable from a physics bug (lv22 t=4,688).
            if (g_slopeDbg)
                std::printf("portfire t=%lld frame=%d x=%.2f y=%.2f uid=%d "
                            "type=%d pcx=%.2f pcy=%.2f\n",
                            (long long)K.t, (int)c.frame, x, (double)c.y,
                            p->uid, (int)p->type, p->cx, p->cy);
            const uint8_t wantFlip = (p->type == 3) ? 1 : 0;
            const uint8_t wantMode = (p->type == 5)    ? 1
                                     : (p->type == 16) ? 2
                                     : (p->type == 19) ? 3   // UFO
                                     : (p->type == 26) ? 4   // wave
                                     : (p->type == 27) ? 5   // robot
                                     : (p->type == 33) ? 6   // spider
                                     : (p->type == 41) ? 7   // swing
                                                       : 0;
            const uint8_t wantMini = (p->type == 18) ? 1 : 0;
            const bool isGrav = (p->type == 3 || p->type == 4);
            const bool isSize = (p->type == 17 || p->type == 18);
            // Dual (23) / solo (24). Measured on lv16 x=10,551: the second
            // player appears AT THE SAME POINT with the opposite gravity and
            // the opposite vy, so the two are mirror images until one of them
            // touches something. The solo portal drops the second half.
            //
            // "THE SAME POINT" IS THE PRE-COLLISION ONE (`yFree`), not `c.y`.
            // In free space the two are the same number, which is why this went
            // unnoticed: it only shows on a tick where the collision pass moved
            // p1 -- and there it puts the whole dual section in the wrong place.
            // Measured on lv20 t=17,109 (UFO pressed down a ceiling ramp at
            // x=25,750, dual portal uid13879):
            //   GD  p1 y = 297.580 (the ramp's seat), p2 born at **298.472**
            //   298.472 = 299.193 (p1's y one tick earlier) + 0.225 * -3.204
            //           = p1's position before the ramp pushed it back down
            // and three injections at the same site pin it further: p1 clamps to
            // the same 297.2145 for vy = -2.172 / -4.086 / -6.400 while p2 is
            // born at 298.675 / 298.581 / 298.060 -- i.e. at a place that still
            // depends on vy, so it cannot be the clamped position.
            // The old `c.y` put p2 0.892 px off, the mirror axis split by the
            // same amount, and the offset survived to the end of the level.
            if (p->type == 23 || p->type == 24) {
                const uint8_t wantDual = (p->type == 23) ? 1 : 0;
                if (c.dual == wantDual) continue;
                if (wantDual) {
                    c.y2 = yFree;
                    c.vy2 = -c.vy;
                    // born in whatever mode and size the first body is in right
                    // now (this pass's earlier portals included), and with no
                    // press behind it -- it has not been anywhere yet.
                    c.mode2 = c.mode;
                    c.mini2 = c.mini;
                    c.ceilT2 = 0;
                    c.ceilM42 = 0;
                    c.flip2 = c.flip ? 0 : 1;
                    c.grounded2 = 0;
                    c.ringHold2 = 0;
                    // Same "no press behind it" as ringHold2, and the same unmeasured
                    // edge: whether GD's fresh p2 inherits +0x986 from a press already
                    // held at the split has no corpus instance either way.
                    c.pressSpent2 = 0;
                    c.onSlope2 = 0;
                    c.slopeM2 = 0.f;
                    c.snapObj2 = nullptr;
                    c.snapDist2 = 0.f;
                    c.usedOrb2 = nullptr;
                    c.usedOrbOld2 = -1;
                    for (int i = 0; i < 3; ++i) c.usedOrbHist2[i] = -1;
                    c.holdDead2 = 0;
                    for (int i = 0; i < 3; ++i) c.portSeen2[i] = -1;
                    for (int i = 0; i < 4; ++i) c.touchRing2[i] = -1;
                    c.touchRingT2 = 0;
                    for (int i = 0; i < 4; ++i) c.usedPad2[i] = nullptr;
                }
                c.dual = wantDual;
                // Entering a dual re-derives the band from THIS portal's cy
                // with the current mode's dual height, and pins bandRefY there
                // for the whole dual section. Leaving one (24) does not touch
                // the band: measured on lv16, after the merge at x=15,103 GD
                // still reports [330,630], the ship-in-dual band.
                // A Free Mode DUAL portal is left alone deliberately: this
                // branch also pins bandRefY for the rest of the dual section,
                // so skipping it would hand the later in-dual writes a stale
                // reference y. No level in lv1-22 has one (lv22 owns every
                // Free Mode portal there is and none of them is a dual), so
                // there is nothing measured to model here.
                if (wantDual) {
                    c.bandRefY = (float)p->cy;
                    const FlyBand nb = bandFor(p->cy, bandHeightDual(c.mode));
                    c.bandFloor = (float)nb.floorY;
                    c.bandCeil = (float)nb.ceilY;
                    if (g_shipCeilSet) c.bandCeil = (float)(g_shipCeil + kCubeHalf);
                    if (g_ufoCeil > 0.0) c.bandCeil = (float)g_ufoCeil;
                    if (g_flyFloor > 0.0) c.bandFloor = (float)g_flyFloor;
                }
                continue;
            }
            // The band is written HERE, by the portal that actually fired --
            // not by every portal the layer's x has passed (see State::band*).
            //
            // ...and it is written BEFORE the "already in that state" bail-out
            // below, because **a mode portal you are already in still rewrites
            // the band**. Measured on lv20 with the ceilprobe build's pmin/pmax
            // columns: the wave portal at (4445,303) is entered as a wave at
            // t=3406 (x=4420.69, its box starts at 4425.28 and the wave's half
            // is 5) and GD's band goes [90,390] -> [150,450] on exactly that
            // tick -- which is bandFor(303, 300) to the pixel. Nothing else
            // changes: vy stays -5.193 across the portal, so there is no
            // halving and no impulse. The old comment called this portal INERT
            // and skipped it, which left the model on the x=867 portal's band
            // and clamped the wave at 380 (= 390 - 10) while GD climbed past
            // 400. That clamp was lv20's wall: the model sat grounded at
            // y=380.000 from t=3865 on.
            //
            // Safe for the other kinds: bandHeightFor returns 0 for gravity
            // (3/4) and size (17/18) portals, so an inert one of those still
            // writes nothing.
            {
                // Inside a dual the reference y stays the dual portal's cy and
                // only H follows the new mode -- and a cube portal, which is
                // inert outside a dual, updates it too (H = 270). Gravity and
                // size portals never switch mode, so they never call
                // updateDualGround and must not reach this at all.
                const bool isMode = !isGrav && !isSize;
                const bool inDual = isMode && c.dual != 0;
                // Every mode portal writes GD's Free Mode byte from its own
                // property 111 (bands.hpp, kBandFreeKnown) -- before the band,
                // and whether or not it animates one in.
                if (isMode && g_freeModeCol)
                    c.bandBranch = (uint8_t)((c.bandBranch & ~kBandFree)
                                             | kBandFreeKnown
                                             | (p->freeMode ? kBandFree : 0));
                const double H = inDual ? bandHeightDual(wantMode)
                                        : bandHeightFor(p->type);
                const double refY = inDual ? (double)c.bandRefY : p->cy;
                // ...unless the portal is a FREE MODE one, which writes no
                // band at all (updateDualGround's gate -- see g_freeModeCol).
                // Seven of lv22's seventeen mode portals are, and GD's ground
                // sprites confirm all seventeen.
                // A MODE portal that does not animate the band in still
                // retracts it -- updateDualGround's else branch runs the same
                // tween the other way -- and that is the whole of the wave
                // section's 322: the band there is not 300, it is out of the
                // way. Gravity and size portals never reach updateDualGround
                // at all, hence isMode.
                if (g_staticCamCol && isMode
                    && (H <= 0.0 || (g_freeModeCol && p->freeMode))) {
                    c.bandAnim = bandAnimStart(false);
                    // the else branch drops the static camera only when the
                    // band was the MODE's, so it cannot pull a level out of
                    // branch A
                    if (c.bandBranch & 2) c.bandBranch &= (uint8_t)~1;
                }
                if (H > 0.0 && !(g_freeModeCol && p->freeMode)) {
                    if (g_staticCamCol) {
                        // animateInDualGroundNew: it takes staticY for itself
                        // when nobody else holds it, and claims the band
                        c.bandAnim = bandAnimStart(true);
                        c.bandBranch |= 3;
                    }
                    if (!inDual) c.bandRefY = (float)p->cy;
                    const FlyBand nb = bandFor(refY, H);
                    c.bandFloor = (float)nb.floorY;
                    c.bandCeil = (float)nb.ceilY;
                    if (g_shipCeilSet) c.bandCeil = (float)(g_shipCeil + kCubeHalf);
                    if (g_ufoCeil > 0.0) c.bandCeil = (float)g_ufoCeil;
                    if (g_flyFloor > 0.0) c.bandFloor = (float)g_flyFloor;
                }
            }
            // Everything from here on is the state CHANGE, which an inert
            // portal does not do (the band above is the only thing it touches).
            // ...and this SECOND gate reads GD's statement too. It was the last
            // one on lv22 t=5,110: with only `changes` converted the portal
            // reported changes=1 and still did nothing, because
            // `c.flip == wantFlip` is 0 == 0 in frame 3.
            // ...and it reads the gravity the player had BEFORE this tick's
            // BALL TAP. GD's tick is update -> collisions -> buttons, so a
            // gravity portal has already decided by the time the tap flips;
            // the model taps first and then walks the portals, so a portal that
            // was inert on entry came out "changing" and fired.
            // Measured on lv22 t=5,940 (ball corridor, x=8,204): uid5810 is an
            // id-10 (normal) gravity portal at (8251,945) 75x25, i.e. active for
            // y in 917.5..972.5. The ball is at y=972.02 in NORMAL gravity, so
            // GD's portal is a no-op and the tap leaves at vy=+3.426 flipped.
            // The model tapped, became flipped, and the portal then flipped it
            // back AND halved it: vy=+1.713 unflipped, and the corridor after it
            // was a different level. The pad block below states the same
            // ordering the other way round ("the pad wins over the tap").
            const uint8_t gdUpPortal =
                (isGrav && ballFlippedThisTick)
                    ? ((c.frame == 3) ? (uint8_t)!s.flip : (uint8_t)s.flip)
                    : gdUpOf(c);
            // [2026-08-22 r100] **A gravity portal during a dual passes through**,
            // and **even a same-mode portal produces the flying-end halving**.
            // Measured lv16 t=13,496 (second dual, a mini ship, still mini,
            // touches the boxes of ship portal uid6721 and gravity portal
            // uid6748 (id10=normal gravity) on the same tick):
            //   GD p1 vy 1.153 -> **0.319** = (1.153+0.122) x **1/4**
            //   GD's upsideDown **stays p1=1 / p2=0 to the very end**
            //   (no flip even following past the gravity portal's 25px span)
            // So only **the same-mode ship portal** is in effect, and its value
            // is two flying ends (leaving 1/2 x entering 1/2) = x1/4. The
            // gravity portal does not fire in the dual (r82's "gravity portal
            // passes through" reading is correct for this sample).
            // [2026-08-22 r101] **In a dual, when both bodies enter the same
            // gravity portal's box, flipGravity runs twice.** GD itself was made
            // to state it (py/gdprobe.py 16 --cfg hitboxtrace=1; the MOD's
            // `pfg:` line writes m_player1's flipGravity per call):
            //   pfg: t=13,495 flip=0 up 1->0 vy=0.637   (half of 1.275)
            //   pfg: t=13,495 flip=1 up 0->1 vy=0.319   (halved again)
            // -> **vy is x1/4, up round-trips back to what it was**. The
            // identity of corpus family `m1/mini1/g0/gdg0/sp1.1/air` edvy
            // -0.318; it was neither "same-mode ship portal is x1/4" nor
            // "gravity portal passes through" (both refuted on the dualport
            // calibration rig).
            // **When only one body is inside, as before** (dualport 12 units:
            // the touching body gets x1/2 + flip, the partner flip only).
            // **Entry tick only.** This bypasses the inert gate (`changes`), so
            // it would re-fire for as long as the player is inside the box (the
            // first implementation did exactly that and broke t=13,497 onward).
            // "Was already inside" is read at the previous tick's position.
            // ...AND "INSIDE" HAS TO MEAN THE SAME BOX THE FIRING TEST USES. This asked the
            // BOUND while the fire above asks the ORIENTED box, and for a portal turned off the
            // axis those are very different: lv16's dual pair at x=12,123 is 25x75 rotated 54
            // and 58 degrees, so the bound is 76 wide against a real 25.
            //
            // What that costs is not an early fire but NO FIRE AT ALL. Measured on lv16 t=8,014
            // (dual cube, gravity portals uid3450 for p1 and uid3448 for p2, GD flips both on
            // this tick):
            //   t=8,013  the oriented test REJECTS uid3450 (margin -0.910) -> no fire, but the
            //            player is already inside the 76-wide bound
            //   t=8,014  the oriented test passes -- and this line, reading the bound, answers
            //            "already inside" and skips it
            // p1's portal is then skipped on every later tick too, so the model runs the rest of
            // the section at the wrong gravity: the fixup recorder wrote 30 consecutive p2
            // records with dvy off by 0.430 = exactly two cube gravity steps.
            // Which is why it is portalWasInsideAtPrev: r52's gate 300 lines
            // above and the ground arm's pre-evaluation ask the same question
            // through the same expression, and none of the three can drift.
            const bool wasInBoxPrev =
                portalWasInsideAtPrev(*p, xPrev, (double)s.y, pHalfP, pRotHere);
            // (The same-box skip r101 that stood here was the --no-dualcouple arm; the
            // two partner calls in stepBoth, fixup.hpp, replace it.)
            // ...and **a dual's gravity portal fires only on the entry tick**.
            // Once the double call returns up to what it was (above), the next
            // tick reads "still not the wanted up" = `changes` raises and the
            // normal path re-fires. On GD's side the object's activation flag
            // makes it one-shot.
            // **Dual only** -- the non-dual "entry tick only" generalisation is
            // already rejected (lv5/14/18/20/21 regressed, the r52 note).
            if (isGrav && c.dual && wasInBoxPrev) {
                // --slopedbg: is this still doing work? The portal LATCH
                // (67ab13f) suppresses a re-fire per half on the object's own
                // flag, which is the same suppression this line was written for
                // before that existed. If the count is 0 the line is a fossil.
                if (g_slopeDbg)
                    std::printf("dualskip kind=wasinbox half=%d t=%lld uid=%d\n",
                                g_halfNow, (long long)K.t, p->uid);
                continue;
            }
            // [Rejected (2026-08-22 r100)] Two rules were tried from the reading
            // above:
            //   (a) `if (isGrav && c.dual) continue;` (gravity portals pass
            //       through during a dual)
            //   (b) emit the x1/4 for same-mode fly portals too
            // **With both in, lv16's second dual is already dy -0.466 by
            // t=13,494** -- i.e. (a) also kills the gravity portal **before**
            // this section, one GD genuinely fires. Same shape as r82's failure.
            // At least 3 combinations produce the same x1/4 for the single
            // sample (t=13,496):
            //   ship 2 ends x1/4 + gravity pass-through / ship 1 end x1/2 +
            //   gravity that "does not flip but does halve" / ...
            // **Do not touch until a dedicated dual rig separates them.**
            if (isGrav ? (gdUpPortal == wantFlip)
                : isSize ? (c.mini == wantMini)
                         : (c.mode == wantMode)) continue;
            // ...except the BALL portal, which does not halve at all. Measured
            // on lv10 t=1743: vy goes 0.5960 -> 0.3800, i.e. that tick's cube
            // gravity (-0.216) and nothing else. Ship, cube and gravity portals
            // all halve (lv5 -8.044 -> -4.022, lv7 -1.979 -> -0.990, lv6
            // 0 -> -0.108); type 16 is the exception. Measured once -- re-check
            // at lv10's second ball portal (x=18405) when a plan reaches it.
            // ...and neither does the SIZE portal. Measured on lv11 t=3384:
            // the cube is grounded (vy = 0) when it enters the mini portal, and
            // GD's next tick shows vy = -0.2160 -- one FULL cube gravity step.
            // The "gravity then halve" rule would have produced -0.1080.
            // The type-16 exemption below was the zero-flying case of the
            // "one half per flying end" rule wearing a disguise (the big
            // comment below even says so). Measured on lv16's second dual,
            // UFO -> ball at (19193,543): GD comes out at 2.868 =
            // (5.888 - 0.152) * 0.5 -- ONE flying end, ONE halving, ball
            // portal or not. So the ball portal only skips the halving when
            // NEITHER end flies (the lv10 cube -> ball measurement).
            // --portalpress (speed.hpp): GD's buttons run AFTER this collision pass, so a press on
            // the tick a MODE portal fires is the new mode's press. Undo the old mode's action
            // here, before the halving reads it, and let the new mode redo it after the change.
            // Cube -> UFO too (speed.hpp, the portal flap): the redo is the next tick's flap.
            if (g_portalPress && pressAction && !isGrav && !isSize && wantMode != c.mode
                && (wantMode == 0 || wantMode == 1 || wantMode == 2 || wantMode == 4
                    || (wantMode == 3 && c.mode == 0))) {
                c.flip = s.flip;
                VYSET(c.vy) = 0.f;
                c.grounded = 1;
                if (pressAction == 2) { c.rotStep = s.rotStep; c.rotNeg = s.rotNeg; }
                // The undone tap did not happen, so it does not spend +0x985 either -- a ship
                // made from the ball thrusts on the held press (a custom level t=10,786, GD vy 0.127)
                if (pressAction == 2) ballFlippedThisTick = false;
                c.pressSpent = s.pressSpent;
                portalPressRedo = true;
            }
            const bool halves = !isSize;
            double vAtPortal = (double)c.vy;
            // [2026-08-18] ...but **it differs only when the footing is an
            // object**. GD's ground layer stops y inside PlayerObject::update =
            // before checkCollisions, so the portal halves 0 and emits 0.
            // Standing on a solid, the grounding clamp lives inside
            // checkCollisions and, depending on uid, the portal can come first
            // -- there it halves "the value with one tick of gravity applied".
            // GD measurements (gdref all levels, every cube that crossed a
            // gravity portal while grounded):
            //   lv5  t=17,015 y=195 (block)  up1->0  vy 0 -> **+0.108**
            //   lv6  t=13,616 y=195 (block)  up0->1  vy 0 -> **-0.108**
            //   lv7  t=7,766  y=285 (block)  up1->0  vy 0 -> **+0.108**
            //   lv4  t=6,731  y=105 (ground) up0->1  vy 0 -> **0.000**
            //   lv12 t=4,733  y=99  (ground) up0->1  vy 0 -> **0.000**
            // The sign is the **old gravity's** direction (+ when flip=1). A
            // hack with the same intent used to live here and was removed after
            // colliding with lv12's 0.000, but the real split was "ground layer
            // or object".
            if (isGrav && s.grounded && c.mode == 0) {
                const bool onFloor = !s.flip && s.frame == 0
                    && (double)s.y <= (kGroundY + pHalf) + 0.5;
                if (!onFloor)
                    vAtPortal = (s.flip ? 1.0 : -1.0)
                              * std::fabs(cubePhysFor(useDx).g);
                // --portalunpin: ...and y keeps that step too, like a pad taken off a block.
                // Nothing re-seats the body once gravity points away from the block. gdref:
                //   lv6 t=13,615 y=195 (block) up0->1  y 195 -> 194.9514 (-0.0486)
                //   lv5 t=17,015 y=195 (block) up1->0  y 195 -> 195.0486 (+0.0486)
                //   lv4 t=6,731 / lv12 t=4,733 (ground layer)  y unchanged
                // The model already left the flipped case (lv5) off the block -- a later write
                // moves it, so releasing the pin there too moved it twice (lv5 went 96 -> 2,719
                // bad ticks) -- and the upright one stayed seated, 0.0486 px high for 106 ticks.
                if (!onFloor && !s.flip && g_portalUnpin && pinnedOnBlock) releasePin(false);
            }
            // TRIED AND REVERTED (2026-08-19): "a ball crossing while grounded
            // on the ceiling side leaves carrying +-2.000 (+-1.000 after
            // halving)". The measurement is lv22 t=6,307-8 (frame1's ceiling
            // corridor, ud 1->0): GD is exactly vy=-1.000 at 6,308, then plain
            // decay at -0.129/tick.
            // Put in as `mode==2 && s.grounded && s.flip` it **over-fired at
            // lv16 t=4,2xx** (the census m2/fly/land family 1->3, edvy +1.000,
            // lv16's t=4,200 section 400->37) -- GD emits no +-1.000 in lv16's
            // twin case (flipped grounded ball x gravity portal). The condition
            // separating lv22's -1.000 (rotation frame? kind of g2? firing
            // order?) is unidentified.
            // One point is not a rule -- lv22 t=6,308 stays a known census item.
            // A GROUNDED player brings vy = 0 into the halving -- GD does not
            // slip an extra gravity step in first. There used to be one here,
            // fitted to lv6 t=13616 where a grounded cube left an inverse portal
            // at -0.1080 = (0 - 0.216)/2. lv12 t=4733 is the same shape and GD
            // comes out at 0.0000: grounded going in, so the tick produced no
            // gravity, and halving zero is zero. The lv6 reading was really a
            // one-tick offset in `grounded` caused by the old x constant (see
            // kDxF), and the hack was compensating for that rather than
            // modelling anything. With x exact it is simply wrong.
            // TRIED AND REVERTED (2026-07-31): snapping the halved value to a
            // 0.001 velocity grid. The observation behind it is real and
            // reproduces on demand -- a halving is the only thing that puts vy
            // off a 0.001 grid, and the very next tick then moves by 0.0005 more
            // than the mode's gravity:
            //   lv7  -1.979 -> -0.9895 raw, GD reports -0.990
            //   lv12 -10.275 -> -5.1375 raw, next step -0.0865, not -0.086
            //        (= -5.138 - 0.086), reproduced twice by re-injection
            //   lv12 -7.456 -> -3.728 raw (on grid), next step the plain -0.086
            // Left alone it is 0.0001 px of y per tick, which had grown to
            // 0.049 px by lv12 t=16796 -- exactly enough to put the model
            // 32.3457 from a saw of radius 32.3 where GD sat at 32.2997 and died.
            // But snapping HERE breaks lv10 (cleared -> stuck at x=11,243) with
            // either rounding direction, so the grid is not applied at the
            // portal. It is probably a property of the velocity update itself,
            // and the samples so far are all negative and all from portals.
            // CLOSED (2026-08-07): it was exactly that -- the grid belongs to
            // the velocity update, see qVy. The halving's own output is
            // reported raw and lands back on the grid one tick later. So the
            // rejection above is right and stays: this is not the rounding
            // point.
            // ...and the factor is ONE HALF PER FLYING END, not one per portal.
            // Counting ship and UFO as flying modes, all five measurements line
            // up (each is the value AFTER that tick's gravity, before the mode
            // change):
            //   cube -> ball  0 flying  x1     lv10 t=1743   0.596 -> 0.380
            //   cube -> ship  1 flying  x1/2   lv14 t=5340  -2.560 -> -1.280
            //   cube -> UFO   1 flying  x1/2   lv12         -2.376 -> -1.188
            //   UFO  -> ship  2 flying  x1/4   lv13 t=10798  4.549 -> 1.1373
            //                                  lv14 t=11655 -6.195 -> -1.5488
            //   ship -> UFO   2 flying  x1/4   lv14 t=14192  6.489 -> 1.6222
            // The ball portal's "no halving" (measured separately, see `halves`)
            // is the zero-flying case of the same rule, which is a second reason
            // to believe it. ball <-> cube is still handled as a half by
            // `halves` above; nobody has measured one.
            // ...and the WAVE is a flying end too. Two more measurements, both
            // from lv17's verified replay (so a plain run, not an injection):
            //   cube -> wave  1 flying  x1/2  t=3395  -5.899 -> -2.9495
            //   wave -> ball  1 flying  x1/2  t=8497   5.193 ->  2.5965
            // Both land exactly on the half, and both are half-grid values,
            // which is the halving's own fingerprint (see qVy). The model kept
            // the full value and lv17's first divergence was reported as
            // "wave/ball's velocity is exactly 2.0x" in update 29 -- it was not a factor
            // applied twice, it was a halving that never happened.
            // The ball still does NOT count (lv10 t=1743 cube -> ball is x1),
            // so this set is {ship, ufo, wave} and NOT GD's `flyish`.
            // ...and the SWING (mode 7) is one too. lv22 is the only level with
            // one, and all three of its swing mode portals are exact halves of
            // "the old mode's gravity step, then x1/2" (2026-08-18):
            //   t=3,323 cube  -> swing   2.801 -> 1.379
            //           (2.801 - 0.0432 [cube g under the 0.2x warp]) * 0.5
            //   t=6,938 ball  -> swing   5.809 -> 2.969   (ud=1)
            //           (5.809 + 0.129 [ball g]) * 0.5
            //   t=4,635 swing -> cube    0.770 -> 0.428   (ud=1)
            //           (0.770 + 0.086 [kSwingG]) * 0.5
            // The missing membership is why the model came out of every swing
            // portal at twice GD's speed. lv22 t=8,231 (swing -> spider off a
            // RAMP) does not fit any of this -- GD adds +0.504 there -- but
            // that tick is a known open (the ride's exit impulse), not
            // evidence about the ladder.
            // ...but **a swing riding a ramp does not count as a flying end**
            // (2026-08-19). lv22 t=8,230 (swing->spider, departing from a ramp
            // ride): GD's vy 2.258 is exactly 2.000x the model's (with x1/2
            // applied) = one rung too many on the ladder. The note above's "GD
            // adds +0.504" was a stale-worldline reading (the
            // [[gd-constant-justification-goes-stale]] pattern).
            const bool srcFly =
                ((c.mode == 1 || c.mode == 3 || c.mode == 4 || c.mode == 7)
                 && !(c.mode == 7 && s.onSlope));
            const bool dstFly =
                (wantMode == 1 || wantMode == 3 || wantMode == 4
                 || wantMode == 7);
            const int flyEnds = (srcFly ? 1 : 0) + (dstFly ? 1 : 0);
            // Gravity portals halve regardless of mode (lv5: cube -8.044 ->
            // -4.022 with zero flying ends); the flying-ends ladder is a MODE
            // portal rule, and its wantMode is meaningless for isGrav anyway.
            const double portalScale =
                isGrav             ? kGravPortalScale
                : (flyEnds == 2)   ? 0.25
                : (flyEnds == 1)   ? kGravPortalScale
                                   : 1.0;
            // --slopedbg: WHO halved the velocity. The portal loop prints
            // `portfire` when a portal is taken and `portgate` with the
            // `changes` verdict, but neither says whether the halving actually
            // ran or what it ran on -- and at lv22 t=6,291 a ball tap's -3.4260
            // reaches the state as -1.7130 with the only portal on that tick
            // reporting changes=0. One of those two readings is wrong and the
            // line says which.
            if (g_slopeDbg)
                std::printf("porthalve t=%lld uid=%d type=%d halves=%d "
                            "isGrav=%d flyEnds=%d scale=%.4f vAt=%.4f "
                            "vy=%.4f -> %.4f\n",
                            (long long)K.t, p->uid, (int)p->type,
                            halves ? 1 : 0, isGrav ? 1 : 0, flyEnds,
                            portalScale, vAtPortal, (double)c.vy,
                            halves ? vAtPortal * portalScale : (double)c.vy);
            if (halves) VYSET(c.vy) = (float)(vAtPortal * portalScale);
            if (isGrav) {
                // 3 = inverse (upside down), 4 = back to normal -- stated in
                // GD's `upsideDown`, so convert back to the frame's own sign.
                const uint8_t flipBefore = c.flip;
                c.flip = (c.frame == 3) ? (uint8_t)!wantFlip : wantFlip;
                // [2026-09-05] **GD's flipGravity also fires the PARTNER.** A
                // dual's two bodies are not independent: GJBaseGameLayer's
                // flipGravity calls the other player with the polarity inverted,
                // and GD runs p1.update -> collisions(p1) -> p2.update ->
                // collisions(p2), so the partner call lands BEFORE p2 has
                // integrated. The model steps each half through a whole stepOne,
                // so p2 halves after its own gravity: (vy + a)/2 where GD gives
                // vy/2 - a.
                // Measured on lv16 t=8,062 (dual cube, p1 on uid 3450, p2 on
                // uid 3448 -- a mirrored pair): p2's vy is 7.176 against GD's
                // 6.854, a fixed 0.322 forever after, and y2 moves +3.229 where
                // GD moves +1.543 (about half). That position difference is why
                // the model's p2 then also fires 3448 while GD's misses it by
                // 0.25 px -- GD's p2, having halved first, sits lower.
                // Only from p1, and only outside the same-box case: r101's skip
                // above already models the round-trip that a partner call plus
                // p2's own activation produce when both bodies are in ONE box,
                // and doing both would count it twice. Whether the coupling can
                // subsume r101 is a separate question with its own two witnesses
                // (lv16 13,495) -- see the ledger. [flag clean-up] r101's skip is gone: it
                // was the --no-dualcouple arm, and the coupling in fixup.hpp replaced it.
                if (linkFlip && c.flip != flipBefore) *linkFlip = true;
                // [2026-08-21 r70] **On the tick a flipped body grounded on a
                // ceiling is returned to normal, g/2 is placed in the old
                // gravity direction (up).** Calibration rig ceilramp measured
                // (the tick a ceiling-running robot/spider passes the
                // gravity-restore portal):
                //   robot  vy 0 -> **+0.097** (= 0.194/2), then -0.194/tick
                //   spider vy 0 -> **+0.065** (= 0.129/2), then -0.129/tick
                // The model stayed 0, and a parallel g/2 vy offset persisted to
                // the end (a uniform tail of family dvy -0.097/-0.065).
                // **No blip on normal->flipped (grounded on a floor)** -- the
                // same rig's unit heads (GRAV_FLIP, floor-grounded) are
                // bit-identical. And **none for the ball** (gating cube/ball in
                // split the ball's 6 units by 1.5px/dvy13.9 -- GD only peels the
                // ball off). Only the measured robot/spider.
                // y also gets the half step: GD moves y by +0.225*g on the blip
                // tick (robot +0.044 / spider +0.029 -- vy alone leaves a y
                // residual).
                // [2026-08-21 r73] **No blip when the grounding surface is an
                // invisible ceiling (band/portal ceiling).** Calibration rig
                // ceilramp's spider m=2 (unit34/35): after a big fall from a
                // ramp launch, re-hung on the band ceiling (pmax=360,
                // y=346.5=360-pHalf), passing the restore portal GD moves
                // neither y nor vy and starts falling under plain gravity
                // (t=43,347). m=1 (the original measurement, hung on an actual
                // block's underside 290) shows the +g/2 in the dump as before
                // (t=38,304 vy=+0.065).
                // The blip's identity is the half step of collision resolution
                // against an actual object, and an invisible ceiling is not an
                // object. The discriminator is the same formula and same 0.6
                // tolerance as the support test (the invisible-ceiling clause of
                // `sup`).
                const double bandCG = (double)s.bandCeil;
                const bool bandUG = bandCG < 1e8
                    && std::fabs(bandCG - std::round(bandCG / 30.0) * 30.0)
                           < 0.01;
                const double invCeilG = std::min(
                    playerCeilAt(x),
                    (c.mode == 6 && bandUG) ? bandCG : 1e9);
                if (flipBefore && !c.flip && s.grounded
                    && std::fabs((double)c.vy) < 1e-6
                    && (c.mode == 5 || c.mode == 6)
                    && !(std::fabs((double)s.y + pHalf - invCeilG) < 0.6)) {
                    const double gMag =
                        (c.mode == 6) ? -kBallG
                        : (((double)useDx > 1.78) ? 0.195 : 0.194);
                    VYSET(c.vy) = (float)(0.5 * gMag);
                    YSET(c.y) = (float)((double)c.y + 0.225 * gMag);
                }
                // [2026-08-21 r76] **The cube's gravity restore adds only the y
                // half step.** The calibration rig ceilramp's 6 cube cells
                // (unit6-11, all |m| x mini) show a uniform dy -0.049: on the
                // restore tick GD emits both vy=+0.108 (=g/2, the old gravity's
                // +0.216 accumulated then halved by the portal -- the model
                // already matches via the same path) and **y+0.0486
                // (=0.225*g)**. The model's seat clamp put y back on the face,
                // and that 0.049 remained parallel to the end (GD leaves with
                // the foot 0.049 embedded at 290.049).
                // vy untouched (already matches). The gate is "exactly the
                // halved g/2 is left" = only this shape of lift-off. Same family
                // as the robot/spider blip (above), but that one places from
                // vy 0; this one is y only.
                if (flipBefore && !c.flip && s.grounded && c.mode == 0) {
                    const double gMagC = std::fabs(cubePhysFor(useDx).g);
                    if (std::fabs((double)c.vy - 0.5 * gMagC) < 0.002)
                        YSET(c.y) = (float)((double)c.y + 0.225 * gMagC);
                }
                c.grounded = 0;
            } else if (isSize) {
                // 18 = mini, 17 = back to normal. grounded is NOT forced here:
                // the support test at the top of the next tick decides it, and
                // on lv11 that is precisely what drops the player -- it stands
                // at y=165 on a surface whose top is 150, which supports a
                // half of 15 but not a half of 9.
                const double oldHalf = c.mini ? kMiniHalf : kCubeHalf;
                const double newHalf = wantMini ? kMiniHalf : kCubeHalf;
                if (!sizeFiredThisTick) {   // --padsection
                    sizeFiredThisTick = true;
                    sizeFiredCx = p->cx;
                    sizeFiredCy = p->cy;
                    sizeFiredUid = p->uid;
                    sizePreMini = c.mini;
                }
                c.mini = wantMini;
                pHalfLive = (c.mode == 4 && c.mini)
                                ? kWaveContactHalfMini
                                : playerHalf(c.mode, c.mini != 0);
                // A player standing on something re-seats IN THE SAME TICK --
                // but only when it GROWS. Measured on lv12 t=3286: a mini cube
                // grounded at y=189 on a surface of 180 enters the regular-size
                // portal and GD reports y=195 on that very tick, not the next
                // one. Without this the model ran a tick behind for the rest of
                // the level -- and the lag is invisible while airborne (the
                // position does not depend on the size), so it only surfaced 60
                // ticks later as a one-tick offset in `grounded`.
                //
                // SHRINKING does not re-seat: GD resolves the overlap by
                // pushing OUT of the surface, and there is nothing to push
                // against when the box gets smaller. Measured on lv11 t=3384
                // (the mini portal at x=4,395): a cube grounded at y=165 on a
                // surface of 150 goes mini and GD leaves it at y=165, drops
                // onGround on the next tick and lets it FALL the 6 px, reaching
                // its new rest height 159 only at t=3400 -- 16 ticks later.
                // The model teleported it to 159 instantly, which is the
                // "exactly 6.000px" (= 15 - 9) entry in update 29's diff list.
                // ...and only when the player was grounded AT TICK START.
                // A player that LANDED this very tick keeps the old-half seat
                // through the portal tick and the ordinary support clamp lifts
                // it next tick. Measured on lv18 t=14,612 (mini cube lands on
                // 210-top blocks the same tick the RegularSize portal uid10479
                // fires): GD's row is y=219 (=210+9, the MINI seat) with the
                // box already 30x30 (pbox size=1.000, 6 px embedded), and only
                // t=14,613 shows 225. The same-tick re-seat (lv12 t=3286) had
                // s.grounded=1 -- the walk-in case -- and stays.
                // [2026-08-21 r69 -> retracted] The growth re-seat on the world
                // ground splits its tick by mode (calibration rig ceilramp's
                // unit boundaries measured: cube next tick, ball/UFO same
                // tick). Written as "next tick if on the ground", the UFO's
                // re-seat disappeared entirely (persisted at 99), so back to the
                // unconditional same tick. The cube's 1-tick 6px stays as a
                // known quirk of the rig's boundary band only (excluded from
                // scoring with calib_units --settle). OPEN: is the
                // discriminating axis the mode, or the kind of support.
                // Ground-grow (speed.hpp): on the world ground the lift is the ground clamp's,
                // next tick; only a player standing on an object is re-seated here.
                const bool growOnGround = (c.mode == 0 || c.mode == 2)
                                          && !c.flip
                                          && std::fabs((double)c.y - oldHalf - kGroundY) < 0.01;
                // Grow-away (speed.hpp): a body moving away from its floor is not re-seated
                const bool awayNoLift = (double)c.vy * (c.flip ? -1.0 : 1.0) > 0.0;
                // Multiple grow supports (speed.hpp, replacing Ball-grow-lag): the grown body is
                // lifted on this tick only when its pre-grow box stands on two or more solids --
                // counted as objects, overlapping ones too -- and otherwise by the next tick's
                // support, as on the world ground.
                // Counted where the body stood at the tick's start: a press on this tick has
                // already made c airborne by here.
                int growSupports = 0;
                if (newHalf > oldHalf && s.grounded) {
                    const double foot = (double)s.y + (c.flip ? oldHalf : -oldHalf);
                    for (const Obj* o : *K.near) {
                        if (o->type != 0 || o->dynObj) continue;
                        const double face = c.flip ? o->cy - o->hh : o->cy + o->hh;
                        if (std::fabs(face - foot) < 0.01
                            && std::fabs((double)x - o->cx) < o->hw + oldHalf)
                            ++growSupports;
                    }
                }
                const bool growLag = growSupports < 2;
                // Size-press (speed.hpp): a grounded press on this tick is the grown body's --
                // GD grows in the collision pass and jumps or taps in the buttons phase after it
                const bool growPress = pressAction && s.grounded
                                       && newHalf > oldHalf && (c.mode == 0 || c.mode == 2);
                if (growPress && c.mode == 0) {
                    // lifted first only on two or more supports (above); on one solid GD jumps
                    // from where it stands, 6 px into the solid
                    if (!growLag)
                        YSET(c.y) = (float)((double)s.y
                                      + (c.flip ? -1.0 : 1.0) * (newHalf - oldHalf));
                    const double j = cubePhysFor(useDx).jump
                                     * (c.mini ? (kCubeJumpMini / kCubeJump) : 1.0);
                    VYSET(c.vy) = (float)(c.flip ? -j : j);
                } else if (growPress) {
                    const double bTap = ballFlipFor(useDx) * (c.mini ? kMiniImpulse : 1.0);
                    VYSET(c.vy) = (float)(-bTap * (c.flip ? -1.0 : 1.0));
                } else if (s.grounded && c.grounded && newHalf > oldHalf && !growOnGround
                           && !awayNoLift && !growLag)
                    YSET(c.y) = (float)((double)c.y
                                  + (c.flip ? -1.0 : 1.0) * (newHalf - oldHalf));
            } else {
                const uint8_t oldMode = c.mode;
                c.mode = wantMode;
                // --portalpress: the new mode takes the press (undone above). A cube jumps, a
                // ball taps; a ship or wave holds, which the next tick reads from s.action.
                if (portalPressRedo) {
                    portalPressRedo = false;
                    if (wantMode == 0) {
                        const double j = cubePhysFor(useDx).jump
                                         * (c.mini ? (kCubeJumpMini / kCubeJump) : 1.0);
                        VYSET(c.vy) = (float)(c.flip ? -j : j);
                        c.grounded = 0;
                        c.pressSpent = 1;
                    } else if (wantMode == 2) {
                        c.flip = c.flip ? 0 : 1;
                        c.rotStep = (float)ballRotRate(c.mini != 0, true, useDx);
                        c.rotNeg = (uint8_t)!((c.flip != 0) ^ (c.rev != 0));
                        const double bTap = ballFlipFor(useDx) * (c.mini ? kMiniImpulse : 1.0);
                        VYSET(c.vy) = (float)(-bTap * (c.flip ? -1.0 : 1.0));
                        c.grounded = 0;
                        c.pressSpent = 1;
                        // This tap clears +0x985 like any other, so a button still held after it
                        // does not tap the ball again on a later landing (a custom level t=15,425: cube
                        // -> ball portal with the press, held to 15,526; GD sits on the ceiling
                        // at 15,494 without a second tap)
                        if (input) c.holdDead = 1;
                    } else if (wantMode == 3) {
                        // The portal flap: nothing this tick; the pending flap below fires on
                        // the next one, not the same-tick re-issue.
                        impulsedThisTick = false;
                    }
                }
                // [2026-09-05] A ROBOT or SPIDER portal zeroes the sprite
                // rotation, and the player then stands upright for the whole
                // section. GD does this the tick the portal fires: lv20
                // t=7,707->7,708 goes 171.335 -> 0.000 and t=11,979->11,980
                // goes 168.776 -> 0.000. Corpus-wide it is 11 sections over
                // lv19/20/21/22 -- 15,326 ticks, every single one exactly 0,
                // both modes, no exceptions. The model used to FREEZE instead
                // -- it has no writer of `rot` in either mode -- so it carried
                // the pre-portal value out the far side and every later
                // oriented test on the level ran 81.328 deg (then 88.774,
                // and up to 5,132 deg raw on lv21) out of phase.
                // The phase is what the SAT eats: at lv20's speed portal
                // uid8187 (rot 53) that made the player's projected radius
                // 9*(|cos 81.68|+|sin 81.68|) = 10.208 against GD's
                // 9*(|cos 0.347|+|sin 0.347|) = 9.054, and 1.15 px at
                // ~1.2 px/tick is exactly the 1 tick the portal fired early.
                // WHY THE ROTATION CENSUS CALLED THIS INNOCENT: rotrate scores
                // a mode by the SHARE of ticks whose rate disagrees, and this
                // defect is one tick per section -- 7 bad ticks for robot's 7
                // entries, over 11,181 ticks, = 0.1% and it read as innocent.
                // The instrument was not blind; it weighted a defect by its
                // FREQUENCY when what matters is whether the error PERSISTS. A
                // one-tick rate error that rewrites a base is permanent for the
                // rest of the level; one that is corrected next tick is not.
                // Nothing in a share column separates those two.
                // Entry-only is enough BECAUSE nothing writes `rot` in either
                // mode today (measured: all 15,326 ticks frozen). If a writer
                // is ever added, this has to become a per-tick pin instead.
                // `rotStep` is deliberately left alone: whether GD also clears
                // m_rotationSpeed here is unmeasured, and the corpus cannot
                // tell -- every section here leaves grounded, where the ball
                // re-stakes on its first tick down regardless.
                // [2026-09-05, second pass] The rule is not "which mode did we
                // enter" -- it is WHICH FLAG CHANGED ON WHICH EDGE. GD has one
                // toggler per mode flag and each writes setRotation
                // (PlayerObject vtable +0x150) asymmetrically:
                //   ship / UFO / wave   rising: 0        falling: 0
                //   swing               rising: 0        falling: flip?180:0
                //   robot / spider      rising: 0        falling: (nothing)
                //   ball                rising: (nothing) falling: flip?180:0
                // CUBE IS NOT A MODE -- it is "all seven flags down", so it has
                // no toggler and neither of its edges writes anything. The
                // chain per transition is: raise the destination flag ->
                // switchedToMode drops the old one (the old flag's FALLING edge
                // write) -> the destination's RISING edge write. Last write
                // wins. That is why entering ship/UFO/wave/swing/robot/spider
                // always ends at 0, and why only cube and ball have a landing
                // value that depends on where they came from.
                // Falsified on the way in, and worth keeping because both
                // mistakes were mine: (a) I scored lv22 t=4,635 swing->cube as
                // a PRESERVE because my predicate was |rot| < 5, but GD lands
                // on 178.269 = 180 - 1.731 with flip going 0->1 -- the swing's
                // falling edge writing 180, then resetPlayerIcon re-latching
                // the cube rate and updateRotation spending exactly one step in
                // the same physics step. It is a reset, to 180. (b) lv13
                // t=18,921 looked like a reset that ran a tick late; gdref
                // carries its OWN mode column and it reads `ball` there and
                // `cube` at 18,922, so the MODEL switches a tick early and the
                // late reset does not exist. Corpus-wide the two mode columns
                // disagree on 12 ticks out of ~400,000 (lv13 2, lv14 10).
                // MEASURABILITY, stated before running rather than after: the
                // only levels where any player-rotation change can show up are
                // lv20/21/22 -- a deliberate +5 deg on every consumer of pRot
                // left the other 19 byte-identical, and 5 deg is larger than
                // most of the entry errors this fixes. The five no-reset pairs
                // (cube->ball, robot/spider->ball, robot/spider->cube) are
                // worse than that: only cube->ball is even discriminable, since
                // the other four are entered with rot already 0. So this does
                // not "pass" the suite; the suite CANNOT SEE IT. Neutrality is
                // the expected result and the justification is the disassembly.
                // Ghidra printed 3 of the 8 setRotation call sites as taking no
                // argument when all 8 pass one, so the edge table above was read
                // from instruction bytes. Do not cite a decompiled argument
                // list as evidence for anything here.
                const bool wroteOnEntry = (c.mode != 0 && c.mode != 2);
                if (wroteOnEntry) {
                    c.rot = 0.f;
                } else if (oldMode == 1 || oldMode == 3 || oldMode == 4) {
                    c.rot = 0.f;                      // their falling edge: 0
                } else if (oldMode == 2 || oldMode == 7) {
                    c.rot = c.flip ? 180.f : 0.f;     // ball / swing falling
                }
                // oldMode 0/5/6 falling edge writes nothing: cube has no
                // toggler, robot and spider deliberately leave the angle alone.
                pHalfLive = (c.mode == 4 && c.mini)
                                ? kWaveContactHalfMini
                                : playerHalf(c.mode, c.mini != 0);
                // [2026-08-19 item 4 -> adopted in 2026-08-20 r32] **A mode
                // portal changes the box seen by later portals of the same
                // pass.** The 2026-08-19 version applied this to **all
                // portals** and fell at the acceptance gate (lv18 tracking
                // 19,927->19,801, quick_regress red). As the disassembly
                // (pHalfLive's note) says, **only rotated objects** re-call
                // getOrientedBox(), so r32 applies it only for `p->oriented` --
                // and that passed (families stay 23, lv18's max error
                // 28.359->6.498, lv19/lv20 tracking improved).
                // Grounds (measured lv18 t=20,466, mini wave, box 6x6 =
                // half 3.0): cube portal uid14052 (OBB 31x86, rot=51) fires, but
                // the size portal uid14055 (OBB 31x90) 1.8px to the right is
                // **3.095px short on the width axis, 22.798 vs 15.5+4.203**.
                // GD fires both on the same tick (the dump's mode/vsize are
                // same-tick, and pbox emits one 30x30 row at t=20,466). With
                // half=15 after becoming a cube it passes with +13.7 to spare.
                // Uniformly enlarging the half breaks down: "uid14052 must not
                // fire at 20,465" (r2 < 5.578) and "uid14055 must fire at
                // 20,466" (r2 >= 7.298) cannot both hold.
                // That a size portal does not change later boxes is measured at
                // lv19 t=20,309 (note above), so the only consistent reading is
                // "the box rebuild is done by the mode switch".
                // **Why the 2026-08-19 version was not taken** (applied to all
                // portals): census stays 27 but lv18's tracking drops
                // 19,927->19,801 (the t=13,800 section 400->274) and
                // quick_regress goes red. r32's oriented-only form shows no such
                // regression.
                // The rest of the acquisition was taken over by r33
                // (`slopepush`): once mini resolves on the same tick, it then
                // grabs ramp uid14050 (m=-2) on the far side of the **ridge**
                // and seats at 398.50 (GD is at the ridge 390+pH=405). It cannot
                // be solved unless the seat is "the **highest** face under the
                // box" -- a single ramp's rotated-box formula cannot handle a
                // ridge.
                if (c.mode == 1) c.grounded = 0;
                // [2026-08-19 D8] When a mode portal ends a ramp ride, the swing
                // **fires the ball-rate slope-exit launch as an assignment**
                // (the flying-end ladder does not run -- another face of the
                // same picture as srcFly's exclusion). Confirmed by worker98
                // injection at ride 2/4/6 ticks, all with post-vy = 2.762 =
                // exit(1) x 0.75 x clamp(ride/24 -> 0.4) x sp1.1 (measured
                // 2026-08-19; the old records' +2.240/+2.899 fit the same
                // formula at ride 14.4/18.7). Passing the same portal without
                // riding gives the normal ladder (0.408->0.161 measured), so the
                // gate is the ride itself.
                // The sign "follows the face" (same rule as acquire's +-2.000).
                if (oldMode == 7 && wantMode != 7 && s.onSlope) {
                    const double mTravP = (double)s.slopeM
                        * (((double)K.dxF < 0.0 || s.rev != 0) ? -1.0 : 1.0);
                    VYSET(c.vy) = (float)rawQ((mTravP >= 0.0 ? 1.0 : -1.0)   // speed.hpp
                                   * slopeExitVy(std::fabs((double)s.slopeM),
                                                 2, useDx, c.mini != 0)
                                   * slopeRampFactor((int)s.slopeT + 1));
                    c.grounded = 0;
                    c.onSlope = 0;
                    // [2026-08-21 r44] **This tick does not take the seat's
                    // step.** The ride puts y on the face, but GD leaves the
                    // tick a portal ends the ride on with a free step. Measured
                    // lv22 t=8,231 (flipped swing, rode the m=+1 ramp to ride3,
                    // passes spider portal uid8743, sp1.1, dx=1.6133):
                    //   t=8,230  both y=411.870 vy=2.258
                    //   t=8,231  GD    y=412.398 (+0.528 = 0.225x(2.258+0.086)
                    //                   = free integration one rung up the
                    //                   swing's ladder)
                    //            model y=413.485 (+1.615 = the ramp's step m*dx)
                    //   a parallel +1.087 remains after (census
                    //   `m7/mini0/g1/gdg0/gdm6/sp1.1/slope+1.00/ride3` edy -1.087)
                    // vy is decided separately by the formula above (2.762), so
                    // only y is restored.
                    YSET(c.y) = yFreeBeforeSlope;
                }
                // [2026-08-28] **...and the y half of that is not the swing's,
                // nor the slope ride's.** "GD leaves the tick a portal ends the
                // ride on with a free step" is a statement about being CARRIED,
                // and a ceiling ramp's push-down carries just as much as a seat
                // does. Measured on lv20 t=17,110 -- a UFO pressed down the
                // ceiling ramp chain at x=25,750, mode portal uid13881:
                //   t=17,109  GD and the model both y=297.5798, vy=-3.204
                //   t=17,110  GD    y=296.8395  (-0.7403 = 0.225 x (-3.204
                //                   - 0.086), the free UFO integration)
                //             model y=295.9665  (-1.6133 = the press's own
                //                   step, m*dx)
                // -- the same 1.087-shaped parallel offset the swing case
                // measured at lv22 t=8,231, and it is what puts the model's
                // second body 1.585 px clear of the slope GD kills it on
                // 5 ticks later (p2dead=1 at t=17,115, x=25,760.89).
                // The swing's vy assignment above stays swing-only: what is
                // measured twice is the POSITION, and the ceiling press has its
                // own release velocity (ceil/release) already.
                else if (oldMode != wantMode && s.ceilT > 0 && !s.onSlope)
                    YSET(c.y) = yFreeBeforeSlope;
                // A MODE portal that changes the resting half re-seats a
                // grounded player the same tick, exactly like the size portal
                // above (and by the same mechanism: the box GROWS into the
                // surface and is pushed out; shrinking has nothing to push
                // against). The only pair that differs is the spider's 13.5
                // against everyone else's 15. Measured on lv22, both
                // orientations of spider -> cube:
                //   t=1,168 upright on a floor: 223.5 -> 225.0 (+1.5) on the
                //           portal tick, vy 0, grounded stays 1
                //   t=8,759 flipped under a ceiling at 840: 826.5 -> 825.0
                //           (-1.5) on the portal tick
                // The model kept the old y and ran one tick late out of both
                // (fixcensus edy = +1.5 / -1.5 exactly, clamp:fly/land).
                // Placed after the ship's grounded=0 so flying destinations
                // are excluded automatically.
                {
                    const double oh = playerHalf(oldMode, c.mini != 0);
                    const double nh = playerHalf(c.mode, c.mini != 0);
                    if (c.grounded && nh > oh)
                        YSET(c.y) = (float)((double)c.y
                                      + (c.flip ? -1.0 : 1.0) * (nh - oh));
                    // [2026-08-19] Even in the air, if the grown box penetrates a
                    // floor ramp's face it seats on the same tick -- the rest of
                    // the collision pass resolves the face with the new body.
                    // The seating formula is the rider's own "sample the line at
                    // the rotated box's lowest point" (slopeXOffset): measured
                    // lv21 t=18,087 (mini wave -> mini UFO, sliding on the
                    // sdir=4 m=-2 floor ramp): on the firing tick GD does
                    // y 217.006 -> 222.269, vy=0, g=1, matching
                    // line(x-5.562)+9 = 222.26 exactly (= line+9*sqrt(5)).
                    // The model kept the wave's step and seated by itself the
                    // next tick, and the 1-tick edy +8.49 remained as the census
                    // m4/mini1/gdg1/gdm3 family. The gate is "centre above the
                    // line, below the seat" plus non-flipped floor side, not
                    // spiked. The flipped side and ceiling ramps are unmeasured
                    // and untouched.
                    // ...and **a uid gate** (same as the teleport's teleUid): a
                    // ramp processed before the portal was judged with the old
                    // body, so it does not seat on the same tick. Measured pair:
                    //   lv21 t=18,087  slope 24198 > portal 24194 -> same tick
                    //   lv18 t=12,243  slope  8273 < portal  8326 -> next tick
                    //     (GD: the firing tick stays y 269.14 vy -3.229 g=0, and
                    //      it seats at 12,244 at y 278.985 = line+15*sqrt(2).
                    //      Without the gate, census lv18's t=12,200 section
                    //      shrank 50->43 -- only the model seated 1 tick early)
                    else if (!c.grounded && !c.flip && nh > oh && K.slopes) {
                        for (const Obj* sp : *K.slopes) {
                            if (sp->uid < p->uid) continue;
                            if (sp->slopeHazard) continue;
                            if (slopeIsCeiling(sp->slopeDir)) continue;
                            const double sx0 = sp->cx - sp->hw;
                            const double sx1 = sp->cx + sp->hw;
                            if (x < sx0 || x > sx1) continue;
                            const double sm =
                                (sp->sy1 - sp->sy0) / (sx1 - sx0);
                            const double line = sp->sy0 + sm * (x - sx0);
                            const double r = x + (sm > 0
                                ? slopeXOffset(sm, nh)
                                : -slopeXOffset(sm, nh));
                            const double seat =
                                sp->sy0
                                + sm * (std::min(std::max(r, sx0), sx1) - sx0)
                                + nh;
                            if ((double)c.y < line) continue;  // centre below the line
                            if ((double)c.y >= seat) continue; // not touching
                            // --slopedbg: does this branch still fire? Its two
                            // witnesses (8396-8397) are ticks in another repo's
                            // base and cannot be located in today's gdref, so
                            // "how often" has to be asked rather than assumed.
                            if (g_slopeDbg)
                                std::printf("rampseat t=%lld uid=%d portal=%d "
                                            "y=%.4f seat=%.4f nh=%.2f oh=%.2f\n",
                                            (long long)K.t, sp->uid, p->uid,
                                            (double)c.y, seat, nh, oh);
                            YSET(c.y) = (float)seat;
                            VYSET(c.vy) = 0.f;
                            c.grounded = 1;
                            break;
                        }
                    }
                    // [2026-09-05] THIS RAMP BRANCH FIRES ZERO TIMES on today's
                    // 22 levels (counted with the print above). Its two witnesses
                    // are ticks in the approx repo's base (e24f1c7) and cannot be
                    // located in today's gdref -- neither lv18 nor lv21 has a
                    // single mode change with onGround 0->1 any more. Left in
                    // place as UNVERIFIED rather than deleted: unwitnessed is not
                    // refuted, and the uid gate below it is the only record of
                    // that measurement.
                // [2026-09-05] ...and the case where the box does NOT grow.
                // `playerHalf` gives wave and spider their own halves and sends
                // everything else -- ship AND cube -- to kCubeHalf, so a
                // ship->cube portal has nh == oh and the branch above cannot
                // reach it. The difference there is not the box, it is WHICH
                // BODY collides: GD's solid pass runs after the activation pass
                // with the new body, and a cube stops on a flat face the ship
                // flew through.
                // Measured, lv11 t=15,506 (hook 15,505, hitboxtrace):
                //   t=15,497..15,504  obj 3870, the SAME 30x30 player rect
                //                     overlapping the block by ~9px, hit=0
                //   t=15,505          hit=1, ppre y 170.71 -> player y 180.00
                //                     (centre 185.71 -> 195.000 = GD's y)
                // Geometry continuous, only the mode changed, and the 9.29px
                // lift is the whole of the family's dy -9.294.
                // WHY EVERY MODE. This first read line 1521's selector as "which
                // bodies collide with flat solids" and excluded the flight modes
                // on the strength of it. That was wrong twice over: 1521 answers
                // only "which bodies use the landing loop at 2708", the flight
                // modes seat through their own branch at 4045, and GD's UFO
                // plainly rests on a floor -- lv17 t=15,730, where GD sits at
                // y=195.000 (the 180 face plus the UFO's 15) on the portal tick
                // while the model falls past 6.719px inside it.
                // What 1521 does explain is the CAUSE: it selects on the mode
                // ENTERING the tick, so a body that changes mid-tick reaches
                // neither landing path, whichever one it would have used.
                // So the seat runs for any new mode, and what varies is the
                // slack -- see below.
                // This is a compensation for the activation -> solid inversion,
                // the fourth fossil of the same hole (the ramp branch above,
                // `releasePin(undoSnap)`, and the teleport-only portal pass at
                // the orb loop). Reordering the passes is a separate campaign.
                // ...and the predicate is the WHOLE of the new mode's landing
                // test, velocity gate included -- `vpNow <= 0` at the landing
                // loop's own line 2884, i.e. the body has to be moving toward
                // the face. Leaving that out is not a near miss: the geometry
                // alone fires 11 times on the corpus and GD seats on exactly
                // one of them, and the split is clean with nothing near the
                // boundary --
                //   GD seats      lv11 t=15,506   vy -0.2065   (falling)
                //   GD does not   the other 10    vy +0.0015 .. +3.1985
                // lv8 t=9,966 is the tight one: +0.0015 above zero and GD
                // still does not seat, so `<= 0` is the boundary the loop
                // already uses and not a value fitted here.
                // The slack GD widens the previous edge by is 10.0f (0x62307C)
                // except for the modes in the [+0x9bb] set, which take 6.0f
                // (0x391c48). The disassembly names that set "ship / bird / dart
                // / swing / ball" -- ufo, wave and the ball included.
                // BALL IS DELIBERATELY LEFT ON 10.0 HERE. It belongs in GD's 6.0
                // set, and the model runs it through the 2708 loop's kLandTol
                // instead, but that is a pre-existing disagreement of its own
                // with its own acceptance; folding it in would put two variables
                // in one regression.
                const bool flySlack = (c.mode == 1 || c.mode == 3
                                       || c.mode == 4 || c.mode == 7);
                const double seatSlack = flySlack ? kShipLandTol : kLandTol;
                if (!c.grounded && K.near
                    && (double)c.vy * (c.flip ? -1.0 : 1.0) <= 0.0) {
                    const double gs = c.flip ? -1.0 : 1.0;
                    const Obj* best = nullptr;
                    double bestFace = 0.0;
                    for (const Obj* o : *K.near) {
                        if (o->type != 0 || o->slope || o->oneway
                            || o->oriented)
                            continue;
                        if (std::fabs(x - o->cx) > o->hw + nh + kContactEps)
                            continue;
                        const double face =
                            c.flip ? (o->cy - o->hh) : (o->cy + o->hh);
                        // GD's own test, not an analogy to one. collidedWithObject
                        // carries TWO edge sets: the current rect (the `ppre` on
                        // an hbox line) and a previous one it builds as the
                        // current edge minus the position delta
                        // (getPosition().y - [this+0x4d4], 0x391e8e-0x391f48).
                        // For a body whose half just changed, that previous edge
                        // is the NEW body's foot displaced back a tick, which is
                        // exactly `s.y - gs*nh` -- so both edges use nh and
                        // neither uses the old mode's half.
                        // The previous edge is then widened by a slack (xmm8):
                        // 10.0f at 0x62307C, and 6.0f at 0x391c48 for the modes
                        // in the [+0x9bb] set. There is NO minimum-overlap
                        // threshold anywhere in the function, so the depth is
                        // bounded only through that slack, and the direction is
                        // decided by the velocity sign gate at 0x392a60-6e.
                        // (This replaced a bound on the CURRENT foot's
                        // penetration. That form was not GD's: it is the overlap
                        // term alone, missing the widened previous edge.)
                        const double prevFoot =
                            ((double)s.y - gs * nh - face) * gs;
                        const double curFoot =
                            ((double)c.y - gs * nh - face) * gs;
                        if (prevFoot < -seatSlack || curFoot > 0.0) continue;
                        if (!best || (face - bestFace) * gs > 0.0) {
                            best = o;
                            bestFace = face;
                        }
                    }
                    if (best) {
                        if (g_slopeDbg)
                            std::printf("portalseat t=%lld uid=%d portal=%d "
                                        "old=%d new=%d y=%.4f -> %.4f "
                                        "vy=%.4f gs=%.0f flip=%d\n",
                                        (long long)K.t, best->uid, p->uid,
                                        (int)oldMode, (int)c.mode,
                                        (double)c.y, bestFace + gs * nh,
                                        (double)c.vy, gs, (int)c.flip);
                        YSET(c.y) = (float)(bestFace + gs * nh);
                        VYSET(c.vy) = 0.f;
                        c.grounded = 1;
                    }
                    }
                }   // oh / nh scope
                // (Entering the SWING halves vy. That used to be a special case
                // right here, one-directional; it is now the flying-ends ladder
                // above, which also covers LEAVING one -- see the swing note by
                // `srcFly`. Keeping both halved twice: lv22 t=3,323 came out at
                // 0.689 instead of GD's 1.379.)
                // The impulse belongs to the NEW mode (see impulsedThisTick).
                // Re-issue it here, unhalved, because GD's buttons run after
                // the collision pass that changed the mode.
                if (impulsedThisTick && oldMode != c.mode) {
                    const double sgn = c.flip ? -1.0 : 1.0;
                    const double ms = c.mini ? kMiniImpulse : 1.0;
                    // ...BUT THE NEW MODE'S OWN PRECONDITION STILL APPLIES.
                    // A cube jumps from the ground and nowhere else, and
                    // re-issuing the press in its body does not change that.
                    // Measured on calib_portalpress' air cells (2026-09-15),
                    // both controls alive so the silence is a reading and not a
                    // dead cell:
                    //   ufo->cube, airborne at the portal
                    //     -12 old body   UFO flaps in the air        6.871
                    //      -1 / 0        NOTHING -- vy just takes the
                    //                    portal's step and then cube gravity
                    //     +12 new body   airborne cube, no effect
                    //   cube->ufo, airborne
                    //     -12 old body   airborne cube, no effect
                    //      -1 / 0        UFO flaps                   6.871
                    //     +12 new body   UFO flaps                   6.871
                    // so the UFO's flap needs no ground and the cube's jump
                    // does. Without this gate the model hands the DP a jump
                    // from mid-air: lv21 t=18,619 is a cube arriving at the
                    // portal off a ramp, where the model left with 9.136 --
                    // exactly its own mini cube jump, 11.420 * 8.944/11.180 --
                    // and GD left with 3.324. That one phantom step cost 37 of
                    // that level's 44 cold rounds, all on the same wall.
                    // The `-> ball` case below has always done this by
                    // omission ("a ball tap only acts while ROLLING").
                    if ((c.mode == 0 || c.mode == 5) && !c.grounded) {
                        // nothing: the body that now owns the press cannot use
                        // it here
                    } else if (c.mode == 0 || c.mode == 5) {  // -> cube / robot: a jump
                        const CubePhys jph = cubePhysFor(useDx);
                        VYSET(c.vy) = (float)(jph.jump * (c.mini ? (kCubeJumpMini / kCubeJump) : 1.0)
                                       * (c.mode == 5 ? kRobotJumpScale : 1.0)
                                       * sgn);
                        c.grounded = 0;
                        // the hover budget belongs to the jump, not to the mode
                        if (c.mode == 5) c.rHover = (uint8_t)kRobotHoverTicks;
                    } else if (c.mode == 3) {   // -> UFO: a flap
                        // The same raise-to-target the flap itself is (see
                        // UfoModel::stepVy): the re-issue cannot SLOW a UFO
                        // that leaves the portal climbing faster than the flap
                        // would have taken it. The tick's gravity has already
                        // run here, so both sides of the test are post-gravity.
                        const double fp =
                            (c.mini ? gdapprox::UfoParams::mini()
                                    : gdapprox::UfoParams::normal()).flapPostVy();
                        if ((double)c.vy * sgn < fp) VYSET(c.vy) = (float)(fp * sgn);
                        c.grounded = 0;
                    }
                    // -> ball: NO re-issue. A ball tap only acts while
                    // ROLLING, and a player leaving a portal is airborne.
                }
                // ship->UFO, the case where a fresh edge on the portal tick is
                // eaten by the old mode (thrust = the edge is not consumed).
                // There is no impulse, so it does not ride the re-issue above.
                // GD buffers it and emits the flap on the **next tick** (lv19
                // t=13,892: both agree at vy=-1.573 -> 13,893 GD alone +6.871).
                // Carried in a 1-tick-lifetime pending.
                {
                    // [2026-08-20] Neither ship-only nor fresh-edge-only. lv19
                    // t=19,491 is **wave->UFO**, with the button held since
                    // t=19,484 (not a fresh edge), yet GD emits a +6.648 flap
                    // the next tick. The same happens whenever the old mode is a
                    // kind that does not consume the edge (the ship's thrust,
                    // the wave's steering).
                    // --shipheldflap: the ship does not consume the press
                    // either (note in constants.hpp), so a held one counts --
                    // unless something already spent it (pressSpent: a cube's
                    // jump before the ship portal leaves +0x986 at 0 in GD).
                    // The portal flap: a cube's fresh press, grounded (its jump undone above)
                    // or airborne (nothing to undo).
                    if (!impulsedThisTick && c.mode == 3 && input
                        && ((oldMode == 1
                             && (!s.action || !s.pressSpent))
                            || (oldMode == 4
                                && !s.pressSpent)
                            || (oldMode == 0 && !s.action)))
                        c.pFlap = 1;
                    // The old branch flipped the player and set the flip
                    // impulse right at the portal: measured on lv16's second
                    // dual (UFO -> ball at (19193,543), press on the portal
                    // tick), GD comes out UPRIGHT at (5.888-0.152)*0.5 while
                    // the model came out flipped at +2.683 and climbed away
                    // at +0.129/tick.
                }
            }
        }
    }
    };  // runPortalPass
    runPortalPass(0);                              // teleports only
    if (!teleportedThisTick) runPortalPass(1);     // no jump -> as before
    // --portalceil (speed.hpp): a ground body that a mode portal made a flying one this tick meets
    // the ceilings as the flying body -- the flight loop's ceiling ride, run once for the new body
    if (!dead && s.frame == 0
        && (s.mode == 0 || s.mode == 2 || s.mode == 5 || s.mode == 6)
        && (c.mode == 1 || c.mode == 3 || c.mode == 4 || c.mode == 7)) {
        const double pH = playerHalf(c.mode, c.mini != 0);
        const double gs = c.flip ? -1.0 : 1.0;
        for (const Obj* o : *K.near) {
            if (o->type != 0 || o->slope || o->oneway || o->oriented) continue;
            if (std::fabs(x - o->cx) >= o->hw + pH) continue;
            const double head = c.flip ? (o->cy + o->hh) : (o->cy - o->hh);
            const double prevHeadP = ((double)s.y + gs * pH - head) * gs;
            const double newHeadP = ((double)c.y + gs * pH - head) * gs;
            if ((double)c.vy * gs >= 0.0 && prevHeadP <= kShipLandTol && newHeadP >= 0.0) {
                YSET(c.y) = (float)(head - gs * pH);
                VYSET(c.vy) = 0;
                CLAMP0O("portal/ceil", o);
                break;
            }
        }
    }
    // Pads fire ONCE PER CONTACT, like orbs. The guard used to be a one-tick
    // lockout (padCd), so a pad the player was still overlapping fired again
    // every OTHER tick: measured on lv6, the pad at t=14175 re-fired at t=14177,
    // 14179, 14181... each time resetting vy to the pad value, which pinned the
    // model at terminal velocity while GD decayed normally. That single
    // difference is what put the model 260 px away from GD by t=14355. The
    // per-object memory below (usedPad, mirroring GD's touched list) covers that
    // case exactly, and the tick lockout is GONE: it was global, and GD fires a
    // DIFFERENT pad on the very next tick. Measured on lv13, where pad (1395,150)
    // fires at t=1053 and pad (1395,152) at t=1054 -- GD holds vy at exactly
    // 16.000 for both ticks instead of decaying to 15.784.
    // There is NO side test. There used to be one -- "the pad's centre has to be
    // inside the player's box", i.e. (player y - pad cy) > -pHalf -- fitted to
    // eleven firing observations (+13.00 .. +16.98 on lv2/3/5/6/7/9, and
    // -1.07/-2.87/-4.89/-10.29 on lv12) against lv10's non-firing case at -17.6.
    // lv13 t=1053 falsifies it: the player is at y=134.237 under the mid-air pad
    // at (1395,150), i.e. (player y - pad cy) = -15.76 with the pad's centre
    // 0.76 px ABOVE the player's top edge, and GD sets vy = 16.000 anyway.
    // Plain box overlap (the test on the line below) accounts for all twelve
    // firing observations AND for lv10's silence: that pad's box never overlaps
    // the swept player either (-17.6 is outside hh + pHalf = 17), so it was
    // never evidence for a side rule in the first place. The gravity direction
    // still decides which way the pad THROWS the player, not whether it fires.
    // ...and the GRAVITY pad's flip is IDEMPOTENT WITHIN A TICK. Every pad the
    // player overlaps is still consumed on the tick it is entered (see lv13
    // below), but two gravity pads entered together produce ONE flip, not two.
    //
    // Measured on lv21 (2026-08-10): blue pads at (9405,213) and (9435,213), both
    // rot=0, boxes 25x6. The player falls at terminal -15 and its box bottom
    // crosses their top edge (216) on t=7250, entering BOTH at once. Injecting
    // GD's own t=7249 state and stepping:
    //   GD     t=7250..7253  vy = +6.400 +6.616 +6.832 +7.048   up 0 -> 1
    //   model  t=7250..7253  vy = -6.400 -6.616 -6.832 -7.048   flip unchanged
    // An exact mirror: the magnitudes agree tick for tick, so the constant and the
    // timing were never wrong -- the model toggled twice and cancelled.
    // The driver could not repair this either. A fixup carries dy/dvy and CANNOT
    // carry `flip`, so it patched vy on one tick, diverged again on the next, and
    // re-recorded one tick earlier every iteration (t=7257 -> 7250 across 40
    // iterations) -- the "fixup grind = missing rule" signature.
    //
    // NOT "one pad per tick": lv13's yellow pads at (1395,150) and (1395,152) are
    // both inside the player's box from t=1053, and GD's own reference decays to
    // 15.784 on t=1054 -- i.e. GD consumed BOTH on t=1053 and had none left. (The
    // comment above this loop claimed GD held 16.000 for both ticks; the recorded
    // reference says otherwise. Deferring the second pad to t=1054 re-fires it and
    // takes lv13 from bit-identical to 61/400 ticks of follow.)
    // So consumption is per-pad and unconditional; only the flip is collapsed.
    // This is what a SET (gravity := the pad's own direction) looks like from the
    // outside whenever the pads agree, and it leaves every single-pad measurement
    // -- lv11 t=4722, lv12 t=18838, lv14 t=7030 -- reading exactly as before.
    bool gravPadFlipped = false;
    // --padthenland (speed.hpp): the landing as the collision loops left it, for the solid pass
    // that GD runs after the pads
    const bool landedBeforePads = landedThisTick || pinnedOnBlock;
    const bool cubeLandedBeforePads = cubeLandedThisTick;
    const float yBeforePads = c.y;
    const uint8_t flipBeforePads = c.flip;
    bool padFiredNow = false;
    // --gravpadchain (speed.hpp): GD's order, uid ascending, and every gravity pad the gate
    // lets through flips. K.pads comes sorted by x.
    std::vector<const Obj*> padsByUid(K.pads->begin(), K.pads->end());
    std::stable_sort(padsByUid.begin(), padsByUid.end(),
                     [](const Obj* a, const Obj* b) { return a->uid < b->uid; });
    for (const Obj* pd : padsByUid) {
        if (spiderWarpedThisTick) break;
        // The landing site follows uid order (measurements at teleUid's
        // declaration). A pad processed before the teleport was judged at the
        // old position, so it does not fire on the landing tick.
        if (teleportedThisTick && pd->uid < teleUid) continue;
        // --padsection (speed.hpp): with a size portal fired this tick, the size this pad is judged
        // and launched with is the one GD had when its collision pass reached it
        double padHalf = pHalf;
        uint8_t padMini = c.mini;
        if (sizeFiredThisTick) {
            padMini = gdCollidesAfter(*pd, sizeFiredCx, sizeFiredCy, sizeFiredUid) ? c.mini
                                                                                  : sizePreMini;
            padHalf = playerHalf(s.mode, padMini != 0);
        }
        // counted even when merely nearby (diagnosing missed collisions)
        // -- the landing site's contact counts from the next tick (type 28)
        // count the vicinity first (same reason as g_nearOrb -- diagnosing missed impulses)
        if (std::fabs(x - pd->cx) < pd->hw + pHalf + kPadReach + 30.0
            && std::fabs((double)c.y - pd->cy) < pd->hh + pHalf + 30.0)
            g_nearOrb = 1;
        if (std::fabs(x - pd->cx) >= pd->hw + padHalf + kPadReach) continue;
        if (std::fabs((double)c.y - pd->cy) >= pd->hh + padHalf) continue;
        // ...and **a rotated pad is judged with its rotated box**. Portals and
        // orbs already go through orientedHit, but only pads still used the
        // bounding rect. A thin pad (w0 x h0 = 25 x 4) rotated 29 degrees swells
        // its bounding rect to 34.5 x 22.6, firing 10px+ early in y.
        // Measured (lv20, id35 uid7030 (10835.9,133.5) rot=29):
        //   GD fires at dump t=7,286, player (10837.866,153.314) (|ly| = 18.28)
        //   the model fired at t=7,283, player (10832.016,159.151)
        //   (|ly| = 24.32, outside the rotated box's threshold ohh + r = 22.39)
        // The bounding rect is stage 1 of GD's own two-stage test, so the two
        // lines above stay.
        // The player's rotation is passed too, AS IT STANDS: `s.rot` is the end
        // of the previous tick and that is what the gate is given. An
        // axis-aligned projection (pRot=0) is 1 tick early: on uid7030 above,
        // |ly|=19.08 passes against the threshold 22.39.
        //
        // [2026-09-06] THE ONE-STEP ADVANCE THAT USED TO SIT HERE IS DELETED --
        // `--no-satrotraw` puts it back, and constants.hpp carries the whole
        // measurement. In one line: it read
        //     pRotPad += (s.rotNeg ? 1.0 : -1.0) * (s.mini ? 2.25 : 1.7307692);
        // while the cube's rotation law 1,100 lines below writes
        //     c.rot += (spinSign ? -rate : rate),  spinSign = s.rotNeg
        // -- the same field with the opposite mapping, so the advance subtracted
        // the step the law was about to add and the SAT was handed an angle TWO
        // steps off GD's (38.166 against 34.681 on lv20 t=7,296, the +3.484 the
        // paragraph below used to end on).
        double pRotPad = (double)s.rot;
        if (g_noSatRotRaw && s.mode == 0)
            pRotPad += (s.rotNeg ? 1.0 : -1.0) * (s.mini ? 2.25 : 1.7307692);
        // [2026-09-06 morning, RETRACTED THE SAME DAY -- kept because the
        // evidence for it was real and the next reader will meet it again]
        // "...but the PLAYER's half of that test is AXIS-ALIGNED", on the
        // strength of the `ccl:` instrument, which prints the very rect GD hands
        // the activation and on lv20 uid 7030 (rot 29) reads
        //     prect=(10822.8096,138.3140,30.0000,30.0000)
        // -- an axis-aligned 30 x 30. The rect is real; the inference is not.
        // That rect is the AABB CONJUNCT (`player->getObjectRect()`, taken once
        // at 0x2149b8, before the object loop). The SAT two lines later builds a
        // SECOND shape from the same player -- `PlayerObject::getOrientedBox`
        // (0x3a0650) at 0x214ba1 -- and that one is turned by
        // `player->getRotation()`. It reads 30 x 30 in `prect` for the same
        // reason it always will: `getOrientedBox` is an override that, unlike
        // GameObject's, never sets the player's own `m_isOriented`, so
        // `getObjectRect()` stays the plain centred rect however the cube spins.
        // AN INSTRUMENT THAT PRINTS ONLY THE RECT CANNOT SEE THE ROTATION.
        //
        // GD's gate is BOTH conjuncts (RVAs and the full chain at
        // g_noPadPlayerRot in constants.hpp):
        //   AABB( player rect ) n AABB( obj->getObjectRect() )  0x214b09-0x214b56
        //   and, when the object is m_isOriented, the two-way SAT of the two
        //   OBBs                              0x214b5e / 0x214bb0 / 0x214bbf
        // The two lines above ARE the first conjunct: `pd->hw,hh` is objrects'
        // getObjectRect, which for an oriented object is getBoundingRect of its
        // OBB (0x1978a2) -- and `ohw*|rc| + ohh*|rs|` reproduces it exactly
        // (17.2588 / 11.3236 for lv20's boards). So the AABB half is present and
        // stays; what changes below is only the angle the SAT half is given.
        //
        // The board's own shape is measured three ways on the padedge rig
        // (data/rigs/padedge*.units.json, 2026-09-06; 78 units / 234 objects,
        // nodeath, 0 deaths, and a second arm of 110 units for the sign):
        //   rot=0 arms validate the method -- the boundary is the plain rect
        //     inflated by the player half, and all three arms (scale 1.00 /
        //     1.45 / 1.45-mini) land on their predicted intercepts;
        //   rot=29: the firing x follows the height offset at slope
        //     cot 29 = 1.804 (an AABB gives 0), and the flat-to-sloped break is
        //     where the OBB's leading corner (-17.258, -6.251) leaves the
        //     player's y band -- dy = 8.749 full / 2.749 mini, i.e. `dy - h <=
        //     -6.251`, DERIVED and matching the sweep on both sizes. Reach =
        //     corner height + player half = 26.32 / 20.32;
        //   rot=-29 mirrors it: the corner moves to (-17.258, +6.251), the flat
        //     region widens, and the residual slope becomes tan 29 = 0.554,
        //     never cot -- so the sign of GD's rotation is fixed too.
        // Activation carries no tick lag of its own: 39 rig samples at two
        // speeds put residual/x-step uniformly in [0,1).
        //
        // Type 8 only -- that is the family the rig swept, and it is also the
        // whole rotated population: of the corpus's 239 type-8 pads exactly 6
        // are turned off a quarter turn (lv20 uid 6963/6964/7025/7026/7027/7030,
        // all rot 29), and no type 9/10/34 pad is. `oriented` is only set off a
        // quarter turn (level_loader.hpp:824), so at 0/90 the recorded rect IS
        // the box and this line cannot move a single digit. Scoping it to type 8
        // is also what keeps the ~40 rotated PORTALS of the corpus out of this:
        // their fire ticks already agree with GD and nothing here touches them.
        //
        // TWO ARMS (a third, --no-padobb for the raw angle with no mode gate,
        // is gone since the flag clean-up):
        //   (default)                the player's real rotation, mode-gated
        //   --no-padplayerrot        the axis-aligned square (a874728)
        if (pd->type == 8) {
            if (g_noPadPlayerRot) pRotPad = 0.0;
            else if (!padPlayerRotMode(s.mode)) pRotPad = 0.0;
        }
        // WHAT THIS DOES AND DOES NOT FIX, stated where the next reader will
        // look. lv20's whole-run first divergence is uid 7030 firing early
        // against GD's 7,299. The turned square refuses that contact on 7,296
        // and 7,297 and takes it on 7,298, so the divergence moves 7,296 ->
        // 7,298 (179 -> 176 divergent ticks). ONE tick early is what is left.
        //
        // [2026-09-06, rebased onto 05c3a5d] Written first against ec948e9,
        // where this paragraph read "it STAYS at 7,296" -- true there, false
        // here, and the difference is 351f9de. That commit turns a pad's
        // same-tick spin toward the gravity its call saw, and on this pad it
        // moves the model's cube angle at 7,295 from 39.90 deg mod 90 (6.9 deg
        // of error, enough to carry the turned square over a 2.9 px-thick
        // board anyway) to 36.43 against GD's 36.41. This rule needs a right
        // angle to feed it; on its own it changed nothing at all.
        //
        // The last tick was a THIRD quantity, not the shape and not `rot`: the
        // model's rot column tracks GD's to 0.023 deg through 7,292..7,297, and
        // it was the one-step advance above -- moving the OPPOSITE way to the
        // column's own step -- that put the SAT's angle two steps ahead of GD's.
        // [2026-09-06] That leaf is now taken: the advance is deleted and this
        // pad fires at 7,299, which is GD's own tick. lv20's first divergence
        // moves off it; the level still dies later (fixcensus lists four other
        // lv20 divergences), so this is one tick, not the level.
        if (pd->oriented && !orientedHit(*pd, x, (double)c.y, padHalf, pRotPad))
            continue;
        // NO FOOT-SIDE TEST (2026-08-07). The rule below was live for four days
        // and is falsified by two of the verified replays -- plain runs, not
        // injections, which is the stronger kind of evidence:
        //   lv13 t=1053  upright cube FALLING at -6.316, pads (1395,152) and
        //                (1395,150) with rot 0, player centre y=147.355 i.e.
        //                BOTH pads above it. GD sets vy = 16.000; the model
        //                skipped them and died 165 ticks later.
        //   lv14 t=7030  flipped cube grounded at y=735 under the solid whose
        //                underside is 750, blue pad (9165,733) with rot -180
        //                BELOW its centre. GD flips it and leaves at -6.400
        //                (= kPadBlueVy); the model sat there to the end.
        // Both are the tick the x-boxes FIRST overlap (lv13: player right edge
        // 1383.76 vs pad left edge 1382.5, 1.26 px in), which `usedPad` below
        // already models. The lv18 reading that motivated the side test came
        // from an INJECTED state placed inside the pad's x range, where there
        // is no entry to see -- see the block above this loop, which had
        // already concluded from twelve observations that plain box overlap
        // explains everything.
        //
        // (kept for the record) the rule that was here: a pad hung under a
        // ceiling belongs to a flipped player and an upright one cannot step on
        // it from below. Measured on lv18: the pad at (9,015,297) sits on the
        // underside of the solid at (9,015,315); injecting an upright cube at
        // y=290.5 anywhere inside the pad's box (x=8,988.6 and x=9,004.1 both
        // tried) leaves GD falling at -0.432, i.e. NO fire, while the model
        // fired at x=8,988.56 and planned a route GD could not follow.
        // `s.flip` and NOT `c.flip`: the contact belongs to the body as it was
        // when it touched the pad, the same rule the mode portals follow (see
        // pHalf). A ball that TAPS on the contact tick has already had c.flip
        // toggled by the time this runs, and the pad below (which the tap is
        // undone for, three lines down) then looks like it is on the head side.
        // Measured on lv9 t=16,254: the ball rests on the ceiling at y=255
        // under the yellow pad at (21,135,268), taps, and GD leaves at
        // vy = -9.600 (the ball's pad value) while the model left at -3.354
        // (the tap) and died 90 px later. With c.flip here lv9 goes from
        // CLEARED to STUCK at x=21,225 -- the whole 17-level regression's only
        // red, and it stayed red for a session because this rule landed
        // unverified.
        // (the `s.flip` note above is about WHICH flip the removed test read; the
        // tap-undo on the next line, which is what actually fixed lv9 t=16,254,
        // is independent of it and stays.)
        // The blue (gravity) pad **fires only when gravity actually changes**.
        // What GJBaseGameLayer::collisionCheckObjects (2.2081 win 0x2158f9) does
        // right after seeing this pad:
        //
        //   f = player->m_isSideways ? !obj->isFacingLeft() : !obj->isFacingDown()
        //   if (player->m_isUpsideDown == f) -> skip this pad (do not activate)
        //   ... propellPlayer(0.8, noFx, 10);  flipGravity(player, f, true)
        //
        // The gravity the pad installs is f = !isFacingDown, so the gate is
        // "current gravity == isFacingDown" = "that flip would not be a no-op".
        //
        // Verified against GD's own padact: lines (cfg padtrace=1,
        // activatedByPlayer). On all 94 gravity pads of
        // lv2/3/10/11/12/13/14/15/16 not only whether it fires but **the firing
        // tick** matches (scratchpad/padgate.py).
        // This also explains the observation that was added on 2026-08-07 as
        // the "foot-side test" and removed after lv13 t=1053 and lv14 t=7030
        // refuted it -- an upright cube entering lv18's (9,015,297) ceiling pad
        // from below does not fire.
        // That one was never a geometric rule -- it was this (up=0 against
        // fdown=1).
        //
        // The gate is re-evaluated **per object, with the gravity of that
        // moment**. lv14 t=13,428 is a tick entering 2 same-facing blue pads
        // 30px apart at once; GD fires only uid 4985, seen first, and by the
        // time gravity has changed, uid 4997 is rejected by the gate. What
        // gravPadFlipped below was holding down empirically is this phenomenon;
        // with the gate in, the 2nd pad never fires in the first place.
        //
        // A rotated section (m_isSideways) uses the isFacingLeft side, but id 67
        // exists only in lv2-21 and lv22 (the only rotated level) has none, so
        // it is not mirrored here. Implement this when a level with blue pads in
        // a rotated section arrives.
        if (pd->type == 10) {
            // A ball already flipped by its tap is judged with the value after
            // the rewind below (GD's tick order is update -> collisions ->
            // buttons, so the collision side sees the pre-press gravity).
            const bool upNow = ballFlippedThisTick ? (s.flip != 0)
                                                   : (c.flip != 0);
            if (upNow != objFacingDown(*pd)) continue;
        }
        // the pad wins over the tap: undo the flip before applying it
        if (ballFlippedThisTick) { c.flip = s.flip; ballFlippedThisTick = false; }
        bool already = false;
        int slot = -1;
        for (int i = 0; i < 4; ++i) {
            if (c.usedPad[i] == pd) { already = true; break; }
            if (!c.usedPad[i] && slot < 0) slot = i;
        }
        if (already) continue;   // already used, still inside it
        // No free slot means four pads overlap this player at once, which no
        // level does. Firing anyway would be the ratchet all over again, so
        // treat a full memory as "used" and skip.
        // TRIED AND REJECTED (2026-09-25): neither more slots nor eviction fixes a full memory.
        // Old custom level t=1,307 runs through a wall of 348 pads with up to 132 inside
        // one x window (x~1,211), and GD fires each new one. Eight slots still fill (597 skips,
        // parting from GD at t=1,310 instead of 1,308); evicting the farthest remembered pad lets
        // the model fire the evicted ones again (528 re-fires, the opposite divergence from
        // t=1,314). GD's latch is per pad for the whole attempt, so only a per-level bit per pad
        // would match it here.
        if (slot < 0) {
            if (g_histStatOn) ++g_hist.padFull;   // --histstat (speed.hpp)
            continue;
        }
        c.usedPad[slot] = pd;
        padFiredNow = true;
        if (g_histStatOn) {
            int k = 0;
            for (int i = 0; i < 4; ++i) k += c.usedPad[i] != nullptr;
            g_hist.padMax = std::max(g_hist.padMax, k);
            if (std::find(g_histPads.begin(), g_histPads.end(), pd->uid) != g_histPads.end())
                ++g_hist.padRefire;
            else
                g_histPads.push_back(pd->uid);
        }
        // The pad launched the player in the collision pass, before the buttons, so this tick's
        // press found no ground to jump from and is still unspent (speed.hpp, pad first)
        if (pressAction) {
            c.pressSpent = s.pressSpent;
            pressAction = 0;
        }
        // A pad carrying property 117 turns the player round BEFORE its impulse:
        // GJBaseGameLayer::bumpPlayer (0x217b30) tests the object's +0x704 and calls
        // reversePlayer ahead of PlayerObject::bumpPlayer, and the blue pad's own
        // branch in collisionCheckObjects (0x21593d) does the same after its gravity
        // gate. reversePlayer flips m_isGoingLeft, i.e. State::rev. None in lv1-22.
        if (pd->rev) c.rev = c.rev ? 0 : 1;
        // Pads call runNormalRotation too (the rotWrite note). The ordering of
        // the blue pad's flip against the call is unmeasured, so take the same
        // "before the branch" as the rings.
        rotWrite = true;
        rotWriteFlip = c.flip;
        // ...and a PAD also turns the sprite a full step on this very tick,
        // which a ring or an orb does not. See the spin block near the end of
        // the cube branch for the five measurements that separate them.
        rotPadSpin = true;
        // That step turns toward THIS gravity -- the one the call saw, which for
        // a gravity pad is the value from before the flip a few lines below.
        rotPadFlip = c.flip;
        if (pd->type == 10) {
            // the gravity pad scales too -- this branch was missed on the first
            // pass. Measured on lv11 t=4722 (pad at x[6110.5,6135.5]): GD came
            // out at 5.1200 where the model produced 6.4000, and 5.12/6.40 =
            // 0.800. Third independent confirmation of the same factor.
            const double bv = ((c.mode == 2) ? kPadBlueBall : kPadBlueVy)
                              * (c.mini ? kMiniImpulse : 1.0);
            // one flip per tick, however many gravity pads are entered together
            // (see gravPadFlipped). vy is re-set either way, which is a no-op the
            // second time round -- that is the idempotence.
            {
                c.flip = c.flip ? 0 : 1;
                gravPadFlipped = true;
            }
            VYSET(c.vy) = (float)(c.flip ? bv : -bv);
        } else {
            // UNVERIFIED for the pink pad: the ball ratio (the 0.600 below is
            // the yellow pad's, measured) and the mini factor. Both are carried
            // over from yellow; measure them the moment a plan leans on one.
            // The SPIDER takes the ball's 0.600 too, not the full 16. Straight
            // out of GD's own replay of lv21 (no injection), at both
            // orientations:
            //   t=9303 x=12,080 upright on the pad at (12105,212) rot=0
            //           -> vy = +9.600
            //   t=8470 x=10,999 flipped under the pad at (11025,388) rot=-180
            //           -> vy = -9.600
            // The model was giving it 16.0, and the driver logged exactly that
            // gap as edvy = -6.4 / +6.4 (16.0 - 9.6) at those two sites --
            // sign-consistent, so it is the value and not the timing.
            // Spider = ball keeps turning up: kSpiderGScale and kRingSpiderPost
            // are both the ball's numbers as well. The drop ring is the one that
            // is NOT (16.5 vs 15.0), so this is a per-constant fact, not a rule
            // about the mode -- do not generalise it to the untested ones.
            const bool ballish = (c.mode == 2 || c.mode == 6);
            const double pBase = (pd->type == 9)  ? kPadPink
                               : (pd->type == 34) ? kPadRed
                                                  : kPadYellow;
            // The ball ratio is measured per colour (history at kPadPinkBall's
            // declaration). Pink is 0.700, yellow 0.600 -- applying the generic
            // ratio 9.6/16 to pink gives 6.24, 0.48 off GD's 6.72. Red+ball
            // stays on the generic ratio, unmeasured.
            double pv = (ballish ? ((pd->type == 9)
                                          ? kPadPinkBall
                                          : pBase * kPadYellowBall / kPadYellow)
                                       : pBase)
                              * (padMini ? kMiniImpulse : 1.0);
            // --padtable (speed.hpp): GD's own strengths, per pad and mode.
            if (g_padTable) pv = padTableVy((int)pd->type, c.mode, padMini != 0);
            VYSET(c.vy) = (float)(c.flip ? -pv : pv);
            // The RED pad is the bumpPlayer type that sets the velocity-limit
            // exemption (type==34 at +0x191) where every other pad clears it.
            // kPadRed is 20, so without it the swing handed back 12 of those
            // units next tick. bumpPlayer has no mode test either, so a ship
            // or UFO off a red pad carries it as well (boostLatchMode).
            // UNWITNESSED for ship/UFO: no red pad in the corpus launches
            // either of them out of the band.
            if (pd->type == 34 && boostLatchMode(c.mode)) c.boost = 1;
        }
        c.grounded = 0;
        // ...and the ROBOT's hover budget dies with it. The budget belongs to
        // the jump that armed it (the comment at the mode-portal re-issue says
        // so already); a pad sets vy from the outside and GD does not carry the
        // boost through it. Measured on lv21 (2026-08-10, the cold run's own
        // fixup log): the pink pad at (18585,182) launches the mini robot at
        // t~14,300 with the button HELD, and GD then steps vy by -0.194 on
        // EVERY tick from there to t=14,359 while the model froze vy -- 75 of
        // the run's 88 records are that one hole, all with the identical
        // signature `edy=-0.0873 edvy=-0.194` (0.0873 = kYScale * 0.194). The
        // loop bought it back one tick per iteration: iters 29-46 never left
        // x=18,705.
        c.rHover = 0;
        // the pad wins: undo the landing snap -- and for a player that was
        // already resting on the block, keep the tick's gravity step in y for
        // the same reason (GD never put it back). See `pinnedOnBlock`.
        releasePin(true);
    }
    // --padthenland (speed.hpp): pads that left gravity as it was and vy along it do not undo the
    // landing -- GD's solid pass comes after them and lands the player on that vy
    if (padFiredNow && landedBeforePads && c.flip == flipBeforePads
        && (double)c.vy * (c.flip ? -1.0 : 1.0) <= 0.0) {
        YSET(c.y) = yBeforePads;
        VYSET(c.vy) = 0;
        c.grounded = 1;
        landedThisTick = true;
        cubeLandedThisTick = cubeLandedBeforePads;
    }
    // --padflipland (speed.hpp): a gravity pad that flipped the body this tick hands GD's solid
    // pass a body already falling toward its new floor; a static solid whose new-floor face the
    // foot has crossed, within the landing reach now or at the previous position, lands it
    if (!dead && s.frame == 0 && c.flip != flipBeforePads
        && (c.mode == 0 || c.mode == 2 || c.mode == 5 || c.mode == 6)) {
        const double gs = c.flip ? -1.0 : 1.0;
        const double foot = (double)c.y - gs * pHalf;
        const double prevFoot = (double)s.y - gs * pHalf;
        if ((double)c.vy * gs <= 0.0) {
            for (const Obj* o : *K.near) {
                if (o->type != 0 || o->slope || o->oriented || o->dynObj) continue;
                if (std::fabs(x - o->cx) >= o->hw + pHalf) continue;
                const double face = o->cy + gs * o->hh;
                const double pen = (face - foot) * gs;
                if (pen <= 0.0) continue;   // not past the new floor's face
                if (pen > kLandTol && (face - prevFoot) * gs > kLandTol) continue;
                YSET(c.y) = (float)(face + gs * pHalf);
                VYSET(c.vy) = 0;
                c.grounded = 1;
                landedThisTick = true;
                CLAMP0O("pad/flipland", o);
                break;
            }
        }
    }
    // Release each remembered pad once the player is clear of it IN X. Leaving
    // in y is NOT enough, which is what a gravity-pad corridor shows: lv14
    // x=9195 y=677, fired at t=7066 from x=9181, the cube flies up to y=715
    // (its box nowhere near the pad) and falls back into the pad's box at
    // t=7092 with 1.3 px of overlap -- and GD does NOT fire it again. It lands
    // on the block underneath instead. With a y term in the release the model
    // fired it a second time, took +6.4 where GD had -9.2, and the whole
    // corridor after it was solved for a player GD had already put on the floor.
    for (int i = 0; i < 4; ++i) {
        const Obj* up = c.usedPad[i];
        if (up && std::fabs(x - up->cx) >= up->hw + pHalf + kPadReach)
            c.usedPad[i] = nullptr;
    }
    // Orbs: unlike pads they need the button, on a fresh press while touching.
    // Measured on lv3 (dump_lv3_ref.csv): the yellow orb (id 36, type 11) sets
    // vy := 11.18 -- the same value as a cube jump -- regardless of the
    // incoming velocity (28 activations, vy_in -1.3 .. -11.5). Like the pads,
    // y moves with the pre-boost velocity first and vy is set afterwards.
    // An orb can only be used ONCE per touch. GD keeps the ring in
    // m_touchedRings and will not re-fire it until the player has left it, so a
    // second press while still inside the same orb does nothing. The model had
    // no such memory and happily fired the same orb twice: measured on lv6, the
    // orb at (4515,255) fired at t=3488 and AGAIN at t=3494, which put the model
    // 3 px above GD within ten ticks and grew from there.
    // --ringorder (speed.hpp): this tick's m_touchedRings, before anything reads it
    updateTouchRings(c, s, K, x, (double)c.y, pHalf);
    {
        const Obj* used = c.usedOrb;
        bool stillTouching = false;
        if (g_slopeDbg)
            std::printf("orbdbg t=%lld input=%d ringHold=%d used=%d\n",
                        (long long)K.t, (int)input, (int)s.ringHold,
                        used ? used->uid : -1);
        // `input`, not a rising edge. GD fires a ring whenever the button is
        // DOWN as the player touches it -- holding through an orb activates it,
        // which is how the mode is actually played. The old `input && !s.action`
        // gate needed a fresh press inside the orb's box and silently dropped
        // every hold-through activation. Measured on lv11 t=8567: the mini ship
        // is holding, flies into the orb at (11099,285) at a clamped distance of
        // 17.68, and GD sets vy = 8.9440 (the mini yellow orb value) while the
        // model carried on at -1.671 and was 12 px below GD five ticks later.
        // Re-firing is still prevented by usedOrb, which is the real "once per
        // touch" rule; the edge test was redundant with it and wrong besides.
        //
        // [2026-09-04] Confirmed against GD, and the citation above corrected.
        // Three arms on lv11, cube, the same orb (3179,195), differing only in
        // when the button is released (cfg orbtrace=1):
        //   press 2420, hold  -> fires t=2422 (lag 2)
        //   press 2390, hold  -> fires t=2422 (lag 32)  <- no edge at contact
        //   press 2400, release 2401 -> DOES NOT FIRE   <- must still be down
        // The first two are identical in fire tick, dxx/dyy, vy and death tick,
        // so the press moved without moving the trajectory: only the button
        // changed. So the rule is "down at the contact tick", which is what this
        // gate already says. (The old lv11 t=8,567 mini-ship citation above is
        // stale -- the current plan is a mini BALL there, firing at t=8,549 for
        // -6.2608 -- but the rule it argued for is right for a different reason.)
        //
        // WHERE IT IS WRONG: GD reaches a ring by two paths, and only one of
        // them is open in flight. GJBaseGameLayer::playerTouchedRing ends with
        // `!ship && !ufo && !wave && !swing && m_claimTouch == 0` before calling
        // ringJump, so the CONTACT path -- the one that fires a held button on
        // the tick the boxes meet -- is closed in the four flight modes.
        // pushButton offers every touched ring regardless of mode, so a ring
        // still fires in flight, but only on the tick of the press itself.
        // Hence: held is enough on foot, an edge is required in flight.
        //
        // The edge is taken against `s.jumpBuf`, not `s.action` and not
        // `s.held`. `action` keeps the RAW plan value inside a ctrlOff window,
        // so it would see an edge GD never received. `held` is a clean accepted
        // level but only the flight branches maintain it, so on the tick a
        // portal turns a cube INTO a flight mode it still holds whatever the
        // last flight section left. `jumpBuf` is written from the gated `input`
        // at the top of every tick in every mode, which is also what GD's own
        // ringJump reads (the 0x989 mirror of m_jumpBuffered).
        //
        // Its one impurity is harmless here: it is also cleared when a ring
        // fires or the ball's tap spends the press, so the next tick could read
        // as an edge while the button is merely still down -- but `ringHold` is
        // set in both of those cases and is only cleared by a release, so the
        // gate below is shut anyway.
        //
        // `jumpBuf` IS NOT m_jumpBuffered. It agrees on press and release, and
        // that is all this gate needs, but GD clears 0x985 from a longer list:
        // releaseButton / releaseAllButtons / disablePlayerControls (the Player
        // Control trigger) / lockPlayer / didHitHead / toggleDualMode, plus the
        // jump, the flap, the ball's tap, the end of a dash and the collision
        // path. Those extra droppers are not modelled anywhere, and the
        // difference between the two lists is an unmeasured family, not a
        // closed one -- do not read this comment as saying it agrees.
        const bool ringFly = (c.mode == 1 || c.mode == 3
                              || c.mode == 4 || c.mode == 7);
        // On foot the contact path also runs on the tick of a release -- GD takes the release in
        // the buttons phase, after the collision pass (speed.hpp, the ring buffer)
        const bool ringGate = ringFly ? (input && !s.jumpBuf)
                                      : (input != 0 || s.jumpBuf);
        if (!input) {
            c.ringHold = 0;      // released: the next press may ring again
            c.pressSpent = 0;    // ...and GD's releaseButton clears +0x986 with it
        }
        // `!s.pressSpent` REPLACES the old `!s.ringHold` here and subsumes it: every
        // site that set ringHold sets pressSpent too, and pressSpent is also set by
        // the grounded impulse. ringHold keeps its other reader (the re-jump gate),
        // which must NOT read pressSpent -- GD's cube gate is m_jumpBuffered alone
        // and a held cube bounces repeatedly (calib_holdjump_robot: five times).
        // `s.`, not `c.`: see the field's comment for lv14 t=1,859.
        if (ringGate && !s.pressSpent) {
            // Two orbs can sit on the SAME square, and then which one fires is
            // not a detail: lv14 x=16875 y=585 carries a yellow ring (id 36,
            // uid 4774) and a gravity ring (id 84, uid 4775) exactly on top of
            // each other. GD takes the yellow one (t=13016: vy := 11.180),
            // i.e. the LOWER uid -- the same ordering the stair snap already
            // showed (GD walks the touched objects in descending uid and the
            // last one processed wins). The old loop fired whichever came first
            // out of the sort, which for equal cx is unspecified; here it was
            // the gravity ring, so the model flipped and rose at 4.472 where GD
            // jumped at 11.180. Pick the candidate with the smallest uid.
            //
            // [2026-09-06] ...but the lowest uid is only GD's SAME-TICK
            // tie-break. GD fires the ring it touched FIRST.
            // `PlayerObject +0xa38` is `CCArray m_touchedRings` and it is
            // PERSISTENT across ticks:
            //   playerTouchedRing (0x217e40) does containsObject (0x217ea1) and
            //     addObject ONLY if absent (0x217eb5), so a ring's index in the
            //     array is fixed at its FIRST contact tick and never refreshed;
            //   +0xa40 is a per-tick "touched this tick" uid set, and every
            //     tick's head calls resetTouchedRings(player, 0) (0x3982e0,
            //     from GJBaseGameLayer::update 0x23809e / 0x2380b5) which prunes
            //     the entries missing from it (removeObjectAtIndex 0x3983e4)
            //     PRESERVING ORDER, then clears the set (0x398412);
            //   a fired ring is removed (ringJump 0x398e33);
            //   pushButton (0x397f40) walks the array FORWARD (0x3980b7).
            // Ties inside one tick are ascending uid because checkCollisions
            // sorts each section bucket (0x2143a6, comparator 0x205210
            // `a->m_uniqueID < b->m_uniqueID`) and collisionCheckObjects
            // (0x214960) scans it forward.
            // So: first-contact order, ties within a tick by ascending uid.
            //
            // WITNESS -- lv14 dump tick 13,363. A falling cube (vy -15.000) has
            // yellow orb uid 4934 (id 36, 17325,615) and blue gravity orb uid
            // 4938 (id 84, 17389,675) both inside its ring box (centre
            // 17357.54, 645.41; gate 18 + 15 = 33 on both axes). On the PREVIOUS
            // row only the blue was inside -- blue |dy| 26.210 < 33, yellow
            // 33.790 > 33 -- so the blue entered the array first and GD fires
            // it: vy -15.000 -> +4.472 with the gravity flip (11.18 x 0.8 x 0.5,
            // ringJump's orb factor 0x399254 then flipGravity's halving
            // 0x39a2d4). The lowest-uid model fired the yellow at 11.18 and
            // never flipped, which is lv14's first divergence.
            //
            // WHAT IS KEPT: m_touchedRings itself, as State::touchRing (the four
            // rings in first-contact order, updateTouchRings), so the pick is the
            // candidate earliest in it, ties by lowest uid. Until 2026-09-26 this
            // was --ringorder and the default reconstructed one tick of history
            // instead (a candidate also in contact on the previous tick beat one
            // that was not); that reconstruction is gone with the flag.
            const Obj* pick = nullptr;
            int pickRank = 4;          // `pick`'s place in m_touchedRings
            // WHERE the contact is measured. GD's per-tick order is
            //   update -> checkCollisions (this is where the ring is latched)
            //   -> processQueuedButtons (this is where the press is consumed)
            // so a press consumed on GD's tick P sees the ring state from P's
            // collision pass, i.e. the position at the END of P. The model
            // applies an input `latOf(mode)` ticks LATE, so the tick where it
            // fires is P+1 and its `c.y` is one move too far along.
            // Measured on lv20 (cfg orbtrace=1, the event list): the plan's
            // press is `INJECT_handleButton 983 1`, GD's yvel jumps on t=984,
            // and at t=983 the cube sits 31.7 px under the ring (1291,183) --
            // inside the model's own gate. At t=984 it is 34.2 px under it,
            // outside. The model was testing the right ring at the wrong tick
            // and skipped it, and the replay went 22 px/tick the other way.
            // Both positions are accepted rather than just the earlier one:
            // GD is at least this permissive (it keeps m_ringObject rather
            // than re-deriving it), and loosening only ADDS candidates -- a
            // false pass dies in replay and comes back as a fixup.
            for (const Obj* ob : *K.orbs) {
                if (spiderWarpedThisTick) break;
                // a ship's or UFO's press had its one chance at these a tick ago (the fly rings)
                if (!s.dual && (s.mode == 1 || s.mode == 3)
                    && flyEarlyRingType(ob->type))
                    continue;
                // the landing site follows uid order (measured, teleUid's decl.)
                if (teleportedThisTick && ob->uid < teleUid) continue;
                //// the landing site counts from the next tick (type 28)
                const double odxNow = std::fabs(x - ob->cx);
                const double odyNow = std::fabs((double)c.y - ob->cy);
                const double odxPre = std::fabs(xPrev - ob->cx);
                const double odyPre = std::fabs((double)s.y - ob->cy);
                // the pair that is closest to the ring decides the test below
                //
                // --oriringnow: NOT for a rotated ring. GD, lv22's dash ring 1704
                // (13,333,765, rot -45), one plan with the press moved a tick at a
                // time (2026-09-21, worker replay, |lx| = the ring-axis SAT
                // distance, threshold 18 + 15*sqrt(2) = 39.21):
                //   press 9,424  row 9,425 |lx| 33.11           -> dash from 9,426
                //   press 9,425  row 9,426 |lx| 36.30           -> dash from 9,427
                //   press 9,426  row 9,426 36.30, 9,427 39.52   -> NO dash
                //   press 9,427  row 9,427 39.52                -> NO dash
                // The same 36.30 fires as the row after the press and does not
                // as the press's own row, so that row is not a contact. The
                // model's fire tick is the row after the press, so that row is
                // `c.y`. The pair fired the third arm and cost a cold three
                // iterations at x=13,420.
                // WHY ONLY ROTATED RINGS. Two corpus rings fire in GD where only
                // the press row is inside the model's AABB -- lv22's 1751 at
                // (12,825,795), row after the press |dx| 34.38 against 18 + 15,
                // and lv21's 1704 at (18,105,255), mini robot, |dy| 27.71 against
                // 18 + 9 -- and quick_regress loses tracking in both when the
                // pair is dropped for them. Both distances sit inside the
                // unresolved band of the orbedge sweeps below (robot full 33.79
                // fires / 34.45 not, mini 27.05 / 28.97), so they read as "the
                // row after the press, with a box about 1.4 px larger than
                // hw + pHalf", and the pair is what stands in for that margin.
                // That is a COMPENSATING rule, kept until the box is derived. The
                // rotated test has no such margin (39.52 against 39.21 did not
                // fire), so there the pair only over-fires.
                const bool nowOnly = ob->oriented;
                const bool usePre = !nowOnly
                                 && ((odxPre <= odxNow && odyPre <= odyNow)
                                     || (odyPre + odxPre < odyNow + odxNow));
                const double odx = usePre ? odxPre : odxNow;
                const double ody = usePre ? odyPre : odyNow;
                // **Count merely having been NEARBY, first.** The orbs that did NOT fire are
                // exactly the diagnosis targets: there are 12 divergences where only GD gains
                // velocity on the order of a unit, orders of magnitude beyond the weak/strong
                // acceleration differences (0.026, 0.041), so a missed impulse (orb/pad/ring)
                // is the suspect. Without presence-nearby in the signature, that class cannot
                // be told apart from the others.
                if (odx < ob->hw + pHalf + 30.0 && ody < ob->hh + pHalf + 30.0)
                    g_nearOrb = 1;
                // Ring-either (speed.hpp): either position in the box is a contact
                if (!nowOnly) {
                    if (!(odxPre < ob->hw + pHalf && odyPre < ob->hh + pHalf)
                        && !(odxNow < ob->hw + pHalf && odyNow < ob->hh + pHalf))
                        continue;
                } else if (odx >= ob->hw + pHalf || ody >= ob->hh + pHalf) continue;
                // The activation shape is PER MODE. Point-probed, 1 tick per
                // point, all mini:
                //   BALL, lv16 yellow ring (20355,581):
                //     corner dx=25.97 dy=21.61 (clamp 21.1)  FIRED
                //     x edge dx=26.3 FIRED / dx=27.9 did NOT
                //     y edge dy=26.3 FIRED / dy=27.8 did NOT
                //     -> plain AABB, both edges at 18 + 9 = ob->hw + pHalf.
                //        No circle fits (y-edge non-fire at clamp 18.8 vs
                //        corner fire at 21.4).
                //   CUBE, lv14 yellow ring (11475,129):
                //     (dx=20.0, dy=21.7) FIRED / (dx=25.9, dy=10) FIRED /
                //     (dx=25.9, dy=21.7) did NOT
                //     -> dy matters at fixed dx: circle-like, and the old
                //        clamped radius (17.8 mini) brackets all three.
                // So the ball gets the AABB and every other mode keeps the
                // fitted circle -- which cleared lv1-15/17, so it stays until
                // a probe refutes it for ship/UFO too. Gravity rings (13)
                // keep the circle even for the ball: the one non-fire on
                // record (clamp 17.94, lv16 t=9490) is a gravity ring and
                // its ball corners are unprobed.
                // The same sweep confirmed the trigger is "the box overlaps
                // while the button is HELD" -- press 2 ticks early + release
                // did NOT fire on contact, hold-through DID -- which is the
                // `input && !s.ringHold` rule this loop already implements.
                if (ob->oriented) {
                    // Rotated ring: the firing box is the rotated box (the note at the
                    // parser's orb branch). The world axes are already checked by the AABB
                    // gate above, so this is the box test on the ring's own axes = the
                    // remaining 2 axes of the SAT. The fitted circle is a constant measured
                    // on unrotated rings, so it is not used for oriented ones.
                    const double relx = (usePre ? xPrev : x) - ob->cx;
                    const double rely = (usePre ? (double)s.y : (double)c.y)
                                        - ob->cy;
                    const double lx = relx * ob->rc - rely * ob->rs;
                    const double ly = relx * ob->rs + rely * ob->rc;
                    const double ph = pHalf * (std::fabs(ob->rc)
                                               + std::fabs(ob->rs));
                    if (std::fabs(lx) >= ob->ohw + ph
                        || std::fabs(ly) >= ob->ohh + ph)
                        continue;
                // GRAVITY ORB (13): plain AABB, like the ball's yellow/pink.
                // The fitted circle is REFUTED: lv22 t=3,002 has a MINI cube
                // firing the orb at (4,305,281) from (4,284.15, 307.276) --
                // clamped 20.96 against a radius of 17.8 -- and without that
                // fire the model cannot make the flip corridor's exit.
                // The AABB passes it with room (odx 20.85 and ody 26.28 against
                // hw + pHalf = 27), and the whole suite stays byte-identical.
                }
                // ...AND SO IS EVERY OTHER RING: the test is a plain AABB,
                // |dx| < ob->hw + pHalf and |dy| < ob->hh + pHalf, with **the
                // acting mode's own half**. That is exactly the gate 45 lines
                // up, so no extra test belongs here and the fitted circle is
                // gone. Measured on purpose-built sweeps (2026-08-17,
                // py/mklevel.py `orbedge`/`orbedge2`/`orbedge3`: a single-tick
                // press with the ORB moved 1 px at a time, so the resolution is
                // not the 1.298 px tick and nothing is injected):
                //   2-D, full cube: the largest firing |dx| is 33 at dy = 0,
                //     10, 20, 25, 30 AND 32 (next non-fire 34.8..35.9), and at
                //     dy = 34 nothing fires at any dx. A circle of 19.5 would
                //     have shrunk that to 24.5 by dy = 30. It does not shrink.
                //   1-D by mode (pink, boundary = fires / does not):
                //     robot  full 33.79 / 34.45   -> 18 + 15
                //     spider full 31.85 / 33.02   -> 18 + **13.5**
                //     robot  mini 27.05 / 28.97   -> 18 + 9
                //     spider mini 26.47 / 27.75   -> 18 + **8.1**
                //   The spider rows are what settle it: the half is the MODE's,
                //   not a fixed 15. They are also why this could not be turned
                //   on from the cube sweep alone -- the AABB is 1.5 px TIGHTER
                //   than the circle for a spider and lv22's rotated route was
                //   riding that slack (reach_check caught it as 22@5400
                //   SOLVED -> PARTIAL).
                // KNOWN CONFLICT: the note this replaces recorded GD firing
                // id141 (2025,221) at dyy = -35.0 on lv22 t=1,569, which the
                // AABB (33) rejects. That orb is an ordinary 36x36 (checked),
                // so the likely cause is the trace's tick being one off the
                // firing tick -- at vy about -10 the player moves 2.25 px of y
                // per tick, which covers the 2 px gap. If lv22 regresses at
                // x=2,277 this is the first thing to re-measure, with the
                // MOD's orbtrace stamped on the firing tick itself.
                // A SPIDER ORB with nothing on the other side is not a
                // candidate at all: GD's spiderTestJump finds no surface and
                // the tap does nothing, so it must not eat the press (or the
                // shared tail below would unground the player for free).
                if (ob->type == 43) {
                    double tgt = 0.0;
                    if (!spiderTargetY(K, x, (double)c.y, c.flip != 0,
                                       c.mini != 0, pHalf, tgt, c.frame == 0,
                                       nullptr, (int)c.frame, c.rev != 0))
                        continue;
                }
                if (ob == used) { stillTouching = true; continue; }
                if (ob->uid >= 0 && ob->uid == c.usedOrbOld) continue;   // fired before `used`
                if (ringFiredBefore(c, ob->uid)) continue;
                // the first in m_touchedRings wins, then the lowest uid
                const int rk = touchRank(c, ob->uid);
                if (!pick || rk < pickRank || (rk == pickRank && ob->uid < pick->uid)) {
                    pick = ob;
                    pickRank = rk;
                }
            }
            // [2026-09-05, stage 1 of 2 -- BEHAVIOUR-PRESERVING, no rule change]
            // Everything below applies ONE orb. It is lifted into a lambda so the
            // second stage can call it more than once, because GD fires EVERY
            // touched ring rather than choosing one:
            //   PlayerObject::pushButton (0x397f40) walks m_touchedRings; a ring
            //   with the claim bit +0x740 fires alone and returns, otherwise the
            //   list is split into type==0x24 and everything else, and BOTH
            //   buckets are fired in full, first bucket first.
            // Composition is safe because nothing accumulates: ringJump makes 16
            // direct writes (one double via `=`, never `+=`, plus 15 constant byte
            // flags) and calls setYVelocity (a SET), flipGravity (stores the target
            // polarity, so a no-op when it already matches), and
            // runNormalRotation / runBallRotation2 (stake +0x720, last wins). The
            // two calls that are NOT idempotent are reversePlayer and
            // teleportPlayer. teleportPlayer is excluded structurally: it needs
            // type 0x2e (46), which is absent from the playerTouchedRing case list
            // AND has zero instances across all 22 levels. reversePlayer cannot be
            // excluded by type at all -- its gate is the per-object property
            // +0x704 -- but applying orbs one at a time through this lambda
            // reproduces it exactly, so stage 2 removes the question rather than
            // answering it.
            // WHAT STAGE 1 DOES NOT DO: it still passes exactly the one orb `pick`
            // selected, so stage 1 itself was byte-identical on all three
            // instruments. (`pick` was "lowest uid" when that was written; since
            // 2026-09-06 it is "first-touched, ties by lowest uid" -- see the
            // block above. Stage 2, firing EVERY touched ring, is still unwritten.)
            auto applyOrb = [&](const Obj* ob) {
                // [OPEN 2026-08-18] lv20 t=11,896: on the tick a grounded cube
                // fires gravity orb uid10053, GD stays y=219.000 while the model
                // gets 218.9514 (-0.0486 = 0.225 x 0.216 = one gravity step).
                // Adding `if (s.grounded) c.y = s.y;` here did not change the
                // value (suspect the RIDE below happening at c.y == s.y and
                // re-seating at the same y). This 0.0486 advances the robot's
                // landing tick at t=12,033 by one -- the identity of
                // quick_regress's lv20 t=11,800 section (400 -> 233).
                // A ring carrying property 117 turns the player round first:
                // ringJump (0x398d81) calls reversePlayer once the ring is known to
                // fire and before any of its own writes, so everything below (the
                // ball's roll direction included) sees the new heading. None in lv1-22.
                // pushButton gave this press to the ring, so the grounded jump or tap it made
                // earlier in this tick did not happen (speed.hpp, ring first)
                if (pressAction && !portalPressRedo) {
                    c.flip = s.flip;
                    if (pressAction == 2) {
                        c.rotStep = s.rotStep;
                        c.rotNeg = s.rotNeg;
                        ballFlippedThisTick = false;
                    }
                    pressAction = 0;
                }
                if (ob->rev) c.rev = c.rev ? 0 : 1;
                rotWrite = true;   // rings/orbs too (the rotWrite note)
                rotWriteFlip = c.flip;   // default: gravity from before the branch
                // ring impulses scale with the section's speed (see ringScaleFor)
                const double ms = (c.mini ? kMiniImpulse : 1.0) * ringScaleFor(useDx);
                if (ob->type == 13) {
                    // ...and the SPIDER takes the same 0.700 post-multiplier
                    // the yellow/pink and red/green branches already apply.
                    // Only the BALL had a constant here, so a spider was
                    // getting the CUBE's gravity orb. Measured on lv21
                    // (2026-08-18, plain replay, no injection, both runs
                    // bit-identical up to the tick), orb id84 uid11777 at
                    // (11115,315):
                    //   t=8,580  GD vy := -3.130  / model -4.472
                    //   t=9,871  same difference (edvy +1.3416 = 4.472 - 3.1304)
                    // 3.1304 / 4.472 = 0.700000 = kRingSpiderPost, and it is
                    // the same number the ball's own measured constant already
                    // holds (kOrbGravityBall = 3.130). The ROBOT keeps 4.472
                    // (measured), which is why this is a post-multiplier list
                    // and not a mode table. Swing is left out for the same
                    // reason as in the yellow/pink branch: unmeasured.
                    const double gpost = (c.mode == 6) ? kRingSpiderPost : 1.0;
                    // --rawvalues (speed.hpp, rawQ): q(jump x 0.8 x mini), then the flip's
                    // x0.5 and the ball's x0.7 raw -- 4.472, 4.568 at 1.1, the mini cube's
                    // q(7.1552) x 0.5 = 3.5775 (gdref lv11/13/14/20, where q(3.5776) = 3.578
                    // parted from GD) and the ball's 3.1304 (GD stores 3.13039995; a custom level
                    // t=18,078) all come out of that one line.
                    const double gv = g_rawValues
                        ? rawQ(kCubeJump * 0.8 * ms) * 0.5
                              * ((c.mode == 2) ? kRingSpiderPost : gpost)
                        : ((c.mode == 2) ? kOrbGravityBall : kOrbGravity) * ms * gpost;
                    c.flip = c.flip ? 0 : 1;
                    VYSET(c.vy) = (float)(gv * (c.flip ? 1.0 : -1.0));
                } else if (ob->type == 37 || ob->type == 38) {
                    // DASH ring. Freezes vy and starts the straight-line
                    // travel; the ring's rotation is the angle. Every dash
                    // ring in lv21 and all but one in lv22 are rot = 0, i.e.
                    // dead horizontal -- the -45 one at lv22 x=13,333 uses the
                    // same formula and is UNVERIFIED.
                    // 38 flips gravity as well; that ordering (flip, then the
                    // dash line) is unmeasured -- the dash is horizontal in
                    // both of lv21's, so it does not show.
                    c.dashing = 1;
                    c.dashSlope = (float)std::tan(-ob->rot * 3.14159265358979 / 180.0);
                    // The vy GD's dump prints on the engage tick (4 measurements
                    // at g_dashVy's declaration). **The state stays 0** -- only
                    // the display is matched.
                    g_dashVy = (double)c.vy * (ob->type == 38 ? 0.5 : 1.0);
                    g_dashVySet = 1;
                    VYSET(c.vy) = 0.f;
                    c.grounded = 0;
                    if (ob->type == 38) c.flip = c.flip ? 0 : 1;
                } else if (ob->type == 32) {
                    // DROP ring: a fixed slam toward the player's own floor.
                    // No speed scale either -- the value is a literal in the
                    // function, not a multiple of the jump.
                    const double dv = (c.mode == 6)   ? kRingDropSpider
                                      : (c.mode == 3) ? kRingDropUfo
                                      : (c.mode == 1 || c.mode == 4
                                         || c.mode == 7) ? kRingDropFly
                                                         : kRingDrop;
                    // [2026-08-22 r102] **Hit while climbing fast enough, the
                    // next tick's terminal clamp is skipped once.** The dropair
                    // calibration rig, reshaped to "start pressing in mid-air",
                    // swept the incoming vy with off (the firing tick's vp
                    // after that tick's gravity is applied):
                    //   cube  3.085 / 2.005 -> **skips** (next tick -15.216)
                    //         1.789 / 1.357 / negative -> does not skip
                    //   ball  2.329 -> skips / 1.813 -> does not
                    //   robot 2.749 -> skips, spider 4.051 -> skips
                    // The boundary is **2.0** (the same number as GD's other
                    // 2.000s). The corpus's lv21@7,217 is on the skipping side
                    // at vp=2.176 -- the identity of family
                    // `m0/mini0/g0/gdg0/sp0.9/air` edvy -0.216.
                    // The delay is **only the next 1 tick**; the one after
                    // returns to -15.000.
                    if ((double)c.vy * (c.flip ? -1.0 : 1.0) >= 2.0)
                        c.pNoTerm = 1;
                    VYSET(c.vy) = (float)(c.flip ? dv : -dv);
                    c.grounded = 0;
                } else if (ob->type == 43) {
                    // SPIDER ORB (GameObjectType::SpiderOrb = 43, id 3004).
                    // NOT a teleport portal: it carries no stored target. It
                    // runs the SPIDER's own surface search from wherever the
                    // player is -- in any mode, in mid-air -- and flips gravity.
                    // Measured on lv22, plain replay of the level's only two:
                    //   uid 6179 (13965,975) cube, upright, airborne:
                    //     t=10353  y 952.98 -> 1035.000  flip 0 -> 1  vy := +1
                    //   uid 6197 (14325,975) cube, flipped, airborne:
                    //     t=10586  y 980.12 ->  915.000  flip 1 -> 0  vy := -1
                    // Both land exactly on spiderTargetY's face (underside minus
                    // pHalf going up, top plus pHalf going down), and x is
                    // untouched. The +-1 of leftover velocity points the way the
                    // teleport went -- the same rule the spider's own tap uses,
                    // and the arrival tick reports onGround=0 with the landing
                    // resolved on the next one, which is what the shared
                    // `c.grounded = 0` below already gives.
                    double tgt = 0.0;
                    const double gs = c.flip ? -1.0 : 1.0;
                    // the candidate loop already refused a target-less one
                    if (spiderTargetY(K, x, (double)c.y, c.flip != 0,
                                      c.mini != 0, pHalf, tgt, c.frame == 0,
                                      nullptr, (int)c.frame, c.rev != 0)) {
                        YSET(c.y) = (float)tgt;
                        c.flip = c.flip ? 0 : 1;
                        VYSET(c.vy) = (float)gs;
                        c.spiderJumpT = 0;   // GD's +0x820 (State::spiderJumpT)
                        if (g_touchCensus) g_tcBranch |= 2;
                        // whatever held us up is a level away now
                        c.snapObj = nullptr;
                        c.snapDist = 0.f;
                        c.onSlope = 0;
                        c.slopeM = 0.f;
                    }
                } else if (ob->type == 35 || ob->type == 29) {
                    // RED (35) and GREEN (29), straight off the ringJump table.
                    // Both are expressed as a ratio of the cube's jump rather
                    // than as their own constant, because that is how GD
                    // computes them -- and it is what makes the mode entries
                    // that nobody has measured trustworthy.
                    const bool green = (ob->type == 29);
                    double r;
                    if (green) {
                        r = (c.mode == 1) ? kRingGreenShip : kRingGreen;
                    } else {
                        switch (c.mode) {
                            case 1: r = c.mini ? kRingRedShipMini : kRingRedShip; break;
                            case 3: r = c.mini ? kRingRedUfoMini : kRingRedUfo; break;
                            case 2: r = kRingRedBall; break;
                            case 5: r = kRingRedRobot; break;
                            case 6: r = kRingRedSpider; break;
                            default: r = kRingRedCube; break;
                        }
                    }
                    // TRIED AND REVERTED (2026-08-09): `if (green && c.mode==5)
                    // r *= kRingRobotDefault`. The reasoning ("the robot's
                    // blanket 0.9 applies to rings with no entry of their own,
                    // and green has none") was read off the ratio table at
                    // 0x399399, but the green arm does not reach that `mulss`.
                    // GD says so directly -- lv20 t=12,729, a full-size ROBOT
                    // takes the green ring on a plain replay (no injection):
                    //   GD    vy := -11.420 = 11.18 * 1.021467       (x 1.00)
                    //   model vy := -10.278 = 11.18 * 0.9 * 1.021467 (x 0.90)
                    // four digits each, and the two ran bit-identical up to
                    // that tick. The 0.9 put the robot 56 px below GD by
                    // t=12,886 and lv20's cold run could not get past x=18,214
                    // because every plan it built died there.
                    // kRingRobotDefault stays for whatever else needs it.
                    const double post = (c.mode == 2)   ? kRingBallPost
                                        : (c.mode == 6) ? kRingSpiderPost
                                        : (c.mode == 7) ? kRingSwingPost
                                                        : 1.0;
                    // GREEN flips gravity BEFORE the velocity is set, so the
                    // value is not halved and the sign follows the NEW gravity.
                    // Green flips **first** and writes the velocity after. The
                    // rotation-sign write also lands in between, so only green
                    // gets the new gravity (measurements at rotWriteFlip's
                    // declaration).
                    if (green) { c.flip = c.flip ? 0 : 1; rotWriteFlip = c.flip; }
                    // --rawvalues (speed.hpp, rawQ): q(jump x ratio x mini), post raw -- the red
                    // cube's 11.18 x 1.38 = 15.4284 is 15.428 in gdref lv22 t=297.
                    const double ov = g_rawValues ? rawQ(kOrbYellow * r * ms) * post
                                                  : kOrbYellow * r * post * ms;
                    VYSET(c.vy) = (float)(c.flip ? -ov : ov);
                    // RED is one of the two ring/pad types that SET the
                    // velocity-limit exemption instead of clearing it
                    // (ringJump +0xc7a, type 35 only; every bumpPlayer orb
                    // clears it). ringJump has no mode test, so it reaches
                    // every mode that reads the byte (boostLatchMode).
                    // The full-size swing red ring is 11.18*1.38*0.6 = 9.257,
                    // above the terminal -- without the flag the model used to
                    // hand back everything over 8 on the next tick.
                    // UNWITNESSED for ship/UFO: no red ring in the corpus
                    // throws either of them outside the band.
                    if (!green && boostLatchMode(c.mode)) c.boost = 1;
                } else {
                    // pink (12) and yellow (11), each with its own measured
                    // ball value -- there is no shared ball ratio.
                    // UNVERIFIED for pink: the mini factor (0.800 carried over
                    // from every other impulse).
                    const bool pink = (ob->type == 12);
                    // ...and the SPIDER takes the same 0.700 post-multiplier the
                    // red/green branch above already applies. This branch had no
                    // mode term at all, so a spider was getting the CUBE's orb.
                    // Measured on lv21 (2026-08-10) at the yellow orb
                    // (12225,285), on a plain replay with no injection:
                    //   GD    t=9427  vy := 7.826
                    //   model t=9427  vy := 11.180  (= kOrbYellow, untouched)
                    // and 7.826 / 11.180 = 0.700000, which is kRingSpiderPost to
                    // six digits. It was the WORST early divergence in the whole
                    // level: the fixup window at t=9427 followed GD for only 68
                    // ticks before this, against 300-400 for every other window.
                    // The ball is NOT given a post here -- it has its own
                    // measured constants (kOrbYellowBall / kOrbPinkBall) and
                    // multiplying again would double-count.
                    // Swing (7) is deliberately left out: the red/green branch
                    // applies kRingSwingPost there, but nothing has measured it
                    // for the yellow orb and no level reaches one yet.
                    const double post =
                        (c.mode == 6) ? kRingSpiderPost : 1.0;
                    // ...and the ROBOT takes the table's closing
                    // `else if (m_isRobot) *= 0.9` (kRingRobotDefault) on the
                    // YELLOW orb, which has no robot entry of its own.
                    // Measured on lv19 (2026-08-18, plain replay, no injection,
                    // both runs bit-identical up to the tick):
                    //   t=2,965  orb id36 uid1050  GD vy := +10.062  model 11.180
                    //   t=4,036  orb id36 uid2165  GD vy := -10.062  model -11.180
                    // and 10.062 / 11.18 = 0.900000 to six digits.
                    // PINK is deliberately excluded: its robot value is the
                    // CUBE's 8.050 (measured), i.e. type 12 has its own entry
                    // and never reaches the closing branch. Same reason the
                    // gravity orb (13) keeps 4.472 for a robot. Ship / UFO /
                    // wave / swing are unmeasured for the yellow orb and stay
                    // on the cube value.
                    const double robotR =
                        (!pink && c.mode == 5) ? kRingRobotDefault : 1.0;
                    double ov =
                        ((c.mode == 2) ? (pink ? kOrbPinkBall : kOrbYellowBall)
                         : (pink && (c.mode == 1 || c.mode == 3))
                             ? kOrbYellow * pinkRingRatio(c.mode)
                             : (pink ? kOrbPink : kOrbYellow))
                        * ms * post * robotR;
                    // --rawvalues (speed.hpp, rawQ): q(jump x ratio x mini), then the post
                    // multipliers raw. The pink cube at 1.1 reads 8.222 = q(11.42 x 0.72) in
                    // gdref lv15 t=4,016 / 5,308, where 8.05 x 1.0214669 = 8.2228; the pink
                    // ball's separately measured 6.0263 is q(11.18 x 0.77) x 0.7 exactly (the
                    // unrounded product is 6.0260); yellow ball 7.826 = q(11.18) x 0.7.
                    if (g_rawValues) {
                        const double ratio = pink ? pinkRingRatio(c.mode) : 1.0;
                        ov = rawQ(kCubeJump * ratio * ms * robotR)
                             * ((c.mode == 2) ? kRingSpiderPost : 1.0) * post;
                    }
                    VYSET(c.vy) = (float)(c.flip ? -ov : ov);
                }
                c.grounded = 0;
                // Same as the pad: an orb is an outside impulse, so the robot's
                // hover budget from an earlier jump does not survive it (see the
                // pad's note for the lv21 measurement). The dash ring above
                // relies on this too -- its own branch clears rHover a tick
                // later, which is one tick of frozen vy too many if the budget
                // is still armed when the ring fires.
                c.rHover = 0;
                // An orb taken off a block moves y exactly like a pad does --
                // the ordinary jump is the only launch GD re-seats. Measured:
                // lv19 t=254 (+3.999, dy -0.0486) and t=506 (+7.405, same),
                // lv16 t=6404 (+9.208, -0.0484), lv18 t=10824 (+2.499, -0.0486).
                // The model had already run its jump branch by the time it got
                // here, which is why the pin is still there to consume.
                // ...EXCEPT the GRAVITY ORB (13), which leaves y alone.
                // Swept the whole corpus for "grounded on a block, vy 0, an
                // impulse that FLIPS gravity" (2026-08-18) -- the split is by
                // object, not by value or mode:
                //   gravity ORB   cube 3.578 x2 (lv20 11,616/11,896)  y FROZEN
                //   gravity PAD   cube 5.12 x5, 6.4 x14              y MOVES
                //   spider 1.000 x35 (its own teleport)              y MOVES
                // No counter-example either way, but the ORB side is only TWO
                // samples from ONE level: the `cube 5.193 x2` pair first quoted
                // here (lv22 11,344/12,175) turned out to be FRAME TURNS, not
                // orbs -- 5.193 is what a gframe change writes at speed 0.9,
                // and it shows up in the same "grounded, vy 0, gravity flips"
                // sweep. Re-check on a third gravity orb when one appears.
                // Without this the model left
                // the block 0.0486 px low, which is what put lv20's t=11,800
                // segment a tick early into the landing at t=12,033.
                // A ring fired by a FRESH press keeps the pin -- GD fires it from pushButton,
                // after the collision pass has re-seated the body (speed.hpp, ring press pin).
                if (ob->type != 13 && !(input && !s.jumpBuf))
                    releasePin(true);
                noteRingFired(c, ob);
                // Fired on the release tick, the press is spent and then released in the buttons
                // phase, whose releaseButton clears +0x986 again (a custom level t=12,320: the fresh
                // press at 12,321 must stay unspent for the blue ring at 12,322)
                if (input) {
                    c.ringHold = 1;
                    c.pressSpent = 1;   // GD's ringJump spends the press (see the field)
                }
                // ringJump is the second of the two callers that write the
                // ball's AIR step, and unlike the tap it does NOT move gravity
                // first -- so the same `NOT (g XOR r)` computed against the
                // UNCHANGED gravity comes out inverted relative to the roll.
                // That is the whole of the 67.6% kept / 32.4% inverted split
                // measured against the preceding roll: not two rules, one rule
                // and two arrival conditions.
                //
                // In GD this path has no mode gate, which is how the ball's
                // spin leaks into UFO and swing and why those two also read as
                // unrotated. Gated to the ball here on purpose: reproducing the
                // leak needs the attitude law those modes also run, and that is
                // a separate piece of work.
                if (c.mode == 2) {
                    c.rotStep = (float)ballRotRate(c.mini != 0, true, useDx);
                    c.rotNeg = (uint8_t)!((c.flip != 0) ^ (c.rev != 0));
                }
                // A ring that takes the press SPENDS it: in GD the ring path of
                // pushButton runs `ringJump(); m_jumpBuffered = 0; return;` and
                // never calls updateJump. Without this the mirrored buffer would
                // still be set on the next tick and the grounded branch could jump
                // off a press the ring has already used.
                c.jumpBuf = 0;
                // ringJump's post-multiplier arm clears +0x985 for the ball, the spider and the
                // swing (the drop ring's arm for the ball and the swing only; speed.hpp, hold latch)
                if (input
                    && ((flyEarlyRingType(ob->type) && ob->type != 32
                         && (c.mode == 2 || c.mode == 6 || c.mode == 7))
                        || (ob->type == 32 && (c.mode == 2 || c.mode == 7))
                        || ob->type == 43))   // the spider orb runs spiderTestJump
                    c.holdDead = 1;
                used = ob;
                stillTouching = true;
            };
            if (pick) applyOrb(pick);
        }
        // Only on a teleported tick are the landing site's portals applied here
        // (the runPortalPass note: GD goes in uid order, so pads/orbs come
        // first).
        if (teleportedThisTick) runPortalPass(1);
        // [2026-08-16] The "forget once out of the box" release was dropped.
        // **GD's orbs can fire only once per run** (consumed on use). Measured
        // (lv22, cfg orbtrace=1, the cold run's plan): GD fires id141
        // (2025,221) exactly once at t=1,569 and does not fire it when the
        // player re-enters the box at t=1,581.
        // The old rule dropped the memory at t=1,571 (ody=33.2 >= 33) and fired
        // **the same orb a second time** at t=1,581. That was the frozen diff's
        // first divergence, and everything after was a different worldline
        // (just before the cold run's x=6,380 wall).
        // usedOrb keeps holding "the last orb fired". It is not overwritten
        // until a different orb fires, and the one it displaces is kept by uid in
        // usedOrbOld, so A->B->A is refused as GD refuses it (SubZero's Power Trip,
        // two green rings on one square -- see the field). A->B->C->A still
        // cannot be represented: switch to a uid set if one appears.
        (void)stillTouching;
    }
    // Stair snap (GD PlayerObject::checkSnapJumpToObject). Cube only -- GD gates
    // the call on vType == Cube. Runs every grounded tick, once per touched
    // solid. The contact test (half-width 15.0, strict <) reproduced GD's own
    // call sequence on 2022/2022 grounded ticks of the hooked lv3 run.
    // (and the ROBOT is deliberately NOT included: GD's gate is on the vehicle
    // type being Cube, and the robot is its own type. UNVERIFIED against a
    // measurement -- if a robot landing ever runs a pixel behind GD, this is
    // the first thing to check.)
    // ...and NOT while a ramp is what is holding the player up. GD calls the
    // snap from the collision it resolved, and on a ramp that collision is the
    // ramp: measured on lv19 with `snaptrace=1` on one side and `--snaplog` on
    // the other, GD makes **zero** snap calls for the whole ride (its last one
    // before the ramp is t=433..~460, the next is well after t=512).
    // The model kept snapping because its contact test is `|foot - face| <= 0.6`
    // over type-0 solids, and at t=505 the ledge (675,179.25) has its top face
    // at exactly 180.0 with the player's foot at exactly 180.0 -- zero
    // penetration, which GD does not count as a collision. It then compared
    // against a `snapObj` left over from (585,119.25) 90 px back, matched the
    // `big` stair pattern (dx=90, dy=60) and nudged x by the clamped +1.0000.
    // That 1 px never comes back: lv19 ran a pixel ahead of GD from t=505 to
    // the end, which is the whole of its remaining 2,817 divergent ticks.
    // THE CUBE'S OWN SPIN. The portal test needs it once an object is turned
    // (see obbSat): GD compares the two ORIENTED boxes and the player's is its
    // 30x30 turned by this.
    //
    // `runNormalRotation` (win 0x38d220) sets
    //   m_rotationSpeed = 180 * (signs) * [+0xb84] * speedArg / k ,
    //   k = 0.4333333 (size 1.0) / 0.3333333 (mini)
    // i.e. 415.3846 deg/s and 540 deg/s -- 1.730769 and 2.25 per tick at 240 Hz,
    // which is exactly what the dumps show, and SPEED-INDEPENDENT (identical at
    // 0.7 / 0.9 / 1.1 over 5,600 airborne ticks).
    // The sign: a take-off sets it POSITIVE and every GRAVITY FLIP negates it.
    // Measured on lv22's seeded clear -- the only two sign changes in 4,000
    // ticks are t=732 (flip 1->0) and t=1,308 (flip 0->1), both mid-air, and no
    // flip passes without one.
    // Grounded, GD EASES back toward the nearest multiple of 90 rather than
    // snapping -- and that matters, because a take-off before it has arrived
    // leaves the next arc's `rot mod 90` off, which is the only thing the
    // square player box cares about. Fitted over 380 grounded ticks of lv22's
    // seeded clear: rot += 0.1181 * (nearest90 - rot), residual in the 5th
    // decimal (0.11810..0.11815 across the whole sample).
    if (c.mode == 0) {
        // The sign is NOT a running parity -- it is written fresh, from the
        // gravity IN FORCE AT THE MOMENT OF THE WRITE, and then held. Hooked
        // `PlayerObject::runNormalRotation` and logged every call (lv22 seeded
        // clear, cfg hitboxtrace=1, `rnr:` lines): all ten pass speed=+1.0 and
        //   flip=0 -> m_rotationSpeed = +415.3846
        //   flip=1 -> m_rotationSpeed = -415.3846
        // The writes land on take-offs and on the tick a gravity change fires
        // (t=684 with flip still 0 -> +, t=731 with flip still 1 -> -), which is
        // why the arc from t=685 to t=731 keeps turning the OLD way even though
        // the player is upside down for all of it. Two earlier guesses -- "flip
        // decides it every tick" and "each flip negates it" -- are both refuted
        // by exactly that stretch.
        c.rotNeg = s.rotNeg;
        // **This tick's step turns with the sign it came in with.** The write
        // happens this tick, but takes effect from the next. Measured (lv20,
        // t=7,154 where a green ring makes flip 0->1): GD's rot turns at +1.7308
        // through 7,154 and changes to -1.7308 from 7,155.
        const uint8_t rotSignNow = s.rotNeg;
        // ...and the sign written is **the gravity at the end of that tick**
        // (c.flip). The old implementation used s.flip (pre-change) and the
        // sign failed to reverse at t=7,154 above. The original measurements of
        // lv22's t=684 (+ with flip still 0) / t=731 (- with flip still 1) are
        // also consistent with c.flip, since the dump's flip is the
        // end-of-tick value.
        // The gate is not "did flip change" but **was runNormalRotation
        // called** (measurements at rotWrite's declaration). A portal-driven
        // gravity change does not call it.
        if (rotWrite) c.rotNeg = rotWriteFlip;
        else if (s.grounded && !c.grounded) c.rotNeg = c.flip;
        // [2026-08-18] The easing applies "**if either end is grounded**". On
        // both the take-off tick and the landing tick, GD applies the easing,
        // not the rotation step. Measured (lv20, GD's dump, rot column):
        //   take-off t=7,062 (s.grounded=1 -> c.grounded=0):
        //     -359.68869 -> -359.725464, 0.11813 against the remaining -0.31131
        //   landing t=7,395 (s.grounded=0 -> c.grounded=1):
        //     -238.571289 -> -243.933823, 0.17062 against the remaining -31.429
        //   landing t=7,033: 371.923676 -> 370.515167 (GD also subtracts 720),
        //     0.11812 against the remaining -11.9237
        // The old implementation looked only at c.grounded and turned one extra
        // step on the take-off tick. The rotated-box test is decided by rot mod
        // 90, so this accumulated once per ~60 ticks and drifted 30 degrees in
        // 300 ticks.
        // [2026-08-25] ...**except on a tick that called runNormalRotation**.
        // That call restarts the spin there and then: a FULL step, in the
        // direction it has just written -- not the take-off easing, and not the
        // previous tick's sign. `rotWrite` already marks exactly those ticks
        // (pads, rings and orbs; it was only feeding c.rotNeg for the NEXT
        // tick). Measured on lv22, GD's dump against a bit-exact replay:
        //   t=1,170 yellow pad, take-off (s.grounded=1 -> c.grounded=0):
        //     GD 270.002 -> 271.733 = a full +1.731. The model eased (-0.000)
        //     and was one step short from there on.
        //   t=1,484 pink pad in mid-air, vy -15.000 -> +10.400:
        //     GD 180.002 -> 181.733 = +1.731, i.e. it REVERSES on the same
        //     tick. The model kept the old sign for one more step (-1.731) and
        //     lost two more.
        // Those three steps are the whole 5.19-degree gap that made the spider
        // portal uid1156 (see turnedBox) fire on the wrong tick. A plain
        // walk-off take-off calls nothing and still eases, which is what lv20
        // t=7,062 measured (-359.68869 -> -359.725464).
        // ...and only a PAD does. A ring or an orb calls runNormalRotation too
        // but leaves this tick's turn alone. Five measurements on lv22, GD's
        // dump against a bit-exact replay, cover both sides:
        //   PADS -- the step happens and it turns toward the CURRENT gravity
        //     t=1,170 yellow pad, take-off (s.grounded=1 -> c.grounded=0):
        //             GD 270.002 -> 271.733 = a full +1.731; the model eased
        //             (-0.000) and ran one step short from there on
        //     t=1,484 pink pad mid-air, spin was -1.731/tick:
        //             GD 180.002 -> 181.733 = +1.731, i.e. it REVERSES here
        //   ORBS -- the sign simply carries on through the tick
        //     t=663   flip 0->1, spin was +  -> GD +1.731
        //     t=727   flip 1->0, spin was +  -> GD +1.731
        //     t=1,424 flip 1->0, spin was -  -> GD -1.731
        //   (663/727/1424 are the same orb type at the same speed, so it is the
        //    PREVIOUS sign that carries, not the gravity: 727 and 1,424 share a
        //    flip transition and disagree on the step.)
        // The SIGN THE CALL LEAVES BEHIND is a third quantity and is unchanged
        // (c.rotNeg = rotWriteFlip, above): at t=727 GD steps + here and then
        // runs at -1.731 from the next tick.
        // [2026-09-06] ...toward the gravity **at the moment of the call**, not
        // the gravity at the end of the tick. Only a GRAVITY pad can tell those
        // apart, because only it moves the gravity inside the tick, and the two
        // pads measured above are a yellow and a pink one. Every sample:
        //
        //   lv22 t=1,170  yellow pad  flip 0 -> 0   GD +1.731   NOT decisive
        //   lv22 t=1,484  pink pad    flip 0 -> 0   GD +1.731   NOT decisive
        //   lv18 t=18,202 gravity pad flip 0 -> 1   GD +1.731   decisive
        //   lv18 t=18,221 gravity pad flip 1 -> 0   GD -1.731   decisive
        //
        // The first two rows cannot separate "at the call" from "at the end of
        // the tick" -- those are the same value when the gravity does not move --
        // and they equally fit "always positive". Only the lv18 pair discards
        // anything, and only the second of them refutes "always positive".
        // (fid_lv18.dump.csv, rot and upsideDown, GD's own numbers: rot goes
        // 162.713806 -> 164.444580 on 18,202 with upsideDown going 0 -> 1, and
        // 188.885406 -> 187.154633 on 18,221 with upsideDown going 1 -> 0.)
        //
        // Two witnesses would be thin, so the same question was put to the whole
        // corpus by exclusion: replay all 22 levels, take every tick that reaches
        // this branch with the gravity moving inside it, and score the three
        // candidates against GD's own rot column, up to each level's first
        // divergence. 116 witnesses in nine levels (lv10 15, lv11 13, lv12 7,
        // lv13 17, lv14 15, lv15 7, lv18 22, lv19 2, lv21 18):
        //
        //   gravity at the call  116 / 116
        //   gravity at end of tick 0 / 116     <- what this line used to read
        //   always positive       63 / 116
        //
        // and GD's own upsideDown column agrees with the model's before/after
        // gravity on all 116, so the rows are the ticks they claim to be.
        //
        // REACH: 126 ticks in ten levels take this branch with the gravity moving
        // (the 116 above plus 10 past a first divergence, which the dump can no
        // longer score). Only `rot` moves: the whole 22-level replay is
        // byte-identical elsewhere, lv1/2/3/4/5/6/7/8/9/16/20/22 down to the
        // byte, and every first-divergence tick unchanged.
        //
        // This matches what the binary does: `propellPlayer` (which calls
        // runNormalRotation, and whose signed impulse is the `mult` operand)
        // runs BEFORE `flipGravity` in collisionCheckObjects' case 10 -- the
        // pseudocode at the pad gate above -- and runNormalRotation writes the
        // rate from `m_isUpsideDown` as it stands at that instant. It is the same
        // write that leaves the sign behind for the next tick, which is why
        // rotWriteFlip a few lines up already captures it at the same point.
        //
        // STILL NOT SEPARATED: the rate runNormalRotation writes is
        // `sign(180 . rev . vert . timeMod . mult)`, and `propellPlayer` hands it
        // the pad's SIGNED velocity as `mult` (win 0x39f955, the call itself at
        // propellPlayer+0x10a), so the sign is not a function of the gravity
        // alone -- steps of -1.7308 at up=0 do occur. "The gravity at the call"
        // and "that gravity XOR the impulse's sign" therefore predict the same
        // thing on every pad here, because every gravity pad in the corpus is one
        // the player can legally take, which ties the two together. Separating
        // them needs a rig: a floor-facing pad taken in flipped gravity. Until
        // then this is written as the gravity, not the impulse.
        // `!c.grounded && !s.grounded` reads only the two ENDS of the tick, so a
        // landing that happened INSIDE it is invisible: a cube that lands on a
        // solid and leaves it on the same tick clears `grounded` again before
        // this line runs, and the airborne spin fires on a tick GD spent easing
        // toward the upright. `cubeLandedThisTick` is the landing event itself
        // -- written at the `solid/land` site and cleared by `undoSnap` -- and
        // the stair-nudge gate below already treats it as ground. Using it here
        // leaves `grounded` alone, which is the point: that flag feeds the whole
        // collision pass, and widening IT would move physics this branch has no
        // business touching.
        //
        // MEASURED ON A RIG, and the rig is the scope of the claim: a flat floor
        // with pedestals of 18 different heights, so the cube meets a plain top
        // face with a different incoming vy each time (2026-09-13). Over the 18
        // landings -- full-size cube, normal gravity, flat top faces, incoming vy
        // -4.2 .. -10.6 -- the per-tick rotation step across the landing tick is
        // closer to GD's with this term in for 16 of them, and the two that are
        // not are rows where GD's own `rot` column wrapped by 720 degrees. The
        // residual with the term is 0.000 .. 0.002 degrees; without it the spin
        // fires in full and the residual runs to 6.6. Nothing outside that rig
        // was measured: mini, flipped gravity, slopes and moving surfaces are
        // untested here, and so is any effect on search. The corpus shape is
        // lv22 t=613 (`clamp=solid/land`, `clampuid=320`, grounded 0 on both
        // sides, vy -15 -> +11.18 = kCubeJump).
        const bool spinNow =
            rotPadSpin || (!c.grounded && !s.grounded && !cubeLandedThisTick);
        const uint8_t spinSign =
            rotPadSpin ? rotPadFlip : rotSignNow;
        // THE BASE IS c.rot, NOT s.rot, and every law below has to agree. A mode
        // portal earlier in this same tick may already have written the angle
        // (the edge table at the `c.mode = wantMode` site), and `State c = s` at
        // the top means the two are identical whenever it did not -- so reading
        // c.rot changes nothing except where a transition landed. Reading s.rot
        // silently discarded that write: measured lv2 t=12,893, a ship->cube
        // portal where GD reads 1.731 (reset to 0, then this law's one step) and
        // the model read 17.249 = the pre-portal 15.519 plus the same step. The
        // reset looked dead for every mode that HAS a rotation law, and looked
        // fine for robot/spider only because nothing writes their angle at all.
        // That is also where GD's 1.731 / 2.250 landings come from: setRotation
        // puts 0 (or flip?180:0) down and resetPlayerIcon re-latches the cube
        // rate, so updateRotation spends exactly one step in the same physics
        // step. It is not a separate mechanism to model -- it falls out of
        // applying this law to the base the transition just wrote.
        if (spinNow && !c.grounded) {
            const double rate = c.mini ? 2.25 : 1.7307692;
            c.rot = (float)((double)c.rot + (spinSign ? -rate : rate));
        } else {
            // ...and the rate is **0.13125 x GD's speed multiplier**.
            // Size-independent. Taking per-speed medians over 23,868 samples
            // (lv1-22's grounded 3-tick windows, mode=cube), at every one of
            // 0.7/0.9/1.1/1.3 rate / speed = exactly 0.13125:
            //   0.7 -> 0.09187   0.9 -> 0.11812   1.1 -> 0.14437   1.3 -> 0.17063
            // The old 0.1181 was the 0.9 row only, 1.44x short in the fast
            // band, leaving angle behind on every landing.
            const double tgt = std::round((double)c.rot / 90.0) * 90.0;
            const double rate = 0.13125 * speedMulForDx(useDx);
            c.rot = (float)((double)c.rot + rate * (tgt - (double)c.rot));
        }
    } else if (c.mode == 1) {
        // [2026-08-20 r37] **The ship's bank angle.** Until now the model only
        // turned the cube's spin, and the ship's `rot` stayed frozen at
        // whatever value it came in with (0 on a cold run). The SAT for rotated
        // portals/pads uses the player's `s.rot`, so that had been a lie the
        // whole time.
        //
        // `PlayerObject::updateShipRotation` (win 0x390c40) builds an angle
        // from the difference between getObjectRect()'s origin and the
        // previous tick's position [+0x9f8]/[+0x9fc] (0x390cfc-0x390d18:
        // xmm1 = dx, xmm3 = **-dy**, atan2 at 0x390da6), and does nothing if
        // the squared displacement is under a threshold (comiss at 0x390d7b).
        // The direction is cocos's clockwise-positive, so
        //     target = -atan2(dy, dx) [deg]
        // and it **eases linearly** toward it.
        //
        // Measured (all 104,873 ship ticks of gdref lv1-22, of which 89,251
        // have displacement): the coefficient is **exactly 0.0375**, and every
        // quartile is 0.0375 too.
        //   rot += 0.0375 * (target - rot)
        // Agreement **99.86%** (89,126/89,251). All 4 groups of normal/mini x
        // upright/flipped are 99.8-99.9%, so it depends on **neither size nor
        // gravity**. The 125 misses are only ticks whose y is clamp-driven,
        // like the ceiling-ramp ride from lv16 t=4,128 on, off by ~0.05 deg.
        const double ddx = x - xPrev;
        const double ddy = (double)c.y - (double)s.y;
        if (ddx != 0.0 || ddy != 0.0) {
            const double tgt =
                -std::atan2(ddy, ddx) * 180.0 / 3.14159265358979;
            c.rot = (float)((double)c.rot + 0.0375 * (tgt - (double)c.rot));
        }
    } else if (c.mode == 2) {
        // THE BALL. Until now its `rot` never moved at all, which the rate
        // comparison put at 97.7% of its 36,359 ticks disagreeing with GD --
        // and rotation is not cosmetic, because the SAT against a rotated
        // object turns the player's box by this angle.
        //
        // GROUNDED is staked every tick it is on the floor (GD re-enters
        // through hitGround / postCollision) so a speed portal crossed mid-roll
        // takes effect; the corpus agrees, the 1.1 and 1.3 tiers reading 3.1085
        // and 3.7551 against the formula's own values to four decimals.
        //
        // THE SIGN is the three-way XOR runBallRotation writes,
        // `neg = g XOR r XOR q` -- gravity (0x9bf), reverse (0x9c2) and
        // rotation-gameplay (0x9c3). Measuring it against the corpus gave
        // `flip` on 10,226 of 10,226 grounded ball ticks, but that is a
        // CROSS-SECTION and not the rule: no level rolls a ball with `rev` or a
        // rotation frame raised, so the two were indistinguishable there. The
        // XOR is written out here anyway, because the shipped shape of a rule
        // should be the rule.
        //
        // GROUNDED is re-staked every tick on the floor (GD re-enters through
        // hitGround / postCollision), so a speed portal crossed mid-roll takes
        // effect; the 1.1 and 1.3 tiers read 3.1085 and 3.7551 against the
        // formula's own values to four decimals.
        if (c.grounded) {
            c.rotStep = (float)ballRotRate(c.mini != 0, false, useDx);
            c.rotNeg = (uint8_t)((c.flip != 0) ^ (c.rev != 0)
                                 ^ (c.frame != 0));
        }
        // ...and then the stake is SPENT, grounded or not. Airborne it is
        // whatever the last event left, which is the whole point of carrying it:
        // only flipGravity and ringJump write the air value, so a ball that
        // left the ground off a step or a pad is still turning at the ground
        // rate up here.
        if (c.rotStep != 0.f)
            c.rot = (float)((double)c.rot
                            + (c.rotNeg ? -1.0 : 1.0) * (double)c.rotStep);
    }
    // RIDE. GD carries a standing player with the surface under it; the support
    // test above only asks "is a face still within 0.6 px of the foot" and
    // leaves y where it was. A platform that settles DOWNWARD under a standing
    // player therefore drifts away until the gap opens past that tolerance and
    // the model falls -- while GD is still standing on it.
    //
    // Measured on lv22 (2026-08-13, runR3's own plan): uid 254 settles
    // elastically under the cube at x~700. GD's y tracks its face
    // (236.870 -> 236.375 over t=530..542); the model holds 236.935 and goes
    // airborne at t=543, THREE TICKS before GD. That is a permanent vy offset of
    // 3 * 0.216 = 0.648, and by t=2,820 the two are 66 px apart in y -- which is
    // the whole of the x=3,956 wall (GD kills on the solid at (3975,345) that
    // the model's arc passes 100 px under).
    //
    // Gated hard: only a support that actually MOVED (dcy != 0), only when the
    // state came in standing and nothing else re-seated it (c.y == s.y), same
    // gravity, no ramp. A static floor is bit-identical.
    // ...and the ball's TAP does not cancel that tick's ride. GD carries the
    // rider in the collision pass and only then reads the button, so the tap
    // leaves from the face's NEW height. Both gates above go false on a tap
    // tick (`c.grounded` because the ball left, `c.flip == s.flip` because it
    // flipped), so the model tapped off the OLD height. Measured on lv22
    // t=5,940: GD taps from y=972.020, one more 0.129 px ride step below the
    // model's 972.149 -- and that 0.129 then rode along as a constant offset
    // for the whole rest of the section.
    const bool tapRide = ballFlippedThisTick && !c.grounded;
    // ...and neither does a JUMP. Same tick order as the tap: the collision
    // pass seats the rider on the face's NEW height and only then does the
    // button fire, so the jump leaves from the seated y. Measured on lv22
    // t=5,553 (robot held re-jump off a descending eased platform): GD rides
    // one more 0.171 px step down to 874.500 and jumps from there with
    // vy=+5.71; the model jumped off the OLD height and carried the 0.171 as
    // a constant offset for the rest of the segment. The `c.y == s.y` gate in
    // the condition below keeps the held CUBE re-jump out (it moves on the
    // jump tick, so its y is no longer the frozen surface value), and
    // `c.flip == s.flip` keeps out every impulse that changed gravity (the
    // ball's tap has its own `tapRide` path).
    const bool jumpRide = impulsedThisTick && !c.grounded && c.flip == s.flip;
    if (rideOn && s.grounded && c.y == s.y && !s.onSlope && !c.onSlope
        && (tapRide || jumpRide || (c.grounded && c.flip == s.flip))) {
        // TRIED AND REVERTED (2026-08-14): `c.y = s.y + rideDy` -- carry the
        // player by the face's own delta instead of re-seating it on the face,
        // so an offset a RE-ANCHOR came in with survives. It is a no-op from the
        // head (lv22's r24 replay 223 divergent ticks and r36's 68, both
        // unchanged) but the **regression went red**: lv19 lost a whole segment
        // (t=7,800, followed 400 -> 180 ticks). lv19's lift needs the re-seat --
        // GD carries the player exactly ON the face there, and letting it drift
        // by its entry offset is not the same ride.
        // So the mid-ride anchor problem (lv22 t=5,769: the re-seat drags the
        // player 2.559 px down on the first tick after the anchor) has to be
        // fixed on the ANCHOR side, not here.
        YSET(c.y) = (float)(rideFace + (s.flip ? -1.0 : 1.0) * pHalf);
        (void)rideDy;
    }
    if (c.mode == 0 && (c.grounded || cubeContact || cubeLandedThisTick)
        && !s.onSlope && !c.onSlope) {
        const double gs = c.flip ? -1.0 : 1.0;
        // on a jump tick c.y has already been frozen at the surface, so the foot
        // is still the contact face -- s.y and c.y agree there
        const double foot = (double)c.y - gs * pHalf;
        const double blockLen = gs * 30.0;   // GD: flipMod() * 30
        // The size was hardcoded to 1.0, so every mini player got the FULL-size
        // stair table. At speed 0.9 that is little = 120 instead of 90, and the
        // gate is exact (+/- threshold), so mini stairs simply never matched.
        // Measured on lv11 t=3926: the player leaves the block at cx=4995,cy=165
        // and lands on the one at cx=5085,cy=195 -- (dx,dy) = (+90,+30), the
        // mini `little` pattern exactly. GD advanced x by 2.2983 that tick
        // instead of 1.29825, i.e. the clamped +1.0000 nudge; the model advanced
        // the plain 1.29825 and was 1 px behind GD for the rest of the level.
        // ...and the SPEED that selects the table is this state's own, not the
        // layer's (see State::dx). They differ as soon as one branch takes a
        // speed portal and another does not.
        const StairParams sp =
            stairParamsFor((double)useDx, c.mini ? kMiniScale : 1.0);
        // contact set is decided on the pre-snap x (GD collects collisions
        // before resolving them); the nudge then accumulates within the tick
        const double xBase = x;
        double xs = xBase;
        // GD processes the touched solids in DESCENDING m_uniqueID. Verified on
        // the hooked lv3 run: 976/976 multi-contact ticks were in that order,
        // and the LAST one processed is what m_objectSnappedTo ends up as. It is
        // not cx order -- picking ascending cx would take the wrong object on
        // 816 of those 976 ticks, which shifts the next stair's dx by 30 and
        // silently turns a matching pattern into a non-matching one.
        // At most 4 solids can touch a 30px box, so an insertion sort is fine.
        // ...within a 100 px SECTION, that is. GD walks its sections from the highest x section
        // down and, inside one, from the highest y section down, and only then by descending uid.
        // Measured with snaptrace against three keys: SubZero 4002 (a 20,628-tick plan) 3,985 of
        // 3,985 multi-contact ticks, lv3's clear 1,281 of 1,281; uid alone fits lv3 but misses 63
        // on 4002, and 50/150 px sections miss hundreds. The case that needed it: 4002 t=866-888,
        // a slab (uid 233, y 208.5) and a 1.5 px wall (uid 234, y 195) in the same x section --
        // GD takes 233 then 234, so the wall is what it has snapped to at take-off, and the next
        // landing matches the `little` stair against it (+1.0 px). Taking 234 first left the slab
        // as the model's snap object, no stair matched, and the player walked off the next ledge a
        // tick later than GD -- a jump that GD's player, already airborne, never made.
        auto snapSec = [](double v) { return (long long)std::floor(v / 100.0); };
        auto snapBefore = [&](const Obj* a, const Obj* b) {
            const long long ax = snapSec(a->cx), bx = snapSec(b->cx);
            if (ax != bx) return ax > bx;
            const long long ay = snapSec(a->cy), by = snapSec(b->cy);
            if (ay != by) return ay > by;
            return a->uid > b->uid;
        };
        const Obj* touch[8];
        int nTouch = 0;
        for (const Obj* o : *K.near) {
            if (o->type != 0) continue;
            if (std::fabs(xBase - o->cx) > o->hw + pHalf + kContactEps) continue;
            const double face = c.flip ? (o->cy - o->hh) : (o->cy + o->hh);
            if (std::fabs(foot - face) > 0.6) continue;
            if (nTouch == 8) break;
            int j = nTouch++;
            for (; j > 0 && snapBefore(o, touch[j - 1]); --j) touch[j] = touch[j - 1];
            touch[j] = o;
        }
        for (int ti = 0; ti < nTouch; ++ti) {
            const Obj* o = touch[ti];
            const double xIn = xs;
            const double sdIn = (double)c.snapDist;
            const Obj* prevObj = c.snapObj;
            // A ONE-WAY platform never produces the nudge. Counted over GD's own
            // snaptrace for lv1/3/11/13/19 (15,530 calls):
            //   prev type 0  -> obj type 0    105 moved / 15,313 still
            //   anything with a type 21       **0 moved / 108 still**
            // lv13 t=2142 is one of those: prev (2685,195) and obj (2775,255)
            // are both one-ways, dx=90 dy=60 matches the `big` pattern exactly,
            // and GD still reports d=+0.0000. The model took the pattern and
            // moved x by the clamped +1.0000, and lv13 ran a pixel ahead of GD
            // for the rest of the level (its whole remaining divergence).
            // The bookkeeping still happens -- GD's log updates `sd` on these
            // calls (15.7939 -> 8.8877 at that tick) -- so only the displacement
            // is skipped, not the snapObj/snapDist update below.
            // --snaponeway (speed.hpp): GD's gate is the PREVIOUS snap object's type alone
            const bool onewayPair =
                c.snapObj != nullptr && c.snapObj->oneway;
            if (c.snapObj != nullptr && c.snapObj != o && !onewayPair) {
                const double dx = o->cx - c.snapObj->cx;
                const double dy = o->cy - c.snapObj->cy;
                if ((std::fabs(dx - sp.little) <= sp.threshold
                     && std::fabs(dy - blockLen) <= sp.threshold)
                    || (std::fabs(dx - sp.down) <= sp.threshold
                        && std::fabs(dy + blockLen) <= sp.threshold)
                    || (std::fabs(dx - sp.big) <= sp.threshold
                        && std::fabs(dy - 2 * blockLen) <= sp.threshold)) {
                    double d = (o->cx + (double)c.snapDist) - xs;
                    d = std::max(-sp.threshold, std::min(sp.threshold, d));
                    // GD calls setPositionX, so the result lands back in the
                    // same float the next tick accumulates from
                    c.xAbs = (float)(xs + d);
                    xs = (double)c.xAbs;
                }
            }
            c.snapObj = o;
            c.snapDist = (float)(xs - o->cx);
            if (g_snapOut) {
                char b[256];
                snprintf(b, sizeof(b),
                    "snap: t=%lld y=%.3f prev=(%.2f,%.2f) obj=(%.2f,%.2f) "
                    "dx=%.2f dy=%.2f x=%.4f->%.4f d=%+.4f sd=%.4f->%.4f",
                    (long long)K.t, (double)c.y,
                    prevObj ? prevObj->cx : 0.0, prevObj ? prevObj->cy : 0.0,
                    o->cx, o->cy,
                    prevObj ? o->cx - prevObj->cx : 0.0,
                    prevObj ? o->cy - prevObj->cy : 0.0,
                    xIn, xs, xs - xIn, sdIn, (double)c.snapDist);
                *g_snapOut << b << "\n";
            }
        }
    }
    // Speed portals, decided on THIS state's own x and y (see State::dx) with
    // the same box-overlap rule as every other portal. The new dx only takes
    // effect from the next tick, because c.dx is read at the top of the step.
    if (g_spdDbg)
        std::printf("spddbg t=%lld x=%.3f dx=%.5f window=%zu\n",
                    (long long)K.t, x, (double)c.dx,
                    K.speeds ? K.speeds->size() : (size_t)0);
    if (K.speeds) {
        // ...with the PORTAL's contact half, not the collision one. This loop
        // was the only portal path still passing `pHalf`, and for a mini wave
        // those differ: 2.0 against 3.0 (kWaveContactHalfMini = GD's own 6x6
        // getObjectRect, which the decompiled collisionCheckObjects uses for
        // every special object -- the type switch that separates a speed portal
        // from a mode portal is AFTER the box test, so there is no mechanism by
        // which the two would test different player boxes).
        // Measured on lv21's 0.9 portal at (19587.1,239.18) (rot 44, and the
        // level holds a 1.52x-scaled duplicate of it at the same centre, which
        // is the copy that fires): GD switches at t=14,920 x=19,545.1 and the
        // model switched at t=14,950 x=19,593.5, THIRTY TICKS and 48 px late,
        // running that whole stretch 24% fast. With the portal half it fires on
        // GD's tick. Read out of a --spddbg trace naming the gate: it is the
        // oriented (SAT) gate that rejects, and a hand-rolled SAT over the same
        // trace reproduces the model's verdict on all 68 candidates, so the box
        // and not the test was wrong.
        // The 2.0 was kept here on purpose -- constants.hpp says "the SPEED
        // portal still wants the 2.0 bracket" -- but that bracket (lv20's
        // uid4303, half < 2.466) was written on the FULL-SIZE wave path and
        // computed with an AXIS-ALIGNED player square (`25.5 + 1.41077*half`).
        // Both are superseded: GD tests the sprite-rotated box, and the model
        // already fires that site on GD's exact tick with the full-size 5.0.
        // Rotated objects re-read the player's box within the pass (r32) while
        // axis-aligned ones keep the entry snapshot -- the same split the mode
        // portal pass makes above.
        for (const Obj* sp : *K.speeds) {
            const double pHalfSp = pHalfPortal;
            // --spddbg: what each gate computed, per candidate, per tick. The
            // window itself is printed too (a portal that never appears here is
            // a collection problem, not a gate one).
            if (g_spdDbg)
                std::printf("spddbg t=%lld x=%.3f y=%.3f uid=%d id=%d "
                            "cx=%.2f cy=%.2f hw=%.2f hh=%.2f ori=%d obb=%d "
                            "ohw=%.3f ohh=%.3f rc=%.5f rs=%.5f "
                            "pHalf=%.2f |dx|=%.2f need<%.2f g1=%s\n",
                            (long long)K.t, x, (double)c.y, (int)sp->uid,
                            (int)sp->id, sp->cx, sp->cy, sp->hw, sp->hh,
                            (int)sp->oriented, (int)sp->obbOk,
                            sp->ohw, sp->ohh, sp->rc, sp->rs, pHalfSp,
                            std::fabs(x - sp->cx), sp->hw + pHalfSp,
                            (std::fabs(x - sp->cx) >= sp->hw + pHalfSp) ? "REJ"
                                                                        : "pass");
            if (std::fabs(x - sp->cx) >= sp->hw + pHalfSp) continue;
            // yColl, not c.y: the entry-snapshot registers (see its
            // declaration by pHalfPortal). c.y here already carries this
            // tick's landing clamp and any mid-pass size re-seat, which GD's
            // registers never see -- both measured 1-tick-early speed fires
            // (lv18 t=14,612 / lv19 t=20,309) came from exactly that.
            // ...EXCEPT past a teleport: the destination is another section =
            // a later collisionCheckObjects call of the same tick with FRESH
            // registers, so a destination speed portal (uid past the
            // teleport's, the same gate the portal pass uses) fires on the
            // arrival tick at the arrival y. Measured on lv20 t=7,282: the
            // 747 pair drops the cube at y=161 and GD's very next x step is
            // already 1.95 -- the snapshot-only form ran it a tick late and
            // shrank the t=7,000 segment 286 -> 283.
            const double ySp = (teleportedThisTick && sp->uid > teleUid)
                                   ? (double)c.y : yColl;
            // [2026-08-21 r77] **A rotated speed portal is judged with "the
            // current box".**
            // The entry snapshot (yColl) and the axis-aligned player box are the
            // measurements for **axis-aligned** portals (lv18 t=14,612 / lv19
            // t=20,309 -- the "shadows" of the note). Rotated objects, per r32's
            // disassembly, re-call getOrientedBox() within the same pass =
            // current position + the player's rotation.
            // Measured lv19 t=19,491 (wave, the rot=-41 0.5x portal uid13186):
            // GD fires on the same tick as the mode/size portals (portfire
            // t=19,491), and that tick's move is still at the old speed. The
            // model hit 1 tick early with the start-of-tick y + an unrotated
            // box, and census `m4/.../gdm3/sp0.7` edy +0.252 remained to the
            // end. Same formula as the portal pass's pRotHere.
            // [2026-09-06] ...minus the one-step advance, deleted at all four
            // sites that carried it (the pad site has the mechanism,
            // constants.hpp's g_noSatRotRaw the measurement and the switch).
            // No oriented speed portal in the corpus separates the two arms:
            // lv18's uid 14054 is the one a cube reaches and it fires on the
            // same tick either way, so this site is undecided by the corpus and
            // moves because all four carry one expression, not on a witness.
            if (sp->oriented) {
                double pRotSp = (double)s.rot;
                if (g_noSatRotRaw && s.mode == 0)
                    pRotSp += (s.rotNeg ? 1.0 : -1.0)
                              * (s.mini ? 2.25 : 1.7307692);
                const bool hit = orientedHit(*sp, x, (double)c.y, pHalfSp,
                                             pRotSp);
                if (g_spdDbg)
                    std::printf("spddbg   g2 uid=%d pRot=%.3f hit=%d%s\n",
                                (int)sp->uid, pRotSp, (int)hit,
                                hit ? "" : "  <- REJECTED HERE");
                if (!hit) continue;
            }
            const double gapY =
                std::fabs(ySp - sp->cy) - (sp->hh + pHalfSp);
            if (g_spdDbg)
                std::printf("spddbg   g3 uid=%d ySp=%.3f cy=%.2f hh+pHalf=%.2f "
                            "gapY=%.3f %s\n",
                            (int)sp->uid, ySp, sp->cy, sp->hh + pHalf, gapY,
                            gapY >= 0.0 ? "<- REJECTED HERE"
                                        : "-> FIRE (dx from the next tick)");
            if (gapY >= 0.0) {
                // A branch that slips OVER a speed portal by a hair is dropped,
                // the same way g_portalDodgeMin drops one that slips past a
                // mode portal. Off by default (0) because the miss here is not
                // sub-pixel and killing it removes real routes.
                //
                // Why the knob exists: lv19's plan flies 1.1-2.4 px above the
                // 1.1x portal at (26,161,333) and runs the rest of the level at
                // 0.9, which puts it at the moving gate at x=27,690 about 160
                // ticks after the gate's own window. Measured against a working
                // replay of the same level, whose speed log reads
                // t=18,614 x=26,138 -> 1.1 where the plan's has nothing at all.
                // The search HAS the branch that dips into the portal; it has
                // no reason to prefer it, because the timeline it plans against
                // was recorded from a run that did not take it either -- the
                // loop confirms its own choice.
                if (g_speedDodgeMin > 0.0 && gapY < g_speedDodgeMin
                    && std::fabs(c.dx - dxForSpeedId(sp->id)) > 1e-6)
                    DIE("speed/hairline-dodge", sp);
                continue;
            }
            c.dx = dxForSpeedId(sp->id);
        }
    }
    // [2026-08-19 D9, REMOVED 2026-09-03] The leave-face mark used to arm here:
    // `c.mode == 2 && c.frame != 0 && s.grounded && !c.grounded && c.flip !=
    // s.flip && !impulsedThisTick` set `c.pBallOff`, and the next tick wrote
    // vy := -1.000. Four independent reasons to take it out, none of them a
    // preference:
    //   binary  -- every writer of `this+0x9a0` was enumerated on 2026-09-03
    //     (the 42 setYVelocity xrefs included) and not one writes a fixed
    //     +-1.0. The nearest, postCollision 0x38da69, writes the RECORDED slope
    //     velocity on leaving a ramp, gated on "was on a slope, is not now" --
    //     not on a gravity flip.
    //   positive witness -- lv22 t=6,307 belonged to a worldline that has been
    //     re-solved away; the verified solution is in free fall there.
    //   negative witness -- lv16 t=4,237 (GD 0.0000, then -0.129/tick) has to
    //     keep matching, and does: it is Section A of the ball/portal table.
    //   in situ -- five arms at the exact configuration this fired in (lv22,
    //     rotated frame, the ball leaving the receding block through gravity
    //     portal uid13833) have GD writing plain gravity at 6,292 (-0.0650) and
    //     -1.000 nowhere.
    // Cost of keeping it: zero firings across the 22 verified solutions, so its
    // removal is bit-identical on the corpus and shows only where it was wrong.
    // [2026-08-21 r52] Carry "the tick the rotation frame changed" one tick
    // forward. Used only by the next tick's gravity-portal gate (the note at the
    // declaration).
    // **Not lowered while the suppression is active**: the player passes through
    // the portal's box for many ticks, so lowering after 1 tick merely produced
    // the same re-fire on the next (r52's measurement: the divergence just
    // shifted 1 tick, t=6,323 -> 6,324).
    // [2026-08-21 r61] **GD sees the portal's flip first and then seats on the
    // ramp.** The model's tick order is "ramp -> portal", so a ride on the same
    // tick as the flip is resolved still in the old (upside-down) orientation
    // and vy survives 1 tick.
    // Measured lv22 t=8,236 (spider stuck to floor ramp uid17788 while gravity
    // portal uid8817 returns it upright): GD has vy=0 / onGround=1 on the same
    // tick. The model carried 1.704 (= the just-flipped value; GD's `pfg:` line
    // shows the same number) for 1 tick, census `m6/.../slope+1.00/ride2`
    // edvy -1.704.
    // The gate is just two things -- "this tick's ride was the upside-down-side
    // branch" + "the portal returned upright" -- limited to the portal-order
    // hole itself.
    if (rodeFlipped && c.onSlope && !c.flip && c.flip != s.flip) {
        VYSET(c.vy) = 0;
        c.grounded = 1;
    }
    // [2026-08-21 r66] **The ceiling ramp's push-down release places vy on the
    // next tick.** GD keeps m_isOnSlope set even during the push-down (slp:
    // lines), and the release runs the slope-exit launch machinery as is:
    //   vy := -slopeExitVy(|m|, mode, dx, mini) x slopeRampFactor(pressed ticks)
    // applied **max-down** (do nothing if free fall is already faster -- this is
    // why nothing appears at m=0.5 or sp0.7). Measured on the calibration rig
    // ceilrel x 3 speeds (sp0.7/0.9/1.1, 4 kinds of d): in all 14 set events
    // k = the pressed tick count matches exactly, q = base/24 is strictly
    // proportional to dx, base = cube launch x 0.75 (the ship/UFO/swing flag
    // family). The corpus's lv20 t=18,836 is also exactly base(sp1.1) x 10/24 =
    // -2.877 (pressed section 18,826..18,835 = 10 ticks).
    // Modes are only the measured ship/UFO/swing. The cube is **not included**:
    // the corpus (lv18 t=20,491, r40) measured "pure free fall after the
    // release". ball/wave are unmeasured (the rig cannot catch them). y is
    // already integrated this tick with the old vy, so it is untouched (GD has
    // the same order).
    if (ceilPressedNow) {
        c.ceilT = (uint8_t)std::min<int>((int)s.ceilT + 1, 200);
        // --ceilreleasemode [2026-09-19]: GD times the ride from the air->slope
        // transition (+0x598, written only while !m_wasOnSlope at 0x390767), and
        // its one isOnSlope bit does not tell a floor ride from an underside
        // press -- so a body going straight from riding a ramp's top into a
        // ceiling ramp's underside keeps the ride's clock (lv16 t=9,879: 29
        // ticks, factor 1.0). Remember the mode too: the impulse +0x9b4 is
        // computed for the mode of the contact, not the mode the body has when
        // it leaves (a cube portal on the same tick, lv16 t=9,879 -> 9,880).
        if (s.onSlope && s.ceilT == 0)
            c.ceilT = (uint8_t)std::min<int>(
                std::max<int>((int)c.ceilT, (int)s.slopeT + 1), 200);
        c.ceilMode = ceilPressMode;
        c.ceilM4 = (uint8_t)std::min<int>(
            255, (int)std::lround(std::fabs(ceilPressM) * 4.0));
    } else if (s.ceilT > 0) {
        // [2026-08-21 r81] The spider receives it too. Measured lv22 t=8,273 (a
        // 14-tick m=-2 push-down chain, sp1.1): GD places vy := -7.621.
        // 7.621 = base x 14/24 -> base 13.064 -- the very shape of this formula.
        // [2026-08-28] **...and not on a tick the body has come to rest.** The
        // release is a launch off the surface that was pressing, and a body that
        // ended this tick standing on something is not leaving anything: GD
        // holds it still and the launch appears on the tick it actually goes.
        // Measured on lv20 t=17,110 (the dual's second body, flipped, coming out
        // of the ceiling ramp chain at x=25,752 onto slope uid13913):
        //   GD    t=17,110 p2y=295.9665 p2vy=**0.000** p2ground=1
        //         t=17,111 p2y=295.9955 (+0.029 = 0.225 x 0.129, the launch
        //                  convention's "y moves with the OLD velocity")
        //                  p2vy=**-2.762**
        //   model t=17,110 y2=295.9665 (right) but vy2=-2.762 already, while
        //         reporting grounded2=1 -- a launch velocity on a resting body
        // and the tick it costs is what leaves the model's p2 1.585 px clear of
        // the slope GD kills it on five ticks later.
        if (c.grounded && !s.grounded) {
            // landed THIS tick: the launch waits one tick, held not dropped, so
            // the same value comes out where GD puts it (t=17,111 above). A body
            // that was already resting is not this case -- gating on `grounded`
            // alone withheld the launch for as long as the body stayed down, and
            // cost lv22 its whole run (cold, t=19,037 -> stuck at t=2,783).
        } else {
            // --ceilreleasemode: gate and value on the mode of the press.
            const uint8_t relMode = s.ceilMode;
            if (relMode == 1 || relMode == 3 || relMode == 6 || relMode == 7) {
                const double exU = rawQ(slopeExitVy((double)s.ceilM4 / 4.0, relMode,   // speed.hpp
                                                    useDx, c.mini != 0)
                                        * slopeRampFactor((int)s.ceilT));
                if ((double)c.vy > -exU) {
                    VYSET(c.vy) = (float)-exU;
                    CLAMP0("ceil/release");
                    // [2026-09-06] ...and it sets GD's velocity-limit
                    // exemption, for the same reason the two uphill/downhill
                    // sites above do: this IS the slope-exit launch machinery
                    // (the comment at the head of this block says so), and
                    // that machinery is postCollision 0x38d966 -> boostPlayer
                    // 0x39ff0a, which raises [player+0x952] before it writes
                    // vy. One GD event, three model sites -- which surface the
                    // body left decides which of them runs.
                    // WITNESS: lv16 t=8,913 is a DUAL, and its two halves come
                    // out of the mirrored ramp pair through DIFFERENT sites --
                    // p1 through the uphill launch (onSlope 1 -> 0) and p2
                    // through this one (ceilT2 38 -> 0). GD decays both at
                    // -0.086/tick for six ticks; without this line only p1
                    // reproduced and p2 stayed pinned at the terminal.
                    if (boostLatchMode(c.mode)) c.boost = 1;
                }
            }
            c.ceilT = 0;
            c.ceilM4 = 0;
        }
    }
    // [2026-08-21 r93] **The launch of a ride interrupted by a warp appears on
    // the next tick.** The value is computed on the interrupting tick and stored
    // in pExitVy (State::pExitVy). The same "place vy on the next tick" frame as
    // ceil/release, placed **after all the clamps** (GD too writes only vy
    // without moving y: lv21 t=16,714 stays og=0 / y=226.500 with +5.226, pushed
    // back onto the ceiling to 0 the next tick).
    if (s.pExitVy != 0.f) {
        VYSET(c.vy) = s.pExitVy;
        c.grounded = 0;
    }
    // GD's flip stamp (player+0x800), as an age. Written by flipGravity, which
    // D4 measured as firing only when the value REALLY changes -- so "c.flip
    // differs from s.flip at the end of the tick" is the same event, and it is
    // one site instead of the nineteen that assign c.flip. Everything that
    // flips gravity therefore grants the grace: gravity portal, blue pad,
    // gravity orb, gravity teleport. Yellow and pink pads do not flip, so they
    // do not stamp it -- which is the discriminating case in C7 and the reason
    // the old `!impulsedThisTick` guard could not work.
    // Compared through gdUpOf and not on the raw flip: in a rotated frame the
    // model writes c.flip as a function of the frame, and gdUpOf is the
    // function that turns that back into GD's own upsideDown (frame 3 is the
    // mirror). Diffing the raw bit would stamp a grace on a frame change, which
    // is not a gravity flip and never reaches flipGravity.
    c.flipT = (gdUpOf(c) != gdUpOf(s))
                  ? 0
                  : (uint8_t)std::min<int>(kFlipGraceTicks, (int)s.flipT + 1);
    // --cubeceilgrace: the mode-switch clock, kept like flipT above.
    c.modeT = (c.mode != s.mode)
                  ? 0
                  : (uint8_t)std::min<int>(kFlipGraceTicks, (int)s.modeT + 1);
    // [2026-08-22 r106] **Crush: touching a solid's interior with the inner box
    // is death.** (The full measurement table at kCrushHalf's declaration).
    // The rule that replaces, with physics, lv22's dead end at x=20,130 -- "the
    // phantom that survives with no input until t=17,025 because the model has
    // no crush" (the origin of the driver's 20130,20270 band). Placed
    // **after** all position resolution: a state pushed out by landing / snap /
    // ride re-seating is not killed (the seat centre is face+-pHalf, and the
    // inner box never reaches within pHalf-4.5 >= 4.5px of the face). Applies
    // to axis-aligned solids only -- slopes have different semantics
    // (push-down/launch), oneways have a measurement surviving 15px embedded
    // (the Obj::oneway note), and non-90-degree rotations have lying bboxes
    // (the Obj::oriented note). Rotated sections (frame != 0) are excluded,
    // unmeasured.
    // [004b, GATE WITHDRAWN 2026-09-01] The flip grace belongs here too -- it is
    // one guard in GD, covering this overlap and the side test's alike -- and it
    // was taken back out with it. See the note at the side test for the
    // measurement, the cost, and what 004b has to model first. The band it acted
    // in here is thin (`hh < |dy| < hh + kCrushHalf`), and none of the nine
    // probe points was taken in it, which is its own reason to wait.
    // [2026-09-14] ...AND THE INNER BOX IS THE ONE THAT MODE ACTUALLY HAS.
    // 4.5 is the CUBE's inner box. GD builds all of these with one function --
    // getObjectRect(0.3, 0.3) -- so the inner box is 0.3 of the vehicle rect:
    // cube 30x30 -> 9x9 -> half 4.5, wave 10x10 -> 3x3 -> half 1.5. It does not
    // scale with vsize because PlayerObject::setScale bypasses the scale cache
    // the explicit-multiplier overload reads, which is why the rig found 4.5 for
    // the mini cube as well and read the whole family as size-independent.
    // The wave's 1.5 is MEASURED on its own, and from the other side of the same
    // box: kWaveKillHalf, bisected to 0.01 px on two levels, two object ids, both
    // sizes and both faces. Its note already says this rule is "the same box seen
    // from the side", so the two constants are one measurement.
    // WHAT 4.5 COST THE WAVE: its centre sits only 5.0 from a face it is seated
    // on, so a 4.5 box clears that face by 0.5 px (a cube clears it by 10.5) and
    // the rule fired on a wave that was still legally riding. Four references --
    // lv17_t7876, lv19_t19192, lv20_t2150, lv20_t2700, every one a wave -- died
    // of `crush` exactly 2 ticks before GD, which killed them on the side test.
    // 35/47 -> 39/47, and the one reference the rule kills correctly
    // (lv19_t15353) is a ufo and is untouched.
    // The spider's 27x27 would be 4.05 by the same mechanism. NOT changed here:
    // nothing has measured it, and no reference moves either way.
    const double crushHalf = (c.mode == 4) ? kWaveKillHalf : kCrushHalf;
    if (!dead && s.frame == 0) {
        const double cyF = (double)c.y;
        for (const Obj* o : *K.near)
            if (o->type == 0 && !o->slope && !o->oneway && !o->oriented
                && std::fabs(x - o->cx) < o->hw + crushHalf + 1e-6
                && std::fabs(cyF - o->cy) < o->hh + crushHalf + 1e-6
                && !footFaceContact(*o, c, pHalf)) {   // --faceclass (speed.hpp)
                if (flipGraceSeat(*o, c, s, ballFlippedThisTick && input && !s.action, pHalf)) {   // --flipgrace (speed.hpp)
                    seatOnNearFace(*o, c, pHalf);
                    CLAMP0O("crush/flipgrace", o);
                    continue;
                }
                DIE("crush", o);
                break;
            }
    }
    // The BALL's tap spends the press too: GD's ball arm of updateJump ends with
    // `flipGravity, vy *= 0.6, m_jumpBuffered = 0`. Cleared once here rather than
    // at each of the four tap sites, which is the same thing -- ballFlippedThisTick
    // is exactly "the ball tapped on this tick".
    if (ballFlippedThisTick) c.jumpBuf = 0;
    // ...and +0x985 stays 0 while the button is held (State::holdDead; speed.hpp, hold latch)
    // (the spider's tap too: spiderTestJumpInternal ends with +0x985 = 0)
    if ((ballFlippedThisTick || spiderWarpedThisTick) && input) c.holdDead = 1;
    c.frameChg = (gravHoldOver || c.frame != s.frame) ? 1 : 0;
    return c;
}

// Swap the primary player's fields with the second one's. Running the SAME
// stepOne twice (once per half) is what keeps the dual honest: the two halves
// see different geometry, so nothing about the second can be derived from the
// first once either of them touches anything.
inline void swapHalves(State& s) {
    std::swap(s.y, s.y2);
    std::swap(s.vy, s.vy2);
    std::swap(s.slopeM, s.slopeM2);
    std::swap(s.snapDist, s.snapDist2);
    std::swap(s.grounded, s.grounded2);
    std::swap(s.flip, s.flip2);
    std::swap(s.ringHold, s.ringHold2);
    std::swap(s.pressSpent, s.pressSpent2);
    // ...and the velocity-limit exemption, which became per-half on 2026-09-06
    // (State::boost2). lv16 t=8,913 is a DUAL ship whose two halves both carry
    // it; left shared, p2's step would read p1's byte and its own answer would
    // be dropped by the merge in fixup.hpp.
    std::swap(s.boost, s.boost2);
    std::swap(s.onSlope, s.onSlope2);
    std::swap(s.slopeT, s.slopeT2);
    std::swap(s.rideLanded, s.rideLanded2);
    std::swap(s.mode, s.mode2);
    std::swap(s.mini, s.mini2);
    // ...and WHICH RAMP each half is riding. slopeUid0/slopeUidNow were left behind, so the
    // second body's step read the FIRST body's ramp uid -- which decides the seam hand-over
    // clamp (rTopIsSeam ... sp->uid != s.slopeUid0) and whether a re-acquisition counts as the
    // same ride. Two halves on mirrored ramps never share a uid, so the comparison was answering
    // about the wrong body every time.
    std::swap(s.slopeUid0, s.slopeUid02);
    std::swap(s.slopeUidNow, s.slopeUidNow2);
    std::swap(s.ceilT, s.ceilT2);
    std::swap(s.ceilM4, s.ceilM42);
    std::swap(s.snapObj, s.snapObj2);
    std::swap(s.usedOrb, s.usedOrb2);
    std::swap(s.usedOrbOld, s.usedOrbOld2);
    for (int i = 0; i < 3; ++i) std::swap(s.usedOrbHist[i], s.usedOrbHist2[i]);
    std::swap(s.holdDead, s.holdDead2);
    for (int i = 0; i < 3; ++i) std::swap(s.portSeen[i], s.portSeen2[i]);
    for (int i = 0; i < 4; ++i) std::swap(s.touchRing[i], s.touchRing2[i]);
    std::swap(s.touchRingT, s.touchRingT2);
    std::swap(s.portalLatch, s.portalLatch2);
    for (int i = 0; i < 4; ++i) std::swap(s.usedPad[i], s.usedPad2[i]);
}

// Touch-trigger boxes (see TouchTrig): plain rect overlap of the player's box
// with the trigger's, which is what GD was measured to do. Once a bit is set it
// stays set -- the doors do not close again, and a state that could un-touch a
// trigger would be a different world line, not the same one.
// The dual's second body is deliberately not tested: no level has put a touch
// trigger inside a dual section, and firing from the mirrored half would have to
// be threaded through swapHalves as well.
// `preY` is where the player was BEFORE this tick's button effects. GD's tick
// is update -> collisions (triggers) -> buttons, so a SPIDER that teleports on
// this tick has already been counted as touching whatever its old position was
// inside. Measured on lv22 t=1,753 (first rotated section, frame 1): the player
// is at v=2,266.5 and the box uid1417 (world 2277,273 -> frame u=-273,v=2277)
// is du=34.41 / dv=10.50 away, inside 21.165+13.5 and 15+13.5 -- it fires in GD
// and the spawn cascade under it moves the spike uid17571 by -150 from t=1,815.
// The model tested the POST-teleport v=2,143.5 (dv=133.5), never fired, and so
// kept that spike frozen at its t=1 position 150 px away from where GD has it --
// a phantom hazard sitting in the only lane out of the section.
// THIS READS p1's POSITION ONLY. In a dual section a box that only the second
// player enters is one the model can never fire -- the DP then plans against a
// world where that trigger does not exist, with or without an anchor, and a
// fire tick carried in from GD would be a value the step function cannot
// reproduce going forward.
//
// COUNTED 2026-09-04, and the corpus does not exercise it. Only lv20 has both
// a dual portal and touch boxes at all (lv16 and lv17 have portals and no
// boxes; lv19 and lv22 have boxes and NO dual portal, so their 3 and 155 can
// never be reached by a second player). On lv20, GD's own trajectory puts the
// two players against its six boxes for 805 dual ticks and p2 enters none of
// them (oneoff/py/p2boxes.py).
//
// So this is a real limit on what the model can express, with zero witnesses.
// It is recorded rather than fixed because adding the p2 arm increases forward
// firing -- geometry and deaths change -- and there is nothing to measure the
// change against. Whoever gives it a witness should read fullreplay and
// deathref, not the seeding check.
//
// AND NOTHING WAS WATCHING FOR IT. The anchor-seeding check compares a seeded
// state against the model's own whole run, and lv20's whole run died at
// t=1,157 while its dual section starts near t=17,119 -- so that check could
// not reach the one place in the corpus where this could bite. There was no
// detector that would name this the day it started to matter; the condition
// for one existing was lv20's replay reaching t~17,119.
//
// [2026-09-21] **THAT CONDITION IS MET.** With the three fidelity fixes on by
// default (0e5bd3a) lv20's whole-run replay completes the level, so the dual
// section is on the model's own trajectory rather than only on GD's. Re-taken
// there with --p2touch: 805 dual ticks, and p2 enters a box on NONE of them --
// the same 805 and the same zero the 2026-09-04 count got off GD's dump. So
// the reading is unchanged and it is now a reading of the run the corpus
// actually makes, which is what "nothing is watching" was about.
//
// The reason to leave it alone is therefore NOT "something will catch it". It
// is that only lv20 can be affected at all, it measures zero there over 805
// dual ticks, and lv22 -- the 155-box level -- has no dual portal, so it is
// excluded by the level data rather than by a measurement that might age.
// `btnHeld`: the button as the game's collision pass sees it on this tick -- the PARENT's input,
// since a tick runs update, collisions, then buttons (a press on tick t is first seen by t+1's
// collisions). Read only by a toggle block (TouchTrig::press): measured on SubZero 4003's uid
// 4001, a tap at t=7,776 fires it on 7,777 and a press held from before it fires it on the first
// tick the boxes overlap.
inline void markTouched(State& c, const StepCtx& K, double preY, bool btnHeld) {
    if (!K.trigs || K.trigs->empty()) return;
    const double half = playerHalf(c.mode, c.mini != 0);
    for (const auto& tb : *K.trigs) {
        if (c.trig & tb.second) continue;
        const TouchTrig* T = tb.first;
        // A COUNT trigger has no box to enter: the item counter fires it, from
        // wherever the player happens to be (cli.hpp's item test). Nor does a
        // TAP trigger: the press fires that one, once its x is behind.
        if (T->count >= 0 || T->tap) continue;
        // ...and a toggle block needs the button down while the boxes overlap.
        if (T->press && !btnHeld) continue;
        // --p2touch: WOULD THE SECOND PLAYER HAVE ENTERED THIS BOX.
        //
        // This function reads c.xAbs and c.y and nothing else, so in a dual
        // section only p1 can ever enter a box: a trigger p2 alone reaches is
        // one the DP plans against as if it never fires, anchor or no anchor.
        // That is a hole in what the model can express rather than in how an
        // anchor is seeded, so it is counted before anything is carried from
        // GD -- seeding a bit the step function can never set forward would
        // make an anchor claim what a whole run of the same plan would not.
        //
        // Diagnostic only: it prints and changes nothing. Both players share
        // an x (the portal makes the second at the same point), so the test is
        // p2's own half against y2.
        if (g_p2Touch && c.dual) {
            const double half2 = playerHalf(c.mode2, c.mini2 != 0);
            const bool p2in = std::fabs((double)c.xAbs - T->cx) < T->hw + half2
                              && std::fabs((double)c.y2 - T->cy) < T->hh + half2;
            const bool p1in = std::fabs((double)c.xAbs - T->cx) < T->hw + half
                              && (std::fabs((double)c.y - T->cy) < T->hh + half
                                  || std::fabs(preY - T->cy) < T->hh + half);
            if (p2in)
                std::printf("p2touch: t=%lld box=0x%llx p1=%d p2=1\n",
                            (long long)K.t, (unsigned long long)tb.second.word(0),
                            p1in ? 1 : 0);
        }
        // A box that moves with its group (TouchTrig::followIdx) is tested where
        // it is now, not where it was placed.
        double bx = T->cx, by = T->cy;
        if (T->followIdx >= 0 && g_touchFollowObjs
            && (size_t)T->followIdx < g_touchFollowObjs->size()) {
            const Obj& fo = (*g_touchFollowObjs)[(size_t)T->followIdx];
            bx += (double)fo.cx - T->followX0;
            by += (double)fo.cy - T->followY0;
        }
        if (std::fabs((double)c.xAbs - bx) < T->hw + half
            && (std::fabs((double)c.y - by) < T->hh + half
                || std::fabs(preY - by) < T->hh + half)) {
            c.trig |= tb.second;
            c.trigT = (int32_t)K.t;
            {
                // Level-wide first-entry tick per box (see g_touchFireT):
                // the state only remembers its LAST box, and the switch
                // band's per-box delay needs each punch's own tick.
                const int b = touchBitIndex(tb.second);
                if (g_touchFireT[b] < 0) g_touchFireT[b] = (int)K.t;
                // ...and this state's own tick for this box. The line above is
                // level-wide and first-entry-only, so it cannot tell two
                // worldlines apart; this can.
                c.fireB[b] = (uint16_t)K.t;
                // --touchcensus: which test admitted this entry. "y" = the
                // player's y this tick overlaps; "preY" = only the y passed in
                // as preY does (the callers pass the parent state's y).
                if (g_touchCensus) {
                    const bool yHit = std::fabs((double)c.y - T->cy) < T->hh + half;
                    std::printf("tcensus: t=%lld box=%d uid=%d hit=%s mode=%d mini=%d "
                                "x=%.3f y=%.3f preY=%.3f vy=%.3f br=%d\n",
                                (long long)K.t, b, T->uid, yHit ? "y" : "preY",
                                (int)c.mode, (int)c.mini, (double)c.xAbs, (double)c.y,
                                preY, (double)c.vy, g_tcBranchP1);
                }
            }
            if (g_slopeDbg)
                std::printf("trigfire t=%lld box(%.1f,%.1f) %.0fx%.0f "
                            "player(%.1f,%.1f) half=%.1f mask=0x%llx\n",
                            (long long)K.t, T->cx, T->cy, 2 * T->hw, 2 * T->hh,
                            (double)c.xAbs, (double)c.y, half,
                            (unsigned long long)c.trig.word(0));
        }
    }
}

}  // namespace dp

